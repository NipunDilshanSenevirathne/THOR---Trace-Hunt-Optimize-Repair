---
description: Review the engagement's safety boundary before a long run
---
Run `thor budget`, then `thor risk`, then `thor identity list`.

These three together are the engagement's safety posture, and they are worth
one minute before an overnight run:

- **budget** — the request ceiling, rate limit and concurrency cap are
  engagement-wide and shared by every engine, and the counter survives
  restarts. Check the remaining budget against what the run will need. A
  program's published rate limit is a term of the authorisation, not a
  courtesy, and "my scanner had a bug" is not a defence anyone accepts.
- **risk** — which engines the scope permits, and which are declared but
  not implemented. Tell me if an engine I am relying on is gated off, and
  whether raising the ceiling is something the program's policy actually
  permits. Do not suggest raising it just because it would find more.
- **identity list** — any UNRESOLVED identity means the vault cannot produce
  its credentials. That is fatal on purpose: probes sent without an
  Authorization header come back 401 and get recorded as `denied`, which
  reads as a well-secured application when nothing was tested.

Then tell me three things:

1. Whether the budget is sufficient for the planned run, and if not, what to
   cut — narrower corpus, fewer engines, or a smaller identity matrix.
2. Whether the testing window and timezone match what the program published.
3. Anything in the scope file that looks copied from a different engagement:
   a stale `notes` block, hosts that are not in this program, a
   `destructive: true` left over from a lab.

Do not suggest widening the scope. If something is out of scope, the answer
is to leave it out.
