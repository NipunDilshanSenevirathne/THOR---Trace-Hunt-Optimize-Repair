---
description: Review proposed attack chains and whether their links support them
---
Run `thor chain candidates --corpus $ARGUMENTS`.

A chain is a severity-escalating claim, so it needs more evidence than a
single finding, not less. THOR will only turn a proposal into a finding when
every link has itself reached VERIFIED, and the chain's severity is the
highest among its links — never the severity the proposer asked for,
including when the proposer is you.

For each proposal, judge two things the code cannot:

1. **Is the transition real?** The rules connect findings by class and
   route. They cannot tell whether step one genuinely puts the attacker in
   a position to perform step two. Say plainly which proposals are two
   unrelated bugs that happen to share a host — that is the common case,
   and reporting it as a chain damages credibility more than the bugs earn.
2. **Is the combined impact more than the sum?** If the chain's impact is
   "both of these bugs exist", it is not a chain. A chain is worth reporting
   when the combination reaches something neither link reaches alone.

For anything blocked, the reason is printed. If a link is not yet VERIFIED,
say what evidence would get it there; do not suggest lowering the bar.

You may propose new chains I have not considered, with
`thor ai brief --kind chains`. They go to the same gate — a proposal is not
a finding, and the model's severity is discarded in favour of the links'.

Do not claim any chain is exploitable. You are reviewing whether the
proposal is worth the verification effort.
