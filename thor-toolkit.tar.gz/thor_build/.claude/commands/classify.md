---
description: Classify which captured parameters name owned objects
---
Run `thor ai brief --kind classify --corpus $ARGUMENTS`, read `briefs/classify.md`,
and answer it.

The heuristic classifier catches the obvious ones (`user_id`, `orderId`, UUIDs in
paths). You are here for the app-specific cases it cannot know: a parameter called
`ref` or `k` that is actually a tenant key, or an `id` that is really a pagination
cursor.

Flag tenant/organisation scope keys explicitly. Those are the highest-value
targets — a single swap can cross an entire customer boundary.

Write to `answers/classify.json`, then `thor ai apply --kind classify --file answers/classify.json`.
