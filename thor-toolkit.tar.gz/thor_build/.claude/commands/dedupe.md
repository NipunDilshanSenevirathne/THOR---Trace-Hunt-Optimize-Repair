---
description: Check findings against the program's public disclosures
---
For each finding from `thor findings`:

1. Run `thor evidence <id>` and read `finding.json` for the route shape and class.
2. Search the program's Hacktivity / public disclosure list for the same
   vulnerability class on the same asset or route shape.
3. Judge whether a disclosed report covers the same *root cause*, not just the
   same endpoint. Two IDORs on different controllers are two bugs; two IDORs on
   the same controller with different ids are one.

On mature programs duplicates cost more income than false positives do. A finding
that is probably a duplicate is worth saying so about before you spend an hour
writing it up.

Report: for each finding, `unique` / `likely duplicate` / `uncertain`, with the
disclosure link where relevant.
