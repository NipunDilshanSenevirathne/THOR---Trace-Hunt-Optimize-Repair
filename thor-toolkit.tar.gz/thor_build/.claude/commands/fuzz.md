---
description: Design app-specific fuzzing grammar for business-logic fields
---
Run `thor ai brief --kind fuzz --corpus $ARGUMENTS`, read `briefs/fuzz.md`, answer it.

The executor already covers, automatically and for free: SQLi boolean pairs and
error probes, SSTI arithmetic, NoSQL operators, path traversal, SSRF, XSS context
probes, type confusion, and negative/overflow numbers on money-tagged fields.
Do not restate any of that.

You are here for the fields whose *business meaning* the schema cannot infer.
For each, name the invariant the application probably enforces, then values that
would violate it while staying structurally valid enough to reach the logic.

The `oracle` field is the important one: name a checkable response change. "The
response looks wrong" is not an oracle. "The `total` field returns a negative
number" is. If you cannot name one, say so — the field gets skipped rather than
fuzzed blindly.

Flag destructive fields (deletes, sends mail, charges money) so they are excluded.

Write to `answers/fuzz.json`, then `thor ai apply --kind fuzz --file answers/fuzz.json`.
