---
description: Review the hypothesis ledger — what is open, what died, and what it cost
---
Run `thor hypotheses --corpus $ARGUMENTS`.

THOR is hypothesis-native: the loop does not run engines in a fixed order, it
opens falsifiable hypotheses, scores each by information gain

    (uncertainty × boundary_weight × novelty × coverage_deficit)
    ────────────────────────────────────────────────────────────
                     (cost × risk_penalty)

executes the highest-scoring one as a planned experiment, and judges the
outcome against the invariant the hypothesis names. Confirmed or disproved,
the result updates the Beta posterior for that arm, so the next selection is
better informed. Gains are recomputed every round — a hypothesis that looked
strong can fall sharply once real cost data arrives.

Read the ledger and tell me three things:

1. **Which open hypotheses are not actually falsifiable.** If the predicted
   observation is vague enough that any response could be read as support, it
   will burn budget forever. Name them and say what specific observation would
   kill each one.
2. **What the disproved set implies about the application.** A cluster of
   disproved authz hypotheses across one route family is itself information —
   usually that the boundary is enforced somewhere you have not modelled.
   Say what that suggests looking at instead.
3. **Whether the arm statistics look like signal or noise.** Under roughly ten
   trials, a posterior mean is not evidence of anything. Say so rather than
   reading a trend into four samples.

If you think an entire boundary is missing from the catalogue, say which one
and which engine could falsify it — that is a change to `invariants.CATALOGUE`,
and it needs a named falsifier or it does not go in.

Do not claim any vulnerability exists. You are reviewing the plan, not the
target.
