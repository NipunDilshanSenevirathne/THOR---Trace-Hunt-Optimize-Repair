---
description: Write impact sections for confirmed findings
---
Run `thor ai brief --kind impact`, read `briefs/impact.md`, and answer it.

Every finding in that brief is ALREADY CONFIRMED by response diffing. Do not
re-litigate whether the bug is real — that question is settled by bytes.

Your job is the impact section a triager needs. Stay bounded by the evidence:
if the evidence shows one record leaking, do not write "full database exposure"
unless enumeration was actually demonstrated. Overclaiming impact is the fastest
way to get a valid report closed as spam.

If the evidence does not support meaningful impact, set `submit: false` and say
why. That is a useful answer, not a failure.

Write to `answers/impact.json`, then `thor ai apply --kind impact --file answers/impact.json`.
