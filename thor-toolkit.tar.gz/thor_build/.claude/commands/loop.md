---
description: Run the autonomous research loop, then act on its checkpoints
---
Run `thor loop --corpus $ARGUMENTS --minutes 120`.

The loop is deterministic and costs no tokens — it models, hypothesises,
Thompson-samples an engine order, experiments, judges with oracles, and learns,
for as long as its budget allows. Do not babysit it.

When it finishes it prints AI checkpoints: the specific places where a prompt
buys something code cannot. Work through those in the order it lists them,
and tell me which you ran.

Then report: findings before vs after, which root causes were identified, and
the single highest-value thing to do next. Keep it short.
