---
description: Review the application model and the ranked hypotheses
---
Run `thor reason --corpus $ARGUMENTS`.

Read the APPLICATION MODEL and SECURITY BOUNDARIES sections first. Tell me
whether the model looks right — missing tenants, identities that should exist,
boundaries the app clearly has that the catalogue does not cover.

Then judge the top three hypotheses. For each: is the falsifier actually cheap
to check, and is the predicted outcome specific enough to be wrong? A
hypothesis that cannot be killed in fifteen minutes is a time sink regardless
of its gain score.

Do not claim any vulnerability exists. You are reviewing the plan.
