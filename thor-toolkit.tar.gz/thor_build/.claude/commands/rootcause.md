---
description: Review root-cause groups before writing any reports
---
Run `thor rootcause`.

For each group, judge whether the proposed shared defect is the most economical
explanation for all its members, or whether it has over-merged findings that
happen to share a prefix.

This matters commercially: twenty IDORs behind one broken middleware submitted
separately means nineteen duplicates and an annoyed triager. The same twenty as
one report with twenty manifestations is a bigger finding than any of them alone.

For each group tell me: merge as one report, split, or needs more evidence to
decide — and for splits, which members do not belong.
