---
description: Review source ↔ runtime correlations
---
Run `thor source correlate --corpus $ARGUMENTS` and read the output.

For each correlation, judge whether the disagreement is real:

- **unguarded** — is the sibling comparison fair, or do those siblings guard
  something structurally different?
- **unscoped_sink** — does the scoping happen somewhere the regex cannot see
  (a base controller, a global middleware, an ORM default scope)?
- **guard_mismatch** — this one has runtime evidence. Treat it as real unless
  the route is genuinely meant to be public.

Source findings are hypotheses with a strong prior, not findings. Tell me
which ones justify a runtime experiment and what that experiment should be.
