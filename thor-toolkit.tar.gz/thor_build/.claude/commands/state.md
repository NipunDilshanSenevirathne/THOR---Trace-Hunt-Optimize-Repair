---
description: Review the finding lifecycle and why findings are stuck at a gate
---
Run `thor state --corpus $ARGUMENTS`.

Every finding moves through a fixed lifecycle:

    observed → hypothesis → candidate → verification_required
            → verified → deduped → report_ready → submitted

Each transition has a deterministic gate — evidence exists, an oracle fired, a
control was actually executed, scope was proven, the bundle replays, dedupe
ran, impact was written by a human. The gates are code, not judgement, and you
cannot move a finding past one. Neither can I: the database aborts any write
to `status`, `severity`, `disproof_done`, `evidence_ids`, `fingerprint`,
`vuln_class`, `route` or `asset` that comes from the AI actor.

What I can usefully do here is read the blocked list and tell you **which gate
is failing and what the cheapest way to satisfy it is** — usually one more
experiment, an OAST callback that never arrived, or a control request that was
planned and never sent.

For anything sitting at `verification_required`, say plainly whether the
missing evidence is obtainable at all on this target. A finding that cannot
clear its gate is not a finding you should report; it is one you should either
finish or drop, and saying which is the point of this command.

For anything at `report_ready`, the impact line still marked `[auto]` is a
placeholder — it must be replaced with your own words before submission, and
I will not overwrite it for you.

Do not claim any vulnerability exists, and do not suggest changing a gate.
