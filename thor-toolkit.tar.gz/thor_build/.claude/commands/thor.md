---
description: Full pipeline status and next action
---
Run `thor status`, `thor findings` and `thor invariants`.

Then tell me, in order of what will produce a paid report soonest:
1. Which pipeline stage is the bottleneck right now.
2. Which security invariants are still untested, and why (missing identity? missing capture? risk gate?).
3. The single next command to run.
4. Anything in the findings list that is missing its disproof (`!` marker) —
   those must not be submitted until `thor authz` has run with an `anon`
   identity configured.

Keep it to a few lines. Do not re-explain the architecture.
