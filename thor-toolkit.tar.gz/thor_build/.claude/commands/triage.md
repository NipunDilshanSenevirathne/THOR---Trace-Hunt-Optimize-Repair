---
description: Answer the target-selection brief and apply it
---
Run `thor ai brief --kind triage --top 15`, read `briefs/triage.md`, and answer it.

The ranking you are given is deterministic — it comes from measurable facts about
each host relative to its siblings, not from a model. Your job is to choose where
manual hours go, not to re-score.

For each pick, the `kill_criterion` matters more than the `why`: name the single
observation that would let me abandon the hypothesis in under 15 minutes. A pick
with no cheap kill criterion is a time sink.

Do not claim any vulnerability exists.

Write your answer to `answers/triage.json` in the schema the brief specifies, then
run `thor ai apply --kind triage --file answers/triage.json`.
