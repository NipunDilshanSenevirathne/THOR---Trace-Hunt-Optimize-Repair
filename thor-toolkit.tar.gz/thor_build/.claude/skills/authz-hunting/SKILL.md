---
name: authz-hunting
description: Methodology for finding authorization flaws (IDOR, BOLA, BFLA, tenant isolation) on authorised web application targets using THOR. Use when hunting access-control bugs, setting up multi-identity capture, or judging whether a cross-identity response difference is a real finding.
---

# Authorization hunting

The highest-value, most duplicate-resistant bug class on mature programs.
Generic scanners miss it because finding it requires authenticated
multi-account state they never set up.

## Set up identities before capturing anything

You need a minimum of three, ideally five:

| identity | why it matters |
|---|---|
| `userA` | the owner — provides the baseline response |
| `userB` | **a different tenant/org, not just a different user** |
| `admin` | for vertical escalation testing in reverse |
| `anon` | the disproof. Without it every finding is unprovable |
| `support` | if the app has a limited-privilege role, it is often the leakiest |

`userB` in the same organisation as `userA` is the most common setup mistake.
Many apps scope correctly at the org boundary and sloppily within it, or the
reverse. Two separate tenants tests the boundary that actually matters.

## Capture: browse, don't crawl

Twenty minutes clicking through the app as each identity beats a day of
crawling. Crawlers cannot reach multi-step flows — checkout, invitation,
role change, export — and those are where the logic bugs live.

Exercise deliberately:
- every "view detail" from a list
- every export, download, invoice, report
- every settings page, including ones you expect to be denied
- invitation and role-change flows
- anything that names another user or object

## What to swap, in order of value

1. **Tenant/org scoping headers** — `X-Organization-Id`, `X-Tenant`,
   `X-Account-Id`. One swap crosses a whole customer boundary. Highest value
   by a wide margin and routinely unprotected because it is "internal".
2. **Nested JSON object references** — deeply nested ids get authorised at
   the top level and trusted underneath.
3. **Path ids** — the classic. Also the most likely to be already reported.
4. **Query params** — check whether a value is an object id or pagination
   before swapping.

## Judging a response difference

Run `thor authz` and it does this deterministically. When judging manually,
in descending order of strength:

**Strong evidence of a leak**
- Owner-specific *values* (an email, an address, a total) appear in the
  other identity's response
- PII field names populated in a cross-identity response
- Identical JSON type-and-key shape plus near-identical byte length

**Weak or misleading**
- Status 200 alone — plenty of apps return 200 with an empty or generic body
- Similar length alone — templating makes unrelated pages similar
- Timing — noisy over the internet, especially behind a CDN

**Disqualifying**
- The anonymous request returns the same resource. It is public data. Not a
  finding. `thor authz` checks this automatically; never skip it.

## Escalating beyond a single record

A single-record IDOR is a medium. What turns it into a critical:

- **Enumeration** — sequential ids mean the whole table. Demonstrate with
  two or three ids, never by scraping the dataset. Pulling real user data at
  scale is harmful and can breach the program's own rules.
- **Write, not just read** — can you PUT or DELETE the object too? Run
  `thor bfla`.
- **Privilege change** — does the object control access (role, permission,
  membership)? Run `thor massassign`.
- **Chaining** — an id disclosed in one response feeding an IDOR in another
  is a higher finding than either alone.

## Before submitting

1. `thor findings` — the finding must show `✓`, meaning the disproof ran.
2. `thor evidence <id>` — check `replay.sh` actually reproduces.
3. `/dedupe` — check the program's disclosures for the same root cause.
4. `/impact` — bound the claim to what the evidence shows. Do not write
   "full database compromise" for one leaked record.

## Scope discipline

- Never test an account you do not control.
- Never pull more of another user's data than proves the point.
- If `destructive: false` in `scope.yaml`, do not reach for DELETE.
- A scope refusal is an answer, not an obstacle to route around.
