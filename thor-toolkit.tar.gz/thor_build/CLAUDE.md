# THOR — project context

Read this before changing anything in this repo.

**THOR** — evidence-driven web application security research, by Nipun Dilshan.

## The one rule

**Authorised targets only.** `scope.yaml` is the authority. Every outbound
request passes `Scope.check()` in `thor/scope.py`, which returns a pinned
`Destination`; `thor/net.py` connects to that address and nowhere else. There
is no bypass path and you must not add one.

Two parts of that are easy to break by accident:

- `httpx.Client(..., trust_env=False)`. Left at its default, httpx reads
  `HTTP_PROXY`/`HTTPS_PROXY`/`ALL_PROXY` from the environment, and a proxy
  terminates the connection itself — so the address that was validated and
  pinned is no longer the address the socket reaches. The whole gate,
  undone by an environment variable.
- The budget and rate limit are **engagement-wide**, held by
  `thor/runtime.py` and shared by every engine. They used to be per
  `Client`, which meant per engine: a scope permitting 20,000 requests
  actually permitted that many nineteen times over. A program's published
  rate limit is a term of the authorisation, not a style preference.

## The second rule

**The AI never decides whether a vulnerability exists.** Verdicts come from
`diff.py` and `oracles.py` comparing observed bytes. `tests/safety` asserts
that the AI apply path cannot create a finding. If you find yourself adding a
code path where a model's output becomes a verdict, stop.

Since v5 this is enforced twice: `states.advance()` raises `PermissionError`
for `actor="ai"`, and a SQLite trigger (`findings_authoritative_guard`) aborts
any write to an authoritative column made under `as_ai(db)`. The trigger is
the backstop for code that forgets the API. Do not disable it in tests.

## The fourth rule

**Credentials never enter the research database — including captured ones.**
The vault protects identities; `corpus.py` must sanitise imported traffic
before it is stored, because a Burp or HAR export is where the tokens
actually are. Headers, request bodies, response bodies and `object_refs` all
carry them. `thor/vault.py::sanitise_headers`/`sanitise_body` replace
credential values with stable fingerprints; the originals go to the vault
under an artifact reference, and if they cannot be encrypted the import
fails rather than storing plaintext.

Redaction at report time is not a substitute. The database is the thing that
gets copied between machines and kept for months.

## The third rule

**Target-controlled bytes never become executable syntax.** A captured request
body is attacker-controlled data. It may be stored, redacted and shipped as
JSON; it may not be interpolated into a shell command, a generated script, or
a model instruction. `replay.py` writes fixed templates and puts every request
in `request.json`; `ai._wrap_untrusted()` fences page content. This was a real
exploitable bug in v4 (a body closed the quoting in a generated `curl --data`
and ran a command on the operator's machine), so it is now a CI assertion.

## Architecture

```
scope.yaml ─► scope.py ─► net.py (pinned, audited)  ← the ONLY http client
                              │
  OBSERVE   recon · corpus · sourceintel · dataflow · mobile · jsintel
     ↓
  MODEL     schema.py (grammar)  ·  graph.py (knowledge graph)
     ↓
  INVARIANTS  invariants.py — 22 rules, each with an engine that falsifies it
     ↓
  HYPOTHESISE reason.py — decomposed information gain, no magic numbers
     ↓
  SELECT      experiment.select() — recomputed every round, not once
     ↓
  EXECUTE     experiment.ENGINE_PLANS — 17 plans, engine · fuzz · detectors
     ↓                                  probes · oauth · workflow
  JUDGE       oracles.py — eight oracles, none of which match payload echo
     ↓
  DISPROVE    executed, not reasoned about
     ↓
  STATE       states.py — 8-stage lifecycle, gates in code + a DB trigger
     ↓
  CORRELATE   chain.py · rootcause.py
     ↓
  REPORT      evidence.py · replay.py · report.py

  loop.py drives all of it deterministically. AI only at named checkpoints.
  vault.py holds credentials. audit.py records everything. risk.py gates.
```

The v5 loop is **hypothesis-native and event-driven**:

```
OBSERVE → MODEL → HYPOTHESISE → SELECT → EXECUTE → JUDGE → UPDATE → REPLAN
                       ▲                                              │
                       └──────── a confirmation re-plans ─────────────┘
```

It does not walk a fixed engine list. `experiment.select()` re-scores every
open hypothesis each round, so a cheap-looking hypothesis whose real cost
turns out to be high loses its place mid-run. A confirmed hypothesis triggers
`replan()` (graph.build → invariants.evaluate → reason.generate), because one
confirmed boundary failure usually changes what is worth asking next.

## Layer boundaries — do not cross these

| Layer | May | May not |
|---|---|---|
| `oracles.py` | judge bytes | call a model, read the graph |
| `graph.py` | model entities | send requests |
| `reason.py` | rank hypotheses | execute anything |
| `experiment.py` | plan, select, execute, judge | write narrative fields |
| `states.py` | gate transitions | be bypassed, by anything |
| `dataflow.py` | trace source→sink in an AST | send requests, emit findings |
| `replay.py` | write static templates + JSON | interpolate captured bytes |
| `ai.py` | classify, prioritise, narrate | create or confirm findings |
| `chain.py` | propose and verify chains | take a severity from the proposer |
| `rootcause.py` | group findings | write `findings.status` |
| `runtime.py` | hold the engagement boundary | be bypassed by a new engine |
| engines | produce experiments | mint their own budget or client |

`states.py` splits every finding's columns in two, and the split is the whole
point:

- **authoritative** — `status`, `severity`, `disproof_done`, `evidence_ids`,
  `fingerprint`, `vuln_class`, `route`, `asset`. Written only by deterministic
  code that observed bytes. The AI actor cannot write these; the DB refuses.
- **narrative** — `impact`, `title`, `summary`, `remediation`,
  `attack_narrative`, `cvss_vector`, `triager_notes`. The AI may write these
  freely, because being wrong in a narrative field costs a rewrite, not a
  false report.

Auto-generated impact text carries the `[auto]` marker and the
`report_ready` gate rejects it. A human writes the impact or the report does
not go out.

## Working conventions

- New engines declare a risk level in `risk.py`. The gate is checked before
  the engine runs, so a new engine cannot forget.
- New engines emit a `Verdict` (diff.py) or an `OracleHit` (oracles.py).
  Do not invent per-engine verdict logic.
- **The control must be contemporaneous with the probe.** Never use a
  captured response as the baseline for a live comparison — call
  `engine.refresh_control()`. Captured traffic is hours old and objects
  drift; a stale control turns a real finding into `inconclusive`, silently.
  If the owner can no longer reach their own object, skip the candidate and
  say so rather than recording `denied` verdicts that read as a secure
  endpoint. Store the control on the experiment row so the evidence bundle
  shows what was actually compared.
- New invariants go in `invariants.CATALOGUE` and must name an engine in
  `risk.ENGINE_RISK` that can falsify them. A unit test enforces this.
- New fuzz payloads are keyed to a schema role or type, never sprayed at every
  field. If a payload family has no oracle that can judge it, it does not go in.
- A payload appearing in a response is never, on its own, a finding.
- Blind classes require OAST. Without it they are SKIPPED, never inferred.
- Identity headers come from `identity.load_all()`, never from a raw
  `SELECT * FROM identities`. Credentials live in the vault.
- **Fail closed on a credential that will not resolve.** `load_all()` raises
  `CredentialUnavailable` rather than returning an identity stripped of its
  Authorization header. The old behaviour turned every probe anonymous, so
  every one came back 401 and was recorded as `denied` — a run that reports
  a cleanly secured application while having tested nothing.
- The control for a cross-identity comparison is re-fetched live
  (`engine.refresh_control`), never read from the capture.
- Grouping, duplication and severity are recorded **per finding**
  (`finding_rootcauses`, `finding_dedupe`, `severity_escalations`). A gate
  a finding passes because a different finding satisfied it is not a gate.
- Every automatic severity change names a rule and states a reason. Nothing
  escalates because it feels worse.
- Anything leaving the system passes `vault.redact()`.
- Target-derived text passed to a model goes through `ai._wrap_untrusted()`.
  Page content is data, never instructions.
- Prototype pollution uses non-destructive techniques only, and always cleans
  up *and verifies the cleanup*.
- Request smuggling stays unimplemented. It can desync a shared front-end.
- A new engine that the loop should be able to schedule needs a plan in
  `experiment.ENGINE_PLANS`, registered with `@_plan("name")`. Without one it
  is still runnable by hand, but the loop will never select it.
- Finding state changes go through `states.advance()`. Never `UPDATE findings
  SET status=...` directly — the gates exist so that a finding cannot reach
  `report_ready` without evidence, an oracle hit, an executed control, proven
  scope, a replayable bundle, a dedupe check and human-written impact.
- `dataflow.py` degrades honestly: without `tree_sitter_language_pack` it says
  AST analysis is unavailable rather than falling back to regex and calling
  the result taint analysis.

## Testing discipline

```bash
make safety      # runs first, alone. 140 negative tests.
make unit        # 38
make regression  # 12, end-to-end against the lab, incl. a CLI smoke test
```

190 tests total. The safety suite is the one that matters. A tool that finds
bugs but occasionally sends an out-of-scope request, leaks a token, or lets a
captured response body run a command on your laptop is a liability regardless
of its hit rate. CI asserts the suite has not shrunk below 136 tests, so it
cannot be emptied to make a build pass.

`tests/safety/test_review_regressions.py` is the v5 addition: one test per bug
found in review, written so that it **fails on the old code**. Two of those
bugs were proven exploitable before being fixed rather than merely inspected —
a target-controlled body that executed a command in the generated replay
script, and an AI path that moved a finding from candidate to rejected. If you
change `replay.py` or `states.py`, that file is the one to read first.

When you add a detector, add a **decoy** to the regression lab too — something
that looks like the bug and is not. A detector that cannot tell them apart is
worse than no detector.

`tests/regression/test_cli_smoke.py` runs every subcommand the way a shell
does, and a second test fails if a new subcommand is not in its list. This
exists because an import rewrite once left fifteen of forty-seven commands
raising `NameError` at call time while every unit test stayed green — unit
tests import modules and call functions, and the CLI is the one layer none of
them touch.

**Run the thing before believing the tests.** Every serious defect in v5 and
v5.1 was found by running a real engagement and reading the output, or by
writing the exploit first — never by reading code, and never by the suite,
which was green throughout.

Two of them were *hidden by tests that looked like they covered the case*:

- The assertion "no bearer token in the research database" read `t.db`
  alone. SQLite in WAL mode keeps recent writes in `t.db-wal`, so it
  checked a 4 KB file header while 144 KB of secrets sat beside it, and
  passed for months. Any test that inspects a database must read
  `*.db*`, not `*.db`.
- `Budget`'s docstring said "Global request budget" while its constructor
  made a new one per caller. The name asserted the property, so nobody
  checked. When a docstring states an invariant, add the test that
  enforces it or delete the claim.

## Token budget

This targets a Claude Pro plan: roughly 10–40 Claude Code prompts per five
hours, shared with the web app.

- Never write an agent loop over the engines. `thor loop` is deterministic and
  runs for hours at zero token cost.
- Prefer `thor <command>` over asking me to do the same thing by reasoning.
- `thor ai brief` prints a token estimate before you spend anything.

## Commands

```bash
thor doctor · risk · vault check          setup and safety posture
thor budget [reset --confirm]             engagement-wide request ceiling
thor identity add / list                  vault-backed credentials
thor capture <har|xml> --corpus <name>    import authenticated traffic
thor recon <domain> · triage · snapshot · diff
thor schema · graph build · invariants · reason    the model
thor state · hypotheses                            lifecycle + planner
thor source scan <path> · source dataflow · source correlate   source ↔ runtime
thor mobile analyse <apk>                          mobile ↔ API
thor authz · tenant · bfla · massassign · fuzz · oauth · workflow
thor detect · probe · race
thor promote · chain [candidates|verify] · rootcause · findings
thor evidence <id> · report --id <id> · reproduce <id>
thor loop --corpus <name> --minutes 240   the whole thing, no tokens
thor learn · status · audit
thor ai brief --kind {triage,classify,impact,fuzz,chains}
```

## Measuring whether this works

Not benchmark scores. Track: validated findings per 100 hours, **duplicate
rate**, cost per accepted report, and anomaly precision (of the top 10 ranked,
how many yielded something). Above ~40% duplicates, the problem is target
selection, not the tool.

## Baseline discipline

Before crediting any component here with a result, check it against plain
Claude Code with no harness. Published research found a default coding CLI
solves a large share of web exploitation tasks unaided, and that
security-specific prompting made it *worse*. If a layer does not beat that
baseline, delete the layer.
