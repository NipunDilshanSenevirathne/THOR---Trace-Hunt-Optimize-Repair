# THOR

**Evidence-driven web application security research**
by Nipun Dilshan

Authorised targets only.

---

THOR does not think in requests, endpoints and scanners. It builds a model of
the application — identities, tenants, objects, workflows — states the
security invariants that model implies, and then tries to falsify them.

A finding is what survives that.

```
                    OBSERVE                    corpus, recon, source, mobile
                       ↓
                     MODEL                     knowledge graph
                       ↓
              SECURITY INVARIANTS              what should hold
                       ↓
                  HYPOTHESES                   what could fail
                       ↓
             INFORMATION-GAIN RANK             what to test first
                       ↓
                 EXPERIMENT                    scope-gated, pinned, audited
                       ↓
              DETERMINISTIC ORACLES            bytes, not opinions
                       ↓
                 DISPROOF                      executed, not reasoned
                       ↓
              LIFECYCLE GATES                  code, not judgement
                       ↓
        ROOT CAUSE · CHAINS · EVIDENCE
                       ↓
                    REPORT
```

That column is a loop, not a pipeline. A confirmed hypothesis re-enters at
MODEL, because one proven boundary failure usually changes which of the
remaining questions is worth asking.

---

## The rule everything else follows from

**The AI never decides whether a vulnerability exists.**

Verdicts come from `diff.py` and `oracles.py` comparing observed bytes. The
model classifies parameters, ranks targets, and writes impact prose from
confirmed evidence. It has no path to creating a finding — `tests/safety`
asserts this directly.

This is not fastidiousness. Apple throttled bug bounty submissions over
AI-hallucinated reports; curl ended payments when legitimate reports fell
below 5%; GitHub moved some payouts to swag. A tool that cannot produce an
unproven finding is the only kind worth running.

---

## Install

```bash
pip install -e ".[dev]"
make safety              # 140 negative security tests — run these first
thor doctor              # lists missing recon tools with install commands
```

`[dev]` includes tree-sitter, which AST data-flow analysis needs. For a
runtime-only install:

```bash
pip install -e ".[ast,keyring]"
```

Without tree-sitter, `thor source scan` still extracts routes and says
plainly that data-flow was skipped. It does not fall back to regex and call
the result taint analysis.

Recon tools (all optional; `thor doctor` prints these):

```bash
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest
go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest
go install -v github.com/projectdiscovery/katana/cmd/katana@latest
go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest
go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest
go install -v github.com/projectdiscovery/alterx/cmd/alterx@latest
go install -v github.com/projectdiscovery/interactsh/cmd/interactsh-client@latest
go install -v github.com/lc/gau/v2/cmd/gau@latest
pipx install uro arjun
```

No amass — `subfinder + crt.sh + alterx + dnsx` covers the same ground in
minutes rather than hours.

---

# The safety boundary

THOR's scope gate is treated as a security boundary of the tool itself, not
as a configuration convenience.

## Destination pinning

`Scope.check()` resolves once, validates **every** returned address, and
returns a `Destination`. `net.py` then connects to *that address* while
preserving the Host header and TLS SNI. There is no second resolution, so
there is no time-of-check-to-time-of-use window.

A record set mixing public and private addresses is refused outright — that
pattern is the signature of a rebinding attempt, not a legitimate answer.

Also refused, because each is a documented way past a naive allowlist:

| | |
|---|---|
| `https://example.com.evil.com/` | suffix-append |
| `https://example.com@evil.com/` | userinfo confusion |
| `http://2130706433/` `0x7f000001` `0177.0.0.1` | encoded loopback |
| `http://[::ffff:169.254.169.254]/` | IPv6-mapped metadata |
| punycode / IDNA homographs | normalised before matching |
| every redirect hop | full re-check before it is followed |

## One engagement boundary, not one per engine

```bash
thor budget
```

```
engagement     acme-public
requests       1284 / 20000   (18716 left)
rate limit     3 rps, engagement-wide
concurrency    4, engagement-wide
window         22:00-05:00 Asia/Colombo
```

Every engine reaches the same budget, rate limiter and concurrency
semaphore, through `thor/runtime.py`. They used to build their own: each
`Client(scope)` did `Budget(scope.max_rps, scope.max_requests)`, so a scope
file permitting 20,000 requests permitted that many **per engine** —
nineteen times over — and `max_rps: 3` became 3 rps each.

The `Budget` docstring said "Global request budget" the whole time. The name
asserted the property, so nobody checked the constructor.

A program's published rate limit is a term of the authorisation, not a
courtesy. The counter is persisted, so it survives restarts too: running
`thor loop` four times used to send four budgets' worth against a program
that authorised one. Clearing it is deliberate:

```bash
thor budget reset --confirm
```

Testing windows are evaluated in `window_timezone`, not in whatever the
laptop is set to — and an unrecognised timezone falls back to UTC rather
than to local time, so a typo cannot silently shift a contractual window.

---

## Credentials never touch the research database

```
identities table  ──►  credential_ref (cred_a1b2c3…)
                              │
                              ▼
                   encrypted vault (Fernet)
                   key from OS keyring, passphrase, or THOR_VAULT_KEY
```

`vault.redact()` runs on every path out: evidence bundles, reports, AI
briefs, audit log. The fingerprint is stable, so two records using the same
token stay correlatable without the token being present.

If `cryptography` is missing the vault **refuses to store** rather than
silently writing plaintext.

### Captured traffic is where the credentials actually are

Vaulting identities was the easy half. A Burp or HAR export carries the same
bearer token, plus the session cookie, plus whatever password was posted to
`/login` — and `corpus.py` wrote all of it straight into `requests`. Four
columns leaked: headers, request body, response body, and `object_refs`,
which treated `password` as an object identifier and stored its value (and
would have tried swapping it between identities as an IDOR test).

So the import sanitises before it stores:

```
requests table          vault
  headers   <vaulted:a4dc…>    ──►  the original headers
  body      {"password":"<vaulted:3c78…>"}   the original body
  resp_body sanitised           ──►  the original response
  body_sha256 / resp_sha256     hashes of the ORIGINAL, so a replay can
                                still prove it reproduced the request
```

Structure survives: object references, business fields and response shapes
are untouched, so schema inference and differential comparison work exactly
as before. Only credential *values* change, to a stable fingerprint, so two
requests carrying the same session still correlate. If the originals cannot
be encrypted, **the import fails** rather than storing them in the clear.

Redaction on the way out is not a substitute for this. The database is the
thing that gets copied between machines, attached to reports and kept long
after the engagement ends.

There was a test asserting none of this leaked. It read `t.db` and checked
the token was absent. SQLite in WAL mode keeps recent writes in `t.db-wal`,
so it inspected a 4 KB file header while 144 KB of secrets sat beside it,
and passed for months. Every test here reads `*.db*`.

### A credential that will not resolve stops the run

If the vault is locked or a reference is missing, `identity.load_all()`
raises rather than returning an identity without its Authorization header.

The old behaviour was worse than a crash. `userA`, `userB` and `anon` all
collapsed into the same credential-free identity; every probe went out
unauthenticated, every one came back 401, and each was recorded as
`denied`. The run reported a cleanly secured application, having tested
nothing, and said so with complete confidence.

## Risk gate

Every engine declares a level; `scope.yaml` sets the ceiling; the gate is
checked *before* an engine runs so a new engine cannot forget.

```
thor risk
  ✓ SAFE         authz graphql cors pathacl redirect tenant sourcemap
  ✓ ACTIVE       fuzz jwt oauth cache protopollution websocket
  ✗ SENSITIVE    bfla massassign workflow upload
  ✗ DESTRUCTIVE  race smuggling
```

`sensitive: true` does not imply `destructive: true`. Request smuggling is
declared DESTRUCTIVE and deliberately **not implemented** — it can desync a
shared front-end and affect other users.

## Audit trail

Every request, every scope refusal, every engine decision, one JSON object
per line, credentials redacted.

```bash
thor audit           # summary, including refusals
thor audit --tail 50 # raw records
```

If a program asks what you did, the answer is a file.

---

# The intelligence layer

## Knowledge graph

```bash
thor graph build --corpus prod
```

```
Tenant: acme
   ├── Identity: userA
   │      └── Role: BillingUser
   │      └── accesses invoice:5001
   └── Object: invoice:5001
          └── via GET /api/billing/invoices/{id}
```

A property graph in SQLite — not Neo4j, because tens of thousands of nodes on
a laptop do not justify a second datastore. Every edge carries the request ids
that justify it.

This is what turns *"parameter named id looks interesting"* into *"invoice
5001 is scoped to Acme, Bob belongs to Globex, and the endpoint derives the
tenant from a client-supplied header"* — a hypothesis with a predicted outcome
rather than a guess.

## Security invariants

```bash
thor invariants
```

22 rules across authorization, tenancy, workflow, token, injection, egress,
integrity, cache and navigation. Each states a rule, the engine that can
falsify it, and its preconditions.

```
TENANCY
  ✗ tenancy.isolation              violated   critical
        rule: caller.tenant == object.tenant
        at:   https://api.target/api/billing/invoices/{id}
  ✓ tenancy.server_derived         holds      critical
AUTHORIZATION
  · authz.field_level              untested   high
```

An invariant that **holds** is useful information, not a null result: it tells
the scheduler the control exists and stops it retrying.

## Reasoning

```bash
thor reason --corpus prod
```

```
APPLICATION MODEL
────────────────────────────────────────────────────────────
    12 identities     3 roles         2 tenants
     9 assets       184 endpoints    71 object-bearing
   340 objects      612 parameters   19 workflows (7 states)

SECURITY BOUNDARIES
────────────────────────────────────────────────────────────
  tenancy          1 violated, 1 hold
  authorization    2 hold, 3 untested
  workflow         3 untested

OPEN HYPOTHESES  (ranked by information gain)
────────────────────────────────────────────────────────────

H-001
X-Org-Id may override server-derived tenant identity rather than
being ignored

Evidence:
  parameter X-Org-Id observed on GET /api/billing/invoices/{id}
  type string, seen 14x
  tenant-specific responses observed on this route

Invariant:  tenancy.server_derived
Experiment: send the owner's X-Org-Id value with a different identity
Predicted:  the response follows the header, not the session
Falsifier:  the response follows the session and ignores the header
Information gain: 0.94

  gain = (1.0 uncertainty × 1.0 tenancy × 1.2 novelty × 1.3 deficit)
         / (1.0 cost × 1.0 risk)
  uncertainty: no history — maximum uncertainty;  cost: no cost history
```

**The gain is decomposed, not a magic number.** Every term comes from data
already in the database: Beta-posterior variance for uncertainty, observed
requests-per-finding for cost, snapshot novelty, untested-invariant deficit,
and the engine's declared risk.

This is the version of "information gain" that earns its place. An earlier
design rejected the idea because expected gain, impact and success probability
were all guesses, and multiplying three guesses gives confident nonsense. Here
the probability is measured.

---

# Source ↔ runtime correlation

```bash
thor source scan ./app
thor source correlate --corpus prod
```

Not a general SAST engine. It does three things a general SAST cannot, because
they need the runtime side:

```
UNGUARDED
  [high    ] GET /api/billing/invoices/{id}
      src/routes/billing.js:22
      3 of 4 routes under /api/billing carry an authorisation
      decoration; this one carries none, and it is reachable at runtime

UNSCOPED SINK
  [high    ] GET /api/billing/invoices/{id}
      src/routes/billing.js:22
      the handler retrieves an object by client-supplied identifier with
      no tenant or owner argument, and the route carries no ownership guard
      sink: db.findById(req.params.id)

GUARD MISMATCH
  [critical] GET /api/admin/export
      src/routes/admin.js:5
      source declares guards ['auth_middleware', 'role_guard'] on this
      route, but an unauthenticated request returned 200
```

The **sibling comparison** is the strongest signal: when nine routes under a
prefix carry a tenant guard and the tenth does not, the tenth is an oversight,
not a design decision.

Frameworks: Express, NestJS, Flask, FastAPI, Django, Rails, Spring, Laravel,
Go chi/gin/echo.

Source findings are hypotheses with a strong prior — the runtime engines still
have to prove them. Only `guard_mismatch` promotes directly, because it
already carries runtime evidence.

---

# Mobile ↔ API correlation

```bash
thor mobile analyse app.apk --corpus prod
```

Deliberately **not** a mobile security scanner. Android and iOS are their own
disciplines, and a mediocre MobSF would make THOR worse.

What is worth having is the correlation: a mobile app is a list of endpoints,
hostnames, headers and secrets the web corpus does not contain. Mobile clients
routinely call endpoints the web front-end never touches, and those are
frequently older and less guarded.

```
mobile-derived endpoints not present in the web corpus: 7
  https://api.target/api/internal/bulk-export
  https://api.target/api/mobile/v1/sync
context:
  mobile-only headers: ['X-App-Version', 'X-Device-Id'] — backends often
  trust these more than web headers; try them on web endpoints
  custom URL schemes (deep-link surface): ['acmeapp']
  the app permits cleartext traffic
```

Pure Python: unzip, read strings, extract. No JADX, no emulator. Endpoints and
secrets are what survives that, and they feed the existing engines — no new
verification path, no new finding type.

---

# Engines

| | |
|---|---|
| `thor authz` | IDOR / BOLA cross-identity replay, with executed anonymous disproof |
| `thor tenant` | cross-tenant matrix, including header-carried tenant keys |
| `thor bfla` | method swap, privileged routes |
| `thor massassign` | privileged field injection |
| `thor fuzz` | grammar-aware semantic mutation, eight oracles |
| `thor oauth` | RFC 9700: redirect_uri, PKCE downgrade, state, code reuse |
| `thor workflow` | state-machine sequences: replay, jump, revert, reorder |
| `thor detect` | GraphQL field-level authz, JWT forgery, path ACL, CORS, cache |
| `thor probe` | prototype pollution, open redirect, source maps, uploads |
| `thor race` | TOCTOU (DESTRUCTIVE — gated) |

## Oracles, and why none of them match payload echo

Payload-echo detection is the single largest source of AI bug bounty slop: it
finds nothing and reports everything.

| oracle | what it actually asks |
|---|---|
| `error` | did an *engine-specific* error appear that the baseline lacked? |
| `boolean` | do true and false conditions produce systematically different responses? |
| `computed` | did `7*191` render as `1337` **with the expression absent**? |
| `timing` | repeated trials, median ≥ 80% of requested, no overlap with control |
| `oast` | did the server actually call out to infrastructure we control? |
| `differential` | did this move the response in a way an **inert control** did not? |
| `reflection` | parsing-relevant context, HTML content type, breaking chars unencoded |
| `invariant` | did a 200 response compute a negative total, or store a client-supplied state? |

Blind classes require OAST. Without `interactsh-client` or a Collaborator
domain they are **skipped, not guessed**.

## The control is re-fetched, not remembered

Every cross-identity comparison needs a control: the owner's own response to
the same request. THOR fetches it **immediately before the probe**, not from
the capture.

This is not pedantry. You export a Burp session in the evening and hunt
overnight; by probe time the object has a new timestamp, an incremented
counter, a field someone shipped that afternoon. Compared against the stale
capture, the probe's response no longer looks like "the same object" — a real
IDOR scores under threshold and is filed `inconclusive`. Nothing in the output
says a bug was probably missed, because from the engine's view nothing
happened. A control has to be contemporaneous with the treatment.

It costs one request per candidate, roughly 20–30% more traffic on an authz
run. A cheaper run that cannot tell a leak from drift is not cheaper.

The same refresh catches the other failure mode. If the owner now gets a 401
on their own object, the captured session has expired and every probe against
it is noise — so the candidate is skipped and you are told to re-capture,
rather than banking a row of `denied` verdicts that read like a well-secured
endpoint.

The control is stored on the experiment, so the evidence bundle's baseline
step shows what was actually compared. A triager who runs `replay.sh` and sees
`DIFFERS` on step one stops reading, and a correct finding gets closed as
unreproducible.

---

# The research loop

```bash
thor loop --corpus prod --minutes 240
```

The loop is **hypothesis-native**. It does not walk a list of engines. It
picks the open hypothesis with the highest information gain, runs the
experiment that hypothesis names, judges the result against the invariant the
hypothesis names, and re-plans when something is confirmed.

```
OBSERVE → MODEL → HYPOTHESISE → SELECT → EXECUTE → JUDGE → UPDATE → REPLAN
                       ▲                                              │
                       └──────── a confirmation re-plans ─────────────┘
```

```
[invariants] catalogue: 22 rules (22 newly installed)
[loop] round 1 · 240m left
[loop] H-001 (tenant)  gain 1.30 = 1.0u × 1.0tena × 1.0n × 1.3d / 1.0c × 1.0r
  ✓ confirmed     tenant isolation may be enforced at routing rather than at
                  object retrieval
[loop] round 2 · 238m left
[loop] H-002 (authz)   gain 1.17 = 1.0u × 0.9auth × 1.0n × 1.3d / 1.0c × 1.0r
  ✗ disproved     GET /api/billing/invoices/{id} resolves an object the
                  caller does not own
[loop] round 4 · 233m left
[loop] H-003 (authz)   gain 0.21 = 0.238u × 0.9auth × 1.0n × 1.0d / 1.04c × 1.0r
[invariants] 2 violated, 1 hold, 19 untested
[loop] 4 round(s): 1 confirmed, 3 disproved, 0 blocked
[loop] 1 replan(s), 4 hypotheses opened
[loop] findings 0 → 1

[loop] AI checkpoints worth a prompt:
  /impact   — 1 finding(s) need an impact section
  /dedupe   — check disclosures; duplicates cost more than false positives
```

Read the gain line. It is not a score, it is an arithmetic statement you can
argue with:

```
        uncertainty × boundary_weight × novelty × coverage_deficit
gain =  ─────────────────────────────────────────────────────────
                        cost × risk_penalty
```

Every term is printed with its value, so a selection can be wrong in a way you
can see. H-003 above fell from 1.17 to 0.21 between rounds — not because
anything was re-tuned, but because two rounds of real timing data raised its
measured cost and the disproved siblings cut its uncertainty. There are no
magic constants to trust.

**There is no agent loop.** All of this runs as code, for hours, at zero token
cost. The model is consulted only at the checkpoints the loop names when it
finishes.

A real agent loop would exhaust a Claude Pro five-hour quota in about ten
minutes — and the XBOW-benchmark attribution study found it would not beat a
plain coding agent anyway.

```bash
thor hypotheses           # the full ledger
thor hypotheses next      # what the planner would pick next, and why
thor hypotheses run       # run exactly that one, by hand
thor hypotheses replan    # re-model and re-generate after something changed
```

## Outcome learning

```bash
thor learn
```

```
arm                                    hits   runs   rate  90% CI
tenant|nginx|header                       6      9   0.64  0.38-0.90
oauth|nginx|-                             5     14   0.38  0.19-0.57
cors|nginx|-                              0     44   0.02  0.00-0.06
```

Thompson sampling over Beta posteriors built from your own outcomes. Cold arms
are uniform, so the loop explores; it becomes opinionated only once it has
evidence. Disproved hypotheses are kept deliberately, so the scheduler stops
retrying what already failed.

Arms are keyed on `engine | technique | role | archetype | relation`, not on
engine alone. "Authz testing works" is not a useful prior. "Authz testing via
header swap against a `bulk_export` archetype on a foreign-key relation
works" is one you can act on — and it stops a strong result on admin routes
from raising expectations everywhere else.

---

# The finding lifecycle

A finding is not a row someone set a status on. It is a state machine, and
every transition has a gate that is code.

```
observed → hypothesis → candidate → verification_required
        → verified → deduped → report_ready → submitted
```

| Gate | Requires |
|---|---|
| `_has_evidence` | stored request/response bytes, not a summary |
| `_oracle_fired` | a named deterministic oracle, not payload echo |
| `_control_executed` | the inert control was actually sent, not assumed |
| `_scope_proven` | the target resolved inside `scope.yaml` at request time |
| `_replayable` | the evidence bundle regenerates the observation |
| `_dedupe_checked` | fingerprint compared against known disclosures |
| `_has_impact` | impact written by a human — `[auto]` text is rejected |

Each gate result is recorded against **that finding**, with the evidence it
read and the version of the rule, in `finding_gate_results`. Three of the
seven used to be theatre:

- `_dedupe_checked` returned true if the `rootcauses` table merely existed,
  so every finding passed the moment one unrelated finding was analysed.
  A gate a finding passes for someone else's reason is not a gate.
- `_scope_proven` did `url LIKE '%asset%'` — which matched `example.com`
  inside `notexample.com.evil.net`, and blocked seven of ten genuine
  findings whose asset string did not happen to appear in a URL. It now
  reads `dest_address`, the address the scope gate validated and pinned
  when the request was actually sent. An experiment row cannot exist
  without one, so its presence *is* the proof.
- `_replayable` checked that columns were non-null. "It returned 200" is
  not a reproduction; a response hash to compare against is now required.

```bash
thor state             # everything, and where it is stuck
thor state gates --id 4    # which gate is holding finding 4, and why
thor state advance     # re-evaluate every finding against its next gate
```

**The AI cannot move a finding.** `states.advance()` raises `PermissionError`
for the AI actor, and a SQLite trigger aborts any write to `status`,
`severity`, `disproof_done`, `evidence_ids`, `fingerprint`, `vuln_class`,
`route` or `asset` made under `as_ai(db)`. Two independent mechanisms, because
this is the one thing that must not depend on a caller remembering an API.

What the AI *may* write: `impact`, `title`, `summary`, `remediation`,
`attack_narrative`, `cvss_vector`, `triager_notes`. Being wrong there costs a
rewrite. Being wrong about `status` costs your reputation with a triage team.

---

# Evidence bundles cannot execute

A captured response body is attacker-controlled. In v4 the generated
reproduction script built a shell command from it, and this body

```json
{"x": "'; echo PWNED_BY_TARGET_TRAFFIC; echo '"}
```

closed the quoting in `curl --data '...'` and ran a command on the operator's
machine. A target could own the researcher by being tested.

The bundle now contains a **fixed template** plus data:

```
finding.json        the finding, credentials redacted
request.json        every step, bodies base64-encoded
replay.py           a constant — reads request.json, sends, compares
replay.sh           a constant — two lines, `exec python3 replay.py`
creds.json.example  a template you fill in; never written from the vault
```

Nothing target-derived is ever interpolated into script syntax.
`replay.verify_no_shell_injection()` asserts the generated files are
byte-identical to the templates, six malicious-body variants are in the
regression suite, and CI fails if `replay.py` ever writes a modified template
or imports `subprocess`.

---

# Source → sink data flow

```bash
thor source scan ./repo        # routes + AST data-flow
thor source dataflow ./repo    # data-flow only
thor source correlate --corpus prod
```

tree-sitter AST analysis across seven languages, tracing request-derived
values to sinks — `db_lookup`, `query`, `exec`, `render`, `fs`, `http` — and
recording whether an **authority check reaches the same flow**.

The asymmetry is the whole signal. A route that reads `req.params.id` and
hands it to a database lookup is ordinary. A route that does so where no
authority expression is reachable on that path is an IDOR with a file and
line number, which then gets correlated to a live route and tested.

Route registrations are explicitly not sinks, which is what keeps this from
reporting every endpoint in the codebase.

## Three answers, not two

Real code puts the authorisation check somewhere other than the sink: a
decorator, an Express middleware, a base controller, a repository that
always scopes by tenant. "No authority in this call" and "no authority
anywhere" are different statements, and only one of them is a finding.

```
UNSCOPED — a route reaches this lookup and nothing on the way applies authority
  ✗ [0.85] repo.js:3 (javascript)
      req.params.id → db.findById [db_lookup]
      callers: handleInvoice ← <anon@routes.js:3>

UNKNOWN — no authority seen, but no caller could be resolved either
  ? [0.60] helper.js:2 (javascript)
      req.params.id → db.findById [db_lookup]
```

An UNKNOWN flow is never turned into a hypothesis. Spending real requests
on the tool's own blind spot is worse than saying nothing.

## Following taint across files

The ordinary shape of a web application defeats single-file analysis
entirely:

```
routes.js      router.get('/x/:id', (req,res) => ctl(req,res))
controller.js  function ctl(req,res){ return repo(req.params.id) }
repo.js        function repo(id){ return db.findById(id) }
```

No file contains both the source and the sink, so each one on its own looks
clean — and this is exactly where unscoped lookups hide. THOR builds a call
graph, propagates taint through parameters, and follows the authority
question up the caller chain:

```
req.params.id → parameter id of fetchInvoice() → db.findById
```

One guard pattern was, briefly, too generous: it matched bare `require`,
so `const router = require('express')` read as an authorisation check and
marked every route in the file as guarded. A guard pattern that is too
loose does not produce noise, it produces silence — which is why the
patterns are specific and `require(` is explicitly excluded.

---

# Chains are proposals until their links are verified

```bash
thor chain              # build, propose, verify what can be verified
thor chain candidates   # what was proposed and why it did or did not verify
thor chain reject --id 3 --reason "..."
```

A chain is a severity-escalating claim, so it needs more evidence than a
single finding, not less. Every link must itself have reached VERIFIED — a
chain of unproven steps proves nothing — and the chain's severity is the
highest among its links, never the proposer's.

That last point matters because the AI proposes chains too. Its route into
`findings` used to be direct: `ai apply --kind chains` called
`chain.persist()`, which inserted a finding with the model's own severity
and `disproof_done=1`. A model could produce a critical finding that
claimed its own disproof had been executed. The module docstring said "No
chain is inferred from a model's narrative" throughout.

Now it proposes, and `verify()` decides:

```
[chain] proposed (ai): Invented takeover  links=[1, 2]
  · [1] Invented takeover  (ai, proposed)
      links [1, 2]  proposed=critical
      ✗ finding 1 is 'candidate', not yet verified — a chain of unproven
        steps proves nothing
```

A "chain" with one link is not a chain, it is the same bug with a more
exciting title. Two rules produced exactly that, as separate findings
hard-coded to `critical` — the same defect submitted twice, the second copy
claiming a severity nothing measured. Those are now **severity escalations**
on the finding itself, under a named rule:

```
**Severity basis:** raised above the baseline for this class by:
  - `pii-returned-to-unauthorised-identity` (high→critical): the
    unauthorised response contained PII fields (email) belonging to
    another user
```

Every automatic severity change works this way. Nothing escalates because
it feels worse, and a triager can see which rule did it and argue with it.

---

# Correlation and reporting

```bash
thor promote      # experiments → deduplicated findings
thor chain        # attack chains (7 evidence-backed rules)
thor rootcause    # group manifestations by shared defect
thor evidence 1   # replayable bundle
thor report --id 1
thor reproduce 1
```

## Root cause

Twenty IDORs behind one broken middleware is **one bug**. Submitted separately
that is nineteen duplicates and an annoyed triager.

```
CRITICAL  Application-wide object-level authorisation on api.target  (7)

  7 authz findings span 4 unrelated top-level resource families
  (billing, crm, hr, support) across 4 route prefixes. That breadth rules
  out a per-route mistake or a single middleware. The likely cause is a
  shared data-access layer that resolves objects by identifier without
  scoping the query to the caller.

  > Submit this as one report with the manifestations listed.
```

Four rules, each stating the *defect it proposes* rather than just the
similarity. Precision matters: three routes under one prefix are attributed to
a shared middleware, not to the data layer — the more specific claim wins.

## Attack-surface memory

```bash
thor snapshot --label "week-1"
# later
thor recon target.com && thor diff
```

```
## Authentication weakened  ← investigate first
  GET https://api.target/v2/export: 403 -> 200
## New assets (3)
  + new-staging.target.com
```

New surface has had the fewest eyes on it and gets a +4 anomaly boost. An
endpoint that *stopped* requiring authentication is a finding already.

---

# Testing

```bash
make safety       # 140 negative security tests
make unit         # 38 unit tests
make regression   # 12 end-to-end suites against labs with known bugs
make test         # all 190
```

**The safety suite runs first and alone.** If THOR can be made to send an
out-of-scope request, leak a credential, or let a captured response body run a
command on your laptop, its hit rate is irrelevant. CI additionally asserts
the safety suite has not shrunk below 136 tests — so it cannot be quietly
emptied to make a build pass.

44 of those tests are **review regressions**: one per bug found in review,
each written to fail against the code that had the bug. Two were proven
exploitable before being fixed rather than merely reasoned about — a
target-controlled body that executed a command in the generated replay script,
and an AI path that moved a finding from candidate to rejected. Writing the
exploit first is the only way to know the fix is a fix.

A CLI smoke test runs every subcommand the way a shell does, and a second
test fails if a new subcommand is missing from its list. An import rewrite
once left fifteen of forty-seven commands raising `NameError` at call time
while the whole suite stayed green — unit tests import modules and call
functions, and the CLI is the one layer none of them touch.

**The suite is not the last check.** The three worst defects in this version
were found by running a real engagement against a lab and reading the output,
with 126 tests passing throughout: the control was stale, the evidence
bundle's baseline step printed `DIFFERS`, and the report's reproduction
claimed the owner and the attacker had received different-sized objects. None
of those are crashes. All three would have cost a real report. Run the thing.

The regression labs plant known bugs *and decoys*. The decoys matter as much:
a tool that reports them is a slop generator.

```
--- planted vulnerabilities found ---
  PASS  IDOR · SQLi · SSTI · SSRF→metadata · path traversal
  PASS  negative-total logic · ACL bypass · reflected XSS
  PASS  cross-tenant via header · OAuth redirect bypass
  PASS  workflow replay · prototype pollution · guard mismatch

--- decoys correctly ignored ---
  PASS  correctly scoped 403 endpoint
  PASS  genuinely public endpoint
  PASS  reflects into JSON (not a render context)
  PASS  reflects but HTML-encoded
```

---

# What THOR deliberately does not do

These are choices, not gaps.

| | why not |
|---|---|
| Neo4j, Postgres, Redis, pgvector, OpenSearch | Five datastores before the first finding. SQLite does JSON, FTS and recursive CTEs; this graph does not justify the drag. |
| Full mobile / cloud / Kubernetes scanning | Different disciplines with different verification models. THOR takes the *correlation* value and leaves the scanning. |
| Multi-agent AI debate | Five times the cost for a verdict that is still a model's opinion. The deterministic disproof settles it with bytes. |
| Per-finding Bayesian confidence scores | Theatre unless calibrated. Real Beta posteriors exist in `learn.py`, over engine outcomes, where the data to fit them exists. |
| Request smuggling, active cache poisoning | Can affect other users of a live service. |
| Web dashboard, REST API, multi-tenant SaaS | Productising something before it has found a bug. |
| An agent loop | Would exhaust a Pro quota in ten minutes and underperform a plain coding agent. |
| Cloud / Kubernetes / CI-CD modelling | Different disciplines with different verification models. The correlation value needs cloud observations to correlate *with*, and a web-app corpus has none — it would be a scanner bolted on, producing claims THOR could not verify. |
| gRPC, JSON-RPC | Real protocols, but testing them needs proto definitions or reflection that a web-app engagement rarely has. An engine with nothing to feed it is a capability claim, not a capability. |
| A WebSocket engine | Declared in the risk table for months with no implementation behind it, so `thor risk` told the operator THOR could test WebSockets. Now listed as *not implemented*, with the reason, and a unit test stops the table drifting back. Worth building when the corpus can carry WS frames. |
| Browser automation (Playwright) | Genuinely valuable for business logic. It is also a subsystem, and Burp capture already supplies the same traffic. Deferred honestly rather than half-built. |
| Pydantic for AI output schemas | The validation is worth having; a dependency for it is not. Done in the standard library. |
| A maturity score out of ten | Numbers like that measure how many boxes were ticked. Validated findings per hour and duplicate rate measure whether it works. |

# Honest limitations

- **Not the most powerful exploitation engine.** Shannon (96.15% on a cleaned
  XBOW benchmark) and LuaN1aoAgent (90.4%) will out-exploit this. They will
  not tell you which subdomain is worth an hour, whether three people already
  reported it, or that seven findings share one middleware.
- **Duplicate checking is half-built.** Local signals and root-cause grouping
  are computed; the remote Hacktivity check is a `/dedupe` step because it
  needs judgement about what counts as the same bug.
- **The loop cannot invent engines.** It schedules what exists. If the bug is
  in a class with no detector, no amount of AI in the scheduler helps. A new
  bug class needs a plan in `experiment.ENGINE_PLANS` and an oracle that can
  judge it — the scheduler is not the bottleneck, the oracle is.
- **Data-flow is inter-procedural but not whole-program.** Taint follows
  function parameters across files to a bounded depth, and the authority
  question follows the caller chain. A taint that crosses a service
  boundary, a queue, a dynamic dispatch or an ORM's own scoping is not
  followed — and those cases come back UNKNOWN rather than being reported
  as missing checks.
- **The race engine needs a single-use operation to test.** It proves a
  TOCTOU window by contradiction: the server rejects a sequential repeat
  but accepts concurrent copies. An operation that is not single-use gives
  it nothing to contradict, and it says so rather than reporting the two
  200s as a race.
- **Information gain is a heuristic, not a measurement.** The terms are
  legible and every value is printed, which makes a bad selection arguable
  rather than mysterious. It does not make the ordering optimal.
- **The state machine can strand a real bug.** A finding that cannot clear
  `_replayable` on a target with per-request nonces is genuinely blocked, and
  THOR will not wave it through. That is the intended trade: the cost of a
  missed real finding is one you can absorb, the cost of a stream of unproven
  reports is your account.
- **The anomaly scorer needs ≥8 hosts** for a meaningful baseline.
- **Timing oracle under-reports.** It demands no control overlap, so behind a
  CDN expect it to find nothing.

---

# Authorisation

Only run THOR against targets you are explicitly authorised to test. Put the
program URL and authorisation date in `scope.yaml`'s `notes` field so the
record travels with the engagement.

The scope gate will refuse anything else, and the audit log will record that
it did.
