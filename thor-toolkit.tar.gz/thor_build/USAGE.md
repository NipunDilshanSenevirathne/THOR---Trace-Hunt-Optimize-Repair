# THOR — usage

Copy-pasteable, in order. Linux, Claude Pro plan.

## One-time

```bash
pip install -e ".[dev]"
make safety                      # 53 tests. Do not skip.
thor doctor
sudo ln -s "$PWD/thor-cli" /usr/local/bin/thor
```

Vault key — pick one:

```bash
pip install keyring                              # OS keyring (best)
export THOR_VAULT_PASSPHRASE='...'               # or a passphrase
export THOR_VAULT_KEY=$(python -c \
  "from cryptography.fernet import Fernet;print(Fernet.generate_key().decode())")
thor vault check
```

Confirm no API key is stealing your subscription auth:

```bash
echo $ANTHROPIC_API_KEY           # must print nothing
```

## Per engagement

### 0. Know your budget

```bash
thor budget
```

The request ceiling, rate limit and concurrency cap in `scope.yaml` are
engagement-wide and shared by every engine, and the counter survives
restarts. That is deliberate: a program authorises a number of requests,
not a number per run. Starting a genuinely new engagement:

```bash
thor budget reset --confirm
```

If the program publishes testing hours, set both the window and its
timezone — a window without one is ambiguous, and the program means its
own hours:

```yaml
window_start: "22:00"
window_end: "05:00"
window_timezone: "Asia/Colombo"
```

### 1. Scope — always first

```bash
thor init target.com
$EDITOR scope.yaml                # paste the program's published scope EXACTLY
thor doctor && thor risk
```

Put the program URL and authorisation date in `notes`. When in doubt, leave a
host out — the gate refuses and the audit log records the refusal.

### 2. Recon (overnight, zero tokens)

```bash
thor recon target.com
thor snapshot --label "day-1"
thor triage --top 20
```

### 3. Identities

Credentials go to the encrypted vault, and if one cannot be read back the
run stops rather than continuing without it. That is not pedantry: an
identity silently stripped of its Authorization header sends anonymous
probes, every one returns 401, and each is recorded as `denied` — a report
that the application is well secured, having tested nothing.

```bash
thor identity list     # UNRESOLVED entries are named, and exit 1
```


```bash
thor identity add userA --bearer eyJ... --role user  --tenant acme
thor identity add userB --bearer eyJ... --role user  --tenant globex
thor identity add admin --bearer eyJ... --role admin --tenant acme
thor identity add anon  --role anonymous
thor identity list
```

`userB` must be in a **different tenant** where the app has tenants. That is
the boundary worth testing. Tokens go to the vault; the database gets a
reference.

### 4. Capture

Imported traffic is sanitised before it is stored: the bearer token, the
session cookie and any password in a body are replaced with stable
fingerprints, and the originals are encrypted into the vault. Structure is
preserved, so schema inference and comparison are unaffected. If the
credentials cannot be encrypted the import fails rather than writing them
in the clear — so set `THOR_VAULT_KEY` (or install `keyring`) before
importing.


Burp: Proxy → HTTP history → select all → Save items → XML.
Browser: devtools → Network → Save all as HAR.

```bash
thor capture userA.har --corpus prod --identity userA
thor capture userB.xml --corpus prod --identity userB
```

Click through detail views, exports, settings and invitation flows. Twenty
minutes of real browsing beats a day of crawling.

### 5. Extra surface (optional, high value)

```bash
thor source scan ./app                      # if you have source
thor source correlate --corpus prod
thor mobile analyse app.apk --corpus prod   # if there's a mobile client
```

### 6. Model and reason

```bash
thor graph build --corpus prod
thor invariants
thor reason --corpus prod --persist
thor hypotheses                 # the ledger
thor hypotheses next            # what the planner would pick, and the maths
```

Read the top three hypotheses before running anything. They name the boundary,
the experiment and the falsifier.

`thor hypotheses next` prints the information-gain arithmetic term by term.
If a hypothesis is ranked highly for a reason you disagree with, you can see
which term did it — usually `boundary_weight` on a boundary this application
does not really have. Fix the model rather than the score.

### 7. Hunt

```bash
thor loop --corpus prod --minutes 240       # everything, zero tokens
```

The loop selects by information gain, re-scoring every round, and re-plans
whenever a hypothesis is confirmed. You do not need to sequence the engines.

To drive it one step at a time — useful the first time on an unfamiliar
target, or when the program is strict about request volume:

```bash
thor hypotheses next     # see the selection and why
thor hypotheses run      # execute exactly that one
thor hypotheses replan   # re-model after something changed
```

Or stage by stage:

```bash
thor authz --corpus prod        # IDOR / BOLA
thor tenant --corpus prod       # cross-tenant
thor bfla --corpus prod
thor massassign --corpus prod
thor fuzz --corpus prod
thor oauth --corpus prod
thor workflow --corpus prod     # needs sensitive: true
thor detect --corpus prod
thor probe --corpus prod
```

Blind SSRF and command injection need OAST:

```bash
go install -v github.com/projectdiscovery/interactsh/cmd/interactsh-client@latest
thor fuzz --corpus prod                         # auto-detects
thor fuzz --corpus prod --oast-domain <collaborator domain>
```

Without it those classes are skipped, not guessed.

### 8. Correlate before writing anything

```bash
thor promote
thor state advance              # chains need verified links
thor chain                      # propose + verify
thor chain candidates           # what did not verify, and why
thor rootcause                  # ← do this BEFORE any report
thor invariants
thor findings
```

A chain only becomes a finding when every link has itself reached VERIFIED,
and its severity comes from those links, never from whoever proposed it.
A one-link "chain" is recorded as a severity escalation on the finding it
is about, not as a second finding — reporting the same defect twice is the
fastest way to burn a program's patience.

Twenty IDORs behind one middleware is one report, not twenty.

### 9. Clear the gates

```bash
thor state                      # where every finding is stuck
thor state gates --id 1         # which gate, and what it wants
thor state advance              # re-evaluate everything
```

A finding only becomes reportable by passing seven gates in order: stored
evidence, a named oracle, an executed control, proven scope, a replayable
bundle, a dedupe check, and a human-written impact section.

Nothing skips a gate. If `thor state gates` says `_control_executed` is
holding, the answer is to send the control, not to override anything — there
is no override. If a gate cannot be satisfied on this target, that finding is
not ready to submit, and knowing that before a triager tells you is the
point.

```bash
thor state reject --id 3 --reason "control shows the same 403 for the owner"
```

### 10. Report

```bash
thor evidence 1
thor report --id 1
thor reproduce 1
```

The evidence bundle is safe to run: `replay.py` and `replay.sh` are fixed
templates, and every captured request lives in `request.json` as data. A
malicious response body cannot become a command on your machine. Fill in
`creds.json` from `creds.json.example` — credentials are never written into
a bundle.

In Claude Code:

```
/state           # what is blocked and the cheapest way to unblock it
/rootcause       # merge or split the groups
/dedupe          # check the program's disclosures — saves wasted hours
/impact          # write the impact section from the evidence
/chains
```

```bash
thor ai apply --kind impact --file answers/impact.json
thor state advance          # impact written → report_ready
thor report --id 1
```

The `[auto]` impact line THOR generates is a placeholder and the
`report_ready` gate rejects it. Replace it with your own words — the impact
section is the part a triager reads first and the part a model is worst at.

### 11. Over time

```bash
thor recon target.com && thor snapshot && thor diff
```

New surface and weakened authentication are where the unfound bugs are.

## Cron

```cron
0 2 * * *  cd ~/thor && ./thor-cli recon target.com     >> recon.log 2>&1
0 5 * * *  cd ~/thor && ./thor-cli snapshot && ./thor-cli diff > diff.txt
0 6 * * *  cd ~/thor && ./thor-cli loop --corpus prod --minutes 180 --no-ai \
                                        >> loop.log 2>&1
```

Zero tokens. Wake up to a ranked queue and an audit trail.

## Burp MCP

```bash
claude mcp add burp -- <server launch command>
claude
/mcp
```

Export XML and use `thor capture`, or pass MCP JSON to
`corpus.import_mcp_json`.

## Troubleshooting

| symptom | cause |
|---|---|
| `SCOPE REFUSED` | working as intended. Check `thor audit`. |
| `Need at least 2 identities` | add userB, and `anon` for the disproof |
| engine says `SKIP ... SENSITIVE` | raise the ceiling in `scope.yaml` only if the program permits |
| `no OAST` | install `interactsh-client`; blind classes are skipped meanwhile |
| vault prompts for a passphrase | set `THOR_VAULT_KEY` or install `keyring` |
| `thor reason` shows no hypotheses | run `thor graph build` first |
| `thor loop` stops: "no open hypotheses remain" | correct — everything was confirmed or disproved. `thor hypotheses replan` after adding corpus or identities |
| a finding will not reach `report_ready` | `thor state gates --id N`. There is no override; satisfy the gate or reject the finding |
| `PermissionError: ai cannot advance` | working as intended. The AI writes narrative fields, never status |
| `source scan` says data-flow skipped | `pip install tree_sitter tree_sitter_language_pack` |
| a hypothesis' gain dropped between rounds | expected. Cost is measured, not assumed, and siblings reduce uncertainty |
| `CredentialUnavailable` on any engine | the vault cannot produce a token. Set `THOR_VAULT_KEY`, or `thor identity list` to see which. THOR stops rather than sending anonymous probes and recording the 401s as `denied` |
| import refuses: "will not write them in plaintext" | the capture contains credentials and there is nowhere encrypted to put them. Set `THOR_VAULT_KEY` and import again |
| `Engagement request budget exhausted` | the ceiling is engagement-wide and survives restarts, by design. `thor budget` to see it; `thor budget reset --confirm` only for a genuinely new engagement |
| a chain candidate will not verify | `thor chain candidates` names the link that is not yet VERIFIED. Run `thor state advance` first |
| a data-flow result says UNKNOWN | no caller could be resolved, so whether authority is applied upstream is not visible. It is deliberately not turned into a hypothesis |
| `thor risk` shows an engine as "not implemented" | it is declared with a risk level but has no implementation; the reason is printed beside it |
| `N candidate(s) skipped: the owner can no longer reach their own object` | your captured session expired. Re-capture and re-run — nothing useful can be judged against a dead session |
| authz run sends more requests than expected | one control per candidate, re-fetched live. A stale control cannot distinguish a leak from object drift |
| `replay.sh` prints DIFFERS on the owner baseline | the object changed since the run, or the target was fixed. The probe step is the one that matters |
