"""
Regression test: the engine must find the real IDOR, pass over the correctly
scoped endpoint, and NOT report the public endpoint.

This is the baseline you re-run after every change to diff.py or engine.py.
Run:  python3 tests/test_lab.py
"""
import json, os, sys, tempfile, threading, time
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import re

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

PORT = 8911
USERS = {"tokenA": 1, "tokenB": 2}
ORDERS = {"1001": {"id": "1001", "owner": 1, "email": "alice@corp.example",
                   "total": 4210, "card_last4": "9912",
                   "address": "14 Mill Lane, Bristol"}}
PROFILES = {1: {"id": 1, "name": "Alice", "plan": "pro"},
            2: {"id": 2, "name": "Bob", "plan": "free"}}


class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _who(self):
        return USERS.get(self.headers.get("Authorization", "").replace("Bearer ", ""))
    def _j(self, c, o):
        b = json.dumps(o).encode()
        self.send_response(c); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b))); self.end_headers()
        self.wfile.write(b)
    def do_GET(self):
        uid = self._who()
        if m := re.match(r"^/api/orders/(\d+)$", self.path):       # VULNERABLE
            if not uid: return self._j(401, {"error": "unauthorized"})
            o = ORDERS.get(m.group(1))
            return self._j(200, o) if o else self._j(404, {"error": "not found"})
        if m := re.match(r"^/api/profile/(\d+)$", self.path):      # SCOPED OK
            if not uid: return self._j(401, {"error": "unauthorized"})
            if int(m.group(1)) != uid: return self._j(403, {"error": "forbidden"})
            return self._j(200, PROFILES[uid])
        if m := re.match(r"^/api/docs/(\d+)$", self.path):         # PUBLIC trap
            return self._j(200, {"id": m.group(1), "title": "Terms",
                                 "body": "Public text.", "author": "legal@corp.example",
                                 "address": "1 Corp Plaza, London"})
        self._j(404, {"error": "not found"})


def main():
    srv = HTTPServer(("127.0.0.1", PORT), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    time.sleep(0.5)

    from thor.db import DB
    from thor.scope import Scope
    from thor import corpus, engine, evidence

    work = tempfile.mkdtemp()
    os.chdir(work)
    # Importing traffic that carries credentials now requires a vault to
    # put them in: THOR refuses to write them to the research database in
    # plaintext rather than storing them and redacting later.
    os.environ.setdefault(
        "THOR_VAULT_KEY", "sVJgBCWAe0Zz_9oD9pLQ3k7bYQjFqXZy6mB2nT4uRlA=")
    from thor import vault as _vault
    _v = _vault.default()
    _v.path = Path(work) / "vault.enc"
    _v._key = None
    _v._data = None
    Path("scope.yaml").write_text(
        f"engagement: test\nallowed_hosts: ['127.0.0.1']\n"
        f"max_rps: 200\nmax_requests: 500\nallow_private_targets: true\n")
    sc = Scope.load("scope.yaml")
    db = DB("t.db")

    import urllib.request, urllib.error
    entries = []
    for p in ["/api/orders/1001", "/api/profile/1", "/api/docs/5000"]:
        r = urllib.request.Request(f"http://127.0.0.1:{PORT}{p}",
                                   headers={"Authorization": "Bearer tokenA"})
        try:
            with urllib.request.urlopen(r) as x:
                st, body, hd = x.status, x.read().decode(), dict(x.headers)
        except urllib.error.HTTPError as e:
            st, body, hd = e.code, e.read().decode(), dict(e.headers)
        entries.append({"request": {"method": "GET",
                        "url": f"http://127.0.0.1:{PORT}{p}",
                        "headers": [{"name": "Authorization", "value": "Bearer tokenA"}]},
                        "response": {"status": st,
                                     "headers": [{"name": k, "value": v} for k, v in hd.items()],
                                     "content": {"text": body}}})
    Path("a.har").write_text(json.dumps({"log": {"entries": entries}}))

    for n, t, role in [("userA", "tokenA", "user"), ("userB", "tokenB", "user")]:
        db.ex("INSERT OR REPLACE INTO identities (name, role, headers) VALUES (?,?,?)",
              n, role, json.dumps({"Authorization": f"Bearer {t}"}))
    db.ex("INSERT OR REPLACE INTO identities (name, role, headers) VALUES (?,?,?)",
          "anon", "anonymous", "{}")

    corpus.import_har(db, sc, "a.har", "t", "userA", log=lambda *a: None)
    res = engine.run_authz(db, sc, "t", log=lambda *a: None)
    evidence.promote(db, log=lambda *a: None)

    findings = db.q("SELECT * FROM findings")
    routes = [f["route"] for f in findings]

    ok = True
    def check(label, cond):
        nonlocal ok
        print(f"  {'PASS' if cond else 'FAIL'}  {label}")
        ok = ok and cond

    print("\nengine regression:")
    check("exactly 1 leak", res["leaks"] == 1)
    check("correctly-scoped endpoint denied", res["denied"] >= 2)
    check("public endpoint classified public, not leaked", res["public"] >= 1)
    check("exactly 1 finding promoted", len(findings) == 1)
    check("finding is the orders route", any("/api/orders/" in r for r in routes))
    check("no finding on docs (public trap)", not any("/api/docs" in r for r in routes))
    check("no finding on profile (scoped)", not any("/api/profile" in r for r in routes))
    check("disproof was executed", findings and findings[0]["disproof_done"] == 1)
    check("severity escalated by PII", findings and findings[0]["severity"] == "critical")

    print(f"\n  counts: {json.dumps(res)}")
    print("\n" + ("ALL PASS" if ok else "FAILURES PRESENT"))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())


# ---- pytest entry point -------------------------------------------------
import pytest


@pytest.mark.regression
@pytest.mark.lab
@pytest.mark.slow
def test_authz_engine_regression():
    """authz engine: every assertion in main() must pass."""
    assert main() == 0, "authz engine regression failed — see stdout"
