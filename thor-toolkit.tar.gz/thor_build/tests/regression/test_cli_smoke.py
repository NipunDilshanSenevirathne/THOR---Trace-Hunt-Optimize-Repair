"""
CLI smoke: every subcommand, invoked the way an operator invokes it.

This exists because of a real bug. An import rewrite left fifteen of the
forty-seven commands raising NameError at call time. Every unit test still
passed -- they import modules and call functions directly, and the CLI is the
one layer none of them touch. A tool whose commands do not run is not a tool,
however green its test suite is.

So: spin up the lab, build a real engagement in a temp directory, and run
every command through `cli.main()` exactly as the shell would. A command may
legitimately decline (no OAST, risk ceiling, nothing to do) -- that is a clean
exit, not a failure. What this catches is the command that cannot start.
"""

from __future__ import annotations

import contextlib
import io
import json
import re
import sys
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import urlsplit

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

PORT = 8947
B = f"http://127.0.0.1:{PORT}"

USERS = {"tokenA": ("userA", "acme"), "tokenB": ("userB", "globex")}
INVOICES = {"5001": {"id": "5001", "org": "acme", "amount": 12400}}


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _who(self):
        return USERS.get(
            self.headers.get("Authorization", "").replace("Bearer ", ""))

    def _j(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        p = urlsplit(self.path).path
        who = self._who()
        if m := re.match(r"^/api/billing/invoices/(\d+)$", p):
            if not who:
                return self._j(401, {"error": "unauthorized"})
            obj = INVOICES.get(m.group(1))
            if not obj:
                return self._j(404, {"error": "nf"})
            # planted: the object is returned to any authenticated caller
            return self._j(200, obj)
        if p == "/api/me":
            if not who:
                return self._j(401, {"error": "unauthorized"})
            return self._j(200, {"user": who[0], "org": who[1]})
        self._j(404, {"error": "not found"})

    do_POST = do_GET


HAR = {
    "log": {"entries": [
        {"request": {"method": "GET",
                     "url": f"{B}/api/billing/invoices/5001",
                     "headers": [{"name": "Authorization",
                                  "value": "Bearer tokenA"}],
                     "postData": {"text": ""}},
         "response": {"status": 200, "content": {
             "text": json.dumps(INVOICES["5001"]),
             "mimeType": "application/json"}}},
        {"request": {"method": "GET", "url": f"{B}/api/me",
                     "headers": [{"name": "Authorization",
                                  "value": "Bearer tokenA"}],
                     "postData": {"text": ""}},
         "response": {"status": 200, "content": {
             "text": json.dumps({"user": "userA", "org": "acme"}),
             "mimeType": "application/json"}}},
    ]}
}

SOURCE_JS = """
const router = require('express').Router();

router.get('/api/billing/invoices/:id', requireAuth, (req, res) => {
  const inv = db.findById(req.params.id);      // no tenant scoping
  res.json(inv);
});

router.get('/api/billing/statements/:id', requireAuth, (req, res) => {
  const s = db.findById(req.params.id, { tenant: req.user.tenant });
  res.json(s);
});
module.exports = router;
"""

# Every command, with arguments an operator would actually pass. A command
# that needs a finding id gets 1; if no finding exists the command should say
# so cleanly rather than raising.
COMMANDS = [
    ["doctor"],
    ["risk"],
    ["status"],
    ["budget"],
    ["vault", "check"],
    ["identity", "list"],
    ["schema", "--corpus", "smoke"],
    ["graph", "build", "--corpus", "smoke"],
    ["graph", "show"],
    ["invariants"],
    ["reason", "--corpus", "smoke"],
    ["reason", "--corpus", "smoke", "--persist"],
    ["hypotheses"],
    ["hypotheses", "next"],
    ["hypotheses", "replan"],
    ["state"],
    ["state", "advance"],
    ["source", "scan", "app"],
    ["source", "dataflow", "app"],
    ["source", "correlate", "--corpus", "smoke"],
    ["authz", "--corpus", "smoke"],
    ["tenant", "--corpus", "smoke"],
    ["bfla", "--corpus", "smoke"],
    ["massassign", "--corpus", "smoke"],
    ["fuzz", "--corpus", "smoke"],
    ["detect", "--corpus", "smoke"],
    ["probe", "--corpus", "smoke"],
    ["oauth", "--corpus", "smoke"],
    ["workflow", "--corpus", "smoke"],
    ["race", "--corpus", "smoke"],
    ["promote"],
    ["chain"],
    ["chain", "candidates"],
    ["chain", "verify"],
    ["budget", "show"],
    ["rootcause"],
    ["findings"],
    ["learn"],
    ["snapshot"],
    ["diff"],
    ["triage"],
    ["audit", "--tail", "5"],
    ["stats"],
    ["evidence", "1"],
    ["report", "--id", "1"],
    ["reproduce", "1"],
    ["state", "gates", "--id", "1"],
    ["ai", "brief", "--kind", "triage"],
    ["ai", "brief", "--kind", "classify"],
    ["ai", "brief", "--kind", "impact"],
    ["ai", "brief", "--kind", "fuzz"],
    ["ai", "brief", "--kind", "chains"],
    ["loop", "--corpus", "smoke", "--minutes", "1"],
]


@pytest.fixture(scope="module")
def lab():
    srv = HTTPServer(("127.0.0.1", PORT), H)
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    yield B
    srv.shutdown()


@pytest.mark.regression
@pytest.mark.lab
def test_every_cli_command_runs(lab, tmp_path, monkeypatch):
    from thor import cli

    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("THOR_VAULT_KEY",
                       "sVJgBCWAe0Zz_9oD9pLQ3k7bYQjFqXZy6mB2nT4uRlA=")

    Path("scope.yaml").write_text(
        "engagement: smoke\nallowed_hosts: ['127.0.0.1']\n"
        "allowed_methods: [GET, HEAD, POST, PUT, PATCH, OPTIONS]\n"
        "max_rps: 400\nmax_requests: 40000\n"
        "sensitive: true\nallow_private_targets: true\n")
    Path("a.har").write_text(json.dumps(HAR))
    (tmp_path / "app" / "src").mkdir(parents=True)
    (tmp_path / "app" / "src" / "billing.js").write_text(SOURCE_JS)

    def run(argv) -> tuple[int, str]:
        buf = io.StringIO()
        try:
            with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
                code = cli.main(argv)
        except SystemExit as e:
            # A command may decline via SystemExit("run X first"). Python
            # would print that string; since we catch it, capture it here --
            # otherwise a guided decline is indistinguishable from a silent
            # crash, which is precisely the distinction this test makes.
            if isinstance(e.code, int) or e.code is None:
                code = e.code or 0
            else:
                code = 1
                buf.write(str(e.code))
        return code, buf.getvalue()

    # --- setup, which must succeed ---------------------------------------
    for argv in (
        ["identity", "add", "userA", "--header", "Authorization: Bearer tokenA",
         "--header", "X-Org-Id: acme", "--role", "user", "--tenant", "acme"],
        ["identity", "add", "userB", "--header", "Authorization: Bearer tokenB",
         "--header", "X-Org-Id: globex", "--role", "user", "--tenant", "globex"],
        ["identity", "add", "anon", "--role", "anonymous"],
        ["capture", "a.har", "--corpus", "smoke", "--identity", "userA"],
    ):
        code, out = run(argv)
        assert code == 0, f"setup failed: {' '.join(argv)}\n{out}"

    # --- every command --------------------------------------------------
    broken: list[str] = []
    for argv in COMMANDS:
        code, out = run(argv)
        label = "thor " + " ".join(argv)

        # A command may decline. It may not fail to start.
        for marker in ("Traceback (most recent call last)",
                       "NameError", "AttributeError: module",
                       "TypeError: ", "ImportError", "UnboundLocalError"):
            if marker in out:
                broken.append(f"{label}\n{out[-1500:]}")
                break
        else:
            # A non-zero exit is acceptable only as a *guided* decline: it has
            # to tell the operator what to run instead. An exit code with no
            # explanation is a dead end.
            if code not in (0, 2) and not out.strip():
                broken.append(f"{label} -> exit {code} with no message")

    assert not broken, (
        f"{len(broken)} of {len(COMMANDS)} commands are broken:\n\n"
        + "\n\n".join(broken))


@pytest.mark.regression
def test_command_table_covers_every_subparser(tmp_path, monkeypatch):
    """
    The smoke list must not drift behind the CLI. If someone adds a command
    and does not add it here, it never gets executed by any test -- which is
    exactly how fifteen dead commands shipped once already.
    """
    from thor import cli

    parser = cli.build_parser()
    registered = set()
    for action in parser._subparsers._group_actions:      # noqa: SLF001
        registered |= set(action.choices)

    covered = {argv[0] for argv in COMMANDS}
    # commands that mutate an engagement destructively or need an argument
    # no fixture can supply
    exempt = {"init", "nuclei", "recon", "mobile", "all", "capture",
              "identity", "vault", "source", "ai"}

    missing = registered - covered - exempt
    assert not missing, (
        f"these CLI commands are never smoke-tested: {sorted(missing)}. "
        "Add them to COMMANDS or to the exempt set with a reason.")
