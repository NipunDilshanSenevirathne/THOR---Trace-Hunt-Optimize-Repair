"""
v3 regression: new engines against a lab with a known inventory.

  PLANTED                                        DECOY
  cross-tenant via X-Org-Id header               tenant-scoped /api/me
  OAuth redirect_uri suffix bypass               exact-match rejected variants
  workflow: coupon redeemable twice              one-shot /api/verify
  workflow: state jump to 'paid'
  open redirect on ?next=
  prototype pollution (status technique)
  root-cause grouping: 3 IDORs under /api/billing/

Run: python3 tests/test_v3.py
"""
import json
import os
import re
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

PORT = 8931
B = f"http://127.0.0.1:{PORT}"

USERS = {"tokenA": ("userA", "acme"), "tokenB": ("userB", "globex")}
INVOICES = {"5001": {"id": "5001", "org": "acme", "email": "cfo@acme.example",
                     "amount": 12400, "iban": "GB29NWBK60161331926819"}}
ORDERS = {"7001": {"id": "7001", "org": "acme", "email": "ops@acme.example",
                   "total": 300, "status": "pending"}}
STATEMENTS = {"9001": {"id": "9001", "org": "acme", "email": "cfo@acme.example",
                       "balance": 88200}}
STATE = {"coupon_redeemed": False, "order_status": "pending",
         "polluted_status": None, "verified": False}


class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _who(self):
        return USERS.get(self.headers.get("Authorization", "").replace("Bearer ", ""))

    def _j(self, c, o):
        if STATE["polluted_status"]:          # prototype pollution effect
            c = STATE["polluted_status"]
        b = json.dumps(o).encode()
        self.send_response(c); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b))); self.end_headers()
        self.wfile.write(b)

    def _redirect(self, to):
        self.send_response(302); self.send_header("Location", to)
        self.send_header("Content-Length", "0"); self.end_headers()

    # ---------------- POST ----------------
    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n).decode() if n else "{}"
        p = urlsplit(self.path).path
        who = self._who()

        # prototype pollution sink (non-destructive 'status' technique)
        try:
            d = json.loads(raw)
        except Exception:
            d = {}
        proto = d.get("__proto__") or (d.get("constructor") or {}).get("prototype")
        if isinstance(proto, dict) and "status" in proto:
            STATE["polluted_status"] = proto["status"] if proto["status"] != 200 else None
            return self._j(200, {"ok": True})

        if p == "/api/coupon/redeem":
            # BUG: no single-use check
            STATE["coupon_redeemed"] = True
            return self._j(200, {"redeemed": True, "discount": 50,
                                 "status": "applied"})
        if p == "/api/verify":
            if STATE["verified"]:             # DECOY: correctly one-shot
                return self._j(409, {"error": "already verified"})
            STATE["verified"] = True
            return self._j(200, {"verified": True, "status": "verified"})
        self._j(404, {"error": "not found"})

    def do_PATCH(self):
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n).decode() if n else "{}"
        p = urlsplit(self.path).path
        if re.match(r"^/api/orders/\d+$", p):
            try:
                d = json.loads(raw)
            except Exception:
                return self._j(400, {"error": "bad json"})
            # BUG: accepts a client-asserted terminal state
            if "status" in d:
                STATE["order_status"] = d["status"]
            return self._j(200, {"id": "7001", "org": "acme",
                                 "status": STATE["order_status"], "total": 300})
        self._j(404, {"error": "not found"})

    # ---------------- GET ----------------
    def do_GET(self):
        u = urlsplit(self.path); p, q = u.path, parse_qs(u.query)
        who = self._who()
        g = lambda k, d="": (q.get(k) or [d])[0]

        # --- cross-tenant: trusts the X-Org-Id header over the session ----
        for name, store in (("invoices", INVOICES), ("orders", ORDERS),
                            ("statements", STATEMENTS)):
            m = re.match(rf"^/api/billing/{name}/(\d+)$", p)
            if m:
                if not who:
                    return self._j(401, {"error": "unauthorized"})
                obj = store.get(m.group(1))
                if not obj:
                    return self._j(404, {"error": "not found"})
                org = self.headers.get("X-Org-Id") or who[1]
                if org != obj["org"]:          # BUG: header wins over session
                    return self._j(403, {"error": "forbidden"})
                return self._j(200, obj)

        if p == "/api/me":                     # DECOY: correctly scoped
            if not who:
                return self._j(401, {"error": "unauthorized"})
            return self._j(200, {"user": who[0], "org": who[1]})

        if re.match(r"^/api/orders/\d+$", p):
            if not who:
                return self._j(401, {"error": "unauthorized"})
            return self._j(200, {"id": "7001", "org": "acme",
                                 "status": STATE["order_status"], "total": 300})

        # --- OAuth authorize: suffix-append bypass -------------------------
        if p == "/oauth/authorize":
            ru = g("redirect_uri")
            registered = f"{B}/callback"
            ok = ru == registered or ru.startswith(registered)  # BUG: prefix match
            if not ok:
                return self._j(400, {"error": "invalid_request",
                                     "detail": "invalid redirect_uri"})
            return self._redirect(ru + "?code=AUTHCODE" + g("state", ""))

        if p == "/callback":
            return self._j(200, {"ok": True})

        # --- open redirect --------------------------------------------------
        if p == "/go":
            nxt = g("next", "/")
            return self._redirect(nxt)

        if p == "/api/coupon":
            return self._j(200, {"code": "SAVE50",
                                 "redeemed": STATE["coupon_redeemed"]})

        self._j(404, {"error": "not found"})


CAPTURE = [
    ("GET", "/api/billing/invoices/5001", "tokenA", None),
    ("GET", "/api/billing/orders/7001", "tokenA", None),
    ("GET", "/api/billing/statements/9001", "tokenA", None),
    ("GET", "/api/me", "tokenA", None),
    ("GET", "/api/orders/7001", "tokenA", None),
    ("PATCH", "/api/orders/7001", "tokenA", {"status": "pending", "total": 300}),
    ("POST", "/api/coupon/redeem", "tokenA", {"code": "SAVE50", "order": "7001"}),
    ("POST", "/api/verify", "tokenA", {"token": "abc123"}),
    ("GET", "/go?next=/dashboard", "tokenA", None),
    ("GET", "/oauth/authorize?client_id=app1&redirect_uri="
            f"{B}/callback&response_type=code&state=xyz123abc456&scope=openid",
     "tokenA", None),
]


def build_har(path):
    entries = []
    for method, p, tok, body in CAPTURE:
        h = {"Authorization": f"Bearer {tok}", "X-Org-Id": "acme"}
        data = None
        if body is not None:
            data = json.dumps(body).encode(); h["Content-Type"] = "application/json"
        r = urllib.request.Request(B + p, headers=h, data=data, method=method)
        try:
            with urllib.request.urlopen(r) as x:
                st, txt, hd = x.status, x.read().decode(), dict(x.headers)
        except urllib.error.HTTPError as e:
            st, txt, hd = e.code, e.read().decode(), dict(e.headers)
        e = {"request": {"method": method, "url": B + p,
                         "headers": [{"name": k, "value": v} for k, v in h.items()]},
             "response": {"status": st,
                          "headers": [{"name": k, "value": v} for k, v in hd.items()],
                          "content": {"text": txt}}}
        if data:
            e["request"]["postData"] = {"text": data.decode()}
        entries.append(e)
    Path(path).write_text(json.dumps({"log": {"entries": entries}}))


def main():
    srv = HTTPServer(("127.0.0.1", PORT), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    time.sleep(0.6)

    from thor import (corpus, evidence, history, learn, oauth,
                        probes, risk, rootcause, workflow)
    from thor.db import DB
    from thor.scope import Scope

    work = tempfile.mkdtemp(); os.chdir(work)
    Path("scope.yaml").write_text(
        "engagement: v3\nallowed_hosts: ['127.0.0.1']\n"
        "allowed_methods: [GET, HEAD, POST, PUT, PATCH, OPTIONS]\n"
        "max_rps: 400\nmax_requests: 40000\n"
        "sensitive: true\nallow_private_targets: true\n")
    sc = Scope.load("scope.yaml")
    db = DB("t.db")
    build_har("a.har")

    for n, t, tenant in (("userA", "tokenA", "acme"), ("userB", "tokenB", "globex")):
        db.ex("INSERT OR REPLACE INTO identities (name, role, tenant, headers) "
              "VALUES (?,?,?,?)", n, "user", tenant,
              json.dumps({"Authorization": f"Bearer {t}", "X-Org-Id": tenant}))
    db.ex("INSERT OR REPLACE INTO identities (name, role, tenant, headers) "
          "VALUES (?,?,?,?)", "anon", "anonymous", "", "{}")

    quiet = lambda *a, **k: None
    corpus.import_har(db, sc, "a.har", "v3", "userA", log=quiet)

    ok = True
    def check(label, cond):
        nonlocal ok
        print(f"  {'PASS' if cond else 'FAIL'}  {label}")
        ok = ok and cond

    # ---------------- risk gate ----------------
    print("\n--- risk gate ---")
    g = risk.gate_for(sc)
    check("sensitive scope permits workflow engine", g.allows("workflow"))
    check("sensitive scope still blocks race (DESTRUCTIVE)", not g.allows("race"))

    # ---------------- history ----------------
    print("\n--- attack-surface memory ---")
    history.take(db, "before", log=quiet)
    db.upsert_asset("new-staging.acme.example", status=200, scheme="https",
                    title="Staging", server="nginx")
    db.add_endpoint("https://new-staging.acme.example/api/v2/export", "GET")
    history.take(db, "after", log=quiet)
    d = history.diff(db, log=quiet)
    check("new asset detected across snapshots",
          any("new-staging" in x for x in d.new_assets))
    check("new endpoint detected", len(d.new_endpoints) >= 1)

    # ---------------- tenant ----------------
    print("\n--- cross-tenant isolation ---")
    tr = probes.tenant(db, sc, "v3", log=quiet)
    check("cross-tenant access detected", tr.get("crossed", 0) >= 1)

    # ---------------- oauth ----------------
    print("\n--- OAuth (RFC 9700) ---")
    orr = oauth.run(db, sc, "v3", log=quiet)
    check("OAuth flow recovered from corpus", orr.get("flows", 0) >= 1)
    check("redirect_uri bypass detected", orr.get("redirect_bypass", 0) >= 1)
    check("missing PKCE reported", orr.get("no_pkce", 0) >= 1)

    # ---------------- workflow ----------------
    print("\n--- workflow / business logic ---")
    wr = workflow.run(db, sc, "v3", log=quiet)
    check("workflow probes were planned", wr.get("probes", 0) >= 1)
    check("workflow invariant violation found", wr.get("violations", 0) >= 1)

    # ---------------- open redirect ----------------
    print("\n--- open redirect ---")
    rr = probes.open_redirect(db, sc, "v3", log=quiet)
    check("open redirect detected", rr.get("vulnerable", 0) >= 1)

    # ---------------- prototype pollution ----------------
    print("\n--- prototype pollution (non-destructive) ---")
    pr = probes.prototype_pollution(db, sc, "v3", log=quiet)
    check("prototype pollution detected", pr.get("polluted", 0) >= 1)
    check("cleanup restored the default", pr.get("cleanup_failed", 0) == 0)
    STATE["polluted_status"] = None

    # ---------------- promote, root cause, chain ----------------
    print("\n--- root-cause grouping ---")
    evidence.promote(db, log=quiet)
    causes = rootcause.analyse(db, log=quiet)
    rootcause.persist(db, causes, log=quiet)
    rc = db.q("SELECT * FROM rootcauses")
    check("root cause groups the billing manifestations", len(rc) >= 1)
    if rc:
        members = json.loads(rc[0]["member_ids"] or "[]")
        check("root cause has 2+ manifestations", len(members) >= 2)
    else:
        check("root cause has 2+ manifestations", False)

    # ---------------- learning ----------------
    print("\n--- outcome learning ---")
    learn.harvest(db, log=quiet)
    arms = learn.load_arms(db)
    check("arms built from experiment outcomes", len(arms) >= 2)
    ranked = learn.rank(db, ["tenant", "oauth", "workflow", "cors"], seed=1)
    check("Thompson sampling returns a full ordering", len(ranked) == 4)
    check("arms with hits have mean > 0.5",
          any(a.mean > 0.5 for a in arms if a.successes > 0))

    findings = db.q("SELECT vuln_class, severity, route FROM findings")
    classes = {f["vuln_class"] for f in findings}
    print(f"\n  findings: {len(findings)}  classes: {sorted(classes)}")
    print(f"  arms: {len(arms)}   root causes: {len(rc)}")
    print("\n" + ("ALL PASS" if ok else "FAILURES PRESENT"))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())


# ---- pytest entry point -------------------------------------------------
import pytest


@pytest.mark.regression
@pytest.mark.lab
@pytest.mark.slow
def test_engines_v3_regression():
    """v3 engines: every assertion in main() must pass."""
    assert main() == 0, "v3 engines regression failed — see stdout"
