"""
Full regression suite against a lab app with a known bug inventory.

Ground truth — 8 planted vulnerabilities and 4 decoys. The decoys matter as
much as the bugs: a tool that reports the decoys is a slop generator.

  PLANTED                                    DECOY (must NOT be reported)
  /api/orders/{id}   IDOR                    /api/profile/{id}  scoped 403
  /api/search?q      SQLi (error + boolean)  /api/docs/{id}     genuinely public
  /api/render?tpl    SSTI + reflected XSS    /api/safe?q        echoes in JSON
  /api/fetch?url     SSRF -> cloud metadata  /api/echo?v        reflects, encoded
  /api/report?file   path traversal
  /api/cart  price   negative-total logic
  /admin             X-Original-URL ACL bypass

Run:  python3 tests/test_full.py
"""
import json
import os
import re
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit
import html

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

PORT = 8921
B = f"http://127.0.0.1:{PORT}"
USERS = {"tokenA": 1, "tokenB": 2}
ORDERS = {"1001": {"id": "1001", "owner": 1, "email": "alice@corp.example",
                   "total": 4210, "card_last4": "9912",
                   "address": "14 Mill Lane, Bristol"}}
PROFILES = {1: {"id": 1, "name": "Alice"}, 2: {"id": 2, "name": "Bob"}}
ROWS = [{"id": 1, "name": "widget"}, {"id": 2, "name": "gadget"}]


class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _who(self):
        return USERS.get(self.headers.get("Authorization", "").replace("Bearer ", ""))

    def _j(self, c, o):
        b = json.dumps(o).encode()
        self.send_response(c); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b))); self.end_headers()
        self.wfile.write(b)

    def _h(self, c, s):
        b = s.encode()
        self.send_response(c); self.send_header("Content-Type", "text/html")
        self.send_header("Content-Length", str(len(b))); self.end_headers()
        self.wfile.write(b)

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n).decode() if n else "{}"
        if urlsplit(self.path).path == "/api/cart":
            try:
                d = json.loads(raw)
                total = float(d.get("price", 10)) * float(d.get("qty", 1))
            except Exception:
                return self._j(400, {"error": "bad input"})
            return self._j(200, {"total": total, "price": d.get("price"),
                                 "qty": d.get("qty"), "status": "ok"})
        self._j(404, {"error": "not found"})

    def do_GET(self):
        u = urlsplit(self.path); p, q = u.path, parse_qs(u.query)
        uid = self._who()
        g = lambda k, d="": (q.get(k) or [d])[0]

        if m := re.match(r"^/api/orders/(\d+)$", p):           # PLANTED: IDOR
            if not uid: return self._j(401, {"error": "unauthorized"})
            o = ORDERS.get(m.group(1))
            return self._j(200, o) if o else self._j(404, {"error": "nf"})
        if m := re.match(r"^/api/profile/(\d+)$", p):          # DECOY: scoped
            if not uid: return self._j(401, {"error": "unauthorized"})
            if int(m.group(1)) != uid: return self._j(403, {"error": "forbidden"})
            return self._j(200, PROFILES[uid])
        if m := re.match(r"^/api/docs/(\d+)$", p):             # DECOY: public
            return self._j(200, {"id": m.group(1), "title": "Terms",
                                 "body": "Public.", "address": "1 Corp Plaza"})
        if p == "/api/search":                                 # PLANTED: SQLi
            s = g("q", "")
            if "'" in s and s.count("'") % 2 == 1:
                return self._h(500, "<pre>You have an error in your SQL syntax; "
                                    "check the manual that corresponds to your "
                                    "MySQL server version</pre>")
            if re.search(r"AND\s+'?1'?\s*=\s*'?2'?", s, re.I):
                return self._j(200, {"results": [], "count": 0})
            return self._j(200, {"results": ROWS, "count": len(ROWS)})
        if p == "/api/safe":                                   # DECOY: JSON echo
            return self._j(200, {"echo": g("q", ""), "results": ROWS})
        if p == "/api/render":                                 # PLANTED: SSTI+XSS
            t = g("tpl", "hello")
            if m2 := re.fullmatch(r"\{\{\s*(\d+)\s*\*\s*(\d+)\s*\}\}", t):
                return self._h(200, f"<p>{int(m2.group(1))*int(m2.group(2))}</p>")
            return self._h(200, f"<p>{t}</p>")
        if p == "/api/echo":                                   # DECOY: encoded
            return self._h(200, f"<p>{html.escape(g('v',''))}</p>")
        if p == "/api/fetch":                                  # PLANTED: SSRF
            url = g("url", "")
            if not url.startswith(("http://", "https://")):
                return self._j(400, {"error": "bad url"})
            if "169.254.169.254" in url:
                return self._j(200, {"body": "ami-id\ninstance-identity\n"
                                             "iam/security-credentials/role-x"})
            return self._j(502, {"error": "upstream unreachable"})
        if p == "/api/report":                                 # PLANTED: traversal
            f = g("file", "summary.txt")
            if "etc/passwd" in f or "etc%2fpasswd" in f.lower():
                return self._h(200, "root:x:0:0:root:/root:/bin/bash")
            return self._h(200, f"<p>report {html.escape(f)}</p>")
        if p == "/admin" or p.startswith("/admin/"):           # PLANTED: ACL bypass
            if self.headers.get("X-Original-URL"):
                return self._j(200, {"admin": True, "users": ["alice", "bob"]})
            return self._j(403, {"error": "forbidden"})
        self._j(404, {"error": "not found"})


CAPTURE = [
    ("GET", "/api/orders/1001", None), ("GET", "/api/profile/1", None),
    ("GET", "/api/docs/5000", None), ("GET", "/api/search?q=widget", None),
    ("GET", "/api/safe?q=widget", None), ("GET", "/api/render?tpl=hello", None),
    ("GET", "/api/echo?v=hello", None),
    ("GET", "/api/fetch?url=http://example.com/", None),
    ("GET", "/api/report?file=summary.txt", None), ("GET", "/admin", None),
    ("POST", "/api/cart", {"price": 10.0, "qty": 2, "item": "widget"}),
]


def build_har(path):
    entries = []
    for method, p, body in CAPTURE:
        h = {"Authorization": "Bearer tokenA"}
        data = None
        if body is not None:
            data = json.dumps(body).encode(); h["Content-Type"] = "application/json"
        r = urllib.request.Request(B + p, headers=h, data=data, method=method)
        try:
            with urllib.request.urlopen(r) as x:
                st, txt, hd = x.status, x.read().decode(), dict(x.headers)
        except urllib.error.HTTPError as e:
            st, txt, hd = e.code, e.read().decode(), dict(e.headers)
        e = {"request": {"method": method, "url": B + p,
                         "headers": [{"name": k, "value": v} for k, v in h.items()]},
             "response": {"status": st,
                          "headers": [{"name": k, "value": v} for k, v in hd.items()],
                          "content": {"text": txt}}}
        if data:
            e["request"]["postData"] = {"text": data.decode()}
        entries.append(e)
    Path(path).write_text(json.dumps({"log": {"entries": entries}}))


def main():
    srv = HTTPServer(("127.0.0.1", PORT), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    time.sleep(0.6)

    from thor import chain, detectors, engine, evidence, fuzz, oast, schema
    from thor.db import DB
    from thor.scope import Scope
    from thor import corpus

    work = tempfile.mkdtemp()
    os.chdir(work)
    # Importing credentialed traffic requires somewhere encrypted to put
    # the credentials; THOR refuses to write them to the research database.
    os.environ.setdefault(
        "THOR_VAULT_KEY", "sVJgBCWAe0Zz_9oD9pLQ3k7bYQjFqXZy6mB2nT4uRlA=")
    from thor import vault as _vault
    _v = _vault.default()
    _v.path = Path(work) / "vault.enc"
    _v._key = None
    _v._data = None
    Path("scope.yaml").write_text(
        "engagement: test\nallowed_hosts: ['127.0.0.1']\n"
        "allowed_methods: [GET, HEAD, POST, PUT, PATCH, OPTIONS]\n"
        "max_rps: 400\nmax_requests: 40000\nallow_private_targets: true\n")
    sc = Scope.load("scope.yaml")
    db = DB("t.db")
    build_har("a.har")

    for n, t in (("userA", "tokenA"), ("userB", "tokenB")):
        db.ex("INSERT OR REPLACE INTO identities (name, role, headers) "
              "VALUES (?,?,?)", n, "user",
              json.dumps({"Authorization": f"Bearer {t}"}))
    db.ex("INSERT OR REPLACE INTO identities (name, role, headers) "
          "VALUES (?,?,?)", "anon", "anonymous", "{}")

    quiet = lambda *a, **k: None
    corpus.import_har(db, sc, "a.har", "lab", "userA", log=quiet)

    schemas = schema.infer(db, "lab")
    engine.run_authz(db, sc, "lab", log=quiet)
    engine.run_bfla(db, sc, "lab", log=quiet)
    engine.run_massassign(db, sc, "lab", log=quiet)
    detectors.path_acl(db, sc, "lab", log=quiet)
    res = fuzz.run_fuzz(db, sc, "lab", oast=oast.OASTClient(),
                        max_cases=4000, log=quiet)
    for h in res.hits:
        db.ex("INSERT OR REPLACE INTO experiments (signature, kind, as_identity, "
              "method, url, status, verdict, score, detail) VALUES (?,?,?,?,?,?,?,?,?)",
              f"fuzz:{h['endpoint']}:{h['field']}:{h['oracle']}", h["family"],
              "fuzz", "MUT", h["endpoint"], 0,
              "leak" if h["confidence"] >= 0.55 else "inconclusive",
              h["confidence"],
              json.dumps({"reasons": [h["signal"]], "oracle": h["oracle"],
                          "payload": h["payload"], "field": h["field"],
                          "intent": h["intent"], "shared_values": [], "pii": [],
                          "detail": h["detail"]}))
    evidence.promote(db, log=quiet)
    # A chain may only be built from links that have themselves reached
    # VERIFIED -- a chain of unproven steps proves nothing, and that is how
    # a pile of candidates becomes a fictional critical. So the state
    # machine runs first, exactly as `thor chain` and the loop do.
    from thor import states
    states.advance_all(db, log=quiet)
    chain.persist(db, chain.find_chains(db, log=quiet), log=quiet)

    findings = [dict(r) for r in db.q("SELECT * FROM findings")]
    classes = {f["vuln_class"] for f in findings}
    routes = " ".join(f["route"] or "" for f in findings)
    blob = json.dumps(findings)

    ok = True

    def check(label, cond):
        nonlocal ok
        print(f"  {'PASS' if cond else 'FAIL'}  {label}")
        ok = ok and cond

    print("\n--- schema inference ---")
    fields = {f"{f.loc}:{f.name}": f for s in schemas.values()
              for f in s.fields.values()}
    check("url field tagged 'target'", "target" in fields["query:url"].roles)
    check("file field tagged 'file'", "file" in fields["query:file"].roles)
    check("price field tagged 'money'", "money" in fields["body:price"].roles)

    print("\n--- planted vulnerabilities found (8) ---")
    check("IDOR on /api/orders", "authz" in classes and "/api/orders/" in routes)
    check("SQL injection on /api/search", "sqli" in classes)
    check("SSTI on /api/render", "ssti" in classes)
    check("SSRF -> cloud metadata on /api/fetch", "ssrf" in classes)
    check("path traversal on /api/report", "path" in classes)
    check("negative-total logic on /api/cart",
          "logic" in classes and "total" in blob)
    check("ACL bypass on /admin", "pathacl" in classes)
    check("reflected XSS on /api/render", "xss" in classes)

    print("\n--- decoys correctly ignored (4) ---")
    check("no finding on /api/profile (correctly scoped)",
          "/api/profile" not in routes)
    check("no finding on /api/docs (genuinely public)", "/api/docs" not in routes)
    check("no XSS on /api/safe (JSON echo, not a render context)",
          not re.search(r"api/safe.{0,200}xss", blob, re.S))
    check("no XSS on /api/echo (HTML-encoded)", "/api/echo" not in routes)

    print("\n--- evidence discipline ---")
    idor = next((f for f in findings if f["vuln_class"] == "authz"), None)
    check("IDOR ran the anonymous disproof", bool(idor and idor["disproof_done"]))
    check("IDOR severity escalated by PII", bool(idor and idor["severity"] == "critical"))
    check("every finding carries evidence ids",
          all(json.loads(f["evidence_ids"] or "[]") for f in findings))
    check("SSTI proved by computation, not echo",
          "1337" in blob and "rendered as 1337" in blob)
    check("SQLi proved by error + boolean oracle, not payload echo",
          "only under mutation" in blob or "evaluated server-side" in blob)
    # An ACL bypass onto an admin route is ONE bug, not two. It used to
    # produce a second `chain` finding hard-coded to critical -- the same
    # defect submitted twice, the copy claiming a severity nothing
    # measured. It is now a severity escalation on the finding itself,
    # under a named rule that is recorded and can be argued with.
    from thor import chain as _chain
    pathacl = next((f for f in findings if f["vuln_class"] == "pathacl"), None)
    esc = _chain.escalations_for(db, pathacl["id"]) if pathacl else []
    check("ACL bypass on an admin route is escalated, not duplicated",
          bool(esc) and "chain" not in classes)
    check("the escalation names the rule that caused it",
          bool(esc) and bool(esc[0]["rule"]) and bool(esc[0]["reason"]))
    check("escalation raised the severity by one documented step",
          bool(esc) and esc[0]["from_sev"] != esc[0]["to_sev"])

    print(f"\n  fuzz: {res.cases} cases -> {len(res.hits)} hits")
    print(f"  findings: {len(findings)}  classes: {sorted(classes)}")
    print("\n" + ("ALL PASS" if ok else "FAILURES PRESENT"))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())


# ---- pytest entry point -------------------------------------------------
import pytest


@pytest.mark.regression
@pytest.mark.lab
@pytest.mark.slow
def test_pipeline_regression():
    """full pipeline: every assertion in main() must pass."""
    assert main() == 0, "full pipeline regression failed — see stdout"
