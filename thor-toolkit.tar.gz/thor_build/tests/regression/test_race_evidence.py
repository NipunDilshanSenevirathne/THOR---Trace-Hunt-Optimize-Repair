"""
A race finding needs a state change, not two 200s.

The engine used to report any case where more than one concurrent request
returned success. An idempotent endpoint -- PUT /profile, a re-submitted
vote, anything meant to accept repeats -- returns 200 to every copy, so
that rule reports a TOCTOU window on endpoints that have no window at all.
For a bug bounty hunter that is worse than missing the bug: it is a report
that gets closed as informative and costs signal.

The evidence now has to contain a contradiction: the server enforces
single-use when the request is repeated SEQUENTIALLY, and fails to enforce
it under CONCURRENCY. Two planted endpoints, one of each.
"""

from __future__ import annotations

import json
import re
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

PORT = 8961
B = f"http://127.0.0.1:{PORT}"

_lock = threading.Lock()
STATE = {"coupon_redeemed": False, "profile_writes": 0, "coupon_grants": 0}
# A real TOCTOU: the check and the write are not atomic, and a sleep
# between them widens the window the way a slow database read would.
_gate = threading.Event()


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _j(self, code, obj):
        b = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_POST(self):
        p = urlsplit(self.path).path
        if p == "/api/coupon/redeem":
            already = STATE["coupon_redeemed"]        # check
            threading.Event().wait(0.03)              # ... window ...
            if already:
                return self._j(409, {"error": "coupon already redeemed"})
            with _lock:
                STATE["coupon_redeemed"] = True       # write
                STATE["coupon_grants"] += 1
            return self._j(200, {"granted": True})
        if p == "/api/profile/submit":
            with _lock:
                STATE["profile_writes"] += 1
            return self._j(200, {"saved": True})      # idempotent by design
        self._j(404, {"error": "nf"})

    do_PUT = do_POST


@pytest.fixture(scope="module")
def lab():
    # a single-threaded server serialises the burst, so nothing
    # would ever race -- the lab has to be concurrent for the
    # test to mean anything
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    yield B
    srv.shutdown()


def _engagement(tmp_path, monkeypatch):
    from thor import runtime
    from thor.db import DB
    from thor.scope import Scope

    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("THOR_VAULT_KEY",
                       "sVJgBCWAe0Zz_9oD9pLQ3k7bYQjFqXZy6mB2nT4uRlA=")
    Path("scope.yaml").write_text(
        "engagement: race\nallowed_hosts: ['127.0.0.1']\n"
        "allowed_methods: [GET, POST, PUT]\nmax_rps: 0\n"
        "max_requests: 5000\nmax_concurrency: 16\n"
        "sensitive: true\ndestructive: true\nallow_private_targets: true\n")
    sc = Scope.load("scope.yaml")
    db = DB("t.db")
    runtime.reset()
    runtime.bind(sc, db=db)
    for url in (f"{B}/api/coupon/redeem", f"{B}/api/profile/submit"):
        db.ex("INSERT INTO requests (corpus, identity, method, url, headers, "
              "body, status, resp_headers, resp_body, resp_len, object_refs) "
              "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
              "r", "userA", "POST", url, "{}", "{}", 200, "{}", "{}", 2, "[]")
    return db, sc


@pytest.mark.regression
@pytest.mark.lab
def test_real_toctou_is_found_with_a_sequential_control(lab, tmp_path,
                                                        monkeypatch):
    from thor.engine import run_race

    STATE.update(coupon_redeemed=False, profile_writes=0, coupon_grants=0)
    db, sc = _engagement(tmp_path, monkeypatch)
    res = run_race(db, sc, "r", n=10, log=lambda *a, **k: None)

    assert res["suspicious"] >= 1, (
        f"the planted TOCTOU on /api/coupon/redeem was missed: {res}")

    row = db.one("SELECT url, verdict, score, detail FROM experiments "
                 "WHERE kind='race'")
    assert row is not None and "coupon" in row["url"]
    assert row["verdict"] == "leak"
    reasons = " ".join(json.loads(row["detail"])["reasons"]).lower()
    assert "sequential" in reasons, (
        "the finding does not state the sequential control that makes it "
        "a race rather than a repeatable operation")
    assert "409" in reasons, "the serial rejection is not in the evidence"
    assert "control executed" in reasons
    # the server really did grant the coupon more than once
    assert STATE["coupon_grants"] > 1


@pytest.mark.regression
@pytest.mark.lab
def test_idempotent_endpoint_is_not_reported(lab, tmp_path, monkeypatch):
    """The decoy. Accepting repeats is not a vulnerability."""
    from thor.engine import run_race

    STATE.update(coupon_redeemed=True, profile_writes=0, coupon_grants=0)
    db, sc = _engagement(tmp_path, monkeypatch)
    res = run_race(db, sc, "r", n=10, log=lambda *a, **k: None)

    urls = [r["url"] for r in db.q("SELECT url FROM experiments "
                                   "WHERE kind='race'")]
    assert not any("profile" in u for u in urls), (
        "an idempotent endpoint was reported as a race — two 200s is not a "
        "TOCTOU window")
    assert res["idempotent"] >= 1, (
        f"the idempotent endpoint was not recognised as repeatable: {res}")
