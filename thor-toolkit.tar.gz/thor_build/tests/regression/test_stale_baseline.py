"""
The control must be contemporaneous with the probe.

Found by running the tool rather than by reading it. The authz engine used
the *captured* owner response as its control. Captured traffic is routinely
hours old -- you export a Burp session in the evening and hunt overnight --
so by probe time the object has usually moved: a timestamp, a counter, a
field that was added. The shape and value comparison then degrades, a real
IDOR scores below the 0.55 threshold, and it is filed as inconclusive.

That is a silent failure in the under-reporting direction, which is the worst
kind. Nothing in the output says "this was probably a bug and I could not
tell", because from the engine's point of view nothing happened.

Two properties are tested here:

  1. An object that changed since capture is still detected. The engine must
     re-fetch the owner's response now, not trust the capture.
  2. An expired captured session is reported, not silently absorbed. If the
     owner cannot reach their own object any more, every probe against it is
     noise and the operator needs to know to re-capture.
"""

from __future__ import annotations

import json
import re
import sys
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import urlsplit

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

PORT = 8953
B = f"http://127.0.0.1:{PORT}"

# Flipped by a test to simulate the captured session expiring.
OWNER_SESSION_VALID = {"ok": True}

USERS = {"tokenA": ("userA", "acme"), "tokenB": ("userB", "globex")}

# What the live server returns *now*. Deliberately different from what the
# HAR captured: an extra field and a moved counter, exactly as a real object
# drifts between capture and hunt.
LIVE_INVOICE = {"id": "5001", "org": "acme", "amount": 12400,
                "email": "cfo@acme.example", "views": 37,
                "updated": "2026-09-27T11:04:00Z"}

# What the capture recorded, hours earlier.
CAPTURED_INVOICE = {"id": "5001", "org": "acme", "amount": 12400}


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _who(self):
        return USERS.get(
            self.headers.get("Authorization", "").replace("Bearer ", ""))

    def _j(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        p = urlsplit(self.path).path
        who = self._who()
        if re.match(r"^/api/billing/invoices/\d+$", p):
            if not who:
                return self._j(401, {"error": "unauthorized"})
            # userA's session can be expired by a test; userB's cannot.
            if who[0] == "userA" and not OWNER_SESSION_VALID["ok"]:
                return self._j(401, {"error": "session expired"})
            # planted: any authenticated caller receives any invoice
            return self._j(200, LIVE_INVOICE)
        self._j(404, {"error": "nf"})


@pytest.fixture(scope="module")
def lab():
    srv = HTTPServer(("127.0.0.1", PORT), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    yield B
    srv.shutdown()


def _engagement(tmp_path, monkeypatch):
    from thor import identity, vault
    from thor.corpus import import_har
    from thor.db import DB
    from thor.scope import Scope

    monkeypatch.chdir(tmp_path)
    # the engine loads identities through the default vault
    monkeypatch.setenv("THOR_VAULT_KEY",
                       "sVJgBCWAe0Zz_9oD9pLQ3k7bYQjFqXZy6mB2nT4uRlA=")
    Path("scope.yaml").write_text(
        "engagement: stale\nallowed_hosts: ['127.0.0.1']\n"
        "allowed_methods: [GET, HEAD, POST, PUT, PATCH, OPTIONS]\n"
        "max_rps: 400\nmax_requests: 40000\n"
        "sensitive: true\nallow_private_targets: true\n")
    Path("a.har").write_text(json.dumps({"log": {"entries": [{
        "request": {"method": "GET", "url": f"{B}/api/billing/invoices/5001",
                    "headers": [{"name": "Authorization",
                                 "value": "Bearer tokenA"}],
                    "postData": {"text": ""}},
        "response": {"status": 200, "content": {
            "text": json.dumps(CAPTURED_INVOICE),
            "mimeType": "application/json"}}}]}}))

    sc = Scope.load("scope.yaml")
    db = DB("t.db")
    v = vault.default()
    v.path = tmp_path / "vault.enc"
    v._key = None
    v._data = None
    quiet = lambda *a, **k: None
    identity.add(db, "userA", {"Authorization": "Bearer tokenA"},
                 role="user", tenant="acme", v=v, log=quiet)
    identity.add(db, "userB", {"Authorization": "Bearer tokenB"},
                 role="user", tenant="globex", v=v, log=quiet)
    identity.add(db, "anon", {}, role="anonymous", v=v, log=quiet)
    import_har(db, sc, "a.har", "stale", "userA", log=quiet)
    return db, sc


@pytest.mark.regression
@pytest.mark.lab
def test_idor_still_found_when_object_changed_since_capture(
        lab, tmp_path, monkeypatch):
    """
    The captured body is three fields; the live object is six. Against the
    stale control this scored inconclusive. Against a refreshed control it is
    a leak, and the disproof still runs.
    """
    from thor.engine import run_authz

    OWNER_SESSION_VALID["ok"] = True
    db, sc = _engagement(tmp_path, monkeypatch)

    res = run_authz(db, sc, "stale", log=lambda *a, **k: None)

    assert res["leaks"] == 1, (
        f"the planted IDOR was missed because the control was stale: {res}")
    assert res["stale"] == 0

    row = db.one("SELECT * FROM experiments WHERE as_identity='userB'")
    assert row["verdict"] == "leak"

    # and the anonymous disproof was actually executed, not assumed
    assert db.one("SELECT COUNT(*) c FROM experiments "
                  "WHERE as_identity='anon'")["c"] >= 1


@pytest.mark.regression
@pytest.mark.lab
def test_evidence_bundle_baseline_matches_what_was_compared(
        lab, tmp_path, monkeypatch):
    """
    The bundle's owner-baseline step must carry the contemporaneous control,
    not the captured response.

    A triager runs replay.sh. If the very first step prints DIFFERS -- which
    it does when the expectation came from an hours-old capture -- they stop
    reading, and a correct finding gets closed as unreproducible. The
    expectation has to be what the engine actually judged against.
    """
    from thor import evidence as ev
    from thor.engine import run_authz

    OWNER_SESSION_VALID["ok"] = True
    db, sc = _engagement(tmp_path, monkeypatch)
    quiet = lambda *a, **k: None
    run_authz(db, sc, "stale", log=quiet)
    ev.promote(db, log=quiet)

    fid = db.one("SELECT id FROM findings")["id"]
    out = ev.bundle(db, fid, tmp_path / "bundle")

    steps = json.loads((out / "request.json").read_text())["steps"]
    base = next(s for s in steps if s["label"] == "owner baseline")
    probe = next(s for s in steps if s["label"].startswith("probe"))

    live_sha = __import__("hashlib").sha256(
        json.dumps(LIVE_INVOICE).encode()).hexdigest()
    captured_sha = __import__("hashlib").sha256(
        json.dumps(CAPTURED_INVOICE).encode()).hexdigest()

    assert base["expected_sha256"] == live_sha, (
        "the baseline step expects the captured body; replaying this bundle "
        "prints DIFFERS on step one and the finding reads as unreproducible")
    assert base["expected_sha256"] != captured_sha
    assert base["expected_bytes"] == len(json.dumps(LIVE_INVOICE))

    # the probe step is unchanged -- it was always observed live
    assert probe["expected_sha256"] == live_sha


@pytest.mark.regression
@pytest.mark.lab
def test_report_reproduction_shows_the_control_not_the_capture(
        lab, tmp_path, monkeypatch):
    """
    The written report's step 1 must state the control's observation.

    Printing "owner: 46 bytes" then "attacker: 75 bytes" when both in fact
    returned the same 75-byte object reads as two different objects. A
    triager closes the report on that line and never reaches the evidence.
    """
    from thor import evidence as ev
    from thor import report as rep
    from thor.engine import run_authz

    OWNER_SESSION_VALID["ok"] = True
    db, sc = _engagement(tmp_path, monkeypatch)
    quiet = lambda *a, **k: None
    run_authz(db, sc, "stale", log=quiet)
    ev.promote(db, log=quiet)

    fid = db.one("SELECT id FROM findings")["id"]
    path = rep.render(db, fid, outdir=tmp_path / "reports")
    text = Path(path).read_text()

    live_len = len(json.dumps(LIVE_INVOICE))
    captured_len = len(json.dumps(CAPTURED_INVOICE))
    repro = text.split("## Reproduction", 1)[1].split("## ", 1)[0]

    assert f"{live_len} bytes" in repro
    assert f"{captured_len} bytes" not in repro, (
        "the report states the captured length for the owner step; the two "
        "steps then look like different objects")
    # both steps describe the same observation
    assert repro.count(f"{live_len} bytes") >= 2


@pytest.mark.regression
@pytest.mark.lab
def test_expired_owner_session_is_reported_not_absorbed(
        lab, tmp_path, monkeypatch):
    """
    If the owner cannot reach their own object, every probe against it is
    meaningless. The engine must skip and say so rather than quietly
    producing denied verdicts that look like a well-secured endpoint.
    """
    from thor.engine import run_authz

    OWNER_SESSION_VALID["ok"] = False
    try:
        db, sc = _engagement(tmp_path, monkeypatch)
        lines: list[str] = []
        res = run_authz(db, sc, "stale", log=lambda m="", *a, **k: lines.append(str(m)))
    finally:
        OWNER_SESSION_VALID["ok"] = True

    assert res["stale"] == 1, f"expired owner session was not detected: {res}"
    assert res["tested"] == 0, "probes ran against a dead session"
    assert res["denied"] == 0, (
        "a dead session produced 'denied' verdicts — that reads as a secure "
        "endpoint and is exactly the wrong conclusion")

    blob = "\n".join(lines).lower()
    assert "re-capture" in blob, (
        "the operator was not told to re-capture; the run looks clean but is "
        f"worthless:\n{blob}")
