"""
v4 regression: knowledge graph, invariants, reasoning, source and mobile
correlation, and the audit trail.

Ground truth is a lab application plus a small source tree that disagrees
with it in specific, planted ways.
"""

import json
import os
import re
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
import zipfile
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import urlsplit

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

PORT = 8941
B = f"http://127.0.0.1:{PORT}"

USERS = {"tokenA": ("userA", "acme"), "tokenB": ("userB", "globex")}
INVOICES = {"5001": {"id": "5001", "org": "acme", "email": "cfo@acme.example",
                     "amount": 12400}}
ORDERS = {"7001": {"id": "7001", "org": "acme", "status": "pending",
                   "total": 300}}


class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _who(self):
        return USERS.get(self.headers.get("Authorization", "").replace("Bearer ", ""))

    def _j(self, c, o):
        b = json.dumps(o).encode()
        self.send_response(c); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b))); self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        p = urlsplit(self.path).path
        who = self._who()
        if m := re.match(r"^/api/billing/invoices/(\d+)$", p):
            if not who:
                return self._j(401, {"error": "unauthorized"})
            o = INVOICES.get(m.group(1))
            if not o:
                return self._j(404, {"error": "nf"})
            org = self.headers.get("X-Org-Id") or who[1]
            if org != o["org"]:
                return self._j(403, {"error": "forbidden"})
            return self._j(200, o)
        if m := re.match(r"^/api/orders/(\d+)$", p):
            if not who:
                return self._j(401, {"error": "unauthorized"})
            return self._j(200, ORDERS["7001"])
        if p == "/api/admin/export":     # source says guarded; runtime is open
            return self._j(200, {"rows": 4210, "export": "full"})
        if p == "/api/me":
            if not who:
                return self._j(401, {"error": "unauthorized"})
            return self._j(200, {"user": who[0], "org": who[1]})
        self._j(404, {"error": "not found"})


# A source tree that disagrees with the runtime in planted ways.
SOURCE = {
    "src/routes/billing.js": """
const router = require('express').Router();

// sibling routes carry requireAuth + requireTenant
router.get('/api/billing/statements/:id', requireAuth, requireTenant, (req,res) => {
  const s = db.findById(req.params.id, { tenant: req.user.tenant });
  res.json(s);
});

router.get('/api/billing/orders/:id', requireAuth, requireTenant, (req,res) => {
  const o = db.findById(req.params.id, { tenant: req.user.tenant });
  res.json(o);
});

router.get('/api/billing/reports/:id', requireAuth, requireTenant, (req,res) => {
  const r = db.findById(req.params.id, { tenant: req.user.tenant });
  res.json(r);
});

// PLANTED: no guard, and the lookup has no tenant argument
router.get('/api/billing/invoices/:id', (req, res) => {
  const inv = db.findById(req.params.id);
  res.json(inv);
});

module.exports = router;
""",
    "src/routes/admin.js": """
const router = require('express').Router();

// PLANTED: source declares a guard, runtime serves it unauthenticated
router.get('/api/admin/export', requireAuth, requireRole('admin'), (req,res) => {
  res.json(exportAll());
});

// PLANTED: exists in source, never observed in traffic
router.post('/api/admin/impersonate', requireAuth, (req,res) => {
  res.json(impersonate(req.body.userId));
});

module.exports = router;
""",
}


def build_source(root: Path):
    for rel, body in SOURCE.items():
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(body)


def build_apk(path: Path):
    """A minimal APK-shaped archive carrying mobile-only API surface."""
    manifest = (
        b'<?xml version="1.0"?><manifest package="com.acme.mobile">'
        b'<application android:usesCleartextTraffic="true">'
        b'<activity android:name=".DeepLinkActivity" android:exported="true"/>'
        b'</application></manifest>')
    strings = (
        b'https://127.0.0.1:%d/api/mobile/v1/sync\x00'
        b'"/api/internal/bulk-export"\x00'
        b'"/api/billing/invoices"\x00'
        b'"X-App-Version"\x00"X-Device-Id"\x00'
        b'"acmeapp://"\x00'
        b'AKIA4KPQR7TZM3WXCVBN\x00' % PORT)
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("AndroidManifest.xml", manifest)
        z.writestr("classes.dex", strings)


CAPTURE = [
    ("GET", "/api/billing/invoices/5001", "tokenA"),
    ("GET", "/api/orders/7001", "tokenA"),
    ("GET", "/api/me", "tokenA"),
    ("GET", "/api/admin/export", None),      # anon reaches it
]


def build_har(path):
    entries = []
    for method, p, tok in CAPTURE:
        h = {"X-Org-Id": "acme"}
        if tok:
            h["Authorization"] = f"Bearer {tok}"
        r = urllib.request.Request(B + p, headers=h, method=method)
        try:
            with urllib.request.urlopen(r) as x:
                st, txt, hd = x.status, x.read().decode(), dict(x.headers)
        except urllib.error.HTTPError as e:
            st, txt, hd = e.code, e.read().decode(), dict(e.headers)
        entries.append({
            "request": {"method": method, "url": B + p,
                        "headers": [{"name": k, "value": v} for k, v in h.items()]},
            "response": {"status": st,
                         "headers": [{"name": k, "value": v} for k, v in hd.items()],
                         "content": {"text": txt}}})
    Path(path).write_text(json.dumps({"log": {"entries": entries}}))


def main():
    srv = HTTPServer(("127.0.0.1", PORT), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    time.sleep(0.5)

    from cryptography.fernet import Fernet
    os.environ["THOR_VAULT_KEY"] = Fernet.generate_key().decode()

    from thor import (audit, graph, identity, invariants, mobile, probes,
                      reason, sourceintel, vault)
    from thor.corpus import import_har
    from thor.db import DB
    from thor.scope import Scope

    work = tempfile.mkdtemp(); os.chdir(work)
    Path("scope.yaml").write_text(
        "engagement: v4\nallowed_hosts: ['127.0.0.1']\n"
        "allowed_methods: [GET, HEAD, POST, PUT, PATCH, OPTIONS]\n"
        "max_rps: 400\nmax_requests: 40000\n"
        "sensitive: true\nallow_private_targets: true\n")
    sc = Scope.load("scope.yaml")
    db = DB("t.db")
    # The engines resolve identities through the DEFAULT vault, so the test
    # vault has to be the default one. Passing v= only to identity.add()
    # meant the engines could not find the credentials at all -- and
    # because resolution used to fail silently, every probe went out
    # anonymous and the suite stayed green.
    v = vault.default()
    v.path = Path(work) / "vault.enc"
    v._key = None
    v._data = None
    quiet = lambda *a, **k: None

    build_har("a.har")
    build_source(Path(work) / "app")
    build_apk(Path(work) / "app.apk")

    identity.add(db, "userA", {"Authorization": "Bearer tokenA",
                               "X-Org-Id": "acme"},
                 role="user", tenant="acme", v=v, log=quiet)
    identity.add(db, "userB", {"Authorization": "Bearer tokenB",
                               "X-Org-Id": "globex"},
                 role="user", tenant="globex", v=v, log=quiet)
    identity.add(db, "anon", {}, role="anonymous", v=v, log=quiet)

    import_har(db, sc, "a.har", "v4", "userA", log=quiet)

    ok = True
    def check(label, cond):
        nonlocal ok
        print(f"  {'PASS' if cond else 'FAIL'}  {label}")
        ok = ok and cond

    # ---------------- vault-backed identities ----------------
    print("\n--- credential isolation ---")
    # Read EVERY database artifact, not just the main file. SQLite in WAL
    # mode keeps recent writes in t.db-wal, so the original version of this
    # assertion read a 4 KB header while 144 KB of secrets sat next to it
    # and passed for months.
    raw = b"".join(p.read_bytes() for p in Path(work).glob("t.db*"))
    check("no bearer token in any research database file",
          b"tokenA" not in raw and b"tokenB" not in raw)
    got = identity.load(db, "userA", v=v)
    check("credentials resolve in memory",
          got.headers.get("Authorization") == "Bearer tokenA")
    check("non-secret headers stay in the db",
          got.headers.get("X-Org-Id") == "acme")

    # ---------------- knowledge graph ----------------
    print("\n--- knowledge graph ---")
    g = graph.build(db, "v4", log=quiet)
    m = graph.model_summary(db)
    check("identities modelled", m["identities"] >= 3)
    check("tenants modelled", m["tenants"] >= 2)
    check("endpoints modelled", m["endpoints"] >= 3)
    check("objects modelled", m["objects"] >= 2)
    check("object-bearing endpoints identified",
          m["object_bearing_endpoints"] >= 1)
    pairs = graph.cross_tenant_pairs(db)
    check("graph names concrete cross-tenant pairs", len(pairs) >= 1)
    rendered = graph.render(db)
    check("graph renders a tenant slice", "Tenant:" in rendered)

    # ---------------- invariants ----------------
    print("\n--- security invariants ---")
    n = invariants.install(db, log=quiet)
    check("catalogue installed", len(invariants.CATALOGUE) >= 20)
    probes.tenant(db, sc, "v4", log=quiet)
    ev = invariants.evaluate(db, log=quiet)
    check("invariants evaluated against experiments",
          ev["violated"] + ev["holds"] >= 1)
    rep = invariants.report(db)
    check("report distinguishes violated from untested",
          "violated" in rep and "untested" in rep)

    # ---------------- reasoning ----------------
    print("\n--- reasoning / information gain ---")
    hyps = reason.generate(db, "v4", log=quiet)
    check("hypotheses generated", len(hyps) >= 2)
    check("hypotheses are ranked by gain",
          all(hyps[i].gain >= hyps[i + 1].gain for i in range(len(hyps) - 1)))
    h = hyps[0]
    check("top hypothesis has a falsifier", bool(h.falsifier))
    check("top hypothesis has a predicted outcome", bool(h.predicted))
    check("gain is decomposed, not a magic number",
          set(h.components) >= {"uncertainty", "boundary_weight", "cost",
                                "risk_penalty", "novelty"})
    txt = reason.report(db, "v4", log=quiet)
    check("reason report shows the application model",
          "APPLICATION MODEL" in txt and "OPEN HYPOTHESES" in txt)

    # ---------------- source correlation ----------------
    print("\n--- source <-> runtime correlation ---")
    routes = sourceintel.scan(Path(work) / "app", log=quiet)
    sourceintel.persist(db, routes, log=quiet)
    check("routes extracted from source", len(routes) >= 5)
    guarded = [r for r in routes if r.guards]
    check("authorisation decorations detected", len(guarded) >= 3)
    corr = sourceintel.correlate(db, "v4", log=quiet)
    check("source matched to runtime endpoints", corr["matched"] >= 1)
    check("unguarded sibling route detected", corr["unguarded"] >= 1)
    check("unscoped object lookup detected", corr["unscoped_sink"] >= 1)
    check("guard mismatch detected (source guards, anon reaches it)",
          corr["guard_mismatch"] >= 1)
    check("orphan route detected (in source, never exercised)",
          corr["orphan"] >= 1)
    sourceintel.promote(db, log=quiet)
    promoted = db.q("SELECT * FROM experiments WHERE "
                    "detail LIKE '%source_runtime_correlation%'")
    check("guard mismatch promoted with runtime evidence", len(promoted) >= 1)

    # ---------------- mobile correlation ----------------
    print("\n--- mobile <-> API correlation ---")
    intel = mobile.analyse(Path(work) / "app.apk", log=quiet)
    check("package identified", intel.package == "com.acme.mobile")
    check("mobile-only API paths extracted", len(intel.paths) >= 2)
    check("mobile-only headers extracted", len(intel.headers) >= 2)
    check("custom URL scheme extracted", "acmeapp" in intel.schemes)
    check("exported component detected", len(intel.exported) >= 1)
    check("cleartext traffic flagged", intel.cleartext_permitted)
    check("secret found in the binary", len(intel.secrets) >= 1)
    ing = mobile.ingest(db, sc, intel, log=quiet)
    check("mobile endpoints ingested into the corpus", ing["endpoints"] >= 2)
    only = mobile.mobile_only_endpoints(db, "v4")
    check("endpoints the web corpus never saw are surfaced", len(only) >= 1)

    # ---------------- audit ----------------
    print("\n--- audit trail ---")
    al = audit.Audit(path=Path(work) / "audit.jsonl", engagement="v4")
    al.event("request.sent", url=f"{B}/x",
             headers={"Authorization": "Bearer MUSTNOTAPPEAR123456"})
    raw_audit = Path(work, "audit.jsonl").read_text()
    check("audit written", len(al.read()) >= 1)
    check("audit redacts credentials", "MUSTNOTAPPEAR" not in raw_audit)
    check("audit summary renders", "by event" in al.summary())

    print(f"\n  graph: {g['nodes']} nodes / {g['edges']} edges")
    print(f"  hypotheses: {len(hyps)}   top gain: {hyps[0].gain if hyps else 0}")
    print(f"  source routes: {len(routes)}   correlations: {corr}")
    print("\n" + ("ALL PASS" if ok else "FAILURES PRESENT"))
    return 0 if ok else 1


@pytest.mark.regression
@pytest.mark.lab
@pytest.mark.slow
def test_v4_regression():
    """v4: graph, invariants, reasoning, source and mobile correlation."""
    assert main() == 0, "v4 regression failed — see stdout"


if __name__ == "__main__":
    raise SystemExit(main())
