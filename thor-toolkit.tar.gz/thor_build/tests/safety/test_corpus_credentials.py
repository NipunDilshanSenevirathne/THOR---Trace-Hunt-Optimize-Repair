"""
Captured credentials must never reach the research database.

This invariant was stated in the README and violated by the code.
`corpus._store()` wrote the captured headers, body, response headers and
response body straight into `requests`, so importing a Burp or HAR export
put the Authorization header, the session cookie and any password posted
to /login into SQLite.

There *was* a test for it. It read `t.db` and asserted the token was
absent. In WAL mode SQLite keeps recent writes in `t.db-wal`, so the test
read a 4 KB file header while 144 KB of secrets sat beside it, and it
passed for months. Every test here reads *every* database artifact.

The research database is not a safe place for this material. It gets
copied between machines, attached to reports, committed by accident and
kept long after the engagement ends.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from thor import corpus, vault
from thor.db import DB
from thor.scope import Scope

pytestmark = pytest.mark.safety

KEY = "sVJgBCWAe0Zz_9oD9pLQ3k7bYQjFqXZy6mB2nT4uRlA="

BEARER = "SUPERSECRET_bearer_aaaaaaaaaaaaaaaaaaaa"
COOKIE = "session=zzzzsessionvaluezzzz9999"
PASSWORD = "correct-horse-battery"
APIKEY = "AKIAIOSFODNN7EXAMPLE"
JWT = ("eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0."
       "dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U")
REFRESH = "rt_9f8e7d6c5b4a39281706"


def _db_bytes(d: Path) -> bytes:
    """Every SQLite artifact: main file, WAL and shared-memory index."""
    return b"".join(p.read_bytes() for p in sorted(d.glob("*.db*")))


@pytest.fixture
def engagement(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("THOR_VAULT_KEY", KEY)
    (tmp_path / "scope.yaml").write_text(
        "engagement: cred\nallowed_hosts: ['127.0.0.1']\n"
        "allowed_methods: [GET, POST]\nmax_rps: 0\nmax_requests: 100\n"
        "allow_private_targets: true\n")
    v = vault.default()
    v.path = tmp_path / "vault.enc"
    v._key = None
    v._data = None
    return Scope.load("scope.yaml"), DB("t.db"), tmp_path, v


def _har(entries) -> str:
    return json.dumps({"log": {"entries": entries}})


def _entry(headers, body="", rheaders=None, rbody="{}"):
    return {
        "request": {"method": "POST" if body else "GET",
                    "url": "http://127.0.0.1:8999/api/thing/1",
                    "headers": [{"name": k, "value": v}
                                for k, v in headers.items()],
                    "postData": {"text": body}},
        "response": {"status": 200,
                     "headers": [{"name": k, "value": v}
                                 for k, v in (rheaders or {}).items()],
                     "content": {"text": rbody,
                                 "mimeType": "application/json"}},
    }


@pytest.mark.parametrize("label,entry,secret", [
    ("authorization header",
     _entry({"Authorization": f"Bearer {BEARER}"}), BEARER),
    ("session cookie",
     _entry({"Cookie": COOKIE}), "zzzzsessionvaluezzzz9999"),
    ("password in a request body",
     _entry({}, json.dumps({"user": "a", "password": PASSWORD})), PASSWORD),
    ("api key in a request body",
     _entry({}, json.dumps({"api_key": APIKEY})), APIKEY),
    ("jwt in a response body",
     _entry({}, "", None, json.dumps({"id_token": JWT})), JWT),
    ("refresh token in a response body",
     _entry({}, "", None, json.dumps({"refresh_token": REFRESH})), REFRESH),
    ("set-cookie in a response header",
     _entry({}, "", {"Set-Cookie": COOKIE}), "zzzzsessionvaluezzzz9999"),
    ("form-encoded password",
     _entry({}, f"user=a&password={PASSWORD}"), PASSWORD),
])
def test_secret_never_lands_in_the_database(engagement, label, entry, secret):
    sc, db, work, _v = engagement
    Path("a.har").write_text(_har([entry]))
    corpus.import_har(db, sc, "a.har", "c", "userA", log=lambda *a, **k: None)
    db.conn.commit()

    raw = _db_bytes(work)
    assert secret.encode() not in raw, (
        f"{label}: the secret is in the research database")


def test_import_refuses_rather_than_storing_plaintext(tmp_path, monkeypatch):
    """
    If credentials cannot be vaulted, the import must fail — not fall back
    to writing them in the clear and redacting at report time. Redaction on
    the way out does not help a database file that gets copied.
    """
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("THOR_VAULT_KEY", raising=False)
    monkeypatch.delenv("THOR_VAULT_PASSPHRASE", raising=False)
    (tmp_path / "scope.yaml").write_text(
        "engagement: cred\nallowed_hosts: ['127.0.0.1']\n"
        "allowed_methods: [GET, POST]\nmax_rps: 0\nmax_requests: 100\n"
        "allow_private_targets: true\n")
    v = vault.default()
    v.path = tmp_path / "nope" / "vault.enc"
    v._key = None
    v._data = None
    monkeypatch.setattr(vault.Vault, "store_artifact",
                        lambda *a, **k: (_ for _ in ()).throw(
                            vault.VaultUnavailable("no crypto")))

    sc, db = Scope.load("scope.yaml"), DB("t.db")
    Path("a.har").write_text(_har([_entry({"Authorization": f"Bearer {BEARER}"})]))

    with pytest.raises(SystemExit) as ei:
        corpus.import_har(db, sc, "a.har", "c", "userA",
                          log=lambda *a, **k: None)
    assert "plaintext" in str(ei.value).lower()
    assert BEARER.encode() not in _db_bytes(tmp_path)


def test_structure_survives_sanitisation(engagement):
    """
    Sanitising must not break the model. Object references, schema
    inference and response comparison all read these rows, so the shape has
    to be preserved — only the credential values change.
    """
    sc, db, _work, _v = engagement
    body = json.dumps({"invoice_id": "5001", "amount": 12400,
                       "password": PASSWORD})
    Path("a.har").write_text(_har([_entry(
        {"Authorization": f"Bearer {BEARER}", "X-Org-Id": "acme"}, body)]))
    corpus.import_har(db, sc, "a.har", "c", "userA", log=lambda *a, **k: None)

    r = db.one("SELECT * FROM requests")
    stored = json.loads(r["body"])
    assert stored["invoice_id"] == "5001", "object reference was destroyed"
    assert stored["amount"] == 12400, "business field was destroyed"
    assert PASSWORD not in r["body"]

    hdrs = json.loads(r["headers"])
    assert hdrs["X-Org-Id"] == "acme", "non-secret header was destroyed"
    assert BEARER not in r["headers"]

    # the object reference was still extracted
    assert "5001" in (r["object_refs"] or "")


def test_same_credential_stays_correlatable(engagement):
    """
    Two requests carrying the same session must still be recognisable as
    the same session, or tenancy modelling breaks. Fingerprints are stable
    for this reason; dropping the values would have lost the relationship.
    """
    sc, db, _work, _v = engagement
    e = _entry({"Authorization": f"Bearer {BEARER}"})
    Path("a.har").write_text(_har([e, dict(e)]))
    corpus.import_har(db, sc, "a.har", "c", "userA", log=lambda *a, **k: None)

    rows = db.q("SELECT headers FROM requests")
    vals = {json.loads(r["headers"])["Authorization"] for r in rows}
    assert len(vals) == 1, "the same token produced different placeholders"
    assert "vaulted:" in vals.pop()


def test_original_is_recoverable_for_replay(engagement):
    """
    Sanitising the database must not destroy the capture. A replay that
    genuinely needs the original asks the vault, explicitly.
    """
    sc, db, _work, v = engagement
    Path("a.har").write_text(_har([_entry(
        {"Authorization": f"Bearer {BEARER}"},
        json.dumps({"password": PASSWORD}))]))
    corpus.import_har(db, sc, "a.har", "c", "userA", log=lambda *a, **k: None)

    rid = db.one("SELECT id FROM requests")["id"]
    orig = corpus.original(db, rid, v=v)
    assert orig is not None
    assert BEARER in json.dumps(orig["headers"])
    assert PASSWORD in orig["body"]


def test_hash_of_the_original_is_kept(engagement):
    """
    The replay proves it reproduced the request by hash. Sanitising would
    have changed the bytes, so the hash must be of the original.
    """
    import hashlib
    sc, db, _work, _v = engagement
    body = json.dumps({"password": PASSWORD})
    Path("a.har").write_text(_har([_entry({}, body)]))
    corpus.import_har(db, sc, "a.har", "c", "userA", log=lambda *a, **k: None)

    r = db.one("SELECT body, body_sha256 FROM requests")
    assert r["body_sha256"] == hashlib.sha256(body.encode()).hexdigest()
    assert r["body_sha256"] != hashlib.sha256(r["body"].encode()).hexdigest()
