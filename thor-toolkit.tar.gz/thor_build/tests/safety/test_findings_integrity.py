"""
Three ways a finding could become true without evidence.

1. The AI proposed an attack chain and `chain.persist()` inserted it
   straight into `findings` -- with `disproof_done=1` and the model's own
   severity. A model could produce a critical finding that claimed its own
   disproof had been executed. The module docstring said "No chain is
   inferred from a model's narrative" the whole time.

2. `rootcause.persist()` wrote `findings.status = 'grouped'`, bypassing
   the only function allowed to write status -- and 'grouped' is not a
   state, so every finding it touched fell out of the lifecycle and could
   never reach report_ready.

3. The dedupe gate returned True whenever the `rootcauses` table existed.
   Every finding passed it at once, because one unrelated finding had been
   analysed. A gate a finding passes for someone else's reason is not a
   gate.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from thor import ai, chain, rootcause, states
from thor.db import DB

pytestmark = pytest.mark.safety


@pytest.fixture
def db(tmp_path):
    return DB(str(tmp_path / "t.db"))


def _experiment(db, sig="s1", url="http://x.example/api/a/1"):
    return db.ex(
        "INSERT INTO experiments (signature,kind,as_identity,method,url,"
        "status,resp_sha256,resp_len,verdict,score,detail,dest_address) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
        sig, "authz", "userB", "GET", url, 200, "aa", 10, "leak", 0.9,
        json.dumps({"reasons": ["disproof passed: anonymous request did NOT "
                                "return the resource"]}), "93.184.216.34")


def _finding(db, n, severity="low", status=states.CANDIDATE, ev=None):
    return db.ex(
        "INSERT INTO findings (fingerprint,vuln_class,severity,title,asset,"
        "route,summary,evidence_ids,disproof_done,status) "
        "VALUES (?,?,?,?,?,?,?,?,?,?)",
        f"fp{n}", "authz", severity, f"finding {n}", "x.example",
        f"/api/{n}/{{id}}", "s", json.dumps(ev or []), 1, status)


# ───────────────────────── 1. AI chains ──────────────────────────

def test_ai_chain_over_unverified_findings_creates_no_finding(db, tmp_path):
    e = _experiment(db)
    _finding(db, 1, ev=[e])
    _finding(db, 2, ev=[e])
    before = db.one("SELECT COUNT(*) c FROM findings")["c"]

    ans = tmp_path / "chains.json"
    ans.write_text(json.dumps({"chains": [{
        "name": "Invented takeover", "severity": "critical",
        "finding_ids": [1, 2], "walkthrough": "the model asserts these combine",
    }]}))
    ai.apply_answer(db, "chains", ans, log=lambda *a, **k: None)

    assert db.one("SELECT COUNT(*) c FROM findings")["c"] == before, (
        "the AI created a finding through the chains path")
    cand = db.one("SELECT status, source FROM chain_candidates")
    assert cand["source"] == "ai"
    assert cand["status"] == "proposed"


def test_verified_chain_takes_severity_from_its_links_not_the_proposer(
        db, tmp_path):
    e = _experiment(db)
    _finding(db, 1, severity="medium", status=states.VERIFIED, ev=[e])
    _finding(db, 2, severity="high", status=states.VERIFIED, ev=[e])

    ans = tmp_path / "chains.json"
    ans.write_text(json.dumps({"chains": [{
        "name": "Account takeover", "severity": "critical",
        "finding_ids": [1, 2], "walkthrough": "step one then step two",
    }]}))
    ai.apply_answer(db, "chains", ans, log=lambda *a, **k: None)

    row = db.one("SELECT severity FROM findings WHERE vuln_class='chain'")
    assert row is not None, "a chain over verified links should verify"
    assert row["severity"] == "high", (
        f"severity {row['severity']!r} — the model asked for 'critical' and "
        f"got it; severity must come from the links")


def test_chain_never_claims_a_disproof_its_links_did_not_run(db, tmp_path):
    e = _experiment(db)
    _finding(db, 1, severity="high", status=states.VERIFIED, ev=[e])
    fid2 = _finding(db, 2, severity="high", status=states.VERIFIED, ev=[e])
    db.ex("UPDATE findings SET disproof_done=0 WHERE id=?", fid2)

    chain.propose(db, [chain.Chain("C", "critical", "n", [1, fid2], [e], "r")],
                  source="rule", log=lambda *a, **k: None)
    chain.verify_all(db, log=lambda *a, **k: None)

    row = db.one("SELECT disproof_done FROM findings WHERE vuln_class='chain'")
    assert row["disproof_done"] == 0, (
        "the chain claims a disproof that one of its links never ran")


def test_single_link_chain_escalates_rather_than_duplicating(db):
    e = _experiment(db)
    fid = _finding(db, 1, severity="high", status=states.VERIFIED, ev=[e])
    chain.propose(db, [chain.Chain(
        "Administrative surface exposure", "critical", "narrative",
        [fid], [e], "ACL bypass lands on an administrative path")],
        source="rule", log=lambda *a, **k: None)

    assert db.one("SELECT COUNT(*) c FROM findings WHERE vuln_class='chain'"
                  )["c"] == 0, "a one-link chain created a duplicate finding"
    esc = chain.escalations_for(db, fid)
    assert esc and esc[0]["from_sev"] == "high" and esc[0]["to_sev"] == "critical"
    assert esc[0]["rule"] and esc[0]["reason"], "escalation is undocumented"


def test_escalation_is_not_cumulative(db):
    """Running the analysis twice must not walk a finding up the scale."""
    e = _experiment(db)
    fid = _finding(db, 1, severity="low", status=states.VERIFIED, ev=[e])
    c = chain.Chain("rule x", "critical", "n", [fid], [e], "because")
    for _ in range(4):
        chain.propose(db, [c], source="rule", log=lambda *a, **k: None)
    sev = db.one("SELECT severity FROM findings WHERE id=?", fid)["severity"]
    assert sev == "medium", f"severity walked to {sev} on repeated runs"


# ───────────────────── 2. root-cause grouping ────────────────────

def test_grouping_does_not_change_finding_state(db):
    e = _experiment(db)
    ids = [_finding(db, n, status=states.VERIFIED, ev=[e]) for n in range(1, 4)]
    rootcause.persist(db, [rootcause.RootCause(
        title="shared middleware", hypothesis="h", vuln_class="authz",
        severity="high", members=set(ids), traits={}, confidence=0.8)],
        log=lambda *a, **k: None)

    for i in ids:
        st = db.one("SELECT status FROM findings WHERE id=?", i)["status"]
        assert st == states.VERIFIED, (
            f"grouping moved finding {i} to {st!r} — it is metadata, not a "
            f"state, and 'grouped' is not in the lifecycle at all")
        assert st in states.ORDER


def test_grouping_is_recorded_as_a_relation(db):
    e = _experiment(db)
    ids = [_finding(db, n, status=states.VERIFIED, ev=[e]) for n in (1, 2)]
    rootcause.persist(db, [rootcause.RootCause(
        title="shared middleware", hypothesis="h", vuln_class="authz",
        severity="high", members=set(ids), traits={}, confidence=0.8)],
        log=lambda *a, **k: None)
    rc = db.one("SELECT id FROM rootcauses")["id"]
    assert sorted(rootcause.members_of(db, rc)) == sorted(ids)
    assert rootcause.groups_for(db, ids[0]) == [rc]


# ───────────────────────── 3. the gates ──────────────────────────

def test_dedupe_gate_is_per_finding(db):
    """
    One analysed finding must not satisfy the gate for an unrelated one.
    """
    e = _experiment(db)
    a = _finding(db, 1, status=states.VERIFIED, ev=[e])
    b = _finding(db, 2, status=states.VERIFIED, ev=[e])
    states.record_dedupe(db, a, "unique", basis="analysed")

    assert states.evaluate(db, a, states.DEDUPED).moved
    assert not states.evaluate(db, b, states.DEDUPED).moved, (
        "finding b passed the dedupe gate because finding a was analysed")


def test_scope_gate_reads_a_recorded_fact_not_a_substring(db):
    """
    `url LIKE '%asset%'` matched `example.com` inside
    `notexample.com.evil.net`, and blocked findings whose asset string did
    not happen to appear in a URL. The proof is the validated destination
    recorded when the request was actually sent.
    """
    good = _experiment(db, "ok", "http://x.example/api/a/1")
    f_ok = _finding(db, 1, ev=[good])
    assert states.evaluate(db, f_ok, states.VERIFICATION_REQUIRED).moved

    # an experiment that never went through the gate has no destination
    bad = db.ex(
        "INSERT INTO experiments (signature,kind,as_identity,method,url,"
        "status,resp_sha256,verdict,score,detail) VALUES (?,?,?,?,?,?,?,?,?,?)",
        "nogate", "authz", "userB", "GET", "http://x.example/api/b/1", 200,
        "bb", "leak", 0.9, "{}")
    f_bad = _finding(db, 2, ev=[bad])
    r = states.evaluate(db, f_bad, states.VERIFICATION_REQUIRED)
    assert not r.moved
    assert any("destination" in b for b in r.blocked_by)


def test_gate_results_are_recorded_per_finding(db):
    e = _experiment(db)
    fid = _finding(db, 1, ev=[e])
    states.evaluate(db, fid, states.VERIFICATION_REQUIRED)
    rows = states.gate_results(db, fid)
    assert rows, "no gate results recorded"
    assert all(r["checker_version"] for r in rows), (
        "a gate result without a checker version cannot be re-judged when "
        "the rule changes")


def test_replayable_requires_a_hash_to_compare_against(db):
    """'It returned 200' is not a reproduction."""
    e = db.ex(
        "INSERT INTO experiments (signature,kind,as_identity,method,url,"
        "status,verdict,score,detail,dest_address) VALUES (?,?,?,?,?,?,?,?,?,?)",
        "nohash", "authz", "userB", "GET", "http://x.example/a", 200,
        "leak", 0.9, "{}", "93.184.216.34")
    fid = _finding(db, 1, status=states.VERIFICATION_REQUIRED, ev=[e])
    r = states.evaluate(db, fid, states.VERIFIED)
    assert not r.moved
    assert any("replay" in b for b in r.blocked_by)
