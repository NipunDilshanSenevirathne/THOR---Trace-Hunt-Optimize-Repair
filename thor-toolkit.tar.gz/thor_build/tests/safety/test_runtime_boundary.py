"""
The engagement boundary: one budget, one rate limit, one concurrency cap,
and no path around the pinned destination.

These are contractual, not stylistic. A bug bounty program authorises a
number of requests and a rate; exceeding either because the tool counted
per engine is a breach of the authorisation the scope file exists to
honour. "My scanner had a bug" is not a defence anyone accepts.

The defect these lock in: every engine called `Client(scope)`, and
`Client.__init__` did `budget or Budget(scope.max_rps, scope.max_requests)`.
Nineteen engines, nineteen budgets. The `Budget` docstring said "Global
request budget", which is exactly why nobody looked.
"""

from __future__ import annotations

import os
import sys
import threading
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from thor import net, runtime
from thor.db import DB
from thor.scope import Scope, ScopeViolation

pytestmark = pytest.mark.safety


def _scope(tmp_path, **kw) -> Scope:
    body = {
        "engagement": "boundary",
        "allowed_hosts": "['127.0.0.1']",
        "allowed_methods": "[GET, POST]",
        "max_rps": 0,
        "max_requests": 10,
        "allow_private_targets": "true",
    }
    body.update(kw)
    p = tmp_path / "scope.yaml"
    p.write_text("\n".join(f"{k}: {v}" for k, v in body.items()) + "\n")
    return Scope.load(p)


@pytest.fixture(autouse=True)
def _clean_runtime():
    runtime.reset()
    yield
    runtime.reset()


def test_budget_is_shared_across_every_engine(tmp_path):
    """
    Three engines, each opening its own Client as all nineteen do. The
    ceiling must be reached once, not once per engine.
    """
    sc = _scope(tmp_path, max_requests=5)
    runtime.bind(sc, db=DB(str(tmp_path / "t.db")))

    sent = 0
    with pytest.raises(ScopeViolation):
        for _engine in range(3):
            with net.Client(sc) as c:
                for _ in range(4):        # 12 attempts across 3 engines
                    c.budget.take()
                    sent += 1
    assert sent == 5, (
        f"{sent} requests were permitted against a ceiling of 5 — the "
        f"budget is per engine again")


def test_budget_survives_a_restart(tmp_path):
    """
    A ceiling that resets when the process restarts is not a ceiling. An
    operator running `thor loop` four times would send four budgets' worth
    against a program that authorised one.
    """
    dbp = str(tmp_path / "t.db")
    sc = _scope(tmp_path, max_requests=3)

    runtime.bind(sc, db=DB(dbp))
    for _ in range(3):
        runtime.current().budget.take()

    runtime.reset()                       # a new process
    runtime.bind(sc, db=DB(dbp))
    assert runtime.current().budget.used == 3
    with pytest.raises(ScopeViolation):
        runtime.current().budget.take()


def test_exhausted_budget_cannot_be_cleared_by_rebinding(tmp_path):
    """
    Rebinding the engagement — which every CLI command does — must not be a
    way to get a fresh budget. Only a deliberate reset clears it, and that
    goes through the database, not through process state.
    """
    dbp = str(tmp_path / "t.db")
    sc = _scope(tmp_path, max_requests=2)
    runtime.bind(sc, db=DB(dbp))
    runtime.current().budget.take()
    runtime.current().budget.take()

    for _attempt in range(3):
        runtime.bind(sc, db=DB(dbp))                 # a new command
        assert runtime.current().budget.used == 2
        with pytest.raises(ScopeViolation):
            runtime.current().budget.take()

    # even asking for a reset does not clear it without writing the row:
    # `thor budget reset --confirm` is the only path, and it is explicit.
    runtime.bind(sc, db=DB(dbp), reset_budget=True)
    assert runtime.current().budget.used == 2


def test_budget_reset_command_requires_confirmation(tmp_path, monkeypatch):
    """The ceiling is contractual, so clearing it is a deliberate act."""
    from thor import cli

    monkeypatch.chdir(tmp_path)
    _scope(tmp_path, max_requests=2)
    assert cli.main(["--db", "t.db", "budget", "reset"]) == 2, (
        "the counter was reset without --confirm")
    assert cli.main(["--db", "t.db", "budget", "reset", "--confirm"]) == 0


def test_concurrency_cap_is_engagement_wide(tmp_path):
    """
    Ten workers each honouring a per-worker limit is still ten times the
    load on the program's service.
    """
    sc = _scope(tmp_path, max_concurrency=2, max_requests=1000)
    runtime.bind(sc, db=DB(str(tmp_path / "t.db")))

    sem = runtime.concurrency_for(sc)
    assert sem is not None, "no engagement-wide concurrency limiter"

    peak = 0
    live = 0
    lock = threading.Lock()

    def worker():
        nonlocal peak, live
        sem.acquire()
        try:
            with lock:
                live += 1
                peak = max(peak, live)
            threading.Event().wait(0.02)
        finally:
            with lock:
                live -= 1
            sem.release()

    ts = [threading.Thread(target=worker) for _ in range(8)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    assert peak <= 2, f"{peak} concurrent requests against a cap of 2"


# ─────────────────────────────────────────────────────────────────────
# The pinned destination must not be reachable around
# ─────────────────────────────────────────────────────────────────────

@pytest.mark.parametrize("var", ["HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY",
                                 "http_proxy", "https_proxy", "all_proxy"])
def test_environment_proxy_cannot_redirect_traffic(tmp_path, monkeypatch, var):
    """
    A proxy terminates the connection itself, so the address THOR validated
    and pinned would no longer be the address the socket reaches — the
    entire scope gate, defeated by an environment variable.

    This holds today partly because passing an explicit `transport=`
    bypasses httpx's proxy mounts, which is incidental behaviour of a
    library we do not control. `trust_env=False` makes it deliberate; this
    test makes it permanent.
    """
    monkeypatch.setenv(var, "http://127.0.0.1:9")     # discard port
    sc = _scope(tmp_path, max_requests=100)
    runtime.bind(sc, db=DB(str(tmp_path / "t.db")))

    with net.Client(sc) as c:
        assert c._c.trust_env is False, (
            f"{var} would be read from the environment")
        # and no proxy transport was mounted
        assert not getattr(c._c, "_mounts", {}), (
            f"a proxy mount exists while {var} is set")


def test_client_does_not_follow_redirects_itself(tmp_path):
    """
    Redirects are revalidated hop by hop against the scope. If httpx
    followed them internally, the first hop would be checked and every
    later one would not.
    """
    sc = _scope(tmp_path)
    runtime.bind(sc, db=DB(str(tmp_path / "t.db")))
    with net.Client(sc) as c:
        assert c._c.follow_redirects is False


# ─────────────────────────────────────────────────────────────────────
# Storage under the threaded engines
# ─────────────────────────────────────────────────────────────────────

def test_concurrent_writes_do_not_lose_rows(tmp_path):
    """
    The race and fuzz engines write from several threads through one
    sqlite3 connection opened with check_same_thread=False. Without
    serialisation the writes interleave and rows are lost or transactions
    collide — intermittently, which is the worst way to lose evidence.
    """
    import threading as th

    db = DB(str(tmp_path / "t.db"))
    errors: list[Exception] = []
    PER, WORKERS = 40, 8

    def worker(n):
        try:
            for i in range(PER):
                db.ex("INSERT INTO experiments (signature, kind, as_identity, "
                      "method, url, status, verdict, dest_address) "
                      "VALUES (?,?,?,?,?,?,?,?)",
                      f"w{n}-{i}", "fuzz", "userA", "GET",
                      f"http://x.example/{n}/{i}", 200, "inconclusive",
                      "93.184.216.34")
        except Exception as e:                       # noqa: BLE001
            errors.append(e)

    ts = [th.Thread(target=worker, args=(n,)) for n in range(WORKERS)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()

    assert not errors, f"concurrent writes raised: {errors[:3]}"
    got = db.one("SELECT COUNT(*) c FROM experiments")["c"]
    assert got == PER * WORKERS, f"lost rows: {got} of {PER * WORKERS}"


def test_wal_is_enabled(tmp_path):
    """A reader must not block the writer while an engine is running."""
    db = DB(str(tmp_path / "t.db"))
    mode = db.one("PRAGMA journal_mode")[0]
    assert str(mode).lower() == "wal", f"journal mode is {mode!r}"


# ─────────────────────────────────────────────────────────────────────
# Testing windows are the program's hours, not the laptop's
# ─────────────────────────────────────────────────────────────────────

def test_window_is_evaluated_in_its_declared_timezone(tmp_path):
    from datetime import datetime, timezone as _tz

    p = tmp_path / "scope.yaml"
    p.write_text("engagement: w\nallowed_hosts: ['a.example']\n"
                 "window_start: '22:00'\nwindow_end: '23:00'\n"
                 "window_timezone: 'Asia/Colombo'\n")
    sc = Scope.load(p)

    # 17:30 UTC is 23:00 in Colombo (+05:30): inside the window.
    inside = datetime(2026, 9, 27, 17, 30, tzinfo=_tz.utc)
    # 22:30 UTC is 04:00 next day in Colombo: outside.
    outside = datetime(2026, 9, 27, 22, 30, tzinfo=_tz.utc)

    assert sc.in_window(inside) is True
    assert sc.in_window(outside) is False


def test_unknown_timezone_falls_back_to_utc_not_local(tmp_path):
    """
    A typo in the timezone must not silently shift a contractual window to
    wherever the researcher happens to be sitting.
    """
    p = tmp_path / "scope.yaml"
    p.write_text("engagement: w\nallowed_hosts: ['a.example']\n"
                 "window_start: '01:00'\nwindow_end: '02:00'\n"
                 "window_timezone: 'Mars/Olympus_Mons'\n")
    sc = Scope.load(p)
    from datetime import datetime, timezone as _tz
    assert sc.in_window(datetime(2026, 9, 27, 1, 30, tzinfo=_tz.utc)) is True
    assert sc.in_window(datetime(2026, 9, 27, 5, 30, tzinfo=_tz.utc)) is False
