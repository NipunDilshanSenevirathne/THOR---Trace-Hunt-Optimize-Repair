"""
Negative safety tests.

The review made the point that matters most here: the valuable tests are not
"can it find an IDOR" but "can it be made to do something it must never do".
A tool that finds bugs but occasionally sends an out-of-scope request, or
leaks a bearer token into a report, is a liability regardless of its hit rate.

Every test in this file asserts that something does NOT happen. They are
marked `safety` and must never be skipped.
"""

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from thor import vault
from thor.db import DB
from thor.net import Budget, Client, Request
from thor.scope import Scope, ScopeViolation

pytestmark = pytest.mark.safety


@pytest.fixture
def scope(tmp_path):
    p = tmp_path / "scope.yaml"
    p.write_text(
        "engagement: safety\n"
        "allowed_hosts: ['example.com', '*.example.com']\n"
        "denied_hosts: ['secret.example.com']\n"
        "allowed_methods: [GET, POST]\n"
        "max_rps: 100\nmax_requests: 50\n")
    return Scope.load(p)


# ---------------------------------------------------------------- scope

@pytest.mark.parametrize("url,why", [
    ("https://evil.com/", "wholly different host"),
    ("https://example.com.evil.com/", "suffix-append"),
    ("https://evilexample.com/", "prefix-append"),
    ("https://secret.example.com/", "explicitly denied host"),
    ("https://EXAMPLE.COM.evil.com/", "case variation on suffix-append"),
    ("https://example.com.\n.evil.com/", "embedded newline"),
    ("http://127.0.0.1/", "loopback literal"),
    ("http://169.254.169.254/latest/meta-data/", "cloud metadata"),
    ("http://metadata.google.internal/", "GCP metadata hostname"),
    ("http://10.0.0.5/", "RFC1918"),
    ("http://[::1]/", "IPv6 loopback"),
    ("http://2130706433/", "decimal-encoded loopback"),
    ("http://0x7f000001/", "hex-encoded loopback"),
    ("http://0177.0.0.1/", "octal-encoded loopback"),
    ("file:///etc/passwd", "non-HTTP scheme"),
    ("gopher://example.com/", "non-HTTP scheme"),
    ("https://user@evil.com/", "userinfo confusion"),
    ("https://example.com@evil.com/", "userinfo confusion with allowed host"),
])
def test_out_of_scope_urls_are_refused(scope, url, why):
    with pytest.raises(ScopeViolation):
        scope.check("GET", url)


def test_disallowed_method_is_refused(scope):
    with pytest.raises(ScopeViolation):
        scope.check("DELETE", "https://example.com/x")


def test_denied_path_pattern_is_refused(tmp_path):
    p = tmp_path / "s.yaml"
    p.write_text("engagement: t\nallowed_hosts: ['example.com']\n"
                 "denied_path_patterns: ['/logout']\n")
    sc = Scope.load(p)
    with pytest.raises(ScopeViolation):
        sc.check("GET", "https://example.com/account/logout")


def test_port_restriction_is_enforced(tmp_path):
    p = tmp_path / "s.yaml"
    p.write_text("engagement: t\nallowed_hosts: ['example.com']\n"
                 "allowed_ports: [443]\n")
    sc = Scope.load(p)
    with pytest.raises(ScopeViolation):
        sc.check("GET", "https://example.com:8443/x")


def test_scope_file_without_allowed_hosts_is_refused(tmp_path):
    p = tmp_path / "s.yaml"
    p.write_text("engagement: t\n")
    with pytest.raises(ScopeViolation):
        Scope.load(p)


def test_missing_scope_file_is_refused(tmp_path):
    with pytest.raises(ScopeViolation):
        Scope.load(tmp_path / "nope.yaml")


def test_unknown_scope_key_is_refused(tmp_path):
    """A typo'd key must not silently widen scope."""
    p = tmp_path / "s.yaml"
    p.write_text("engagement: t\nallowed_hosts: ['example.com']\n"
                 "allowed_host: ['evil.com']\n")
    with pytest.raises(ScopeViolation):
        Scope.load(p)


def test_check_returns_pinned_destination(scope, monkeypatch):
    """Scope.check must return the address the socket will use."""
    import socket
    monkeypatch.setattr(socket, "getaddrinfo",
                        lambda *a, **k: [(2, 1, 6, "", ("93.184.216.34", 443))])
    dest = scope.check("GET", "https://example.com/x")
    assert dest.addresses == ["93.184.216.34"]
    assert dest.pinned() == "93.184.216.34"
    assert dest.host == "example.com"      # Host/SNI preserved


def test_mixed_public_private_dns_answer_is_refused(scope, monkeypatch):
    """A record set mixing public and private is the rebinding signature."""
    import socket
    monkeypatch.setattr(socket, "getaddrinfo", lambda *a, **k: [
        (2, 1, 6, "", ("93.184.216.34", 443)),
        (2, 1, 6, "", ("127.0.0.1", 443)),
    ])
    with pytest.raises(ScopeViolation):
        scope.check("GET", "https://example.com/x")


def test_redirect_out_of_scope_is_refused(scope, monkeypatch):
    import socket
    monkeypatch.setattr(socket, "getaddrinfo",
                        lambda *a, **k: [(2, 1, 6, "", ("93.184.216.34", 443))])
    with pytest.raises(ScopeViolation):
        scope.check_redirect("https://example.com/a", "https://evil.com/b")


def test_redirect_to_metadata_is_refused(scope, monkeypatch):
    import socket
    monkeypatch.setattr(socket, "getaddrinfo",
                        lambda *a, **k: [(2, 1, 6, "", ("93.184.216.34", 443))])
    with pytest.raises(ScopeViolation):
        scope.check_redirect("https://example.com/a",
                             "http://169.254.169.254/latest/meta-data/")


def test_budget_is_enforced():
    b = Budget(max_rps=0, max_requests=3)
    for _ in range(3):
        b.take()
    with pytest.raises(ScopeViolation):
        b.take()


# ------------------------------------------------------------ credentials

def test_credentials_are_split_from_plain_headers():
    secret, plain = vault.split_credentials({
        "Authorization": "Bearer abc123", "Cookie": "session=xyz",
        "Content-Type": "application/json", "X-Org-Id": "acme"})
    assert set(secret) == {"Authorization", "Cookie"}
    assert set(plain) == {"Content-Type", "X-Org-Id"}


def test_redaction_removes_bearer_tokens():
    out = vault.redact({"Authorization": "Bearer sk-abcdefghijklmnop12345"})
    assert "abcdefghijklmnop" not in json.dumps(out)
    assert "redacted" in json.dumps(out)


def test_redaction_is_recursive_and_stable():
    a = vault.redact({"h": {"Authorization": "Bearer tok-aaaaaaaaaaaaaaaaaaaa"}})
    b = vault.redact({"h": {"Authorization": "Bearer tok-aaaaaaaaaaaaaaaaaaaa"}})
    assert a == b                       # stable fingerprint, correlatable
    assert "tok-aaaa" not in json.dumps(a)


@pytest.mark.parametrize("payload", [
    "Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIn0.abcdefghijkl",
    "set-cookie: session=supersecretvalue123456; Path=/",
    "aws key AKIAIOSFODNN7EXAMPLE here",
    "token ghp_abcdefghijklmnopqrstuvwxyz0123456789",
])
def test_inline_credentials_are_scrubbed_from_free_text(payload):
    out = vault.redact(payload)
    assert vault.scan_for_leaks(out) == [], f"leak survived: {out}"


def test_request_record_never_contains_credentials():
    r = Request("GET", "https://example.com/x",
                {"Authorization": "Bearer verysecrettoken1234567890",
                 "Cookie": "session=anothersecretvalue999"},
                None, "userA")
    blob = json.dumps(r.to_record())
    assert "verysecrettoken" not in blob
    assert "anothersecretvalue" not in blob
    assert vault.scan_for_leaks(blob) == []


def test_identity_table_stores_no_credentials(tmp_path, monkeypatch):
    """The research database must never contain authentication material."""
    from thor import identity
    from cryptography.fernet import Fernet
    monkeypatch.setenv("THOR_VAULT_KEY", Fernet.generate_key().decode())
    v = vault.Vault(path=tmp_path / "v.enc")
    db = DB(str(tmp_path / "t.db"))
    identity.add(db, "userA", {"Authorization": "Bearer TOPSECRET123456789012"},
                 v=v, log=lambda *a: None)

    raw = Path(tmp_path / "t.db").read_bytes()
    assert b"TOPSECRET123456789012" not in raw, \
        "credential found in the research database"

    # but it resolves correctly in memory
    got = identity.load(db, "userA", v=v)
    assert got.headers["Authorization"] == "Bearer TOPSECRET123456789012"


def test_signature_includes_headers():
    """Header-only variants must not collapse into one experiment."""
    a = Request("GET", "https://example.com/admin", {}, None, "x")
    b = Request("GET", "https://example.com/admin",
                {"X-Original-URL": "/admin"}, None, "x")
    assert a.signature() != b.signature()


def test_signature_is_deterministic():
    mk = lambda: Request("POST", "https://example.com/a",
                         {"B": "2", "A": "1"}, b"body", "userA")
    assert mk().signature() == mk().signature()


# ------------------------------------------------------------- verdicts

def test_reflection_in_json_is_not_xss():
    """A payload echoed into JSON is not a rendering context."""
    from thor.oracles import reflection_oracle
    hits = reflection_oracle('{"echo":"zq7x<>"}', "zq7x",
                             content_type="application/json")
    assert hits == []


def test_public_resource_is_not_an_authz_leak():
    """If anonymous gets it too, it is public, not leaked."""
    from thor.diff import compare, normalise
    body = '{"id":"1","title":"Terms","body":"public text here"}'
    base = normalise(200, body, "application/json")
    probe = normalise(200, body, "application/json")
    anon = normalise(200, body, "application/json")
    v = compare(base, probe, anon=anon)
    assert v.verdict == "public"
    assert v.score == 0.0


def test_denied_probe_is_not_a_leak():
    from thor.diff import compare, normalise
    base = normalise(200, '{"id":"1","email":"a@b.example"}', "application/json")
    probe = normalise(403, '{"error":"forbidden"}', "application/json")
    assert compare(base, probe).verdict == "denied"


def test_unverified_experiment_is_not_promoted(tmp_path):
    """Only leak verdicts above threshold become findings."""
    from thor import evidence
    db = DB(str(tmp_path / "t.db"))
    db.ex("INSERT INTO experiments (signature, kind, as_identity, method, url, "
          "status, verdict, score, detail) VALUES (?,?,?,?,?,?,?,?,?)",
          "sig1", "authz", "userB", "GET", "https://example.com/a/1", 200,
          "inconclusive", 0.4, "{}")
    evidence.promote(db, log=lambda *a: None)
    assert db.q("SELECT * FROM findings") == []


def test_duplicate_route_shapes_collapse_to_one_finding(tmp_path):
    from thor import evidence
    db = DB(str(tmp_path / "t.db"))
    for i, oid in enumerate(("1", "2", "3")):
        db.ex("INSERT INTO experiments (signature, kind, as_identity, method, "
              "url, status, verdict, score, detail) VALUES (?,?,?,?,?,?,?,?,?)",
              f"s{i}", "authz", "userB", "GET",
              f"https://example.com/api/orders/{oid}", 200, "leak", 0.9,
              json.dumps({"reasons": ["x"]}))
    evidence.promote(db, log=lambda *a: None)
    rows = db.q("SELECT * FROM findings")
    assert len(rows) == 1, "three ids on one route must be one finding"
    assert json.loads(rows[0]["evidence_ids"]) == [1, 2, 3]


def test_ai_cannot_mark_a_finding_confirmed_without_evidence(tmp_path):
    """The AI apply path must not invent findings."""
    from thor import ai
    db = DB(str(tmp_path / "t.db"))
    ans = tmp_path / "impact.json"
    ans.write_text(json.dumps({"findings": [
        {"id": 999, "attack_narrative": "total compromise", "submit": True}]}))
    ai.apply_answer(db, "impact", ans, log=lambda *a: None)
    assert db.q("SELECT * FROM findings") == [], \
        "AI answer created a finding that no experiment supports"


# ---------------------------------------------------------------- risk

def test_destructive_engines_are_gated_by_default(tmp_path):
    from thor import risk
    p = tmp_path / "s.yaml"
    p.write_text("engagement: t\nallowed_hosts: ['example.com']\n")
    sc = Scope.load(p)
    g = risk.gate_for(sc)
    assert not g.allows("race")
    assert not g.allows("workflow")
    assert g.allows("authz")


def test_sensitive_flag_does_not_unlock_destructive(tmp_path):
    from thor import risk
    p = tmp_path / "s.yaml"
    p.write_text("engagement: t\nallowed_hosts: ['example.com']\n"
                 "sensitive: true\n")
    sc = Scope.load(p)
    g = risk.gate_for(sc)
    assert g.allows("workflow")
    assert not g.allows("race"), "sensitive must not imply destructive"


def test_race_engine_refuses_without_destructive(tmp_path):
    from thor import engine
    p = tmp_path / "s.yaml"
    p.write_text("engagement: t\nallowed_hosts: ['example.com']\n")
    sc = Scope.load(p)
    db = DB(str(tmp_path / "t.db"))
    out = engine.run_race(db, sc, "x", log=lambda *a: None)
    assert out.get("skipped") is True


# --------------------------------------------------------------- audit

def test_audit_log_redacts_credentials(tmp_path):
    from thor.audit import Audit
    al = Audit(path=tmp_path / "audit.jsonl", engagement="t")
    al.event("request.sent", url="https://example.com/x",
             headers={"Authorization": "Bearer THISMUSTNOTAPPEAR12345"})
    raw = (tmp_path / "audit.jsonl").read_text()
    assert "THISMUSTNOTAPPEAR" not in raw
    assert vault.scan_for_leaks(raw) == []


def test_audit_records_scope_refusals(tmp_path, monkeypatch):
    from thor.audit import Audit
    p = tmp_path / "s.yaml"
    p.write_text("engagement: t\nallowed_hosts: ['example.com']\n")
    sc = Scope.load(p)
    al = Audit(path=tmp_path / "audit.jsonl", engagement="t")
    c = Client(sc, audit=al)
    try:
        with pytest.raises(ScopeViolation):
            c.send(Request("GET", "https://evil.com/x"))
    finally:
        c.close()
    recs = al.read(event="scope.refused")
    assert recs and "evil.com" in recs[0]["url"]


def test_invalid_vault_key_is_rejected_clearly(tmp_path, monkeypatch):
    """A malformed key must say so, not fail inside cryptography."""
    monkeypatch.setenv("THOR_VAULT_KEY", "not-a-real-key")
    v = vault.Vault(path=tmp_path / "v.enc")
    with pytest.raises(vault.VaultUnavailable, match="not a valid Fernet key"):
        v.store({"Authorization": "Bearer x"})


def test_vault_roundtrip(tmp_path, monkeypatch):
    from cryptography.fernet import Fernet
    monkeypatch.setenv("THOR_VAULT_KEY", Fernet.generate_key().decode())
    v = vault.Vault(path=tmp_path / "v.enc")
    ref = v.store({"Authorization": "Bearer roundtrip123456"}, "t")
    assert ref.startswith("cred_")
    assert v.fetch(ref)["Authorization"] == "Bearer roundtrip123456"
    raw = (tmp_path / "v.enc").read_bytes()
    assert b"roundtrip123456" not in raw, "vault file is not encrypted"


# ═══════════════════════════════════════════════════════════════════
# A malformed scope file must refuse loudly and cleanly
# ═══════════════════════════════════════════════════════════════════

def test_malformed_scope_yaml_refuses_with_a_usable_message(tmp_path):
    """
    scope.yaml is the file the whole safety boundary rests on. A YAML error
    in it used to surface as an uncaught traceback, which buries the only
    actionable fact -- which line is wrong -- under a stack trace.
    """
    from thor.scope import Scope, ScopeViolation

    p = tmp_path / "scope.yaml"
    p.write_text("engagement: x\n"
                 "allowed_hosts: ['a.example']\n"
                 "  - \"b.example\"\n")

    with pytest.raises(ScopeViolation) as ei:
        Scope.load(p)
    msg = str(ei.value)
    assert "line" in msg, f"no line number in the error: {msg}"
    assert "refusing" in msg.lower()


def test_scope_that_is_not_a_mapping_refuses(tmp_path):
    from thor.scope import Scope, ScopeViolation

    p = tmp_path / "scope.yaml"
    p.write_text("- a.example\n- b.example\n")
    with pytest.raises(ScopeViolation):
        Scope.load(p)


def test_malformed_scope_sends_no_requests(tmp_path, monkeypatch):
    """
    The boundary must hold before anything else: a broken scope file means
    zero outbound requests, not a best-effort run.
    """
    from thor import cli

    monkeypatch.chdir(tmp_path)
    (tmp_path / "scope.yaml").write_text("allowed_hosts: ['x']\n  - bad\n")

    sent = []
    import thor.net as net
    monkeypatch.setattr(net.Client, "send",
                        lambda self, req, **k: sent.append(req))

    for argv in (["authz", "--corpus", "c"], ["tenant", "--corpus", "c"],
                 ["loop", "--corpus", "c", "--minutes", "1"]):
        assert cli.main(argv) == 2, f"{argv} did not refuse cleanly"
    assert sent == [], "a request was sent with an unreadable scope file"
