"""Fast unit tests for the v4 intelligence layer. No network, no lab."""

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from thor import graph, invariants, learn, reason, rootcause, sourceintel
from thor.db import DB

pytestmark = pytest.mark.unit


@pytest.fixture
def db(tmp_path):
    return DB(str(tmp_path / "t.db"))


# ------------------------------------------------------------------ graph

def test_graph_nodes_are_unique_per_kind_and_key(db):
    a = graph.node(db, "Tenant", "acme")
    b = graph.node(db, "Tenant", "acme")
    c = graph.node(db, "Identity", "acme")
    assert a == b
    assert c != a, "same key in a different kind must be a different node"


def test_graph_node_props_merge(db):
    graph.node(db, "Asset", "a.example", props={"status": 200})
    nid = graph.node(db, "Asset", "a.example", props={"server": "nginx"})
    props = json.loads(graph.find(db, "Asset", "a.example")[0]["props"])
    assert props == {"status": 200, "server": "nginx"}


def test_graph_edges_accumulate_evidence(db):
    i = graph.node(db, "Identity", "userA")
    o = graph.node(db, "Object", "invoice:1")
    graph.edge(db, i, "accesses", o, evidence=[1])
    graph.edge(db, i, "accesses", o, evidence=[2])
    row = db.one("SELECT evidence FROM edges WHERE src=? AND dst=?", i, o)
    assert json.loads(row["evidence"]) == [1, 2]


def test_graph_traversal_both_directions(db):
    t = graph.node(db, "Tenant", "acme")
    i = graph.node(db, "Identity", "userA")
    graph.edge(db, i, "belongs_to", t)
    assert graph.neighbours(db, i, "belongs_to")[0]["key"] == "acme"
    assert graph.neighbours(db, t, "belongs_to", "in")[0]["key"] == "userA"


def test_cross_tenant_pairs_only_crosses_boundaries(db):
    for t in ("acme", "globex"):
        graph.node(db, "Tenant", t)
    a = graph.node(db, "Identity", "userA")
    b = graph.node(db, "Identity", "userB")
    graph.edge(db, a, "belongs_to", graph.node(db, "Tenant", "acme"))
    graph.edge(db, b, "belongs_to", graph.node(db, "Tenant", "globex"))
    o = graph.node(db, "Object", "invoice:1")
    graph.edge(db, o, "scoped_to", graph.node(db, "Tenant", "acme"))
    pairs = graph.cross_tenant_pairs(db)
    assert all(p["object_tenant"] != p["identity_tenant"] for p in pairs)
    assert any(p["identity"] == "userB" for p in pairs)
    assert not any(p["identity"] == "userA" for p in pairs), \
        "same-tenant identity is not a cross-tenant experiment"


# ------------------------------------------------------------- invariants

def test_every_invariant_has_an_engine_that_can_test_it():
    from thor import risk
    for inv in invariants.CATALOGUE:
        assert inv.engine, f"{inv.key} names no engine"
        assert inv.engine in risk.ENGINE_RISK, \
            f"{inv.key} names unknown engine {inv.engine}"


def test_invariant_keys_are_unique():
    keys = [i.key for i in invariants.CATALOGUE]
    assert len(keys) == len(set(keys))


def test_untested_invariants_start_untested(db):
    invariants.install(db, log=lambda *a: None)
    invariants.evaluate(db, log=lambda *a: None)
    assert len(invariants.untested(db)) == len(invariants.CATALOGUE)
    assert invariants.violated(db) == []


def test_leak_experiment_marks_invariant_violated(db):
    invariants.install(db, log=lambda *a: None)
    db.ex("INSERT INTO experiments (signature, kind, verdict, score, url, "
          "detail) VALUES (?,?,?,?,?,?)",
          "s1", "tenant", "leak", 0.9, "https://x/api/a", "{}")
    invariants.evaluate(db, log=lambda *a: None)
    keys = {v["key"] for v in invariants.violated(db)}
    assert "tenancy.isolation" in keys


def test_non_leak_experiments_mark_invariant_holds(db):
    invariants.install(db, log=lambda *a: None)
    db.ex("INSERT INTO experiments (signature, kind, verdict, score, url, "
          "detail) VALUES (?,?,?,?,?,?)",
          "s1", "cors", "inconclusive", 0.1, "https://x/", "{}")
    invariants.evaluate(db, log=lambda *a: None)
    row = db.one("SELECT status FROM invariants WHERE key=?",
                 "origin.credentialed_cors")
    assert row["status"] == "holds"


# ---------------------------------------------------------------- learning

def test_cold_arm_is_uniform(db):
    learn.ensure(db)
    arms = learn.load_arms(db)
    assert arms == []
    ranked = learn.rank(db, ["authz", "cors"], seed=1)
    assert len(ranked) == 2
    assert all("no history" in why for _, _, why in ranked)


def test_arm_mean_moves_with_outcomes(db):
    for _ in range(9):
        learn.record(db, "tenant", "nginx", "header", True)
    learn.record(db, "tenant", "nginx", "header", False)
    a = [x for x in learn.load_arms(db) if x.engine == "tenant"][0]
    assert a.mean > 0.7
    lo, hi = a.interval()
    assert lo < a.mean < hi


def test_more_evidence_narrows_the_interval(db):
    learn.record(db, "authz", "-", "-", True, n=2)
    learn.record(db, "authz", "-", "-", False, n=2)
    narrow_before = [x for x in learn.load_arms(db)][0].interval()
    learn.record(db, "authz", "-", "-", True, n=100)
    learn.record(db, "authz", "-", "-", False, n=100)
    narrow_after = [x for x in learn.load_arms(db)][0].interval()
    assert (narrow_after[1] - narrow_after[0]) < (narrow_before[1] - narrow_before[0])


def test_hypothesis_lifecycle_updates_arms(db):
    hid = learn.open_hypothesis(db, learn.Hypothesis(
        engine="authz", target="https://x/a", statement="s",
        predicted="p", falsifier="f", arm=learn.arm_key("authz", "nginx", "path")))
    assert len(learn.open_hypotheses(db)) == 1
    learn.close_hypothesis(db, hid, "confirmed", "leak observed", [1])
    assert learn.open_hypotheses(db) == []
    assert any(a.successes == 1 for a in learn.load_arms(db))


# -------------------------------------------------------------- reasoning

def test_information_gain_is_decomposed(db):
    graph.ensure(db)
    invariants.install(db, log=lambda *a: None)
    hyps = reason.generate(db, "none", log=lambda *a: None)
    for h in hyps:
        assert h.gain >= 0
        assert "uncertainty" in h.components
        assert "cost" in h.components


def test_destructive_engines_are_penalised():
    assert reason.RISK_PENALTY[4] > reason.RISK_PENALTY[1]


def test_tenancy_outweighs_navigation():
    assert reason.BOUNDARY_WEIGHT["tenancy"] > reason.BOUNDARY_WEIGHT["navigation"]


# -------------------------------------------------------------- root cause

def test_route_shapes_group_by_family():
    assert rootcause.route_family("/api/v2/orders/{id}/items") == \
           ("orders", "items")


def test_root_cause_needs_two_manifestations(db):
    db.ex("INSERT INTO findings (fingerprint, vuln_class, severity, title, "
          "asset, route, evidence_ids) VALUES (?,?,?,?,?,?,?)",
          "f1", "authz", "high", "t", "a.example",
          "a.example/api/billing/x/{id}", "[1]")
    assert rootcause.analyse(db, log=lambda *a: None) == []


def test_root_cause_groups_same_prefix(db):
    for i, r in enumerate(("invoices", "orders", "statements")):
        db.ex("INSERT INTO findings (fingerprint, vuln_class, severity, title, "
              "asset, route, evidence_ids) VALUES (?,?,?,?,?,?,?)",
              f"f{i}", "authz", "high", "t", "a.example",
              f"a.example/api/billing/{r}/{{id}}", "[1]")
    causes = rootcause.analyse(db, log=lambda *a: None)
    assert causes
    assert len(causes[0].members) == 3


# ------------------------------------------------------------ source intel

def test_source_path_normalisation():
    n = sourceintel._normalise_source_path
    assert n("/api/users/:id") == "/api/users/{id}"
    assert n("/api/users/<int:id>") == "/api/users/{id}"
    assert n("/api/users/{userId}") == "/api/users/{id}"
    assert n("api/users/") == "/api/users"


def test_runtime_path_normalisation():
    n = sourceintel._normalise_runtime_path
    assert n("https://x/api/orders/4821") == "/api/orders/{id}"
    assert n("https://x/api/o/550e8400-e29b-41d4-a716-446655440000") == \
           "/api/o/{id}"


def test_guard_context_does_not_leak_from_previous_route():
    """The bug the v4 lab caught: a route inheriting its neighbour's guards."""
    lines = [
        "router.get('/a', requireAuth, requireTenant, (req,res) => {",
        "  res.json(x);",
        "});",
        "",
        "router.get('/b', (req,res) => {",
        "  res.json(y);",
        "});",
    ]
    guarded = sourceintel._guard_context(lines, 0)
    unguarded = sourceintel._guard_context(lines, 4)
    assert "requireAuth" in guarded
    assert "requireAuth" not in unguarded


def test_guard_context_includes_decorators_above():
    lines = ["@login_required", "@require_tenant",
             "@app.route('/a')", "def a():", "    pass"]
    ctx = sourceintel._guard_context(lines, 2)
    assert "login_required" in ctx and "require_tenant" in ctx


def test_scope_arg_detects_tenant_scoping():
    assert sourceintel.SCOPE_ARG.search("id, { tenant: req.user.tenant }")
    assert sourceintel.SCOPE_ARG.search("id, owner=current_user")
    assert not sourceintel.SCOPE_ARG.search("req.params.id")


def test_root_cause_prefers_middleware_over_data_layer(db):
    """
    Three routes under one prefix is a shared middleware, not an
    application-wide data-layer defect. The more precise claim must win.
    """
    for i, r in enumerate(("invoices", "orders", "statements")):
        db.ex("INSERT INTO findings (fingerprint, vuln_class, severity, title, "
              "asset, route, evidence_ids) VALUES (?,?,?,?,?,?,?)",
              f"g{i}", "authz", "high", "t", "a.example",
              f"a.example/api/billing/{r}/{{id}}", "[1]")
    causes = rootcause.analyse(db, log=lambda *a: None)
    assert causes
    assert "billing" in causes[0].title, \
        "same-prefix findings must be attributed to the shared middleware"


def test_root_cause_blames_data_layer_across_subsystems(db):
    """Genuinely unrelated subsystems DO justify the data-layer claim."""
    for i, (sub, r) in enumerate((("billing", "invoices"),
                                  ("crm", "contacts"),
                                  ("hr", "employees"),
                                  ("support", "tickets"))):
        db.ex("INSERT INTO findings (fingerprint, vuln_class, severity, title, "
              "asset, route, evidence_ids) VALUES (?,?,?,?,?,?,?)",
              f"h{i}", "authz", "high", "t", "b.example",
              f"b.example/api/{sub}/{r}/{{id}}", "[1]")
    causes = rootcause.analyse(db, log=lambda *a: None)
    assert any("Application-wide" in c.title for c in causes)


# ═══════════════════════════════════════════════════════════════════
# The tool must not claim capabilities it does not have
# ═══════════════════════════════════════════════════════════════════

def test_every_declared_engine_is_implemented_or_says_it_is_not():
    """
    `websocket` sat in ENGINE_RISK with a risk level and a severity
    mapping and no implementation anywhere. `thor risk` listed it as an
    available engine, so the operator was told THOR could test WebSockets.
    An engine that is declared but absent has to say so.

    The authoritative list of what can actually run is
    `experiment.ENGINE_PLANS` — the loop can only schedule what is there.
    Observation-only modules (recon, schema, jsintel, anomaly) have no
    plan because they falsify nothing; they are named explicitly rather
    than waved through.
    """
    from thor import experiment, risk

    OBSERVATION_ONLY = {"recon", "schema", "jsintel", "anomaly"}
    declared = set(risk.ENGINE_RISK)
    runnable = set(experiment.ENGINE_PLANS)

    missing = declared - runnable - OBSERVATION_ONLY - set(risk.NOT_IMPLEMENTED)
    assert not missing, (
        f"declared with a risk level but nothing can run them: "
        f"{sorted(missing)}. Add to risk.NOT_IMPLEMENTED with a reason, "
        f"implement a plan, or list as observation-only — `thor risk` is "
        f"telling the operator these are available.")

    # and nothing runnable is secretly marked unimplemented
    lying = runnable & set(risk.NOT_IMPLEMENTED)
    assert not lying, f"{sorted(lying)} are runnable but marked unimplemented"


def test_unimplemented_engines_explain_themselves():
    from thor import risk
    for engine, why in risk.NOT_IMPLEMENTED.items():
        assert engine in risk.ENGINE_RISK
        assert len(why) > 40, (
            f"{engine} is declared unimplemented with no real reason; "
            f"'not done yet' is not a design decision")


def test_every_invariant_has_an_engine_that_can_falsify_it():
    """
    A hundred rules with no falsifier make `thor invariants` a list of
    things nobody tested, which is worse than a short list of things
    somebody did.
    """
    from thor import invariants, risk

    for inv in invariants.CATALOGUE:
        assert inv.engine, f"{inv.key} names no engine"
        assert inv.engine in risk.ENGINE_RISK, (
            f"{inv.key} names unknown engine {inv.engine!r}")
        assert risk.implemented(inv.engine), (
            f"{inv.key} is falsified by {inv.engine!r}, which is not "
            f"implemented — the invariant can never be tested")


def test_invariant_keys_are_unique():
    from thor import invariants
    keys = [i.key for i in invariants.CATALOGUE]
    assert len(keys) == len(set(keys)), "duplicate invariant keys"


def test_every_invariant_is_wired_to_evidence():
    """
    An invariant with no entry in the evidence map can never be evaluated.
    It is installed, it is counted in the catalogue, and it is invisible in
    every report — decoration that looks like coverage.

    Twelve new invariants shipped in exactly that state: `thor invariants`
    said "22 rules" while the catalogue held 34, and nobody would have
    noticed which twelve were doing nothing.
    """
    from thor import invariants as I

    mapped = {k for v in I._ENGINE_TO_INVARIANT.values() for k in v}
    catalogue = {i.key for i in I.CATALOGUE}

    unmapped = catalogue - mapped
    assert not unmapped, (
        f"these invariants can never be evaluated: {sorted(unmapped)}. "
        f"Add them to _ENGINE_TO_INVARIANT or remove them — an invariant "
        f"nothing can falsify is not coverage.")

    dangling = mapped - catalogue
    assert not dangling, (
        f"the evidence map names invariants that do not exist: "
        f"{sorted(dangling)}")


def test_invariant_report_accounts_for_the_whole_catalogue(tmp_path):
    """violated + holds + untested must equal the catalogue, always."""
    from thor import invariants as I
    from thor.db import DB

    db = DB(str(tmp_path / "t.db"))
    I.install(db, log=lambda *a, **k: None)
    I.evaluate(db, log=lambda *a, **k: None)
    total = (len(I.violated(db)) + len(I.holds(db)) + len(I.untested(db)))
    assert total == len(I.CATALOGUE), (
        f"{total} invariants accounted for, catalogue has "
        f"{len(I.CATALOGUE)} — some are invisible in the report")
