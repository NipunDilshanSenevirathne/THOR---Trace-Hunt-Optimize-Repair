"""
Authority is often applied somewhere other than the sink.

A single-file read can only say "no authority appears in this call". Real
codebases put the check in a decorator, an Express middleware, a base
controller or a repository that always scopes by tenant. Calling those
"missing" produces confident false positives in exactly the well-organised
codebases whose authors will notice and stop reading.

Three values, not two:
  present  a guard reaches the sink, here or on a resolved path
  missing  a route reaches the sink and nothing on the way guards it
  unknown  no caller could be resolved — the analysis cannot see the entry
           point, so it does not get to call it a bug
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from thor import dataflow

pytestmark = pytest.mark.unit

needs_ts = pytest.mark.skipif(not dataflow.available(),
                              reason="tree-sitter not installed")


def _scan(tmp_path, files: dict):
    src = tmp_path / "app"
    for name, body in files.items():
        p = src / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(body)
    flows = dataflow.scan(src, log=lambda *a, **k: None)
    return {f"{f.file}:{f.line}": f for f in flows}, flows


def _by_status(flows, status):
    return [f for f in flows if f.authority_status == status]


@needs_ts
def test_guard_in_a_decorator_is_not_a_missing_check(tmp_path):
    """
    The classic false positive: the lookup is unscoped in its own body,
    and the authorisation is a decorator one line above it.
    """
    _, flows = _scan(tmp_path, {"api.py": '''
@require_tenant
def get_invoice(request):
    invoice_id = request.GET["id"]
    return db.find_by_id(invoice_id)
'''})
    assert flows, "no flow detected at all"
    assert not _by_status(flows, "missing"), (
        "a decorator-guarded handler was reported as an unscoped lookup: "
        f"{[f.describe() for f in flows]}")


@needs_ts
def test_guard_in_a_caller_across_files_is_found(tmp_path):
    """
    route → controller → repository, with the check in the controller and
    the unscoped-looking lookup two files away.
    """
    _, flows = _scan(tmp_path, {
        "routes.js": '''
const router = require('express').Router();
router.get('/api/invoices/:id', (req, res) => {
  return handleInvoice(req, res);
});
''',
        "controller.js": '''
function handleInvoice(req, res) {
  requireTenant(req);
  return fetchInvoice(req.params.id);
}
''',
        "repo.js": '''
function fetchInvoice(id) {
  return db.findById(id);
}
''',
    })
    assert flows
    missing = _by_status(flows, "missing")
    assert not missing, (
        "the guard is applied by the calling controller, two files away, "
        f"and the flow was still reported as unscoped: "
        f"{[f.describe() for f in missing]}")


@needs_ts
def test_genuinely_unscoped_route_is_still_reported(tmp_path):
    """The precision work must not cost the true positive."""
    _, flows = _scan(tmp_path, {
        "routes.js": '''
const router = require('express').Router();
router.get('/api/invoices/:id', (req, res) => {
  return handleInvoice(req, res);
});
''',
        "controller.js": '''
function handleInvoice(req, res) {
  return fetchInvoice(req.params.id);
}
''',
        "repo.js": '''
function fetchInvoice(id) {
  return db.findById(id);
}
''',
    })
    assert _by_status(flows, "missing"), (
        "the unscoped path from a route to a bare lookup was not reported: "
        f"{[(f.describe(), f.authority_status) for f in flows]}")


@needs_ts
def test_orphan_function_is_unknown_not_missing(tmp_path):
    """
    A helper with no resolvable caller might be reached through a route we
    cannot see, or might be dead code. Either way the analysis cannot
    claim a missing authorisation check.
    """
    _, flows = _scan(tmp_path, {"helper.js": '''
function fetchInvoiceById(id) {
  return db.findById(id);
}
'''})
    missing = _by_status(flows, "missing")
    assert not missing, (
        "a function with no resolvable caller was reported as a missing "
        "authorisation check")


@needs_ts
def test_unknown_flows_never_become_hypotheses(tmp_path):
    """
    `unscoped_lookups()` feeds the hypothesis generator. Spending real
    requests on the tool's own blind spot is worse than saying nothing.
    """
    from thor.db import DB

    _, flows = _scan(tmp_path, {"helper.js": '''
function fetchInvoiceById(id) {
  return db.findById(id);
}
'''})
    db = DB(str(tmp_path / "t.db"))
    dataflow.persist(db, flows, log=lambda *a, **k: None)
    assert dataflow.unscoped_lookups(db) == [], (
        "an UNKNOWN flow was offered to the hypothesis generator as if it "
        "were an unscoped lookup")


@needs_ts
def test_report_separates_the_three_states(tmp_path):
    from thor.db import DB

    _, flows = _scan(tmp_path, {
        "routes.js": '''
router.get('/a/:id', (req, res) => { return unguarded(req, res); });
''',
        "a.js": '''
function unguarded(req, res) { return db.findById(req.params.id); }
''',
        "b.js": '''
function orphan(id) { return db.findById(id); }
''',
    })
    db = DB(str(tmp_path / "t.db"))
    dataflow.persist(db, flows, log=lambda *a, **k: None)
    text = dataflow.report(db)
    assert "UNSCOPED" in text
    assert "blind spot" in text, (
        "the report does not explain why UNKNOWN is not a weaker finding")
