"""
THOR — evidence-driven web application security research.

by Nipun Dilshan

Authorised targets only. Every verdict in this system comes from observed
bytes; the AI layer classifies, prioritises and narrates, and has no path to
declaring a vulnerability real.
"""

__version__ = "4.0.0"
__author__ = "Nipun Dilshan"
