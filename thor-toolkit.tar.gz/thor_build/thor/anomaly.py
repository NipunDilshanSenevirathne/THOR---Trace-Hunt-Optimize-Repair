"""
Anomaly triage -- the component that decides where your hours go.

Everyone runs subfinder -> httpx -> nuclei against the same targets, so
everyone finds the same bugs. The hunters who land P1s consistently do it
by noticing what is *odd*, not by matching signatures.

This module scores each asset on how much it differs from its siblings on
the same program. A host running a different stack, exposing an auth scheme
nobody else uses, or referencing routes nobody else has is where the
un-found bugs live.

Deterministic. No LLM. The AI layer explains the ranking; it does not
produce it.
"""

from __future__ import annotations

import json
import math
import re
from collections import Counter
from dataclasses import dataclass, field

from .db import DB

# Substrings in a hostname that historically correlate with weak controls.
_HOST_SIGNALS = [
    (r"\b(dev|development)\b", 2.5, "dev host"),
    (r"\b(stag|staging|uat|qa|test|testing|sandbox)\b", 2.5, "non-prod host"),
    (r"\b(int|internal|intra|corp|private)\b", 3.0, "internal-sounding host"),
    (r"\b(admin|manage|console|panel|dashboard)\b", 3.0, "admin surface"),
    (r"\b(api|gw|gateway|graphql|rpc)\b", 2.0, "api surface"),
    (r"\b(legacy|old|v1|deprecated|archive|bak|backup)\b", 3.5, "legacy host"),
    (r"\b(jenkins|gitlab|jira|confluence|grafana|kibana|prometheus|airflow|rancher|argo)\b",
     3.5, "ops tooling exposed"),
    (r"\b(vpn|sso|auth|login|idp|oauth|saml)\b", 2.5, "auth surface"),
    (r"\b(upload|files|cdn|assets|media|storage|s3)\b", 1.5, "file surface"),
    (r"\b(pay|billing|invoice|checkout|order|wallet)\b", 3.0, "money flow"),
    (r"\b(beta|preview|next|new|canary)\b", 2.0, "pre-release host"),
    (r"\b(mobile|app|ios|android)\b", 1.5, "mobile backend"),
    (r"-\d{2,}\b|\b\d{2,}-", 1.0, "numbered host"),
]

_TITLE_SIGNALS = [
    (r"(?i)(index of|directory listing)", 4.0, "directory listing"),
    (r"(?i)(swagger|openapi|api docs|redoc)", 3.5, "api documentation"),
    (r"(?i)(phpinfo|debug|traceback|stack trace|whitelabel error)", 4.0, "debug output"),
    (r"(?i)(login|sign in|admin)", 1.5, "auth page"),
    (r"(?i)(welcome to nginx|apache2 default|iis windows server|it works)", 2.5,
     "default server page"),
    (r"(?i)(forbidden|unauthorized|403|401)", 1.0, "protected surface"),
    (r"(?i)(grafana|kibana|jenkins|gitlab|rabbitmq|consul|vault)", 4.0,
     "ops console"),
]

_INTERESTING_STATUS = {
    401: (1.5, "requires auth (has something to protect)"),
    403: (2.0, "forbidden -- worth ACL bypass testing"),
    500: (2.5, "server error on landing page"),
    503: (1.0, "service unavailable"),
}


@dataclass
class Score:
    host: str
    total: float = 0.0
    reasons: list[str] = field(default_factory=list)

    def add(self, pts: float, why: str) -> None:
        self.total += pts
        self.reasons.append(f"+{pts:g} {why}")


def _tech_set(raw) -> set[str]:
    if not raw:
        return set()
    try:
        v = json.loads(raw) if isinstance(raw, str) else raw
    except Exception:
        return set()
    if isinstance(v, str):
        return {v.lower()}
    return {str(x).lower() for x in v}


def score_assets(db: DB) -> list[Score]:
    """Score every live asset relative to the rest of the program."""
    rows = db.q(
        "SELECT id, host, status, title, server, tech, cname, content_length, ip "
        "FROM assets WHERE status IS NOT NULL"
    )
    if not rows:
        return []

    # --- build the population baseline --------------------------------
    servers = Counter()
    techs = Counter()
    lengths = []
    ips = Counter()
    for r in rows:
        if r["server"]:
            servers[r["server"].split("/")[0].lower()] += 1
        for t in _tech_set(r["tech"]):
            techs[t] += 1
        if r["content_length"]:
            lengths.append(r["content_length"])
        if r["ip"]:
            ips[r["ip"]] += 1

    n = len(rows)
    mean_len = sum(lengths) / len(lengths) if lengths else 0
    var = (sum((x - mean_len) ** 2 for x in lengths) / len(lengths)) if lengths else 0
    sd_len = math.sqrt(var)

    # endpoint / secret counts per asset
    ep_counts = {r["asset_id"]: r["c"] for r in db.q(
        "SELECT asset_id, COUNT(*) c FROM endpoints WHERE asset_id IS NOT NULL "
        "GROUP BY asset_id")}
    api_counts = {r["asset_id"]: r["c"] for r in db.q(
        "SELECT asset_id, COUNT(*) c FROM endpoints WHERE is_api=1 "
        "AND asset_id IS NOT NULL GROUP BY asset_id")}
    secret_counts = {r["asset_id"]: r["c"] for r in db.q(
        "SELECT asset_id, COUNT(*) c FROM secrets WHERE asset_id IS NOT NULL "
        "GROUP BY asset_id")}

    scores: list[Score] = []
    for r in rows:
        s = Score(host=r["host"])

        # 1. name signals
        for pat, pts, why in _HOST_SIGNALS:
            if re.search(pat, r["host"], re.I):
                s.add(pts, why)

        # 2. title signals
        title = r["title"] or ""
        for pat, pts, why in _TITLE_SIGNALS:
            if re.search(pat, title):
                s.add(pts, why)

        # 3. status
        if r["status"] in _INTERESTING_STATUS:
            pts, why = _INTERESTING_STATUS[r["status"]]
            s.add(pts, why)

        # 4. rare server -- the odd one out is the interesting one
        if r["server"]:
            key = r["server"].split("/")[0].lower()
            freq = servers[key] / n
            if freq <= 0.10 and n >= 8:
                s.add(3.0, f"rare server '{key}' ({servers[key]}/{n} hosts)")
            elif freq <= 0.25 and n >= 8:
                s.add(1.5, f"uncommon server '{key}'")

        # 5. rare tech stack
        my_tech = _tech_set(r["tech"])
        rare = [t for t in my_tech if n >= 8 and techs[t] / n <= 0.10]
        if rare:
            s.add(min(3.0, 1.0 * len(rare)), f"rare tech: {', '.join(sorted(rare)[:4])}")

        # 6. stale / version-disclosing server banner
        if r["server"] and re.search(r"/\d+\.\d+", r["server"]):
            s.add(1.0, f"version disclosed in Server: {r['server']}")

        # 7. content-length outlier
        if r["content_length"] and sd_len > 0:
            z = abs(r["content_length"] - mean_len) / sd_len
            if z >= 2.5:
                s.add(1.5, f"response size outlier (z={z:.1f})")

        # 8. CNAME pointing off-platform -> takeover / third-party surface
        if r["cname"]:
            cn = r["cname"].lower()
            if not any(cn.endswith(h.lstrip("*.")) for h in [r["host"]]):
                if re.search(r"(github\.io|herokuapp|azurewebsites|cloudfront|"
                             r"s3[.-]|netlify|vercel|surge\.sh|pantheon|wpengine|"
                             r"fastly|readme\.io|helpscout|zendesk|statuspage)", cn):
                    s.add(4.0, f"third-party CNAME -> {cn} (takeover surface)")
                else:
                    s.add(1.0, f"external CNAME -> {cn}")

        # 9. isolated IP -- not behind the main load balancer / WAF
        if r["ip"] and ips[r["ip"]] == 1 and n >= 10:
            s.add(2.0, "sole host on its IP (likely outside main infra)")

        # 10. surface volume
        eps = ep_counts.get(r["id"], 0)
        apis = api_counts.get(r["id"], 0)
        if apis >= 5:
            s.add(min(3.0, 0.3 * apis), f"{apis} API endpoints discovered")
        elif eps >= 30:
            s.add(1.5, f"{eps} endpoints discovered")

        # 11. secrets found in its JS
        sec = secret_counts.get(r["id"], 0)
        if sec:
            s.add(min(5.0, 2.0 * sec), f"{sec} secret candidate(s) in JS")

        scores.append(s)

    scores.sort(key=lambda x: x.total, reverse=True)
    return scores


def persist(db: DB, scores: list[Score]) -> None:
    for s in scores:
        db.ex("UPDATE assets SET anomaly_score=?, anomaly_reasons=? WHERE host=?",
              round(s.total, 2), json.dumps(s.reasons), s.host)


def top(db: DB, limit: int = 20) -> list[dict]:
    rows = db.q(
        "SELECT host, scheme, status, title, server, anomaly_score, anomaly_reasons "
        "FROM assets WHERE status IS NOT NULL "
        "ORDER BY anomaly_score DESC LIMIT ?", limit)
    out = []
    for r in rows:
        out.append({
            "host": r["host"],
            "url": f"{r['scheme']}://{r['host']}",
            "status": r["status"],
            "title": r["title"],
            "server": r["server"],
            "score": r["anomaly_score"],
            "reasons": json.loads(r["anomaly_reasons"] or "[]"),
        })
    return out
