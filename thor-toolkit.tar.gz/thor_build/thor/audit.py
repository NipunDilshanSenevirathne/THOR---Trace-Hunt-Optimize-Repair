"""
Structured audit log.

Everything THOR does to a target is appended here as one JSON object per
line: what was sent, where it actually connected, what came back, which
scope decision permitted it, and which engine asked.

Two reasons this matters beyond tidiness. If a program asks what you did,
the answer is a file. And if the tool ever misbehaves, the log is how you
find out — the safety tests assert against it.

Credentials never reach it: every record passes through vault.redact().
"""

from __future__ import annotations

import json
import os
import stat
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from . import vault

DEFAULT_PATH = Path(".thor") / "audit.jsonl"


@dataclass
class Audit:
    path: Path = DEFAULT_PATH
    engagement: str = ""
    run_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    engine: str = ""
    enabled: bool = True
    _lock: threading.Lock = field(default_factory=threading.Lock)

    def __post_init__(self):
        if self.enabled:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            if not self.path.exists():
                self.path.touch()
                try:
                    os.chmod(self.path, stat.S_IRUSR | stat.S_IWUSR)
                except OSError:
                    pass

    def event(self, kind: str, **fields) -> None:
        if not self.enabled:
            return
        rec = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "run": self.run_id,
            "engagement": self.engagement,
            "engine": self.engine or fields.pop("engine", ""),
            "event": kind,
        }
        rec.update(vault.redact(fields))
        line = json.dumps(rec, default=str, ensure_ascii=False)
        with self._lock:
            with self.path.open("a", encoding="utf-8") as f:
                f.write(line + "\n")

    def for_engine(self, engine: str) -> "Audit":
        return Audit(path=self.path, engagement=self.engagement,
                     run_id=self.run_id, engine=engine, enabled=self.enabled)

    # --------------------------------------------------------- reading

    def read(self, limit: int = 0, event: str | None = None) -> list[dict]:
        if not self.path.exists():
            return []
        out = []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                r = json.loads(line)
            except json.JSONDecodeError:
                continue
            if event and r.get("event") != event:
                continue
            out.append(r)
        return out[-limit:] if limit else out

    def summary(self) -> str:
        recs = self.read()
        if not recs:
            return "No audit records yet."
        by_event, by_engine, hosts = {}, {}, set()
        refusals = []
        for r in recs:
            by_event[r.get("event", "?")] = by_event.get(r.get("event", "?"), 0) + 1
            e = r.get("engine") or "-"
            by_engine[e] = by_engine.get(e, 0) + 1
            u = r.get("url", "")
            if "://" in u:
                hosts.add(u.split("/")[2])
            if r.get("event") in ("scope.refused", "redirect.refused"):
                refusals.append(r)
        lines = [f"audit: {len(recs)} records across "
                 f"{len({r.get('run') for r in recs})} run(s)",
                 f"hosts touched: {len(hosts)}",
                 "",
                 "by event:"]
        lines += [f"  {k:22} {v}" for k, v in sorted(by_event.items(),
                                                     key=lambda x: -x[1])]
        lines += ["", "by engine:"]
        lines += [f"  {k:22} {v}" for k, v in sorted(by_engine.items(),
                                                     key=lambda x: -x[1])]
        if refusals:
            lines += ["", f"scope refusals ({len(refusals)}) — these are the "
                          f"gate working, not errors:"]
            for r in refusals[-10:]:
                lines.append(f"  {r.get('url', r.get('from_url', ''))[:70]}  "
                             f"{r.get('reason', '')[:70]}")
        return "\n".join(lines)


_DEFAULT: Audit | None = None


def default(engagement: str = "") -> Audit:
    global _DEFAULT
    if _DEFAULT is None:
        _DEFAULT = Audit(engagement=engagement)
    return _DEFAULT
