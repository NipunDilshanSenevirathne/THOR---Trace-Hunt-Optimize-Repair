"""
Attack chaining.

A single low-severity finding is usually a duplicate and often pays nothing.
The same finding as a link in a chain can be a critical. This module looks
for combinations the individual detectors cannot see, because each one only
ever looks at its own experiment.

Rules are explicit and evidence-backed: every edge in a chain points at real
experiment ids. No chain is inferred from a model's narrative.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field

from .db import DB

SEV_ORDER = ["info", "low", "medium", "high", "critical"]


def _bump(sev: str, steps: int = 1) -> str:
    i = SEV_ORDER.index(sev) if sev in SEV_ORDER else 1
    return SEV_ORDER[min(i + steps, len(SEV_ORDER) - 1)]


@dataclass
class Chain:
    name: str
    severity: str
    narrative: str
    links: list[int] = field(default_factory=list)     # finding ids
    evidence: list[int] = field(default_factory=list)  # experiment ids
    rationale: str = ""


# Each rule: (name, predicate over the finding set, builder)
def find_chains(db: DB, log=print) -> list[Chain]:
    findings = [dict(r) for r in db.q("SELECT * FROM findings")]
    if len(findings) < 1:
        return []

    by_class: dict[str, list[dict]] = {}
    for f in findings:
        by_class.setdefault(f["vuln_class"], []).append(f)

    def host(f):
        return (f["asset"] or "").split(":")[0]

    chains: list[Chain] = []

    # --- 1. disclosure -> authz: leaked ids feed an IDOR -----------------
    disclosures = [f for f in findings
                   if f["vuln_class"] in ("graphql", "authz")
                   and "id" in (f["summary"] or "").lower()]
    idors = by_class.get("authz", [])
    for d in disclosures:
        for i in idors:
            if d["id"] == i["id"] or host(d) != host(i):
                continue
            chains.append(Chain(
                name="Enumeration chain",
                severity=_bump(i["severity"]),
                narrative=(
                    f"Object identifiers disclosed by {d['route']} supply the "
                    f"input required to exploit the authorisation failure on "
                    f"{i['route']} at scale. Individually the disclosure is "
                    f"low-impact and the authorisation flaw requires knowing "
                    f"an identifier; together they permit systematic access "
                    f"to other users' records."),
                links=[d["id"], i["id"]],
                evidence=json.loads(d["evidence_ids"] or "[]")
                         + json.loads(i["evidence_ids"] or "[]"),
                rationale="disclosure supplies the identifier the IDOR needs",
            ))

    # --- 2. read IDOR + write BFLA on the same route ---------------------
    for a in by_class.get("authz", []):
        for b in by_class.get("bfla", []):
            if a["route"] != b["route"]:
                continue
            chains.append(Chain(
                name="Read-write takeover",
                severity="critical",
                narrative=(
                    f"The same route {a['route']} permits both unauthorised "
                    f"reads (object-level) and unauthorised writes "
                    f"(function-level). An attacker can therefore not only "
                    f"view another user's record but modify or destroy it."),
                links=[a["id"], b["id"]],
                evidence=json.loads(a["evidence_ids"] or "[]")
                         + json.loads(b["evidence_ids"] or "[]"),
                rationale="read and write both unauthorised on one object",
            ))

    # --- 3. mass assignment + authz = privilege escalation ---------------
    for m in by_class.get("massassign", []):
        for a in by_class.get("authz", []):
            if host(m) != host(a):
                continue
            chains.append(Chain(
                name="Privilege escalation chain",
                severity="critical",
                narrative=(
                    f"A privileged attribute can be injected at {m['route']}, "
                    f"and authorisation is not enforced at {a['route']}. An "
                    f"attacker can target another account's object and set a "
                    f"privileged attribute on it, converting a data-access "
                    f"issue into account takeover."),
                links=[m["id"], a["id"]],
                evidence=json.loads(m["evidence_ids"] or "[]")
                         + json.loads(a["evidence_ids"] or "[]"),
                rationale="attribute injection applied across a broken "
                          "authorisation boundary",
            ))

    # --- 4. path ACL bypass onto an admin route --------------------------
    for p in by_class.get("pathacl", []):
        if any(k in (p["route"] or "").lower()
               for k in ("admin", "internal", "manage", "console", "staff")):
            chains.append(Chain(
                name="Administrative surface exposure",
                severity="critical",
                narrative=(
                    f"The gateway ACL protecting {p['route']} can be bypassed "
                    f"by request normalisation. The route is administrative, "
                    f"so the bypass exposes privileged functionality rather "
                    f"than ordinary content."),
                links=[p["id"]],
                evidence=json.loads(p["evidence_ids"] or "[]"),
                rationale="ACL bypass lands on an administrative path",
            ))

    # --- 5. SSRF + cloud metadata ----------------------------------------
    ssrf = [f for f in findings if "ssrf" in (f["vuln_class"] or "")
            or "ssrf" in (f["summary"] or "").lower()]
    for s in ssrf:
        if "metadata" in (s["summary"] or "").lower():
            chains.append(Chain(
                name="SSRF to cloud credential access",
                severity="critical",
                narrative=(
                    f"Server-side request forgery at {s['route']} reaches the "
                    f"cloud instance metadata service. This exposes instance "
                    f"role credentials, which typically grant access to the "
                    f"account's cloud resources."),
                links=[s["id"]],
                evidence=json.loads(s["evidence_ids"] or "[]"),
                rationale="SSRF confirmed against the metadata endpoint",
            ))

    # --- 6. CORS + authz: cross-origin theft of the leaked data ----------
    for c in by_class.get("cors", []):
        for a in by_class.get("authz", []):
            if host(c) != host(a):
                continue
            chains.append(Chain(
                name="Cross-origin data theft",
                severity=_bump(a["severity"]),
                narrative=(
                    f"Credentialed cross-origin requests are permitted from "
                    f"an arbitrary origin, and {a['route']} returns other "
                    f"users' data. A page controlled by the attacker can "
                    f"therefore read that data from a victim's browser "
                    f"without any interaction beyond visiting the page."),
                links=[c["id"], a["id"]],
                evidence=json.loads(c["evidence_ids"] or "[]")
                         + json.loads(a["evidence_ids"] or "[]"),
                rationale="credentialed CORS turns a server-side leak into a "
                          "client-side one",
            ))

    # --- 7. JWT forgery escalates everything on that host ----------------
    for j in by_class.get("jwt", []):
        others = [f for f in findings
                  if host(f) == host(j) and f["id"] != j["id"]]
        if others:
            chains.append(Chain(
                name="Token forgery amplification",
                severity="critical",
                narrative=(
                    f"Forged authentication tokens are accepted on "
                    f"{host(j)}. Every other finding on this host should be "
                    f"re-evaluated assuming the attacker can assume an "
                    f"arbitrary identity, including privileged ones."),
                links=[j["id"]] + [o["id"] for o in others[:5]],
                evidence=json.loads(j["evidence_ids"] or "[]"),
                rationale="token forgery removes the identity constraint from "
                          "all other findings on the host",
            ))

    # dedupe by (name, sorted links)
    seen, uniq = set(), []
    for c in chains:
        k = (c.name, tuple(sorted(c.links)))
        if k not in seen:
            seen.add(k)
            uniq.append(c)

    log(f"[chain] {len(uniq)} chain(s) from {len(findings)} findings")
    return uniq


CANDIDATE_SCHEMA = """
CREATE TABLE IF NOT EXISTS severity_escalations (
  id          INTEGER PRIMARY KEY,
  finding_id  INTEGER NOT NULL,
  rule        TEXT NOT NULL,
  from_sev    TEXT,
  to_sev      TEXT,
  reason      TEXT,
  created_at  TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(finding_id, rule)
);

CREATE TABLE IF NOT EXISTS chain_candidates (
  id          INTEGER PRIMARY KEY,
  fingerprint TEXT UNIQUE,
  name        TEXT,
  source      TEXT,        -- 'rule' | 'ai'
  links       TEXT,        -- json: finding ids
  evidence    TEXT,        -- json: experiment ids
  narrative   TEXT,
  rationale   TEXT,
  proposed_severity TEXT,  -- what the proposer claimed; advisory only
  severity    TEXT,        -- derived from the linked findings
  status      TEXT DEFAULT 'proposed',   -- proposed|verified|rejected
  blocked_by  TEXT,        -- json: why verification failed
  finding_id  INTEGER,     -- set once it becomes a finding
  created_at  TEXT DEFAULT CURRENT_TIMESTAMP,
  verified_at TEXT
);
"""


def ensure(db: DB) -> None:
    db.conn.executescript(CANDIDATE_SCHEMA)


def escalate(db: DB, finding_id: int, rule: str, reason: str,
             steps: int = 1, log=print) -> bool:
    """
    Raise one finding's severity under a named, recorded rule.

    A "chain" with a single link is not a chain -- it is the same bug with
    a more exciting title. Two of the rules here produced exactly that, as
    a *separate* finding hard-coded to `critical`. For a bug bounty hunter
    that is the worst possible output: the same defect submitted twice, the
    second copy claiming a severity nothing measured.

    So a single-link rule escalates the finding it is about, by one level,
    and the rule and reason are recorded. Every escalation is answerable to
    "which rule did that, and why".
    """
    ensure(db)
    f = db.one("SELECT severity FROM findings WHERE id=?", finding_id)
    if not f:
        return False
    if db.one("SELECT 1 FROM severity_escalations WHERE finding_id=? AND rule=?",
              finding_id, rule):
        return False                      # already applied; not cumulative
    before = (f["severity"] or "info").lower()
    after = _bump(before, steps)
    if after == before:
        return False
    db.ex("UPDATE findings SET severity=? WHERE id=?", after, finding_id)
    db.ex("INSERT INTO severity_escalations (finding_id, rule, from_sev, "
          "to_sev, reason) VALUES (?,?,?,?,?)",
          finding_id, rule, before, after, reason)
    log(f"[chain] finding {finding_id}: {before} → {after}  ({rule})")
    return True


def escalations_for(db: DB, finding_id: int) -> list[dict]:
    ensure(db)
    return [dict(r) for r in db.q(
        "SELECT rule, from_sev, to_sev, reason FROM severity_escalations "
        "WHERE finding_id=? ORDER BY id", finding_id)]


def propose(db: DB, chains: list[Chain], source: str = "rule",
            log=print) -> int:
    """
    Record chain proposals. This does NOT create findings.

    Both the rule engine and the AI arrive here. The AI used to call a
    function that inserted straight into `findings` -- with
    `disproof_done=1` and a model-chosen severity -- so a model could
    produce a critical finding that claimed its own disproof had been
    executed. The module docstring said "No chain is inferred from a
    model's narrative" while the code did exactly that.

    A proposal is a hypothesis about how findings combine. It becomes a
    finding only by passing `verify()`, which checks the links rather than
    reading the narrative.
    """
    ensure(db)
    n = 0
    for c in chains:
        # A single-link rule is a severity escalation, not a chain. Route
        # it to the finding it is about rather than minting a duplicate.
        if len(set(c.links)) == 1:
            escalate(db, c.links[0], rule=c.name,
                     reason=c.rationale or c.narrative[:200], log=log)
            continue
        fp = f"chain:{c.name}:{'-'.join(map(str, sorted(c.links)))}"
        if db.one("SELECT 1 FROM chain_candidates WHERE fingerprint=?", fp):
            continue
        db.ex(
            "INSERT INTO chain_candidates (fingerprint, name, source, links, "
            "evidence, narrative, rationale, proposed_severity, status) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            fp, c.name, source, json.dumps(sorted(set(c.links))),
            json.dumps(sorted(set(c.evidence))), c.narrative, c.rationale,
            c.severity, "proposed")
        n += 1
        log(f"[chain] proposed ({source}): {c.name}  links={c.links}")
    return n


# Severity of a chain is the highest severity among its verified links.
# It is deliberately NOT escalated for being a chain: "these combine" is a
# claim about reachability, and reachability is already what the links
# prove. Escalating on top of that is how a pile of lows becomes a
# fictional critical.
def _chain_severity(linked: list[dict]) -> str:
    best = "info"
    for f in linked:
        s = (f.get("severity") or "info").lower()
        if s in SEV_ORDER and SEV_ORDER.index(s) > SEV_ORDER.index(best):
            best = s
    return best


def verify(db: DB, candidate_id: int, log=print) -> tuple[bool, list[str]]:
    """
    Decide deterministically whether a proposed chain may become a finding.

    Every link must be a finding that has itself reached VERIFIED, because
    a chain of unproven steps proves nothing. Evidence ids must exist. A
    chain needs at least two distinct links, or it is just a restatement of
    one finding with a more exciting title.
    """
    from . import states

    ensure(db)
    c = db.one("SELECT * FROM chain_candidates WHERE id=?", candidate_id)
    if not c:
        return False, [f"no chain candidate {candidate_id}"]

    links = json.loads(c["links"] or "[]")
    evidence = json.loads(c["evidence"] or "[]")
    blocked: list[str] = []

    if len(set(links)) < 2:
        blocked.append("a chain needs at least two distinct findings")

    verified_ok = states.ORDER[states.ORDER.index(states.VERIFIED):]
    linked: list[dict] = []
    for fid in links:
        row = db.one("SELECT * FROM findings WHERE id=?", fid)
        if not row:
            blocked.append(f"finding {fid} does not exist")
            continue
        row = dict(row)
        linked.append(row)
        if row["status"] not in verified_ok:
            blocked.append(
                f"finding {fid} is '{row['status']}', not yet verified — "
                f"a chain of unproven steps proves nothing")

    for eid in evidence:
        if not db.one("SELECT 1 FROM experiments WHERE id=?", eid):
            blocked.append(f"experiment {eid} does not exist")

    if blocked:
        db.ex("UPDATE chain_candidates SET status='proposed', blocked_by=? "
              "WHERE id=?", json.dumps(blocked), candidate_id)
        return False, blocked

    severity = _chain_severity(linked)
    asset = linked[0].get("asset", "")
    route = " + ".join(sorted({f.get("route", "") for f in linked}))
    # Only claim the disproof is done if every link's disproof was done.
    disproof = 1 if all(f.get("disproof_done") for f in linked) else 0

    fid = db.ex(
        "INSERT INTO findings (fingerprint, vuln_class, severity, title, "
        "asset, route, summary, evidence_ids, disproof_done, status) "
        "VALUES (?,?,?,?,?,?,?,?,?,?)",
        c["fingerprint"], "chain", severity, c["name"], asset, route,
        c["rationale"], json.dumps(evidence), disproof, states.CANDIDATE)
    db.ex("UPDATE chain_candidates SET status='verified', finding_id=?, "
          "severity=?, blocked_by=NULL, verified_at=CURRENT_TIMESTAMP "
          "WHERE id=?", fid, severity, candidate_id)
    log(f"[chain] verified: {c['name']}  severity={severity} "
        f"(from its links, not from the proposal)")
    return True, []


def verify_all(db: DB, log=print) -> dict:
    ensure(db)
    out = {"verified": 0, "blocked": 0}
    for row in db.q("SELECT id FROM chain_candidates WHERE status='proposed'"):
        ok, _why = verify(db, row["id"], log=log)
        out["verified" if ok else "blocked"] += 1
    return out


def reject(db: DB, candidate_id: int, reason: str = "") -> None:
    ensure(db)
    db.ex("UPDATE chain_candidates SET status='rejected', blocked_by=? "
          "WHERE id=?", json.dumps([reason or "operator rejected"]),
          candidate_id)


def candidates_report(db: DB) -> str:
    ensure(db)
    rows = db.q("SELECT * FROM chain_candidates ORDER BY id")
    if not rows:
        return "No chain candidates."
    out = ["chain candidates", "─" * 62]
    for r in rows:
        mark = {"verified": "✓", "rejected": "✗"}.get(r["status"], "·")
        out.append(f"  {mark} [{r['id']}] {r['name']}  "
                   f"({r['source']}, {r['status']})")
        out.append(f"      links {json.loads(r['links'] or '[]')}"
                   f"  proposed={r['proposed_severity']}"
                   + (f"  derived={r['severity']}" if r["severity"] else ""))
        for b in json.loads(r["blocked_by"] or "[]"):
            out.append(f"      ✗ {b}")
    out.append("")
    out.append("A proposal is not a finding. Severity is derived from the "
               "linked findings,\nnever from the proposer — including when "
               "the proposer is the AI.")
    return "\n".join(out)


def persist(db: DB, chains: list[Chain], log=print) -> int:
    """Deprecated name kept for callers: proposes, and verifies what it can."""
    n = propose(db, chains, source="rule", log=log)
    verify_all(db, log=log)
    return n


def report_text(chains: list[Chain]) -> str:
    if not chains:
        return "No chains identified."
    out = []
    for c in chains:
        out.append(f"## {c.name}  [{c.severity.upper()}]\n")
        out.append(f"Links findings: {c.links}\n")
        out.append(f"Evidence experiments: {c.evidence}\n")
        out.append(f"\n{c.narrative}\n")
        out.append(f"\n*Why these combine:* {c.rationale}\n")
    return "\n".join(out)
