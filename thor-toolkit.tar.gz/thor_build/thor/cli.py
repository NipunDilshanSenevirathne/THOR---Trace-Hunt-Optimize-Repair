"""
THOR — command line.

Every phase runs standalone and deterministically. No command requires the
AI layer; `thor ai` only produces briefs for you to answer elsewhere.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import (ai, anomaly, audit, chain, corpus, dataflow, detectors, engine,
               evidence, experiment, fuzz, graph, history, identity,
               invariants, learn, loop, mobile, oast, oauth, probes, reason,
               recon, report, risk, rootcause, runtime, schema, sourceintel,
               states, tools, vault, workflow)
from .db import DB
from .scope import Scope, ScopeViolation

BANNER = (
    "THOR — evidence-driven web application security research\n"
    "by Nipun Dilshan   ·   authorised targets only\n"
    "\n"
    "Every verdict comes from observed bytes. The AI layer never\n"
    "decides whether a vulnerability exists."
)


_DB_CACHE: dict[str, DB] = {}


def _db(a) -> DB:
    """
    One connection per database file per process.

    Opening a second connection to the same SQLite file from the same
    process is how you get 'database is locked' under the threaded race and
    fuzz engines: two connections, two write locks, one file. `_scope()`
    also needs a handle for the budget, so without this cache every command
    that touches both opened two.
    """
    db = _DB_CACHE.get(a.db)
    if db is None:
        db = DB(a.db)
        _DB_CACHE[a.db] = db
    return db


def _scope(a) -> Scope:
    """
    Load the scope AND bind the engagement runtime.

    Binding here rather than inside each command is deliberate: every engine
    reaches the shared budget, rate limiter and concurrency semaphore
    through `runtime`, so a command that forgets to ask still ends up inside
    the boundary. Before this, each engine minted its own budget and a
    20,000-request ceiling silently became 20,000 per engine.
    """
    sc = Scope.load(a.scope)
    try:
        runtime.bind(sc, db=_db(a), vault=vault.default())
    except Exception:
        # Binding must never be the reason a command cannot run; an unbound
        # runtime falls back to a private budget, which is the old (weaker)
        # behaviour rather than no behaviour.
        pass
    return sc


# ---------------------------------------------------------------- commands

def cmd_init(a):
    p = Path(a.scope)
    if p.exists() and not a.force:
        print(f"{p} exists. Use --force to overwrite.")
        return 1
    p.write_text(SCOPE_TEMPLATE.format(domain=a.domain or "example.com"))
    DB(a.db)
    print(f"Wrote {p} and {a.db}.")
    print("EDIT THE SCOPE FILE before running anything. Nothing runs until "
          "allowed_hosts matches the program's published scope.")
    return 0


def cmd_doctor(a):
    st = tools.doctor()
    missing = [t for t, ok in st.items() if not ok]
    for t, ok in st.items():
        print(f"  {'✓' if ok else '✗'} {t}")
    if missing:
        print("\nInstall the missing ones:")
        for t in missing:
            print(f"  {tools.TOOLS[t]}")
    try:
        s = _scope(a)
        print(f"\nScope OK: {s.summary()}")
    except (ScopeViolation, Exception) as e:
        print(f"\nScope problem: {e}")
        return 1
    print(f"DB: {json.dumps(_db(a).stats())}")
    return 0


def cmd_recon(a):
    db, sc = _db(a), _scope(a)
    recon.run_recon(db, sc, a.domain, brute=not a.no_brute, ports=a.ports,
                    crawl=not a.no_crawl, js=not a.no_js)
    scores = anomaly.score_assets(db)
    anomaly.persist(db, scores)
    print(f"\nTop targets:\n")
    for r in anomaly.top(db, 10):
        print(f"  {r['score']:6.1f}  {r['host']}  [{r['status']}] {(r['title'] or '')[:50]}")
    return 0


def cmd_triage(a):
    db = _db(a)
    scores = anomaly.score_assets(db)
    anomaly.persist(db, scores)
    rows = anomaly.top(db, a.top)
    if a.json:
        print(json.dumps(rows, indent=2))
        return 0
    for r in rows:
        print(f"\n{r['score']:6.1f}  {r['url']}  [{r['status']}]")
        if r["title"]:
            print(f"         {r['title'][:80]}")
        for reason in r["reasons"][:6]:
            print(f"         · {reason}")
    return 0


def cmd_nuclei(a):
    recon.run_nuclei(_db(a), _scope(a), severity=a.severity)
    return 0


def cmd_identity(a):
    db = _db(a)
    if a.action == "add":
        headers = {}
        for h in a.header or []:
            k, _, v = h.partition(":")
            headers[k.strip()] = v.strip()
        if a.cookie:
            headers["Cookie"] = a.cookie
        if a.bearer:
            headers["Authorization"] = f"Bearer {a.bearer}"
        identity.add(db, a.name, headers, role=a.role, tenant=a.tenant or "")
    elif a.action == "list":
        # Listing is the one place unresolved identities must be shown
        # rather than raised on — that is how the operator diagnoses it.
        broken = False
        for i in identity.load_all(db, allow_unresolved=True).values():
            mark = "vault" if i.credential_ref else "-"
            if i.unresolved:
                broken = True
                print(f"  {i.name:12} role={i.role:10} "
                      f"tenant={i.tenant or '-':10} creds=UNRESOLVED  "
                      f"← {i.unresolved}")
                continue
            print(f"  {i.name:12} role={i.role:10} tenant={i.tenant or '-':10} "
                  f"creds={mark:6} headers={sorted(i.headers)}")
        if broken:
            print("\nUNRESOLVED identities cannot be used. Engines will "
                  "refuse to run rather than\nsend those probes "
                  "unauthenticated and record the 401s as 'denied'.")
            return 1
        print("\nCredential values live in the encrypted vault, never in the "
              "research database.")
    elif a.action == "rm":
        r = db.one("SELECT credential_ref FROM identities WHERE name=?", a.name)
        if r and r["credential_ref"]:
            try:
                vault.default().delete(r["credential_ref"])
            except Exception:
                pass
        db.ex("DELETE FROM identities WHERE name=?", a.name)
        print(f"removed {a.name} and its vault entry")
    return 0


def cmd_vault(a):
    v = vault.default()
    if a.action == "list":
        refs = v.list_refs()
        if not refs:
            print("vault is empty")
        for ref, label in refs:
            print(f"  {ref}  {label}")
    elif a.action == "rotate":
        v.rotate()
        print("vault re-encrypted under a fresh key")
    elif a.action == "check":
        print(f"cryptography available: {vault.HAVE_CRYPTO}")
        print(f"OS keyring available:   {vault.HAVE_KEYRING}")
        print(f"vault path:             {v.path}")
        print(f"entries:                {len(v.list_refs())}")
    return 0


def cmd_graph(a):
    db = _db(a)
    if a.action == "build":
        graph.build(db, a.corpus)
    print()
    print(graph.render(db, a.root))
    return 0


def cmd_invariants(a):
    db = _db(a)
    invariants.install(db)
    invariants.evaluate(db)
    print()
    print(invariants.report(db))
    return 0


def cmd_reason(a):
    db = _db(a)
    graph.build(db, a.corpus, log=lambda *x: None)
    print(reason.report(db, a.corpus, top=a.top))
    if a.persist:
        reason.persist(db, reason.generate(db, a.corpus, log=lambda *x: None))
    return 0


def cmd_source(a):
    db = _db(a)
    if a.action == "scan":
        routes = sourceintel.scan(a.path)
        sourceintel.persist(db, routes)
        if dataflow.available():
            flows = dataflow.scan(a.path)
            dataflow.persist(db, flows)
        else:
            print("[source] tree-sitter not installed — AST data-flow skipped. "
                  "pip install tree_sitter tree_sitter_language_pack")
    elif a.action == "dataflow":
        flows = dataflow.scan(a.path)
        dataflow.persist(db, flows)
        print()
        print(dataflow.report(db))
        return 0
    elif a.action == "correlate":
        sourceintel.correlate(db, a.corpus)
        sourceintel.promote(db)
        dataflow.correlate(db, a.corpus)
    print()
    print(sourceintel.report(db))
    if a.action != "scan":
        print()
        print(dataflow.report(db))
    return 0


def cmd_state(a):
    db = _db(a)
    if a.action == "advance":
        states.advance_all(db)
    elif a.action == "reject":
        if not a.id:
            print("--id required")
            return 2
        states.reject(db, a.id, a.reason or "operator rejected")
        print(f"finding {a.id} rejected")
    elif a.action == "gates":
        if not a.id:
            print("--id required")
            return 2
        # Gates are evaluated independently, but they are passed in order.
        # Printing PASS for a later gate while an earlier one is held reads
        # as "you could submit this", which is the opposite of true.
        blocked = False
        for target in states.ORDER[1:]:
            r = states.evaluate(db, a.id, target)
            if blocked:
                mark = "—"
            elif r.moved:
                mark = "PASS"
            else:
                mark = "HELD"
            print(f"  {target:24} {mark}")
            for b in r.blocked_by:
                print(f"        ✗ {b}")
            if not r.moved and not blocked:
                blocked = True
        if blocked:
            print("\n  '—' is not reachable until the gate above it passes.")
        return 0
    print()
    print(states.report(db))
    return 0


def cmd_hypotheses(a):
    db = _db(a)
    if a.action == "replan":
        experiment.replan(db, a.corpus)
    elif a.action == "next":
        h, gain, why = experiment.select(db, a.corpus)
        if not h:
            print("no open hypotheses")
            return 0
        print(f"H-{h['id']:03d}  {why}")
        print(f"  {h['statement']}")
        print(f"  engine:     {h['engine']}")
        print(f"  target:     {h['target']}")
        print(f"  predicts:   {h['predicted']}")
        print(f"  falsifier:  {h['falsifier']}")
        return 0
    elif a.action == "run":
        h, gain, why = experiment.select(db, a.corpus)
        if not h:
            print("no open hypotheses")
            return 0
        oc = oast.make("none")
        print(f"H-{h['id']:03d}  {why}\n  {h['statement']}")
        out = experiment.execute(db, _scope(a), a.corpus, h, oast=oc)
        print(out.render())
        oc.close()
        return 0
    print()
    print(experiment.ledger(db))
    return 0


def cmd_mobile(a):
    db, sc = _db(a), _scope(a)
    if a.action == "analyse":
        intel = mobile.analyse(a.path)
        mobile.ingest(db, sc, intel)
    print()
    print(mobile.report(db, a.corpus or "prod"))
    return 0


def cmd_audit(a):
    al = audit.default()
    if a.tail:
        for r in al.read(limit=a.tail):
            print(json.dumps(r))
    else:
        print(al.summary())
    return 0


def cmd_capture(a):
    db, sc = _db(a), _scope(a)
    p = Path(a.file)
    if a.format == "auto":
        fmt = "har" if p.suffix.lower() == ".har" else "burp"
    else:
        fmt = a.format
    if fmt == "har":
        corpus.import_har(db, sc, p, a.corpus, a.identity)
    else:
        corpus.import_burp_xml(db, sc, p, a.corpus, a.identity)
    cands = corpus.authz_candidates(db, a.corpus)
    print(f"{len(cands)} requests carry object references and are testable.")
    return 0


def cmd_authz(a):
    engine.run_authz(_db(a), _scope(a), a.corpus, min_conf=a.min_conf,
                     limit=a.limit)
    return 0


def cmd_bfla(a):
    engine.run_bfla(_db(a), _scope(a), a.corpus)
    return 0


def cmd_massassign(a):
    engine.run_massassign(_db(a), _scope(a), a.corpus)
    return 0


def cmd_race(a):
    engine.run_race(_db(a), _scope(a), a.corpus, n=a.n)
    return 0


def cmd_schema(a):
    db = _db(a)
    s = schema.infer(db, a.corpus)
    schema.persist(db, a.corpus, s)
    if a.json:
        print(json.dumps({k: v.to_dict() for k, v in s.items()}, indent=2))
    else:
        print(schema.summary(s))
        print(f"\n{len(s)} endpoint schemas, "
              f"{sum(len(x.fields) for x in s.values())} fields")
    return 0


def _persist_fuzz(db, res):
    """Write fuzz hits into the experiments table so promote() can see them."""
    for h in res.hits:
        db.ex("INSERT OR REPLACE INTO experiments (signature, kind, as_identity, "
              "method, url, status, verdict, score, detail) "
              "VALUES (?,?,?,?,?,?,?,?,?)",
              f"fuzz:{h['endpoint']}:{h['field']}:{h['oracle']}",
              h["family"], "fuzz", "MUT", h["endpoint"], 0,
              "leak" if h["confidence"] >= 0.55 else "inconclusive",
              h["confidence"],
              json.dumps({"reasons": [h["signal"]], "oracle": h["oracle"],
                          "payload": h["payload"], "intent": h["intent"],
                          "field": h["field"], "shared_values": [], "pii": [],
                          "detail": h["detail"]}))


def cmd_fuzz(a):
    db, sc = _db(a), _scope(a)
    oc = oast.make(a.oast, domain=a.oast_domain, server=a.oast_server)
    try:
        res = fuzz.run_fuzz(db, sc, a.corpus, oast=oc,
                            aggressive=a.aggressive,
                            max_cases=a.max_cases,
                            max_fields_per_endpoint=a.max_fields,
                            only_route=a.route)
        _persist_fuzz(db, res)
    finally:
        oc.close()
    return 0


def cmd_detect(a):
    db, sc = _db(a), _scope(a)
    which = a.which or ["graphql", "jwt", "pathacl", "cors", "cache"]
    fns = {"graphql": detectors.graphql, "jwt": detectors.jwt_attacks,
           "pathacl": detectors.path_acl, "cors": detectors.cors,
           "cache": detectors.cache_poison}
    for w in which:
        if w in fns:
            fns[w](db, sc, a.corpus)
    return 0


def cmd_chain(a):
    db = _db(a)
    if a.action == "candidates":
        print()
        print(chain.candidates_report(db))
        return 0
    if a.action == "verify":
        res = chain.verify_all(db)
        print(f"[chain] {res['verified']} verified, {res['blocked']} blocked")
        print()
        print(chain.candidates_report(db))
        return 0
    if a.action == "reject":
        if not a.id:
            print("--id required")
            return 2
        chain.reject(db, a.id, a.reason or "operator rejected")
        print(f"chain candidate {a.id} rejected")
        return 0

    # Advance first. A chain may only be built from verified links, so
    # chaining before the state machine has run would block every
    # candidate for a reason that is about ordering, not about evidence.
    states.advance_all(db, log=lambda *a, **k: None)
    chains = chain.find_chains(db)
    chain.propose(db, chains, source="rule")
    res = chain.verify_all(db)
    print(f"[chain] {res['verified']} verified, {res['blocked']} awaiting "
          f"verification")
    if chains:
        print()
        print(chain.report_text(chains))
    print()
    print(chain.candidates_report(db))
    return 0


def cmd_all(a):
    """Full deterministic sweep. No tokens spent."""
    db, sc = _db(a), _scope(a)
    print("=== schema inference ===")
    s = schema.infer(db, a.corpus)
    schema.persist(db, a.corpus, s)
    print(f"{len(s)} endpoints, {sum(len(x.fields) for x in s.values())} fields\n")
    print("=== authorization ===")
    engine.run_authz(db, sc, a.corpus)
    engine.run_bfla(db, sc, a.corpus)
    engine.run_massassign(db, sc, a.corpus)
    print("\n=== targeted detectors ===")
    for fn in (detectors.graphql, detectors.jwt_attacks, detectors.path_acl,
               detectors.cors, detectors.cache_poison):
        try:
            fn(db, sc, a.corpus)
        except Exception as e:
            print(f"  {fn.__name__} failed: {e}")
    print("\n=== fuzzing ===")
    oc = oast.make(a.oast, domain=a.oast_domain)
    try:
        res = fuzz.run_fuzz(db, sc, a.corpus, oast=oc, max_cases=a.max_cases)
        _persist_fuzz(db, res)
    finally:
        oc.close()
    print("\n=== promote + chain ===")
    evidence.promote(db)
    chain.persist(db, chain.find_chains(db))
    print()
    return cmd_findings(a)


def cmd_snapshot(a):
    history.take(_db(a), label=a.label or "")
    return 0


def cmd_diff(a):
    db = _db(a)
    d = history.diff(db, since=a.since, until=a.until)
    print(history.report(d))
    if not d.is_empty():
        history.boost_novel(db, d)
        print("\nPriority targets (novel surface has had the fewest eyes):")
        for t in d.priority_targets()[:25]:
            print(f"  {t}")
    return 0


def cmd_oauth(a):
    oauth.run(_db(a), _scope(a), a.corpus)
    return 0


def cmd_tenant(a):
    probes.tenant(_db(a), _scope(a), a.corpus)
    return 0


def cmd_workflow(a):
    db, sc = _db(a), _scope(a)
    g = risk.gate_for(sc)
    if not g.allows("workflow"):
        print(g.explain("workflow"))
        return 2
    workflow.run(db, sc, a.corpus)
    return 0


def cmd_probe(a):
    db, sc = _db(a), _scope(a)
    which = a.which or ["redirect", "sourcemap", "protopollution"]
    fns = {"redirect": lambda: probes.open_redirect(db, sc, a.corpus),
           "sourcemap": lambda: probes.sourcemaps(db, sc),
           "protopollution": lambda: probes.prototype_pollution(db, sc, a.corpus),
           "upload": lambda: probes.upload(db, sc, a.corpus),
           "tenant": lambda: probes.tenant(db, sc, a.corpus)}
    allowed = risk.filter_engines(sc, which)
    for w in allowed:
        if w in fns:
            fns[w]()
    return 0


def cmd_rootcause(a):
    db = _db(a)
    causes = rootcause.analyse(db)
    rootcause.persist(db, causes)
    print()
    print(rootcause.report_text(db))
    return 0


def cmd_learn(a):
    db = _db(a)
    if a.reset:
        learn.ensure(db)
        db.ex("DELETE FROM arms")
    learn.harvest(db)
    print()
    print(learn.report(db))
    print()
    print(learn.ledger(db))
    return 0


def cmd_loop(a):
    db, sc = _db(a), _scope(a)
    loop.run(db, sc, a.corpus, minutes=a.minutes, max_rounds=a.rounds,
             oast_kind=a.oast, oast_domain=a.oast_domain,
             ai_checkpoints=not a.no_ai)
    return 0


def cmd_status(a):
    print(loop.status(_db(a)))
    return 0


def cmd_risk(a):
    sc = _scope(a)
    g = risk.gate_for(sc)
    print(f"ceiling: {risk.NAMES[g.ceiling]}  ({'; '.join(g.reasons)})\n")
    for e, lvl in sorted(risk.ENGINE_RISK.items(), key=lambda x: (x[1], x[0])):
        if not risk.implemented(e):
            print(f"  — {risk.NAMES[lvl]:12} {e}   (not implemented)")
            continue
        mark = "✓" if lvl <= g.ceiling else "✗"
        print(f"  {mark} {risk.NAMES[lvl]:12} {e}")
    print("\n✗ engines are skipped. Raise the ceiling in scope.yaml only if "
          "the program permits it.")
    if risk.NOT_IMPLEMENTED:
        print("\n— engines are declared but have no implementation:")
        for e, why in sorted(risk.NOT_IMPLEMENTED.items()):
            print(f"    {e}: {why}")
    return 0


def cmd_budget(a):
    sc = _scope(a)
    db = _db(a)
    if a.action == "reset":
        if not a.confirm:
            print("This resets the engagement-wide request counter.\n"
                  "The ceiling exists because the program authorised a "
                  "number of requests, not a number per run.\n"
                  "Re-run with --confirm if this really is a new engagement.")
            return 2
        db.conn.executescript(runtime.SCHEMA)
        db.ex("UPDATE budget_state SET used=0, updated_at=? WHERE engagement=?",
              runtime.utcstamp(), sc.engagement or "default")
        runtime.bind(sc, db=db, reset_budget=True)
        print(f"[budget] '{sc.engagement}' reset to 0/{sc.max_requests}")
        return 0

    st = runtime.status()
    if not st.get("bound"):
        print("no engagement bound")
        return 0
    print(f"engagement     {st['engagement']}")
    print(f"requests       {st['requests_used']} / {st['requests_max']}"
          f"   ({st['requests_left']} left)")
    print(f"rate limit     {st['max_rps']} rps, engagement-wide")
    print(f"concurrency    {st['max_concurrency']}, engagement-wide")
    print(f"window         {st['window']}")
    print("\nThis ceiling is shared by every engine and survives restarts. "
          "It is the number\nthe program authorised, not a number per run.")
    return 0


def cmd_reproduce(a):
    db = _db(a)
    f = db.one("SELECT * FROM findings WHERE id=?", a.id)
    if not f:
        print(f"no finding {a.id}")
        return 1
    d = evidence.bundle(db, a.id)
    print(f"finding {a.id}: {f['title']}")
    print(f"severity: {f['severity']}   status: {f['status']}")
    print(f"route:    {f['route']}")
    print(f"disproof: {'executed' if f['disproof_done'] else 'NOT EXECUTED'}")
    print(f"\nbundle:   {d}")
    print(f"replay:   bash {d}/replay.sh")
    print(f"\nEnvironment recorded in {d}/finding.json (hashes, timings, "
          f"identities).")
    return 0


def cmd_promote(a):
    evidence.promote(_db(a), min_score=a.min_score)
    return 0


def cmd_findings(a):
    db = _db(a)
    rows = db.q("SELECT * FROM findings ORDER BY "
                "CASE severity WHEN 'critical' THEN 0 WHEN 'high' THEN 1 "
                "WHEN 'medium' THEN 2 ELSE 3 END, id")
    if not rows:
        print("No findings yet.")
        return 0
    for f in rows:
        ev = json.loads(f["evidence_ids"] or "[]")
        mark = "✓" if f["disproof_done"] else "!"
        print(f"  [{f['id']:3}] {mark} {f['severity']:8} {f['status']:10} "
              f"{f['title']}")
        print(f"        evidence={ev} route={f['route']}")
    print("\n  ✓ = anonymous disproof executed   ! = not yet disproved")
    return 0


def cmd_evidence(a):
    d = evidence.bundle(_db(a), a.id)
    print(f"bundle: {d}")
    for f in sorted(d.iterdir()):
        print(f"  {f.name}")
    return 0


def cmd_report(a):
    db = _db(a)
    if a.id:
        print(f"report: {report.render(db, a.id)}")
    else:
        report.render_all(db)
    return 0


def cmd_ai(a):
    db = _db(a)
    if a.action == "brief":
        b = {"triage": lambda: ai.brief_triage(db, a.top),
             "impact": lambda: ai.brief_impact(db, a.id),
             "classify": lambda: ai.brief_classify(db, a.corpus),
             "fuzz": lambda: ai.brief_fuzz(db, a.corpus),
             "chains": lambda: ai.brief_chains(db)}[a.kind]()
        p = b.write()
        print(f"wrote {p}  (~{b.est_tokens} tokens)")
        print(f"\nIn Claude Code:  /{a.kind}   (or: read {p} and answer it)")
        print(f"Then:            thor ai apply --kind {a.kind} --file answers/{a.kind}.json")
    elif a.action == "apply":
        ai.apply_answer(db, a.kind, a.file)
    return 0


def cmd_stats(a):
    print(json.dumps(_db(a).stats(), indent=2))
    return 0


# ---------------------------------------------------------------- parser

SCOPE_TEMPLATE = """\
# THOR scope gate — the security boundary of the tool itself.
# Nothing in this system sends a request that fails these rules. The gate
# resolves each host once, validates every address, and pins the connection
# to the validated address, so DNS cannot change under it.
# Copy the program's published scope here EXACTLY. When in doubt, leave it out.

engagement: {domain}

allowed_hosts:
  - "{domain}"
  - "*.{domain}"

denied_hosts: []           # anything the program excludes -- put it here

allowed_methods: [GET, HEAD, POST, OPTIONS]   # add PUT/PATCH/DELETE only
                                              # when the program allows them

allowed_ports: []          # empty = any. [443] to pin HTTPS only.

denied_path_patterns:      # regex against the path
  - "/logout"
  - "/(delete|remove|purge)/"

max_rps: 3                 # be a good guest
max_requests: 20000        # hard ceiling for the engagement

# window_start: "22:00"    # uncomment to restrict testing hours
# window_end: "05:00"

sensitive: false           # gates state-changing engines (workflow, bfla sweeps)
destructive: false         # gates DELETE/PUT sweeps and race testing
allow_private_targets: false   # true ONLY for a local lab

notes: |
  Program URL:
  Authorised by:
  Date:
  Scope last checked:
"""


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser("thor", description=BANNER)
    p.add_argument("--db", default="thor.db")
    p.add_argument("--scope", default="scope.yaml")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("init", help="write scope.yaml + create db")
    s.add_argument("domain", nargs="?")
    s.add_argument("--force", action="store_true")
    s.set_defaults(fn=cmd_init)

    s = sub.add_parser("doctor", help="check tools and scope")
    s.set_defaults(fn=cmd_doctor)

    s = sub.add_parser("recon", help="full surface map (no AI, no tokens)")
    s.add_argument("domain")
    s.add_argument("--no-brute", action="store_true")
    s.add_argument("--no-crawl", action="store_true")
    s.add_argument("--no-js", action="store_true")
    s.add_argument("--ports", action="store_true")
    s.set_defaults(fn=cmd_recon)

    s = sub.add_parser("triage", help="rank targets by anomaly score")
    s.add_argument("--top", type=int, default=20)
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_triage)

    s = sub.add_parser("nuclei", help="known-CVE pass")
    s.add_argument("--severity", default="critical,high")
    s.set_defaults(fn=cmd_nuclei)

    s = sub.add_parser("identity", help="manage auth contexts")
    s.add_argument("action", choices=["add", "list", "rm"])
    s.add_argument("name", nargs="?")
    s.add_argument("--role", default="user")
    s.add_argument("--tenant")
    s.add_argument("--header", action="append")
    s.add_argument("--cookie")
    s.add_argument("--bearer")
    s.set_defaults(fn=cmd_identity)

    s = sub.add_parser("capture", help="import Burp XML / HAR traffic")
    s.add_argument("file")
    s.add_argument("--corpus", required=True)
    s.add_argument("--identity", required=True)
    s.add_argument("--format", choices=["auto", "burp", "har"], default="auto")
    s.set_defaults(fn=cmd_capture)

    s = sub.add_parser("authz", help="cross-identity replay (IDOR/BOLA)")
    s.add_argument("--corpus", required=True)
    s.add_argument("--min-conf", type=float, default=0.7)
    s.add_argument("--limit", type=int, default=0)
    s.set_defaults(fn=cmd_authz)

    s = sub.add_parser("bfla", help="method swap + privileged route access")
    s.add_argument("--corpus", required=True)
    s.set_defaults(fn=cmd_bfla)

    s = sub.add_parser("massassign", help="privileged field injection")
    s.add_argument("--corpus", required=True)
    s.set_defaults(fn=cmd_massassign)

    s = sub.add_parser("race", help="concurrent state-change testing")
    s.add_argument("--corpus", required=True)
    s.add_argument("-n", type=int, default=12)
    s.set_defaults(fn=cmd_race)

    s = sub.add_parser("schema", help="infer request schemas from corpus")
    s.add_argument("--corpus", required=True)
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_schema)

    s = sub.add_parser("fuzz", help="grammar-aware semantic fuzzing")
    s.add_argument("--corpus", required=True)
    s.add_argument("--aggressive", action="store_true",
                   help="include time-based blind probes (slow)")
    s.add_argument("--max-cases", type=int, default=0)
    s.add_argument("--max-fields", type=int, default=25)
    s.add_argument("--route", help="only endpoints matching this substring")
    s.add_argument("--oast", choices=["auto", "interactsh", "static", "none"],
                   default="auto")
    s.add_argument("--oast-domain", help="Collaborator / custom OAST domain")
    s.add_argument("--oast-server", help="self-hosted interactsh server")
    s.set_defaults(fn=cmd_fuzz)

    s = sub.add_parser("detect", help="targeted detectors")
    s.add_argument("--corpus", required=True)
    s.add_argument("--which", nargs="*",
                   choices=["graphql", "jwt", "pathacl", "cors", "cache"])
    s.set_defaults(fn=cmd_detect)

    s = sub.add_parser("chain", help="correlate findings into attack chains")
    s.add_argument("action", nargs="?",
                   choices=["build", "candidates", "verify", "reject"],
                   default="build")
    s.add_argument("--id", type=int)
    s.add_argument("--reason")
    s.set_defaults(fn=cmd_chain)

    s = sub.add_parser("all", help="full deterministic sweep (no tokens)")
    s.add_argument("--corpus", required=True)
    s.add_argument("--max-cases", type=int, default=3000)
    s.add_argument("--oast", choices=["auto", "interactsh", "static", "none"],
                   default="auto")
    s.add_argument("--oast-domain")
    s.set_defaults(fn=cmd_all)

    s = sub.add_parser("vault", help="encrypted credential store")
    s.add_argument("action", choices=["list", "rotate", "check"])
    s.set_defaults(fn=cmd_vault)

    s = sub.add_parser("graph", help="security knowledge graph")
    s.add_argument("action", nargs="?", choices=["build", "show"], default="show")
    s.add_argument("--corpus", default="prod")
    s.add_argument("--root", default="Tenant")
    s.set_defaults(fn=cmd_graph)

    s = sub.add_parser("invariants", help="security invariants: which hold, which are violated")
    s.set_defaults(fn=cmd_invariants)

    s = sub.add_parser("reason", help="application model + ranked hypotheses")
    s.add_argument("--corpus", required=True)
    s.add_argument("--top", type=int, default=8)
    s.add_argument("--persist", action="store_true")
    s.set_defaults(fn=cmd_reason)

    s = sub.add_parser("state", help="finding lifecycle and its gates")
    s.add_argument("action", nargs="?",
                   choices=["show", "advance", "reject", "gates"],
                   default="show")
    s.add_argument("--id", type=int)
    s.add_argument("--reason")
    s.set_defaults(fn=cmd_state)

    s = sub.add_parser("hypotheses", help="the hypothesis ledger and planner")
    s.add_argument("action", nargs="?",
                   choices=["show", "next", "run", "replan"], default="show")
    s.add_argument("--corpus", default="prod")
    s.set_defaults(fn=cmd_hypotheses)

    s = sub.add_parser("source", help="source <-> runtime correlation + AST data-flow")
    s.add_argument("action", choices=["scan", "correlate", "dataflow", "show"])
    s.add_argument("path", nargs="?")
    s.add_argument("--corpus", default="prod")
    s.set_defaults(fn=cmd_source)

    s = sub.add_parser("mobile", help="APK/IPA endpoint extraction into the corpus")
    s.add_argument("action", choices=["analyse", "show"])
    s.add_argument("path", nargs="?")
    s.add_argument("--corpus", default="prod")
    s.set_defaults(fn=cmd_mobile)

    s = sub.add_parser("audit", help="structured audit log")
    s.add_argument("--tail", type=int)
    s.set_defaults(fn=cmd_audit)

    s = sub.add_parser("snapshot", help="record the current attack surface")
    s.add_argument("--label")
    s.set_defaults(fn=cmd_snapshot)

    s = sub.add_parser("diff", help="what changed since the last snapshot")
    s.add_argument("--since", default="previous")
    s.add_argument("--until", default="latest")
    s.set_defaults(fn=cmd_diff)

    s = sub.add_parser("oauth", help="OAuth/OIDC engine (RFC 9700)")
    s.add_argument("--corpus", required=True)
    s.set_defaults(fn=cmd_oauth)

    s = sub.add_parser("tenant", help="cross-tenant isolation matrix")
    s.add_argument("--corpus", required=True)
    s.set_defaults(fn=cmd_tenant)

    s = sub.add_parser("workflow", help="business-logic state machine testing")
    s.add_argument("--corpus", required=True)
    s.set_defaults(fn=cmd_workflow)

    s = sub.add_parser("probe", help="redirect, sourcemap, prototype pollution, upload")
    s.add_argument("--corpus", required=True)
    s.add_argument("--which", nargs="*",
                   choices=["redirect", "sourcemap", "protopollution",
                            "upload", "tenant"])
    s.set_defaults(fn=cmd_probe)

    s = sub.add_parser("rootcause", help="group findings by shared defect")
    s.set_defaults(fn=cmd_rootcause)

    s = sub.add_parser("learn", help="outcome priors and hypothesis ledger")
    s.add_argument("--reset", action="store_true")
    s.set_defaults(fn=cmd_learn)

    s = sub.add_parser("loop", help="autonomous research loop (deterministic)")
    s.add_argument("--corpus", required=True)
    s.add_argument("--minutes", type=int, default=120)
    s.add_argument("--rounds", type=int, default=8)
    s.add_argument("--oast", choices=["auto", "interactsh", "static", "none"],
                   default="auto")
    s.add_argument("--oast-domain")
    s.add_argument("--no-ai", action="store_true",
                   help="skip the AI checkpoint suggestions")
    s.set_defaults(fn=cmd_loop)

    s = sub.add_parser("status", help="engagement state at a glance")
    s.set_defaults(fn=cmd_status)

    s = sub.add_parser("budget", help="engagement-wide request budget")
    s.add_argument("action", nargs="?", choices=["show", "reset"],
                   default="show")
    s.add_argument("--confirm", action="store_true",
                   help="required for reset — the ceiling is contractual")
    s.set_defaults(fn=cmd_budget)

    s = sub.add_parser("risk", help="show which engines the scope permits")
    s.set_defaults(fn=cmd_risk)

    s = sub.add_parser("reproduce", help="reproduce a finding from its bundle")
    s.add_argument("id", type=int)
    s.set_defaults(fn=cmd_reproduce)

    s = sub.add_parser("promote", help="experiments -> deduplicated findings")
    s.add_argument("--min-score", type=float, default=0.55)
    s.set_defaults(fn=cmd_promote)

    s = sub.add_parser("findings", help="list findings")
    s.set_defaults(fn=cmd_findings)

    s = sub.add_parser("evidence", help="write replayable evidence bundle")
    s.add_argument("id", type=int)
    s.set_defaults(fn=cmd_evidence)

    s = sub.add_parser("report", help="render report from evidence")
    s.add_argument("--id", type=int)
    s.set_defaults(fn=cmd_report)

    s = sub.add_parser("ai", help="generate / apply AI briefs")
    s.add_argument("action", choices=["brief", "apply"])
    s.add_argument("--kind", choices=["triage", "impact", "classify", "fuzz",
                                      "chains"], required=True)
    s.add_argument("--file")
    s.add_argument("--corpus")
    s.add_argument("--id", type=int)
    s.add_argument("--top", type=int, default=15)
    s.set_defaults(fn=cmd_ai)

    s = sub.add_parser("stats", help="db summary")
    s.set_defaults(fn=cmd_stats)

    return p


def main(argv=None) -> int:
    a = build_parser().parse_args(argv)
    try:
        return a.fn(a) or 0
    except ScopeViolation as e:
        print(f"\nSCOPE REFUSED: {e}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("\ninterrupted")
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
