"""
Request corpus: import authenticated traffic and find the object references.

Input sources:
  * Burp proxy history XML export
  * Burp MCP (proxy history JSON)
  * HAR files (browser devtools)

The corpus is the raw material for every authorization test. You browse the
app normally as each identity; this turns that into a structured test plan.
"""

from __future__ import annotations

import base64
import hashlib
import json
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import parse_qsl, urlsplit

from . import vault
from .db import DB
from .scope import Scope

# Parameter names that almost always reference an object the server must
# authorise. Ordered by how reliably they indicate an ownership boundary.
_REF_NAMES = re.compile(
    r"(?i)^(id|_id|uuid|guid|ref|key|"
    r"(user|account|customer|member|profile|org|organisation|organization|team|"
    r"tenant|workspace|project|group|company|client|employee|owner|"
    r"order|invoice|payment|transaction|subscription|card|"
    r"file|document|doc|attachment|upload|report|export|"
    r"message|thread|conversation|comment|post|ticket|case|"
    r"session|token|booking|reservation|node|record|item|entity|resource)"
    r"([_\-]?(id|uuid|guid|key|ref|no|num|number|code|slug|hash))?)$"
)

_ID_VALUE = re.compile(
    r"^(?:"
    r"\d{1,19}"                                              # numeric
    r"|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"  # uuid
    r"|[0-9a-fA-F]{24}"                                      # mongo objectid
    r"|[0-9a-fA-F]{32}"                                      # md5-ish
    r"|[A-Za-z0-9_-]{16,64}"                                 # opaque token/slug
    r")$"
)

_PATH_ID = re.compile(
    r"/(?P<val>\d{1,19}"
    r"|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
    r"|[0-9a-fA-F]{24})(?=/|$|\?)"
)

_STATIC = re.compile(r"\.(png|jpe?g|gif|svg|css|js|woff2?|ttf|ico|map|mp4|webp)($|\?)", re.I)


@dataclass
class ObjectRef:
    loc: str        # path | query | body | header | cookie
    name: str       # parameter name (or path segment index)
    value: str
    kind: str       # numeric | uuid | objectid | opaque
    confidence: float


def classify_value(v: str) -> tuple[str, float] | None:
    if not v or len(v) > 128:
        return None
    if re.fullmatch(r"\d{1,19}", v):
        # tiny numbers are usually pagination/flags, not object ids
        return ("numeric", 0.9 if len(v) >= 2 else 0.3)
    if re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", v, re.I):
        return ("uuid", 1.0)
    if re.fullmatch(r"[0-9a-fA-F]{24}", v):
        return ("objectid", 0.95)
    if re.fullmatch(r"[0-9a-fA-F]{32}", v):
        return ("hash", 0.7)
    if re.fullmatch(r"[A-Za-z0-9_-]{16,64}", v):
        return ("opaque", 0.6)
    return None


def extract_refs(method: str, url: str, headers: dict, body: str | None) -> list[ObjectRef]:
    """Find every client-controlled value that could name a server-side object."""
    refs: list[ObjectRef] = []
    parts = urlsplit(url)

    # path segments that look like ids.
    # A bare "/1" in a path is an object reference even though the same value
    # in a query string would usually be pagination -- position carries the
    # meaning, so path refs get full confidence.
    for m in _PATH_ID.finditer(parts.path or ""):
        val = m.group("val")
        kind = classify_value(val)
        if kind:
            refs.append(ObjectRef("path", str(m.start()), val, kind[0],
                                  max(kind[1], 0.85)))

    # query params
    for k, v in parse_qsl(parts.query, keep_blank_values=True):
        kind = classify_value(v)
        if not kind:
            continue
        conf = kind[1] + (0.3 if _REF_NAMES.match(k) else 0.0)
        refs.append(ObjectRef("query", k, v, kind[0], min(conf, 1.0)))

    # body
    if body:
        ct = (headers.get("content-type") or headers.get("Content-Type") or "").lower()
        if "json" in ct or body.lstrip().startswith(("{", "[")):
            refs += _refs_from_json(body)
        elif "x-www-form-urlencoded" in ct or "=" in body:
            for k, v in parse_qsl(body, keep_blank_values=True):
                kind = classify_value(v)
                if kind:
                    conf = kind[1] + (0.3 if _REF_NAMES.match(k) else 0.0)
                    refs.append(ObjectRef("body", k, v, kind[0], min(conf, 1.0)))

    # headers that carry tenant/org scoping -- very high value
    for hk, hv in headers.items():
        if re.match(r"(?i)^x-(tenant|org|account|workspace|customer|company|"
                    r"impersonate|on-behalf|user)-?(id)?$", hk):
            refs.append(ObjectRef("header", hk, hv, "scoping-header", 1.0))

    # A credential is not an object reference. Dropping these does two
    # things: it keeps the secret out of `requests.object_refs` (which is
    # how a password re-entered the database after the body was
    # sanitised), and it stops the authz engine trying to prove an IDOR by
    # swapping someone's password between identities -- which is not a
    # test of anything and would be an ugly thing to find in an audit log.
    return [r for r in refs if not vault._secret_field(r.name)]


def _refs_from_json(body: str) -> list[ObjectRef]:
    out: list[ObjectRef] = []
    try:
        data = json.loads(body)
    except Exception:
        return out

    def walk(node, path=""):
        if isinstance(node, dict):
            for k, v in node.items():
                walk(v, f"{path}.{k}" if path else k)
        elif isinstance(node, list):
            for i, v in enumerate(node[:20]):
                walk(v, f"{path}[{i}]")
        else:
            if node is None or isinstance(node, bool):
                return
            s = str(node)
            kind = classify_value(s)
            if not kind:
                return
            leaf = path.split(".")[-1].split("[")[0]
            conf = kind[1] + (0.3 if _REF_NAMES.match(leaf) else 0.0)
            out.append(ObjectRef("body", path, s, kind[0], min(conf, 1.0)))

    walk(data)
    return out


# ---------------- importers ----------------

def import_burp_xml(db: DB, scope: Scope, path: str | Path,
                    corpus: str, identity: str, log=print) -> int:
    """Burp -> Proxy -> HTTP history -> select all -> Save items (XML)."""
    tree = ET.parse(str(path))
    n = 0
    for item in tree.getroot().findall("item"):
        url = (item.findtext("url") or "").strip()
        method = (item.findtext("method") or "GET").strip().upper()
        if not url or _STATIC.search(url):
            continue
        host = urlsplit(url).hostname or ""
        if not scope.host_allowed(host):
            continue
        req_b64 = item.find("request")
        resp_b64 = item.find("response")
        raw_req = _decode(req_b64)
        raw_resp = _decode(resp_b64)
        headers, body = _split_http(raw_req)
        rh, rbody = _split_http(raw_resp)
        status = int(item.findtext("status") or 0) or _status_from(raw_resp)
        _store(db, corpus, identity, method, url, headers, body,
               status, rh, rbody)
        n += 1
    log(f"[corpus] imported {n} requests as identity '{identity}'")
    return n


def import_har(db: DB, scope: Scope, path: str | Path,
               corpus: str, identity: str, log=print) -> int:
    data = json.loads(Path(path).read_text())
    n = 0
    for e in data.get("log", {}).get("entries", []):
        req = e.get("request", {})
        res = e.get("response", {})
        url = req.get("url", "")
        if not url or _STATIC.search(url):
            continue
        host = urlsplit(url).hostname or ""
        if not scope.host_allowed(host):
            continue
        headers = {h["name"]: h["value"] for h in req.get("headers", [])}
        body = (req.get("postData") or {}).get("text")
        rh = {h["name"]: h["value"] for h in res.get("headers", [])}
        rbody = (res.get("content") or {}).get("text") or ""
        _store(db, corpus, identity, req.get("method", "GET").upper(), url,
               headers, body, res.get("status", 0), rh, rbody)
        n += 1
    log(f"[corpus] imported {n} requests as identity '{identity}'")
    return n


def import_mcp_json(db: DB, scope: Scope, records: list[dict],
                    corpus: str, identity: str, log=print) -> int:
    """For Burp MCP output: list of {method,url,headers,body,status,...}."""
    n = 0
    for r in records:
        url = r.get("url", "")
        if not url or _STATIC.search(url):
            continue
        if not scope.host_allowed(urlsplit(url).hostname or ""):
            continue
        _store(db, corpus, identity, (r.get("method") or "GET").upper(), url,
               r.get("headers") or {}, r.get("body"),
               r.get("status") or 0, r.get("response_headers") or {},
               r.get("response_body") or "")
        n += 1
    log(f"[corpus] imported {n} requests as identity '{identity}'")
    return n


def _store(db, corpus, identity, method, url, headers, body,
           status, rheaders, rbody, v=None, log=print):
    """
    Store a captured request WITHOUT its credentials.

    An imported Burp or HAR export is where authentication material
    actually lives: the Authorization header, the session cookie, the
    password posted to /login, the refresh token in the response. Writing
    those into `requests` put them in a file that gets copied between
    machines, attached to reports and kept for months — and it contradicted
    the invariant this project states in its own README.

    What goes in the database: the request, with credential values replaced
    by stable fingerprints, plus hashes of the originals. Structure is
    preserved, so schema inference, object-reference extraction and
    response comparison are unaffected, and two requests carrying the same
    token still correlate.

    What goes in the vault: the originals, under an artifact reference, so
    a replay that genuinely needs them can ask.
    """
    # Object references are extracted from the ORIGINAL, because a token in
    # a header is not an object reference and sanitising first would not
    # change the outcome — but a body id must be read before redaction.
    refs = extract_refs(method, url, headers, body)

    safe_headers, secret_headers = vault.sanitise_headers(headers)
    safe_rheaders, secret_rheaders = vault.sanitise_headers(rheaders or {})
    safe_body, body_had = vault.sanitise_body(body or "")
    safe_rbody, rbody_had = vault.sanitise_body(rbody or "")

    had_secrets = bool(secret_headers or secret_rheaders
                       or body_had or rbody_had)

    artifact_ref = ""
    if had_secrets:
        try:
            artifact_ref = (v or vault.default()).store_artifact({
                "headers": headers, "body": body,
                "resp_headers": rheaders, "resp_body": (rbody or "")[:200000],
            }, label=f"capture:{corpus}:{method} {url[:120]}")
        except vault.VaultUnavailable as e:
            # Fail closed. The alternative is writing the plaintext we just
            # went to the trouble of finding.
            raise SystemExit(
                f"{e}\n\nThis capture contains credentials and THOR will "
                f"not write them to the research database in plaintext.\n"
                f"Install cryptography, or set THOR_VAULT_KEY, then import "
                f"again.")
        except Exception as e:                        # noqa: BLE001
            raise SystemExit(
                f"Could not vault the captured credentials ({e}). Refusing "
                f"to store the capture in plaintext.")

    db.ex(
        "INSERT INTO requests (corpus, identity, method, url, headers, body, "
        "status, resp_headers, resp_body, resp_len, object_refs, "
        "body_sha256, resp_sha256, artifact_ref, had_secrets) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        corpus, identity, method, url, json.dumps(safe_headers), safe_body,
        status, json.dumps(safe_rheaders), safe_rbody[:200000],
        len(rbody or ""),
        json.dumps([r.__dict__ for r in refs]),
        hashlib.sha256((body or "").encode()).hexdigest(),
        hashlib.sha256((rbody or "").encode()).hexdigest(),
        artifact_ref, 1 if had_secrets else 0,
    )


def original(db, request_id: int, v=None) -> dict | None:
    """
    The unsanitised capture, decrypted in memory.

    Deliberately explicit: nothing reaches the originals by accident. The
    engines never need them — they strip captured auth and substitute the
    identity's own headers — so this exists for the rare replay that must
    reproduce a request byte for byte.
    """
    r = db.one("SELECT artifact_ref FROM requests WHERE id=?", request_id)
    if not r:
        return None
    try:
        ref = r["artifact_ref"] or ""
    except (IndexError, KeyError):
        return None
    if not ref:
        return None
    return (v or vault.default()).fetch_artifact(ref)


def _decode(node) -> str:
    if node is None or node.text is None:
        return ""
    if node.get("base64") == "true":
        try:
            return base64.b64decode(node.text).decode("utf-8", "replace")
        except Exception:
            return ""
    return node.text


def _split_http(raw: str) -> tuple[dict, str]:
    if not raw:
        return {}, ""
    head, _, body = raw.partition("\r\n\r\n")
    if not _:
        head, _, body = raw.partition("\n\n")
    lines = head.splitlines()[1:]
    headers = {}
    for ln in lines:
        if ":" in ln:
            k, _, v = ln.partition(":")
            headers[k.strip()] = v.strip()
    return headers, body


def _status_from(raw: str) -> int:
    m = re.match(r"HTTP/[\d.]+ (\d{3})", raw or "")
    return int(m.group(1)) if m else 0


# ---------------- corpus queries ----------------

def authz_candidates(db: DB, corpus: str, min_conf: float = 0.7) -> list[dict]:
    """Requests worth replaying across identities: those carrying object refs."""
    rows = db.q("SELECT * FROM requests WHERE corpus=?", corpus)
    out = []
    for r in rows:
        refs = [x for x in json.loads(r["object_refs"] or "[]")
                if x["confidence"] >= min_conf]
        if not refs:
            continue
        out.append({
            "id": r["id"], "method": r["method"], "url": r["url"],
            "headers": json.loads(r["headers"] or "{}"),
            "body": r["body"], "status": r["status"],
            "resp_len": r["resp_len"], "resp_body": r["resp_body"],
            "identity": r["identity"], "refs": refs,
        })
    return out
