"""
AST-based data-flow analysis.

The regex source engine could see that a route existed and that a guard name
appeared near it. It could not answer the question that actually matters:

    does the client-controlled identifier reach the database lookup,
    and does the caller's tenant reach it too?

That needs a parse tree. This module uses tree-sitter (seven languages) to
build, per handler:

    sources      request.params.id, req.body.x, request.args['y'], params[:id]
        ↓        assignment tracking through local variables
    propagation  const id = req.params.id  →  id is tainted
        ↓        service.get(id)           →  the argument is tainted
    sinks        findById(...), query(...), exec(...), render(...)

and separately:

    authority    req.user.tenant, current_user.id, session.org
        ↓
    does any authority value reach the same sink?

The finding is the *asymmetry*: a tainted identifier reaches the lookup and
no authority value does. That is a far stronger claim than "this route has
no decorator near it", and it survives the cases regex cannot see — a guard
applied at the router level, a scope applied inside a helper, an ORM default.

Degrades cleanly: without tree-sitter installed, `available()` is False and
`sourceintel.py` keeps its regex behaviour.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterator

from .db import DB

try:
    from tree_sitter_language_pack import get_parser
    HAVE_TS = True
except ImportError:      # pragma: no cover
    HAVE_TS = False
    get_parser = None

LANGS = {
    ".js": "javascript", ".jsx": "javascript", ".mjs": "javascript",
    ".ts": "typescript", ".tsx": "typescript",
    ".py": "python", ".rb": "ruby", ".java": "java", ".go": "go",
    ".php": "php",
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS dataflows (
  id INTEGER PRIMARY KEY,
  file TEXT,
  line INTEGER,
  language TEXT,
  handler TEXT,
  source_expr TEXT,        -- the tainted origin, e.g. req.params.id
  sink_expr TEXT,          -- the sink call
  sink_kind TEXT,          -- db_lookup | query | exec | render | fs | http
  path TEXT,               -- json: the variable chain
  authority_reaches INTEGER,   -- did an authority value reach the same sink
  authority_expr TEXT,
  confidence REAL,
  -- present | missing | unknown. "Not seen" and "not there" are different
  -- claims and only one of them is a finding.
  authority_status TEXT DEFAULT 'unknown',
  authority_where TEXT,
  callers TEXT,
  UNIQUE(file, line, sink_expr)
);
CREATE INDEX IF NOT EXISTS idx_df_authority ON dataflows(authority_reaches);
"""


def ensure(db: DB) -> None:
    db.conn.executescript(SCHEMA)
    db.conn.commit()


def available() -> bool:
    return HAVE_TS


# --------------------------------------------------------------- patterns

# Client-controlled origins, per language family.
SOURCE_EXPR = re.compile(
    r"""(?x)
    (?:\breq(?:uest)?\s*\.\s*(?:params|query|body|args|form|json|
                              GET|POST|values|data|input|cookies|headers)
       (?:\s*(?:\.\s*\w+|\[\s*['"]?\w+['"]?\s*\]))*)
    | (?:\bparams\s*\[\s*:\w+\s*\])                      # rails
    | (?:\bparams\s*\.\s*\w+)
    | (?:\$_(?:GET|POST|REQUEST|COOKIE)\s*\[[^\]]*\])    # php
    | (?:\b@?RequestParam\b|\b@?PathVariable\b)          # java
    | (?:\bc\.(?:Param|Query|PostForm)\s*\()             # go gin
    | (?:\bmux\.Vars\s*\()                               # go mux
    | (?:\bchi\.URLParam\s*\()                           # go chi
    """)

# Values that carry the caller's authority. If one of these reaches the sink,
# the lookup is scoped.
AUTHORITY_EXPR = re.compile(
    r"""(?x)
    (?:\breq(?:uest)?\s*\.\s*(?:user|auth|session|principal|identity|ctx|
                               context|current_user)
       (?:\s*\.\s*\w+)*)
    | \bcurrent_user\b (?:\s*\.\s*\w+)*
    | \bcurrent_tenant\b
    | \bsession\s*\[\s*['"](?:user|tenant|org|account)[^\]]*\]
    | \b(?:g|flask\.g)\s*\.\s*(?:user|tenant|org)\b
    | \b@current_\w+
    | \bAuth::(?:user|id)\s*\(\)                         # laravel
    | \bSecurityContextHolder\b                          # spring
    | \bctx\.Value\s*\(                                  # go
    """)

SINKS: list[tuple[str, re.Pattern]] = [
    ("db_lookup", re.compile(
        r"""(?x)\b\w+\s*\.\s*(?:findById|findByPk|find_by_id|findOne|find_one|
            getById|get_by_id|findUnique|findFirst|first|get|fetch|load|
            retrieve)\s*\(""")),
    ("query", re.compile(
        r"""(?x)\b\w+\s*\.\s*(?:where|filter|find|objects|query|select|
            createQueryBuilder|raw|execute|exec|aggregate)\s*\(""")),
    ("exec", re.compile(
        r"""(?x)\b(?:exec|execSync|spawn|system|popen|shell_exec|passthru|
            Runtime\.getRuntime|subprocess\.(?:run|call|Popen))\s*\(""")),
    ("render", re.compile(
        r"""(?x)\b(?:render|render_template|renderString|compile|
            Template|eval)\s*\(""")),
    ("fs", re.compile(
        r"""(?x)\b(?:readFile|readFileSync|open|File\.read|file_get_contents|
            os\.path\.join|Path)\s*\(""")),
    ("http", re.compile(
        r"""(?x)\b(?:fetch|axios|requests\.(?:get|post)|urlopen|HttpClient|
            http\.Get|curl_exec)\s*\(""")),
]

# Route-registration calls look like sinks to a naive matcher --
# `router.get('/x', handler)` matches `.get(`. They are not sinks; they are
# where handlers are declared. Excluding them removes the largest source of
# noise from the analysis.
NOT_A_SINK = re.compile(
    r"""(?xi)^\s*(?:app|router|r|api|server|mux|http|routes?|blueprint|bp)
        \s*\.\s*(?:get|post|put|patch|delete|all|use|route|
                    handle|handlefunc|add_url_rule)\s*\(
        | ^\s*@\w*\.?(?:route|get|post|put|patch|delete)\s*\(
        | ^\s*(?:describe|it|test|expect)\s*\(""")

HANDLER_HINT = re.compile(
    r"""(?x)(?:app|router|r)\s*\.\s*(?:get|post|put|patch|delete|all)\s*\(
        | @\w+\.route\s*\( | @\w+\.(?:get|post|put|patch|delete)\s*\(
        | @(?:Get|Post|Put|Patch|Delete|Request)Mapping
        | \bdef\s+\w+ | \bfunc\s+\w+ | \bpublic\s+\w+\s+\w+\s*\(""")

SKIP_DIRS = {"node_modules", ".git", "dist", "build", "vendor", "__pycache__",
             ".venv", "venv", "target", "coverage", ".next", "migrations",
             "test", "tests", "spec", "__tests__"}


# ------------------------------------------------------------ the analysis

@dataclass
class Flow:
    file: str
    line: int
    language: str
    handler: str
    source_expr: str
    sink_expr: str
    sink_kind: str
    path: list[str] = field(default_factory=list)
    authority_reaches: bool = False
    authority_expr: str = ""
    confidence: float = 0.0
    # present | missing | unknown. Three values, not two, because "I did
    # not see an authority check" and "there is no authority check" are
    # different statements and only one of them is a finding. An authority
    # check applied by a caller, a decorator or a framework middleware is
    # invisible to a single-file read; calling that `missing` produces
    # confident false positives in exactly the codebases that are
    # organised well.
    authority_status: str = "unknown"
    authority_where: str = ""      # which function applied it, if any
    callers: list = field(default_factory=list)

    def describe(self) -> str:
        chain = " → ".join(self.path) if self.path else "direct"
        if self.authority_status == "present":
            where = f" in {self.authority_where}" if self.authority_where else ""
            auth = self.authority_expr or "an authority check"
            return (f"{self.source_expr} reaches {self.sink_expr} "
                    f"({chain}), and {auth} reaches it too{where} — the "
                    f"lookup appears scoped")
        if self.authority_status == "unknown":
            return (f"{self.source_expr} reaches {self.sink_expr} ({chain}); "
                    f"no authority check is visible, but no caller of this "
                    f"function could be resolved either — this is UNKNOWN, "
                    f"not a missing check")
        return (f"{self.source_expr} reaches {self.sink_expr} ({chain}) "
                f"with NO authority value on any resolved path from a route "
                f"handler — the lookup is not scoped to the caller")


def _text(node, src: bytes) -> str:
    return src[node.start_byte:node.end_byte].decode("utf-8", "replace")


def _walk(node) -> Iterator[Any]:
    yield node
    for c in node.children:
        yield from _walk(c)


def _enclosing_function(node) -> Any:
    cur = node
    while cur is not None:
        if cur.type in ("function_declaration", "function_definition",
                        "arrow_function", "function_expression", "method_definition",
                        "method_declaration", "func_literal", "function_item",
                        "method", "def"):
            return cur
        cur = cur.parent
    return None


def analyse_file(path: Path, root: Path, log=print) -> list[Flow]:
    """Per-file taint: sources → local variables → sinks, plus authority."""
    if not HAVE_TS:
        return []
    lang = LANGS.get(path.suffix.lower())
    if not lang:
        return []
    try:
        src = path.read_bytes()
    except OSError:
        return []
    if len(src) > 2_000_000:
        return []
    try:
        parser = get_parser(lang)
        tree = parser.parse(src)
    except Exception:
        return []

    flows: list[Flow] = []
    rel = str(path.relative_to(root))

    # 1. tainted variable assignments: const id = req.params.id
    tainted: dict[str, str] = {}      # variable name -> origin expression
    authority: dict[str, str] = {}
    for node in _walk(tree.root_node):
        if node.type not in ("variable_declarator", "assignment",
                             "assignment_expression", "short_var_declaration",
                             "local_variable_declaration"):
            continue
        txt = _text(node, src)
        if len(txt) > 400:
            continue
        name_node = node.child_by_field_name("name") or (
            node.children[0] if node.children else None)
        if name_node is None:
            continue
        name = _text(name_node, src).strip()
        if not re.fullmatch(r"[A-Za-z_$][\w$]*", name):
            # destructuring: const { id } = req.params
            ids = re.findall(r"[A-Za-z_$][\w$]*", name)
        else:
            ids = [name]
        m = SOURCE_EXPR.search(txt)
        if m:
            for i in ids:
                tainted[i] = m.group(0)
        a = AUTHORITY_EXPR.search(txt)
        if a:
            for i in ids:
                authority[i] = a.group(0)

    # 2. sinks, and what flows into them
    for node in _walk(tree.root_node):
        if node.type not in ("call_expression", "call", "method_invocation",
                             "function_call_expression", "method_call"):
            continue
        call = _text(node, src)
        if len(call) > 600:
            continue
        if NOT_A_SINK.search(call):
            continue                      # route registration, not a sink
        kind = None
        for k, pat in SINKS:
            if pat.search(call):
                kind = k
                break
        if not kind:
            continue

        args_node = node.child_by_field_name("arguments")
        args = _text(args_node, src) if args_node else call

        # direct source in the arguments
        origin = ""
        chain: list[str] = []
        m = SOURCE_EXPR.search(args)
        if m:
            origin = m.group(0)
            chain = ["direct argument"]
        else:
            for var, expr in tainted.items():
                if re.search(rf"\b{re.escape(var)}\b", args):
                    origin = expr
                    chain = [expr, var, "argument"]
                    break
        if not origin:
            continue

        # does any authority value reach the same call?
        auth_expr = ""
        a = AUTHORITY_EXPR.search(args)
        if a:
            auth_expr = a.group(0)
        else:
            for var, expr in authority.items():
                if re.search(rf"\b{re.escape(var)}\b", args):
                    auth_expr = expr
                    break
        # scoping can also appear as an explicit keyword argument
        if not auth_expr and re.search(
                r"(?i)\b(tenant|org(anisation|anization)?|owner|account|"
                r"workspace|company)\s*[:=]", args):
            auth_expr = re.search(
                r"(?i)\b(tenant|org\w*|owner|account|workspace|company)"
                r"\s*[:=]\s*[\w.\[\]'\"]+", args).group(0)

        fn = _enclosing_function(node)
        handler = ""
        if fn is not None:
            head = _text(fn, src).splitlines()[0][:90]
            handler = head.strip()

        line = src[:node.start_byte].count(b"\n") + 1
        conf = 0.55
        if kind in ("db_lookup", "query"):
            conf += 0.20
        if chain and chain[0] != "direct argument":
            conf += 0.05
        if not auth_expr:
            conf += 0.10

        flows.append(Flow(
            file=rel, line=line, language=lang, handler=handler,
            source_expr=origin, sink_expr=call.split("(")[0].strip()[:80],
            sink_kind=kind, path=chain,
            authority_reaches=bool(auth_expr), authority_expr=auth_expr,
            confidence=min(0.95, conf)))

    return flows


def _iter_sources(root: Path):
    for p in root.rglob("*"):
        if p.is_dir() or p.suffix.lower() not in LANGS:
            continue
        if any(part in SKIP_DIRS for part in p.parts):
            continue
        yield p, LANGS[p.suffix.lower()]


def scan(root: str | Path, log=print) -> list[Flow]:
    root = Path(root)
    if not root.exists():
        raise SystemExit(f"no such source tree: {root}")
    if not HAVE_TS:
        log("[dataflow] tree-sitter not installed — skipping AST analysis. "
            "pip install tree_sitter tree_sitter_language_pack")
        return []
    flows, files = [], 0
    for p in root.rglob("*"):
        if p.is_dir() or p.suffix.lower() not in LANGS:
            continue
        if any(part in SKIP_DIRS for part in p.parts):
            continue
        files += 1
        flows.extend(analyse_file(p, root, log=log))
    # Inter-procedural pass. Without it, a guard in a decorator, a
    # middleware or a caller reads as a missing check, and the well-organised
    # codebases are the ones that get false positives.
    funcs = build_call_graph(root, log=log)
    # Taint that crosses function boundaries. Without this, the ordinary
    # route → controller → repository shape produces no flow at all,
    # because no single file contains both the source and the sink.
    crossing = propagate_taint(root, funcs, log=log)
    seen = {(f.file, f.line, f.sink_expr) for f in flows}
    flows.extend(f for f in crossing
                 if (f.file, f.line, f.sink_expr) not in seen)
    resolve_authority(flows, funcs, log=log)

    missing = [f for f in flows if f.authority_status == "missing"]
    unknown = [f for f in flows if f.authority_status == "unknown"]
    present = [f for f in flows if f.authority_status == "present"]
    log(f"[dataflow] {files} files, {len(flows)} tainted flows: "
        f"{len(missing)} unscoped, {len(present)} scoped, "
        f"{len(unknown)} unknown")
    if unknown:
        log(f"[dataflow] {len(unknown)} flow(s) are UNKNOWN, not findings — "
            f"no caller could be resolved, so whether authority is applied "
            f"upstream cannot be seen from the source alone")
    return flows


def persist(db: DB, flows: list[Flow], log=print) -> int:
    ensure(db)
    n = 0
    for f in flows:
        try:
            db.ex("INSERT OR IGNORE INTO dataflows (file, line, language, "
                  "handler, source_expr, sink_expr, sink_kind, path, "
                  "authority_reaches, authority_expr, confidence, "
                  "authority_status, authority_where, callers) "
                  "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  f.file, f.line, f.language, f.handler, f.source_expr,
                  f.sink_expr, f.sink_kind, json.dumps(f.path),
                  1 if f.authority_status == "present" else 0,
                  f.authority_expr, f.confidence,
                  f.authority_status, f.authority_where,
                  json.dumps(f.callers))
            n += 1
        except Exception:
            pass
    log(f"[dataflow] {n} flows stored")
    return n


def unscoped_lookups(db: DB) -> list[dict]:
    """
    The payload: a client-controlled identifier reaching a data lookup with
    no authority value in the call. This is the source-side signature of an
    IDOR, and it names a file and line.
    """
    ensure(db)
    return [dict(r) for r in db.q(
        # 'missing' only. An 'unknown' flow means no caller could be
        # resolved, so whether authority is applied upstream is not
        # visible -- turning that into a hypothesis would spend real
        # requests on the tool's own blind spot.
        "SELECT * FROM dataflows WHERE authority_status='missing' "
        "AND sink_kind IN ('db_lookup','query') "
        "ORDER BY confidence DESC")]


def correlate(db: DB, corpus: str, log=print) -> dict:
    """
    Tie unscoped lookups to routes that are actually reachable, and raise the
    matching hypothesis with a strong prior.
    """
    from . import learn
    ensure(db)
    out = {"unscoped": 0, "correlated": 0, "hypotheses": 0}
    flows = unscoped_lookups(db)
    out["unscoped"] = len(flows)
    if not flows:
        return out

    routes = {}
    for r in db.q("SELECT id, method, path, file, line FROM source_routes"):
        routes.setdefault(r["file"], []).append(dict(r))

    # Which functions call this sink, and in which files? An
    # inter-procedural flow has its sink in the repository layer and its
    # route two files away, so a same-file line-proximity match would miss
    # exactly the flows the call graph exists to find.
    caller_files: dict = {}
    for r in db.q("SELECT file, callers FROM dataflows"):
        for c in json.loads(_get(r, "callers") or "[]"):
            caller_files.setdefault(c, set()).add(r["file"])

    for f in flows:
        near = [r for r in routes.get(f["file"], [])
                if abs((r["line"] or 0) - f["line"]) <= 60]
        if not near:
            # follow the call chain out to the files its callers live in
            for c in json.loads(_get(f, "callers") or "[]"):
                for rf, rs in routes.items():
                    if any(c in (r.get("handler") or "") for r in rs):
                        near = rs
                        break
                if near:
                    break
        if not near:
            # last resort: a handler named in the flow's own chain
            for rs in routes.values():
                for r in rs:
                    if f["handler"] and r.get("handler") and \
                            f["handler"].split("(")[0] in r["handler"]:
                        near = [r]
                        break
                if near:
                    break
        if not near:
            continue
        route = (min(near, key=lambda r: abs((r["line"] or 0) - f["line"]))
                 if len(near) > 1 else near[0])
        out["correlated"] += 1

        detail = {
            "reason": (
                f"AST data-flow: {f['source_expr']} reaches "
                f"{f['sink_expr']} at {f['file']}:{f['line']} and no "
                f"authority value (tenant, owner, current_user) is present in "
                f"the call. The identifier is client-controlled and the "
                f"lookup is unscoped."),
            "source": f"{f['file']}:{f['line']}",
            "flow": json.loads(f["path"] or "[]"),
            "sink_kind": f["sink_kind"],
            "confidence": f["confidence"],
        }
        db.conn.execute(
            "INSERT OR IGNORE INTO correlations (route_id, endpoint, kind, "
            "severity, detail) VALUES (?,?,?,?,?)",
            (route["id"], f"{route['method']} {route['path']}",
             "unscoped_dataflow", "high", json.dumps(detail)))

        learn.ensure(db)
        stmt = (f"{route['method']} {route['path']} resolves an object by "
                f"client-controlled id with no tenant/owner constraint "
                f"(AST: {f['file']}:{f['line']})")
        if not db.one("SELECT 1 FROM hypotheses WHERE statement=?", stmt):
            learn.open_hypothesis(db, learn.Hypothesis(
                engine="authz", target=route["path"], statement=stmt,
                predicted="a second identity receives the owner's object",
                falsifier=("an anonymous request also returns it, or the "
                           "scoping happens in a layer the AST cannot see "
                           "(router middleware, ORM default scope)"),
                arm=learn.arm_key("authz", "-", "dataflow")))
            out["hypotheses"] += 1

    db.conn.commit()
    log(f"[dataflow] {json.dumps(out)}")
    return out


def report(db: DB) -> str:
    ensure(db)
    rows = db.q("SELECT * FROM dataflows ORDER BY "
                "CASE authority_status WHEN 'missing' THEN 0 "
                "WHEN 'unknown' THEN 1 ELSE 2 END, confidence DESC LIMIT 60")
    if not rows:
        return ("No data-flow results. Run `thor source dataflow <path>`.\n"
                + ("" if HAVE_TS else
                   "tree-sitter is not installed: "
                   "pip install tree_sitter tree_sitter_language_pack"))

    groups = {
        "missing": ("UNSCOPED — a route reaches this lookup and nothing on "
                    "the way applies authority", "✗"),
        "unknown": ("UNKNOWN — no authority seen, but no caller could be "
                    "resolved either", "?"),
        "present": ("SCOPED — an authority check reaches this call", "✓"),
    }
    out, shown = [], None
    for r in rows:
        st = (_get(r, "authority_status") or "unknown")
        if st != shown:
            if shown is not None:
                out.append("")
            head, _ = groups.get(st, (st.upper(), "·"))
            out.append(head)
            out.append("─" * 70)
            shown = st
        mark = groups.get(st, ("", "·"))[1]
        out.append(f"  {mark} [{r['confidence']:.2f}] {r['file']}:{r['line']} "
                   f"({r['language']})")
        out.append(f"      {r['source_expr']} → {r['sink_expr']} "
                   f"[{r['sink_kind']}]")
        where = _get(r, "authority_where")
        if st == "present":
            out.append(f"      scoped by: {r['authority_expr'] or 'a guard'}"
                       + (f" ({where})" if where else ""))
        callers = json.loads(_get(r, "callers") or "[]")
        if callers:
            out.append(f"      callers: {' ← '.join(callers[:5])}")
        path = json.loads(r["path"] or "[]")
        if path and path != ["direct argument"]:
            out.append(f"      via: {' → '.join(path)}")

    out += ["",
            "An UNSCOPED flow is a hypothesis with a strong prior, not a "
            "finding. The runtime",
            "authz engine still has to prove it.",
            "",
            "An UNKNOWN flow is not a weaker finding — it is the analysis "
            "saying it cannot see",
            "the entry point. It is never turned into a hypothesis, because "
            "spending requests on",
            "the tool's own blind spot is worse than saying nothing."]
    return "\n".join(out)


def _get(row, name):
    try:
        return row[name]
    except (IndexError, KeyError):
        return None


# ══════════════════════════════════════════════════════════════════════
# Inter-procedural pass: route → controller → service → repository
# ══════════════════════════════════════════════════════════════════════
#
# A single-file read can only say "no authority appears in this call".
# Real codebases put the check somewhere else on purpose -- a route
# decorator, an Express middleware, a base controller, a repository that
# always scopes by tenant. Reporting those as missing checks produces
# confident false positives in precisely the well-organised codebases
# whose authors will notice.
#
# So: build a call graph, then ask whether authority is applied anywhere
# on a resolved path from a route handler down to the sink. Three answers,
# not two. `unknown` never becomes a finding.

# Names that mean "an authorisation check happens here".
#
# Deliberately specific. An earlier version accepted bare `require`, which
# matched `const router = require('express')` — a module import read as an
# authorisation check, marking every route in the file as guarded and
# silencing the real findings underneath it. A guard pattern that is too
# generous does not produce noise; it produces silence, which is worse.
GUARD_DECORATOR = re.compile(
    r"(?i)\b("
    r"require[_-]?(auth|authz|authorisation|authorization|login|user|tenant|"
    r"org|owner|admin|role|permission|scope|session|member)\w*"
    r"|ensure[_-]?(auth|authz|login|user|tenant|org|owner|admin|role|"
    r"permission|scope|session|member)\w*"
    r"|authori[sz]e\w*|authenticated?|is_authenticated|login_required"
    r"|permission_required|has_permission|can_access|check_access"
    r"|check_permission|verify_(auth|token|session|user|tenant|permission)\w*"
    r"|guard\w*|with_auth|auth_required|admin_required"
    r"|before_action|use_guards?|roles?_required|authorize_resource"
    r")\b")

# Never treat these as guards, whatever else matches.
_NOT_A_GUARD = re.compile(r"(?i)\brequire\s*\(\s*['\"]")

_DEF_NODES = ("function_declaration", "function_definition", "arrow_function",
              "function_expression", "method_definition", "method_declaration",
              "func_literal", "function_item", "method")

_MAX_DEPTH = 4


@dataclass
class FuncInfo:
    name: str
    file: str
    line: int
    applies_authority: bool = False
    authority_expr: str = ""
    is_route_handler: bool = False
    calls: set = field(default_factory=set)
    # For inter-procedural taint: the parameter names, the call sites with
    # their argument expressions, and the byte range so the body can be
    # re-read once a parameter turns out to be tainted.
    params: list = field(default_factory=list)
    lang: str = ""
    span: tuple = (0, 0)
    callsites: list = field(default_factory=list)   # (callee, [args], line)
    tainted_params: dict = field(default_factory=dict)  # param -> origin


def _func_name(node, src: bytes) -> str:
    for c in node.children:
        if c.type in ("identifier", "property_identifier", "field_identifier"):
            return _text(c, src)
    # assigned arrow function: const getInvoice = (req,res) => {...}
    parent = node.parent
    while parent is not None and parent.type in ("variable_declarator",
                                                 "assignment", "pair",
                                                 "assignment_expression"):
        for c in parent.children:
            if c.type in ("identifier", "property_identifier"):
                return _text(c, src)
        parent = parent.parent
    return ""


def _callee_name(call_text: str) -> str:
    head = call_text.split("(")[0].strip()
    return head.split(".")[-1].split("::")[-1].strip()


def build_call_graph(root: str | Path, log=print) -> dict:
    """Map every function we can see to what it calls and what guards it."""
    root = Path(root)
    funcs: dict[str, FuncInfo] = {}
    if not HAVE_TS:
        return funcs

    for path, lang in _iter_sources(root):
        try:
            src = path.read_bytes()
            tree = get_parser(lang).parse(src)
        except Exception:
            continue
        rel = str(path.relative_to(root))
        for node in _walk(tree.root_node):
            if node.type not in _DEF_NODES:
                continue
            line_no = src[:node.start_byte].count(b"\n") + 1
            name = _func_name(node, src)
            if not name:
                # Route handlers are very often anonymous:
                #   router.get('/x/:id', (req, res) => ctl(req, res))
                # Skipping them breaks the caller chain of everything they
                # call, and the genuinely unscoped lookup two files down
                # then reads as UNKNOWN because no route could be found.
                name = f"<anon@{rel}:{line_no}>"
            body = _text(node, src)
            head = body.splitlines()[0][:200] if body else ""
            info = funcs.setdefault(
                name, FuncInfo(name=name, file=rel, line=line_no))
            # Guards attached at the definition: decorators above it, or
            # middleware named in the route registration line.
            before = src[max(0, node.start_byte - 400):node.start_byte]
            context = before.decode("utf-8", "replace") + head
            ctx = _NOT_A_GUARD.sub(" ", context)
            m = GUARD_DECORATOR.search(ctx)
            if m:
                info.applies_authority = True
                info.authority_expr = m.group(0)
            # An authority VALUE used in the body (req.user.tenant, ...)
            a = AUTHORITY_EXPR.search(body)
            if a:
                info.applies_authority = True
                info.authority_expr = info.authority_expr or a.group(0)
            # ...or a guard CALL in the body: `requireTenant(req)` is an
            # authorisation check even though it names no value.
            g = GUARD_DECORATOR.search(_NOT_A_GUARD.sub(" ", body))
            if g:
                info.applies_authority = True
                info.authority_expr = info.authority_expr or g.group(0)
            if re.search(r"(?i)\b(router|app|@(get|post|put|patch|delete)"
                         r"|route|blueprint)\b", context):
                info.is_route_handler = True
            info.params = info.params or _param_names(node, src)
            info.lang = info.lang or lang
            if info.span == (0, 0):
                info.span = (node.start_byte, node.end_byte)
            for c in _walk(node):
                if c.type in ("call_expression", "call", "method_invocation"):
                    txt = _text(c, src)
                    callee = _callee_name(txt)
                    if callee and callee != name:
                        info.calls.add(callee)
                        info.callsites.append(
                            (callee, _arg_exprs(txt),
                             src[:c.start_byte].count(b"\n") + 1))
    log(f"[dataflow] call graph: {len(funcs)} function(s)")
    return funcs


def _param_names(node, src: bytes) -> list:
    """Positional parameter names, in order."""
    for c in node.children:
        if c.type in ("formal_parameters", "parameters", "parameter_list",
                      "argument_list"):
            out = []
            for pc in c.children:
                if pc.type in ("identifier", "required_parameter",
                               "simple_parameter", "parameter",
                               "typed_parameter", "shorthand_property_identifier"):
                    t = _text(pc, src).strip()
                    t = t.split(":")[0].split("=")[0].strip()
                    if t and t not in ("(", ")", ","):
                        out.append(t)
            return out
    return []


def _arg_exprs(call_text: str) -> list:
    """Split a call's argument list at top level. Good enough for names."""
    i = call_text.find("(")
    if i < 0:
        return []
    depth, cur, out = 0, "", []
    for ch in call_text[i:]:
        if ch in "([{":
            depth += 1
            if depth == 1:
                continue
        elif ch in ")]}":
            depth -= 1
            if depth == 0:
                break
        if depth == 1 and ch == ",":
            out.append(cur.strip())
            cur = ""
            continue
        cur += ch
    if cur.strip():
        out.append(cur.strip())
    return out


def propagate_taint(root: Path, funcs: dict, log=print) -> list:
    """
    Carry taint across function boundaries.

    Intra-procedural analysis sees nothing at all in this shape, which is
    the shape most real code takes:

        routes.js     router.get('/x/:id', (req,res) => ctl(req,res))
        controller.js function ctl(req,res){ return repo(req.params.id) }
        repo.js       function repo(id){ return db.findById(id) }

    The source is in one file, the sink in another, and neither file on its
    own contains a flow. Reporting nothing here is not caution, it is
    blindness: this is precisely where unscoped lookups hide.

    So: when a call passes a request-derived expression as argument i, the
    callee's parameter i becomes tainted, carrying the origin with it.
    Repeat to a fixed point, bounded, then look for sinks that use those
    parameters.
    """
    if not HAVE_TS:
        return []

    # 1. seed and propagate parameter taint
    for _round in range(_MAX_DEPTH):
        changed = False
        for caller in list(funcs.values()):
            for callee_name, args, _line in caller.callsites:
                callee = funcs.get(callee_name)
                if callee is None or not callee.params:
                    continue
                for idx, arg in enumerate(args):
                    if idx >= len(callee.params):
                        break
                    origin = ""
                    m = SOURCE_EXPR.search(arg)
                    if m:
                        origin = m.group(0)
                    else:
                        for pname, porigin in caller.tainted_params.items():
                            if re.search(rf"\b{re.escape(pname)}\b", arg):
                                origin = porigin
                                break
                    if not origin:
                        continue
                    pname = callee.params[idx]
                    if callee.tainted_params.get(pname) != origin:
                        callee.tainted_params[pname] = origin
                        changed = True
        if not changed:
            break

    # 2. find sinks that consume a tainted parameter
    flows: list = []
    cache: dict = {}
    for info in funcs.values():
        if not info.tainted_params:
            continue
        key = info.file
        if key not in cache:
            try:
                cache[key] = (root / info.file).read_bytes()
            except Exception:
                cache[key] = b""
        src = cache[key]
        if not src:
            continue
        body = src[info.span[0]:info.span[1]].decode("utf-8", "replace")
        for kind, pat in SINKS:
            for m in pat.finditer(body):
                call = body[m.start():m.start() + 400]
                args = "(".join(call.split("(")[1:])
                hit = None
                for pname, porigin in info.tainted_params.items():
                    if re.search(rf"\b{re.escape(pname)}\b",
                                 args.split(")")[0]):
                        hit = (pname, porigin)
                        break
                if not hit:
                    continue
                if NOT_A_SINK.search(call):
                    continue
                pname, porigin = hit
                line = (info.line
                        + body[:m.start()].count("\n"))
                flows.append(Flow(
                    file=info.file, line=line, language=info.lang,
                    handler=f"{info.name}()",
                    source_expr=porigin,
                    sink_expr=call.split("(")[0].strip()[:80],
                    sink_kind=kind,
                    path=[porigin, f"parameter {pname} of {info.name}()",
                          "sink"],
                    authority_reaches=False,
                    confidence=0.6))
    if flows:
        log(f"[dataflow] {len(flows)} flow(s) found only by following taint "
            f"across function boundaries")
    return flows


def _callers_of(funcs: dict, name: str) -> list[str]:
    return [n for n, f in funcs.items() if name in f.calls]


def resolve_authority(flows: list, funcs: dict, log=print) -> list:
    """
    Decide present / missing / unknown for each flow, using the call graph.

    present  authority is applied in the sink's own function, or by any
             function on a resolved path that reaches it
    missing  a route handler reaches this sink and nothing on the way
             applies authority
    unknown  the enclosing function has no resolvable callers and is not
             itself a route handler -- we cannot see the entry point, so
             we do not get to call it a bug
    """
    for fl in flows:
        if fl.authority_reaches:
            fl.authority_status = "present"
            fl.authority_where = "the sink call itself"
            continue

        fname = _handler_name(fl.handler)
        info = funcs.get(fname) if fname else None
        if info is None:
            fl.authority_status = "unknown"
            fl.authority_where = ""
            continue
        if info.applies_authority:
            fl.authority_status = "present"
            fl.authority_expr = fl.authority_expr or info.authority_expr
            fl.authority_where = f"{info.name}() in {info.file}"
            continue

        # walk upwards through callers, bounded
        seen, frontier, guarded_by = {fname}, [fname], ""
        reached_route = info.is_route_handler
        chain: list[str] = []
        for _depth in range(_MAX_DEPTH):
            nxt = []
            for n in frontier:
                for caller in _callers_of(funcs, n):
                    if caller in seen:
                        continue
                    seen.add(caller)
                    c = funcs[caller]
                    chain.append(caller)
                    if c.applies_authority:
                        guarded_by = f"{c.name}() in {c.file}"
                    if c.is_route_handler:
                        reached_route = True
                    nxt.append(caller)
            frontier = nxt
            if not frontier:
                break

        fl.callers = chain[:8]
        if guarded_by:
            fl.authority_status = "present"
            fl.authority_where = guarded_by
        elif reached_route:
            fl.authority_status = "missing"
        else:
            # no route handler reaches this and nothing guards it: we
            # cannot see how it is entered, so we cannot say it is
            # unreachable-without-authority
            fl.authority_status = "unknown"
    return flows


def _handler_name(handler: str) -> str:
    """Recover a function name from the stored handler signature line."""
    if not handler:
        return ""
    m = re.search(r"(?:function|def|fn|func)\s+([A-Za-z_]\w*)", handler)
    if m:
        return m.group(1)
    m = re.search(r"(?:const|let|var)\s+([A-Za-z_]\w*)\s*=", handler)
    if m:
        return m.group(1)
    m = re.search(r"^\s*(?:async\s+)?([A-Za-z_]\w*)\s*\(", handler)
    return m.group(1) if m else ""
