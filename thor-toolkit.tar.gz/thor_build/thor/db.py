"""
SQLite store. One file per engagement, no server, no ORM.

Tables map to the hunt lifecycle:
  assets      -> hosts found in recon
  endpoints   -> URL + method + params
  identities  -> the auth contexts you captured
  requests    -> the request corpus (from Burp / capture)
  experiments -> every replay we ran (novelty dedup lives here)
  findings    -> confirmed, evidence-backed
  notes       -> free-form per-asset intel (AI output lands here, tagged)
"""

from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS assets (
  id INTEGER PRIMARY KEY,
  host TEXT UNIQUE NOT NULL,
  ip TEXT,
  port INTEGER DEFAULT 443,
  scheme TEXT DEFAULT 'https',
  status INTEGER,
  title TEXT,
  server TEXT,
  tech TEXT,              -- json list
  cname TEXT,
  content_length INTEGER,
  first_seen TEXT DEFAULT CURRENT_TIMESTAMP,
  last_seen TEXT DEFAULT CURRENT_TIMESTAMP,
  source TEXT,            -- which recon module found it
  anomaly_score REAL DEFAULT 0,
  anomaly_reasons TEXT,   -- json list
  triaged INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS endpoints (
  id INTEGER PRIMARY KEY,
  asset_id INTEGER REFERENCES assets(id),
  url TEXT NOT NULL,
  method TEXT DEFAULT 'GET',
  params TEXT,            -- json list of param names
  content_type TEXT,
  source TEXT,            -- katana | gau | js | burp | arjun
  is_api INTEGER DEFAULT 0,
  UNIQUE(url, method)
);

CREATE TABLE IF NOT EXISTS secrets (
  id INTEGER PRIMARY KEY,
  asset_id INTEGER REFERENCES assets(id),
  kind TEXT,              -- aws_key | jwt | google_api | ...
  value_masked TEXT,
  value_sha256 TEXT UNIQUE,
  source_url TEXT,
  context TEXT
);

CREATE TABLE IF NOT EXISTS identities (
  id INTEGER PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,   -- userA, userB, admin, anon
  role TEXT,
  tenant TEXT,
  headers TEXT,                -- json: NON-SECRET headers only
  credential_ref TEXT,         -- opaque vault reference; secrets live there
  notes TEXT
);

CREATE TABLE IF NOT EXISTS requests (
  id INTEGER PRIMARY KEY,
  corpus TEXT NOT NULL,        -- capture session name
  identity TEXT,
  method TEXT,
  url TEXT,
  headers TEXT,                -- json
  body TEXT,
  status INTEGER,
  resp_headers TEXT,
  resp_body TEXT,
  resp_len INTEGER,
  object_refs TEXT,            -- json: [{loc,name,value,kind}]
  -- Captured traffic is stored sanitised: credential values are replaced
  -- with stable fingerprints. The hashes are of the ORIGINAL bytes, so a
  -- replay can still prove it reproduced the same request, and
  -- artifact_ref points at the encrypted original in the vault.
  body_sha256 TEXT,
  resp_sha256 TEXT,
  artifact_ref TEXT,
  had_secrets INTEGER DEFAULT 0,
  imported_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS experiments (
  id INTEGER PRIMARY KEY,
  signature TEXT UNIQUE,       -- novelty guard
  kind TEXT,                   -- authz | bfla | massassign | race | probe
  base_request_id INTEGER REFERENCES requests(id),
  as_identity TEXT,
  method TEXT,
  url TEXT,
  body TEXT,
  status INTEGER,
  resp_sha256 TEXT,
  resp_len INTEGER,
  elapsed_ms REAL,
  verdict TEXT,                -- leak | denied | inconclusive | public
  score REAL,
  detail TEXT,                 -- json
  -- The contemporaneous owner control this experiment was judged against.
  -- Not the captured response: the capture may be hours stale, and the
  -- evidence bundle has to show what was actually compared, or a triager
  -- replaying it sees the baseline step DIFFER and stops reading.
  control_status INTEGER,
  control_sha256 TEXT,
  control_len INTEGER,
  -- The address the scope gate validated and pinned for this request.
  -- An experiment row can only exist after Client.send() passed
  -- Scope.check(), so a non-empty value here IS the proof that the gate
  -- ran -- a recorded fact, not a substring match on the URL later.
  dest_address TEXT,
  ran_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS findings (
  id INTEGER PRIMARY KEY,
  fingerprint TEXT UNIQUE,     -- for dedup: class+host+route-shape
  vuln_class TEXT,
  severity TEXT,
  title TEXT,
  asset TEXT,
  route TEXT,
  summary TEXT,
  impact TEXT,
  evidence_ids TEXT,           -- json list of experiment ids
  disproof_done INTEGER DEFAULT 0,
  disproof_result TEXT,
  status TEXT DEFAULT 'candidate',  -- see thor/states.py for the lifecycle
  remediation TEXT,                 -- narrative, AI-writable
  attack_narrative TEXT,            -- narrative, AI-writable
  cvss_vector TEXT,                 -- narrative, AI-writable
  triager_notes TEXT,               -- narrative, AI-writable
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS notes (
  id INTEGER PRIMARY KEY,
  subject TEXT,                -- host or route
  tag TEXT,                    -- ai:triage | ai:impact | manual
  body TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_assets_score ON assets(anomaly_score DESC);
CREATE INDEX IF NOT EXISTS idx_req_corpus ON requests(corpus);
CREATE INDEX IF NOT EXISTS idx_exp_verdict ON experiments(verdict);
"""


class DB:
    """
    One SQLite connection, shared, with writes serialised.

    `check_same_thread=False` lets the race and fuzz workers use this
    connection from several threads at once. That is only safe if writes
    are serialised: two threads interleaving on one connection corrupt each
    other's transactions, and the symptom is an intermittent
    'cannot start a transaction within a transaction' or a lost row —
    exactly the kind of failure that is invisible until it matters.

    WAL is enabled so a reader never blocks a writer, and a busy timeout
    covers the case where a second process (an operator running a second
    command) holds the file.
    """

    def __init__(self, path: str | Path = "hunt.db"):
        self.path = str(path)
        self.conn = sqlite3.connect(self.path, check_same_thread=False,
                                    timeout=30.0)
        self.conn.row_factory = sqlite3.Row
        self._wlock = threading.RLock()
        try:
            self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.execute("PRAGMA busy_timeout=30000")
            self.conn.execute("PRAGMA synchronous=NORMAL")
            self.conn.execute("PRAGMA foreign_keys=ON")
        except Exception:
            pass
        with self._wlock:
            self.conn.executescript(SCHEMA)
            self._migrate()
            self.conn.commit()

    def _migrate(self) -> None:
        """Additive column migrations for databases created by older versions."""
        wanted = {
            "findings": [("remediation", "TEXT"), ("attack_narrative", "TEXT"),
                         ("cvss_vector", "TEXT"), ("triager_notes", "TEXT")],
            "identities": [("credential_ref", "TEXT")],
            "requests": [("body_sha256", "TEXT"), ("resp_sha256", "TEXT"),
                         ("artifact_ref", "TEXT"),
                         ("had_secrets", "INTEGER DEFAULT 0")],
            "experiments": [("control_status", "INTEGER"),
                            ("control_sha256", "TEXT"),
                            ("control_len", "INTEGER"),
                            ("dest_address", "TEXT")],
            "dataflows": [("authority_status", "TEXT DEFAULT 'unknown'"),
                          ("authority_where", "TEXT"), ("callers", "TEXT")],
        }
        for table, cols in wanted.items():
            try:
                have = {r[1] for r in
                        self.conn.execute(f"PRAGMA table_info({table})")}
            except Exception:
                continue
            for name, typ in cols:
                if name not in have:
                    try:
                        self.conn.execute(
                            f"ALTER TABLE {table} ADD COLUMN {name} {typ}")
                    except Exception:
                        pass

    @contextmanager
    def tx(self) -> Iterator[sqlite3.Connection]:
        with self._wlock:
            try:
                yield self.conn
                self.conn.commit()
            except Exception:
                self.conn.rollback()
                raise

    def q(self, sql: str, *args) -> list[sqlite3.Row]:
        return self.conn.execute(sql, args).fetchall()

    def one(self, sql: str, *args) -> sqlite3.Row | None:
        return self.conn.execute(sql, args).fetchone()

    def ex(self, sql: str, *args) -> int:
        # Serialised: the race and fuzz engines write from several threads
        # through this one connection, and interleaved writes on a shared
        # sqlite3 connection corrupt each other's transactions.
        with self._wlock:
            cur = self.conn.execute(sql, args)
            self.conn.commit()
            return cur.lastrowid

    def exscript(self, sql: str) -> None:
        with self._wlock:
            self.conn.executescript(sql)
            self.conn.commit()

    # ---- convenience upserts ----

    def upsert_asset(self, host: str, **kw) -> int:
        if "tech" in kw and isinstance(kw["tech"], (list, dict)):
            kw["tech"] = json.dumps(kw["tech"])
        row = self.one("SELECT id FROM assets WHERE host=?", host)
        if row:
            if kw:
                sets = ", ".join(f"{k}=?" for k in kw)
                self.ex(f"UPDATE assets SET {sets}, last_seen=CURRENT_TIMESTAMP WHERE id=?",
                        *kw.values(), row["id"])
            return row["id"]
        cols = ["host"] + list(kw)
        vals = [host] + list(kw.values())
        ph = ",".join("?" * len(cols))
        return self.ex(f"INSERT INTO assets ({','.join(cols)}) VALUES ({ph})", *vals)

    def add_endpoint(self, url: str, method: str = "GET", **kw) -> None:
        if "params" in kw and isinstance(kw["params"], (list, dict)):
            kw["params"] = json.dumps(kw["params"])
        cols = ["url", "method"] + list(kw)
        vals = [url, method] + list(kw.values())
        ph = ",".join("?" * len(cols))
        self.conn.execute(
            f"INSERT OR IGNORE INTO endpoints ({','.join(cols)}) VALUES ({ph})", vals
        )
        self.conn.commit()

    def note(self, subject: str, tag: str, body: str) -> None:
        self.ex("INSERT INTO notes (subject, tag, body) VALUES (?,?,?)", subject, tag, body)

    def seen_signature(self, sig: str) -> bool:
        return self.one("SELECT 1 FROM experiments WHERE signature=?", sig) is not None

    def stats(self) -> dict[str, Any]:
        g = lambda s: (self.one(s) or [0])[0]
        return {
            "assets": g("SELECT COUNT(*) FROM assets"),
            "live": g("SELECT COUNT(*) FROM assets WHERE status IS NOT NULL"),
            "endpoints": g("SELECT COUNT(*) FROM endpoints"),
            "secrets": g("SELECT COUNT(*) FROM secrets"),
            "requests": g("SELECT COUNT(*) FROM requests"),
            "experiments": g("SELECT COUNT(*) FROM experiments"),
            "leaks": g("SELECT COUNT(*) FROM experiments WHERE verdict='leak'"),
            "findings": g("SELECT COUNT(*) FROM findings"),
        }
