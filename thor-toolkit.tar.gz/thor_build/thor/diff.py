"""
Response normalisation + structural diff.

The core question: did identity B receive substantially the same resource
that identity A received? Answering it by byte comparison produces garbage
(CSRF tokens, timestamps, nonces all differ). Answering it semantically is
what makes the verdict trustworthy.

This module is deterministic and contains no model calls. A verdict here is
a fact about observed bytes, not an opinion.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field

# Values that legitimately differ between two identical requests.
_VOLATILE_PATTERNS = [
    (re.compile(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b", re.I), "<UUID>"),
    (re.compile(r"\b\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?Z?\b"), "<TS>"),
    (re.compile(r"\b1[6-9]\d{8,11}\b"), "<EPOCH>"),
    (re.compile(r"(?i)(csrf|xsrf|nonce|_token|authenticity_token)[\"']?\s*[:=]\s*[\"']?[A-Za-z0-9+/=_\-]{8,}"), "<CSRF>"),
    (re.compile(r"\beyJ[A-Za-z0-9_\-]{6,}\.[A-Za-z0-9_\-]{6,}\.[A-Za-z0-9_\-]{6,}\b"), "<JWT>"),
    (re.compile(r"(?i)\b(session|sid|phpsessid|jsessionid)=[^;\s\"']+"), "<SESSION>"),
    (re.compile(r"\bsha256-[A-Za-z0-9+/=]{20,}\b"), "<SRI>"),
    (re.compile(r"\b[0-9a-f]{32,64}\b"), "<HASH>"),
]

_VOLATILE_KEYS = re.compile(
    r"(?i)^(csrf|xsrf|_token|authenticity_token|nonce|timestamp|ts|created_?at|"
    r"updated_?at|last_?seen|expires?_?(at|in)|iat|exp|request_?id|trace_?id|"
    r"correlation_?id|etag|session|jti)$"
)

_DENY_MARKERS = re.compile(
    r"(?i)(access[ _-]?denied|not[ _-]?authoriz|unauthoriz|forbidden|permission"
    r"[ _-]?denied|you[ _-]?do[ _-]?not[ _-]?have|insufficient[ _-]?(privileg|permission)|"
    r"must[ _-]?be[ _-]?logged[ _-]?in|please[ _-]?log[ _-]?in|sign[ _-]?in[ _-]?to[ _-]?continue|"
    r"invalid[ _-]?(token|session|credentials)|session[ _-]?expired|"
    r"not[ _-]?found|does[ _-]?not[ _-]?exist|no[ _-]?such)"
)

# Fields whose presence in a cross-identity response is strong leak evidence.
_PII_KEYS = re.compile(
    r"(?i)^(email|e_?mail|phone|mobile|ssn|tax_?id|address|street|postcode|zip|"
    r"first_?name|last_?name|full_?name|dob|date_?of_?birth|salary|balance|"
    r"card_?(number|last4)|iban|account_?number|api_?key|secret|password_?hash|"
    r"token|national_?id|passport)$"
)


@dataclass
class Normalised:
    status: int
    shape: str            # structural fingerprint of the body
    keys: set[str] = field(default_factory=set)
    values: set[str] = field(default_factory=set)
    text: str = ""
    length: int = 0
    is_json: bool = False
    pii_keys: set[str] = field(default_factory=set)
    denied: bool = False
    content_type: str = ""
    # sha256 of the *raw* body as received, before scrubbing. The evidence
    # bundle replays raw bytes, so a hash of the normalised text would never
    # match and every baseline step would read DIFFERS.
    sha256: str = ""

    @property
    def shape_hash(self) -> str:
        return hashlib.sha256(self.shape.encode()).hexdigest()[:16]


def scrub(text: str) -> str:
    for pat, repl in _VOLATILE_PATTERNS:
        text = pat.sub(repl, text)
    return text


def normalise(status: int, body: str, content_type: str = "") -> Normalised:
    body = body or ""
    is_json = "json" in (content_type or "").lower() or body.lstrip()[:1] in "{["
    n = Normalised(status=status, shape="", length=len(body), is_json=is_json,
                   content_type=content_type or "",
                   sha256=hashlib.sha256(body.encode()).hexdigest())

    if is_json:
        try:
            data = json.loads(body)
            n.shape = _json_shape(data)
            _collect(data, n)
            n.text = scrub(json.dumps(data, sort_keys=True)[:20000])
            n.denied = bool(_DENY_MARKERS.search(n.text)) or status in (401, 403, 404)
            return n
        except Exception:
            pass

    txt = scrub(body)
    n.text = txt[:20000]
    n.shape = _html_shape(txt)
    n.denied = bool(_DENY_MARKERS.search(txt[:4000])) or status in (401, 403, 404)
    return n


def _json_shape(node, depth: int = 0) -> str:
    """Type-and-key skeleton, ignoring values. Same shape == same resource kind."""
    if depth > 8:
        return "…"
    if isinstance(node, dict):
        inner = ",".join(f"{k}:{_json_shape(v, depth+1)}"
                         for k, v in sorted(node.items())
                         if not _VOLATILE_KEYS.match(k))
        return "{" + inner + "}"
    if isinstance(node, list):
        if not node:
            return "[]"
        return "[" + _json_shape(node[0], depth + 1) + f"x{len(node)}]"
    if isinstance(node, bool):
        return "bool"
    if isinstance(node, (int, float)):
        return "num"
    if node is None:
        return "null"
    return "str"


def _html_shape(text: str) -> str:
    tags = re.findall(r"<([a-zA-Z][a-zA-Z0-9]{0,12})", text[:60000])
    counts: dict[str, int] = {}
    for t in tags:
        t = t.lower()
        counts[t] = counts.get(t, 0) + 1
    ids = sorted(set(re.findall(r'id=["\']([A-Za-z0-9_\-]{2,40})["\']', text[:60000])))[:40]
    return json.dumps({"tags": dict(sorted(counts.items())), "ids": ids},
                      sort_keys=True)


def _collect(node, n: Normalised, path: str = "", depth: int = 0) -> None:
    if depth > 8:
        return
    if isinstance(node, dict):
        for k, v in node.items():
            if _VOLATILE_KEYS.match(k):
                continue
            n.keys.add(k)
            if _PII_KEYS.match(k) and v not in (None, "", []):
                n.pii_keys.add(k)
            _collect(v, n, f"{path}.{k}", depth + 1)
    elif isinstance(node, list):
        for v in node[:50]:
            _collect(v, n, path, depth + 1)
    else:
        if isinstance(node, str) and 2 < len(node) < 200:
            n.values.add(node)
        elif isinstance(node, (int, float)) and not isinstance(node, bool):
            n.values.add(str(node))


# ---------------- the verdict ----------------

@dataclass
class Verdict:
    verdict: str          # leak | denied | public | inconclusive
    score: float          # 0..1 confidence that this is a real authz failure
    reasons: list[str] = field(default_factory=list)
    shared_values: list[str] = field(default_factory=list)
    pii_leaked: list[str] = field(default_factory=list)


def compare(baseline: Normalised, probe: Normalised,
            anon: Normalised | None = None) -> Verdict:
    """
    baseline = owner's response (identity A asking for A's object)
    probe    = attacker's response (identity B asking for A's object)
    anon     = unauthenticated response, for the public-resource disproof

    Returns a verdict grounded only in what the bytes show.
    """
    v = Verdict(verdict="inconclusive", score=0.0)

    # --- clear denial ------------------------------------------------
    if probe.status in (401, 403):
        v.verdict = "denied"
        v.reasons.append(f"probe returned {probe.status}")
        return v
    if probe.denied and probe.status not in (200, 201, 206):
        v.verdict = "denied"
        v.reasons.append("probe body carries a denial marker")
        return v
    if probe.status >= 500:
        v.verdict = "inconclusive"
        v.reasons.append(f"probe returned {probe.status} (server error)")
        return v
    if probe.status == 404 and baseline.status == 200:
        v.verdict = "denied"
        v.reasons.append("probe 404 while owner 200 (object scoped correctly)")
        return v
    if probe.status not in (200, 201, 202, 206, 302):
        v.verdict = "inconclusive"
        v.reasons.append(f"probe status {probe.status}")
        return v

    score = 0.0

    # --- structural match --------------------------------------------
    if baseline.shape and baseline.shape == probe.shape:
        score += 0.45
        v.reasons.append("identical response structure to owner's")
    elif baseline.is_json and probe.is_json:
        overlap = len(baseline.keys & probe.keys)
        union = len(baseline.keys | probe.keys) or 1
        jac = overlap / union
        if jac >= 0.85:
            score += 0.35
            v.reasons.append(f"near-identical JSON keys (jaccard {jac:.2f})")
        elif jac >= 0.6:
            score += 0.15
            v.reasons.append(f"similar JSON keys (jaccard {jac:.2f})")

    # --- value-level leakage: the strongest signal --------------------
    shared = baseline.values & probe.values
    # discard tiny/common values
    shared = {s for s in shared if len(s) >= 4 and s not in {"true", "false", "null"}}
    if shared:
        v.shared_values = sorted(shared)[:25]
        if len(shared) >= 5:
            score += 0.40
            v.reasons.append(f"{len(shared)} owner-specific values present in probe response")
        else:
            score += 0.20
            v.reasons.append(f"{len(shared)} owner value(s) present in probe response")

    # --- PII -----------------------------------------------------------
    leaked_pii = baseline.pii_keys & probe.pii_keys
    if leaked_pii and shared:
        v.pii_leaked = sorted(leaked_pii)
        score += 0.25
        v.reasons.append(f"PII fields returned: {', '.join(sorted(leaked_pii))}")

    # --- size similarity -------------------------------------------------
    if baseline.length and probe.length:
        ratio = min(baseline.length, probe.length) / max(baseline.length, probe.length)
        if ratio >= 0.95:
            score += 0.10
            v.reasons.append(f"response sizes within 5% ({baseline.length} vs {probe.length})")
        elif ratio < 0.4:
            score -= 0.15
            v.reasons.append(f"response sizes differ greatly ({baseline.length} vs {probe.length})")

    # --- the disproof: is it simply public? -------------------------------
    if anon is not None:
        anon_gets_it = (
            anon.status in (200, 201, 206)
            and not anon.denied
            and (anon.shape == baseline.shape or len(baseline.values & anon.values) >= 3)
        )
        if anon_gets_it:
            v.verdict = "public"
            v.score = 0.0
            v.reasons.append(
                "DISPROVED: unauthenticated request returns the same resource "
                "-- this is public data, not an authorisation failure"
            )
            return v
        v.reasons.append("disproof passed: anonymous request did NOT return the resource")
        score += 0.10

    v.score = max(0.0, min(1.0, score))
    v.verdict = "leak" if v.score >= 0.55 else "inconclusive"
    return v
