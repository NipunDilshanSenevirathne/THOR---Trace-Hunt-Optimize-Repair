"""
The replay engine. Four bug classes, one corpus, zero model calls.

  authz     -- identity B requests identity A's object          (IDOR / BOLA)
  bfla      -- low-priv identity calls privileged method/route  (BFLA)
  massassign-- inject privileged fields into a write            (mass assignment)
  race      -- fire N concurrent copies of a state-changing op  (TOCTOU)

Every experiment is: send, observe, compare against the owner's baseline,
and — before anything is called a leak — run the anonymous disproof.
"""

from __future__ import annotations

import json
import re
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from urllib.parse import urlsplit, urlunsplit

from .db import DB
from .diff import Verdict, compare, normalise
from .net import Client, Request
from .scope import Scope, ScopeViolation

# Fields worth injecting into a write to test mass assignment.
_PRIV_FIELDS = {
    "role": "admin", "is_admin": True, "isAdmin": True, "admin": True,
    "is_staff": True, "is_superuser": True, "permissions": ["*"],
    "scope": "admin", "plan": "enterprise", "tier": "enterprise",
    "verified": True, "is_verified": True, "email_verified": True,
    "balance": 999999, "credit": 999999, "price": 0, "amount": 0,
    "discount": 100, "status": "approved", "approved": True,
    "owner_id": None, "user_id": None, "tenant_id": None,
}

_WRITE_METHODS = {"POST", "PUT", "PATCH", "DELETE"}
_PRIV_PATH = re.compile(
    r"(?i)/(admin|manage|internal|staff|superuser|console|settings|config|"
    r"users?/\w+/(role|permission|ban|suspend|delete)|impersonate|billing|"
    r"export|audit|report)")


@dataclass
class Identity:
    name: str
    headers: dict[str, str]
    role: str = "user"
    tenant: str = ""

    @classmethod
    def load_all(cls, db: DB) -> dict[str, "Identity"]:
        """Resolved through identity.py so credentials come from the vault."""
        from . import identity as ident_mod
        out = {}
        for name, i in ident_mod.load_all(db).items():
            out[name] = cls(name=i.name, headers=dict(i.headers),
                            role=i.role, tenant=i.tenant)
        return out


def _swap(url: str, body: str | None, ref: dict, new_value: str) -> tuple[str, str | None]:
    """Replace one object reference with another identity's value."""
    parts = urlsplit(url)
    if ref["loc"] == "path":
        path = parts.path
        old = ref["value"]
        # replace only as a whole segment
        new_path = re.sub(rf"(?<=/){re.escape(old)}(?=/|$)", new_value, path)
        return urlunsplit(parts._replace(path=new_path)), body
    if ref["loc"] == "query":
        q = re.sub(rf"(?<=[?&]{re.escape(ref['name'])}=)[^&]*", new_value, parts.query)
        return urlunsplit(parts._replace(query=q)), body
    if ref["loc"] == "body" and body:
        try:
            data = json.loads(body)
            _set_json_path(data, ref["name"], new_value)
            return url, json.dumps(data)
        except Exception:
            return url, re.sub(
                rf"(?<=[?&\"']{re.escape(ref['name'].split('.')[-1])}[\"']?[=:][\"']?)"
                rf"{re.escape(ref['value'])}", new_value, body)
    if ref["loc"] == "header":
        return url, body
    return url, body


def _set_json_path(data, path: str, value):
    keys = re.split(r"\.|\[", path.replace("]", ""))
    cur = data
    for k in keys[:-1]:
        cur = cur[int(k)] if k.isdigit() else cur[k]
    last = keys[-1]
    if last.isdigit():
        cur[int(last)] = value
    else:
        cur[last] = value


def _record(db: DB, kind: str, base_id: int | None, ident: str,
            req: Request, resp, verdict: Verdict, control=None) -> int | None:
    """
    `control` is the contemporaneous owner response this experiment was
    judged against. Storing it is what lets the evidence bundle show the
    comparison that was actually made, rather than a captured response that
    may have drifted since.
    """
    sig = req.signature()
    if db.seen_signature(sig):
        return None
    return db.ex(
        "INSERT INTO experiments (signature, kind, base_request_id, as_identity, "
        "method, url, body, status, resp_sha256, resp_len, elapsed_ms, verdict, "
        "score, detail, control_status, control_sha256, control_len, "
        "dest_address) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        sig, kind, base_id, ident, req.method, req.url,
        (req.body or b"").decode("utf-8", "replace")[:20000],
        resp.status, resp.sha256, len(resp.body), resp.elapsed_ms,
        verdict.verdict, verdict.score,
        json.dumps({"reasons": verdict.reasons,
                    "shared_values": verdict.shared_values,
                    "pii": verdict.pii_leaked}),
        getattr(control, "status", None),
        getattr(control, "sha256", None),
        getattr(control, "length", None),
        getattr(resp, "address", "") or "",
    )


# ---------------------------------------------------------------- authz

def run_authz(db: DB, scope: Scope, corpus: str, *,
              min_conf: float = 0.7, limit: int = 0, log=print) -> dict:
    """
    For every request carrying an object reference, replay it as every other
    identity. The owner's original response is the baseline. Every candidate
    leak is then disproved against an anonymous request.
    """
    from .corpus import authz_candidates

    idents = Identity.load_all(db)
    if len(idents) < 2:
        raise SystemExit("Need at least 2 identities. Run: thor identity add ...")

    cands = authz_candidates(db, corpus, min_conf)
    if limit:
        cands = cands[:limit]
    log(f"[authz] {len(cands)} requests carry object references")

    results = {"tested": 0, "leaks": 0, "denied": 0, "public": 0,
               "inconclusive": 0, "stale": 0}

    with Client(scope) as client:
        for c in cands:
            owner = c["identity"]

            # Skip requests the owner themselves could not access.
            if c["status"] not in (200, 201, 202, 206):
                continue

            # The control must be contemporaneous with the probe, so refresh
            # it. Only fall back to the captured body if the refresh could
            # not be made at all.
            baseline, skip = _owner_baseline(client, c, idents, log)
            if skip:
                log(f"[authz] skip {c['method']} {c['url']} — {skip}")
                results["stale"] += 1
                continue
            if baseline is None:
                baseline = normalise(
                    c["status"], c["resp_body"] or "",
                    (c["headers"].get("Content-Type") or ""))

            for name, ident in idents.items():
                if name == owner:
                    continue

                headers = dict(c["headers"])
                _strip_auth(headers)
                headers.update(ident.headers)

                req = Request(c["method"], c["url"], headers,
                              (c["body"] or "").encode() or None, identity=name)
                if db.seen_signature(req.signature()):
                    continue
                try:
                    resp = client.send(req)
                except ScopeViolation as e:
                    log(f"[authz] blocked: {e}")
                    continue
                except Exception as e:
                    log(f"[authz] error {c['url']}: {e}")
                    continue

                probe = normalise(resp.status, resp.text,
                                  resp.headers.get("content-type", ""))

                # cheap pre-filter, then the expensive disproof only if needed
                pre = compare(baseline, probe, anon=None)
                anon_norm = None
                if pre.verdict == "leak" and name != "anon":
                    anon_norm = _anon_probe(client, c, log)

                verdict = compare(baseline, probe, anon=anon_norm)

                # An unauthenticated identity receiving the resource does not
                # prove an authorisation failure -- it proves the resource is
                # public. Reclassify rather than report it as a leak.
                if name == "anon" and verdict.verdict == "leak":
                    verdict.verdict = "public"
                    verdict.score = 0.0
                    verdict.reasons.append(
                        "served without authentication -- public resource, "
                        "not an authorisation failure")

                _record(db, "authz", c["id"], name, req, resp, verdict,
                        control=baseline)

                results["tested"] += 1
                key = {"leak": "leaks", "denied": "denied",
                       "public": "public"}.get(verdict.verdict, "inconclusive")
                results[key] += 1

                if verdict.verdict == "leak":
                    log(f"[authz] LEAK  {name} -> {c['method']} {c['url']} "
                        f"(score {verdict.score:.2f})")
                    for r in verdict.reasons:
                        log(f"          · {r}")

    log(f"[authz] {json.dumps(results)}")
    if results["stale"]:
        log(f"[authz] {results['stale']} candidate(s) skipped: the owner can "
            f"no longer reach their own object. Re-capture authenticated "
            f"traffic and re-run — results against a dead session are noise.")
    return results


def _strip_auth(headers: dict) -> None:
    for k in list(headers):
        if k.lower() in ("authorization", "cookie", "x-api-key", "x-auth-token",
                         "x-csrf-token", "x-xsrf-token", "content-length"):
            headers.pop(k, None)


def refresh_control(client: Client, method: str, url: str, headers: dict,
                    body: str, owner_headers: dict, owner: str, log=print):
    """
    Re-fetch the owner's own response *now*, and use that as the control.

    The captured response is not a valid control. Captured traffic is
    routinely hours old -- you export a Burp session in the evening and hunt
    overnight -- and any field that moved since capture (a timestamp, a
    counter, an attribute that was added) degrades the shape and value
    comparison against the probe. A real IDOR then scores below threshold and
    is filed as inconclusive. That failure is silent and in the
    under-reporting direction, which is the worst kind: nothing in the output
    says "this was probably a bug and I could not tell".

    A control has to be contemporaneous with the treatment. So: one extra
    request per candidate, with the owner's identity, immediately before the
    probes. That is roughly a 20-30% request increase on an authz run, which
    is the correct trade -- a cheaper run that cannot distinguish a leak from
    drift is not cheaper, it is wrong.

    Returns (normalised_control, reason_to_skip):

      (Normalised, None)  use this control
      (None, None)        could not refresh; caller falls back to the capture
      (None, "reason")    the owner cannot reach their own object -- skip the
                          candidate entirely and tell the operator

    Shared by the authz and tenant engines, which had the same flaw.
    """
    h = dict(headers)
    _strip_auth(h)
    h.update(owner_headers)
    try:
        r = client.send(Request(method, url, h,
                                (body or "").encode() or None, identity=owner))
    except ScopeViolation as e:
        return None, f"scope refused the owner baseline: {e}"
    except Exception as e:
        log(f"[control] could not refresh baseline for {url}: {e}")
        return None, None                 # fall back to the captured response
    if r.status not in (200, 201, 202, 206):
        return None, (f"owner now gets {r.status} on their own object "
                      f"(captured session likely expired -- re-capture)")
    return normalise(r.status, r.text,
                     r.headers.get("content-type", "")), None


def _owner_baseline(client: Client, c: dict, idents: dict, log):
    """authz-engine adapter over `refresh_control`."""
    owner = idents.get(c["identity"])
    if owner is None:
        return None, None                 # unknown identity; fall back
    return refresh_control(client, c["method"], c["url"], c["headers"],
                           c["body"] or "", owner.headers, c["identity"], log)


def _anon_probe(client: Client, c: dict, log):
    """The §27 disproof, executed rather than reasoned about."""
    headers = dict(c["headers"])
    _strip_auth(headers)
    try:
        r = client.send(Request(c["method"], c["url"], headers,
                                (c["body"] or "").encode() or None,
                                identity="anon"))
    except Exception:
        return None
    return normalise(r.status, r.text, r.headers.get("content-type", ""))


# ---------------------------------------------------------------- bfla

def run_bfla(db: DB, scope: Scope, corpus: str, log=print) -> dict:
    """
    Method swapping + privileged-route access from a low-privilege identity.
    If userB can PUT/DELETE where only GET was offered, that is a function-level
    authorisation failure.
    """
    idents = Identity.load_all(db)
    low = [i for i in idents.values() if i.role not in ("admin", "superuser")]
    rows = db.q("SELECT * FROM requests WHERE corpus=?", corpus)
    results = {"tested": 0, "leaks": 0}

    with Client(scope) as client:
        for r in rows:
            url, method = r["url"], r["method"]
            headers = json.loads(r["headers"] or "{}")
            privileged_route = bool(_PRIV_PATH.search(urlsplit(url).path or ""))

            swaps = []
            if method == "GET":
                swaps = ["POST", "PUT", "DELETE", "PATCH"]
            elif method in _WRITE_METHODS:
                swaps = ["GET"]
            if privileged_route:
                swaps.append(method)

            for ident in low:
                for m in swaps:
                    if m.upper() not in {x.upper() for x in scope.allowed_methods}:
                        continue
                    if m in ("DELETE", "PUT") and not scope.is_destructive_allowed():
                        continue
                    h = dict(headers)
                    _strip_auth(h)
                    h.update(ident.headers)
                    req = Request(m, url, h, (r["body"] or "").encode() or None,
                                  identity=ident.name)
                    if db.seen_signature(req.signature()):
                        continue
                    try:
                        resp = client.send(req)
                    except Exception:
                        continue
                    results["tested"] += 1
                    probe = normalise(resp.status, resp.text,
                                      resp.headers.get("content-type", ""))
                    v = Verdict("inconclusive", 0.0)
                    if resp.status in (200, 201, 202, 204) and not probe.denied:
                        v = Verdict("leak", 0.7 if privileged_route else 0.6,
                                    [f"{ident.name} ({ident.role}) got "
                                     f"{resp.status} on {m} {url}"
                                     + (" [privileged route]" if privileged_route else "")])
                        results["leaks"] += 1
                        log(f"[bfla] LEAK  {ident.name} {m} {url} -> {resp.status}")
                    _record(db, "bfla", r["id"], ident.name, req, resp, v)

    log(f"[bfla] {json.dumps(results)}")
    return results


# ------------------------------------------------------- mass assignment

def run_massassign(db: DB, scope: Scope, corpus: str, log=print) -> dict:
    """Inject privileged fields into write requests and see if they stick."""
    idents = Identity.load_all(db)
    rows = db.q("SELECT * FROM requests WHERE corpus=? AND method IN "
                "('POST','PUT','PATCH')", corpus)
    results = {"tested": 0, "accepted": 0}

    with Client(scope) as client:
        for r in rows:
            body = r["body"] or ""
            if not body.lstrip().startswith("{"):
                continue
            try:
                base = json.loads(body)
            except Exception:
                continue
            if not isinstance(base, dict):
                continue

            ident = idents.get(r["identity"]) or next(iter(idents.values()))
            for field, value in _PRIV_FIELDS.items():
                if field in base:
                    continue
                mutated = dict(base)
                mutated[field] = value
                h = json.loads(r["headers"] or "{}")
                h.pop("Content-Length", None)
                h.pop("content-length", None)
                h.update(ident.headers)
                req = Request(r["method"], r["url"], h,
                              json.dumps(mutated).encode(), identity=ident.name)
                if db.seen_signature(req.signature()):
                    continue
                try:
                    resp = client.send(req)
                except Exception:
                    continue
                results["tested"] += 1
                accepted = (
                    resp.status in (200, 201, 202)
                    and field in resp.text
                    and str(value).strip("[]'\"") in resp.text
                )
                v = Verdict("inconclusive", 0.0)
                if accepted:
                    v = Verdict("leak", 0.75,
                                [f"injected field '{field}={value}' reflected in "
                                 f"{resp.status} response"])
                    results["accepted"] += 1
                    log(f"[massassign] ACCEPTED {field} on {r['method']} {r['url']}")
                _record(db, "massassign", r["id"], ident.name, req, resp, v)

    log(f"[massassign] {json.dumps(results)}")
    return results


# ---------------------------------------------------------------- race

def run_race(db: DB, scope: Scope, corpus: str, n: int = 12,
             log=print) -> dict:
    """
    Fire N concurrent copies of a state-changing request. Two successes where
    one is expected is a TOCTOU window. Only runs when scope allows
    destructive testing -- this genuinely changes state.
    """
    if not scope.is_destructive_allowed():
        log("[race] skipped: scope.destructive is false")
        return {"skipped": True}

    rows = db.q("SELECT * FROM requests WHERE corpus=? AND method IN "
                "('POST','PUT','PATCH') AND status IN (200,201,202)", corpus)
    results = {"tested": 0, "suspicious": 0, "idempotent": 0,
               "precondition_failed": 0}

    with Client(scope) as client:
        for r in rows:
            path = urlsplit(r["url"]).path or ""
            if not re.search(r"(?i)(redeem|apply|claim|coupon|voucher|transfer|"
                             r"withdraw|vote|like|follow|invite|purchase|checkout|"
                             r"submit|confirm)", path):
                continue
            h = json.loads(r["headers"] or "{}")
            req = Request(r["method"], r["url"], h,
                          (r["body"] or "").encode() or None,
                          identity=r["identity"] or "unknown")

            # Two concurrent 200s are not a race. An idempotent endpoint --
            # PUT /profile, a re-submitted vote, anything meant to accept
            # repeats -- returns 200 to every copy, and calling that a
            # TOCTOU window is how a tool earns a reputation for noise.
            # "Single-use operation" is a claim that has to be established
            # before concurrency can contradict it.
            #
            # The control therefore runs AFTER the burst, not before. A
            # single-use resource can only be spent once, so probing first
            # consumes the very thing being tested: the burst then races
            # for something already gone and the real bug reads as clean.
            # (Found by running it: the planted TOCTOU went undetected
            # because the control had redeemed the coupon.)
            #
            # Afterwards the distinction still holds. If the operation is
            # idempotent the follow-up succeeds like every other repeat;
            # if it is single-use it is now spent and the server rejects
            # it. Rejection plus several concurrent successes is the
            # contradiction that makes this a finding.
            def fire(_):
                try:
                    return client.send(req)
                except Exception:
                    return None

            with ThreadPoolExecutor(max_workers=n) as ex:
                responses = [x for x in ex.map(fire, range(n)) if x]
            results["tested"] += 1
            ok = [x for x in responses if x.status in (200, 201, 202)]

            if len(ok) <= 1:
                log(f"[race] holds: {r['method']} {r['url']} — "
                    f"{len(ok)}/{n} concurrent succeeded")
                continue

            try:
                after = client.send(req)
            except ScopeViolation as e:
                log(f"[race] blocked: {e}")
                continue
            except Exception as e:
                log(f"[race] control failed on {r['url']}: {e}")
                continue

            if after.status in (200, 201, 202):
                results["idempotent"] += 1
                log(f"[race] skip {r['method']} {r['url']} — a further "
                    f"sequential request also returned {after.status}, so "
                    f"this operation accepts repeats by design; "
                    f"{len(ok)}/{n} concurrent successes prove nothing")
                continue

            v = Verdict("leak", 0.9, [
                f"{len(ok)}/{n} concurrent copies of a single-use operation "
                f"returned success",
                f"control executed after the burst: a further sequential "
                f"request was rejected with {after.status}, so the server "
                f"does enforce single use — just not under concurrency",
                "an idempotent endpoint would have accepted that follow-up; "
                "this one did not, which is what separates a TOCTOU window "
                "from an operation that simply allows repeats",
            ])
            results["suspicious"] += 1
            log(f"[race] TOCTOU {r['method']} {r['url']}: concurrent "
                f"{len(ok)}/{n} succeeded, follow-up {after.status}")
            _record(db, "race", r["id"], req.identity, req, ok[0], v,
                    control=_norm_of(after))

    log(f"[race] {json.dumps(results)}")
    return results


def _norm_of(resp):
    """Normalise a response so it can be stored as an experiment's control."""
    return normalise(resp.status, resp.text,
                     resp.headers.get("content-type", ""))
