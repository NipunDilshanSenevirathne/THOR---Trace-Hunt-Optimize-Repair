"""
Evidence bundles and finding deduplication.

A finding does not exist until it has an evidence bundle: the paired
requests, the hashes, and a replay script a triager can run. Nothing here
takes a model's word for anything.
"""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from urllib.parse import urlsplit

from . import replay as replay_mod
from . import vault
from . import states
from .db import DB
from . import runtime

_ID_IN_PATH = re.compile(
    r"/(\d{1,19}"
    r"|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
    r"|[0-9a-fA-F]{24})(?=/|$)", re.I)

SEVERITY = {
    "authz": "high", "bfla": "high", "massassign": "high", "race": "medium",
    "sqli": "critical", "nosql": "high", "ssti": "critical", "cmdi": "critical",
    "ssrf": "high", "path": "high", "xss": "medium", "logic": "high",
    "type": "low", "graphql": "high", "jwt": "critical", "pathacl": "high",
    "cors": "medium", "cache": "medium", "chain": "critical",
    "oauth": "high", "tenant": "critical", "workflow": "high",
    "redirect": "low", "protopollution": "high", "upload": "medium",
    "websocket": "medium", "sourcemap": "low",
}

CWE = {
    "authz": "CWE-639 Authorization Bypass Through User-Controlled Key",
    "bfla": "CWE-285 Improper Authorization",
    "massassign": "CWE-915 Improperly Controlled Modification of Object Attributes",
    "race": "CWE-367 Time-of-check Time-of-use Race Condition",
    "sqli": "CWE-89 SQL Injection",
    "nosql": "CWE-943 Improper Neutralization of Data within Query Logic",
    "ssti": "CWE-1336 Server-Side Template Injection",
    "cmdi": "CWE-78 OS Command Injection",
    "ssrf": "CWE-918 Server-Side Request Forgery",
    "path": "CWE-22 Path Traversal",
    "xss": "CWE-79 Cross-site Scripting",
    "logic": "CWE-840 Business Logic Errors",
    "type": "CWE-843 Type Confusion",
    "graphql": "CWE-285 Improper Authorization (GraphQL field level)",
    "jwt": "CWE-347 Improper Verification of Cryptographic Signature",
    "pathacl": "CWE-288 Authentication Bypass Using an Alternate Path",
    "cors": "CWE-942 Permissive Cross-domain Policy",
    "cache": "CWE-524 Use of Cache Containing Sensitive Information",
    "chain": "Multiple — see linked findings",
    "oauth": "CWE-601 / CWE-352 OAuth flow weakness (RFC 9700)",
    "tenant": "CWE-639 Authorization Bypass (cross-tenant)",
    "workflow": "CWE-841 Improper Enforcement of Behavioral Workflow",
    "redirect": "CWE-601 URL Redirection to Untrusted Site",
    "protopollution": "CWE-1321 Prototype Pollution",
    "upload": "CWE-434 Unrestricted Upload of File with Dangerous Type",
    "sourcemap": "CWE-540 Inclusion of Sensitive Information in Source Code",
}

TITLES = {
    "authz": "Broken object-level authorization on {r}",
    "bfla": "Broken function-level authorization on {r}",
    "massassign": "Mass assignment on {r}",
    "race": "Race condition on {r}",
    "sqli": "SQL injection on {r}",
    "nosql": "NoSQL operator injection on {r}",
    "ssti": "Server-side template injection on {r}",
    "cmdi": "OS command injection on {r}",
    "ssrf": "Server-side request forgery on {r}",
    "path": "Path traversal / arbitrary file read on {r}",
    "xss": "Reflected cross-site scripting on {r}",
    "logic": "Business logic flaw on {r}",
    "type": "Type-confusion behaviour on {r}",
    "graphql": "GraphQL authorization flaw on {r}",
    "jwt": "JWT signature verification bypass on {r}",
    "pathacl": "Access-control bypass via path normalisation on {r}",
    "cors": "Permissive CORS with credentials on {r}",
    "cache": "Unkeyed input reflected into cacheable response on {r}",
    "oauth": "OAuth flow weakness on {r}",
    "tenant": "Cross-tenant data access on {r}",
    "workflow": "Business workflow invariant not enforced on {r}",
    "redirect": "Open redirect on {r}",
    "protopollution": "Server-side prototype pollution on {r}",
    "upload": "Unrestricted file upload on {r}",
    "sourcemap": "Source map exposed on {r}",
}

# Classes where the anonymous disproof is the relevant control. For injection
# and logic classes the control is the inert mutation, already run by the
# fuzzer, so they are not marked as missing a disproof.
_NEEDS_ANON_DISPROOF = {"authz", "bfla", "graphql", "tenant"}


def route_shape(url: str) -> str:
    """Collapse concrete ids so /orders/123 and /orders/456 are one finding."""
    p = urlsplit(url)
    return f"{p.netloc}{_ID_IN_PATH.sub('/{id}', p.path or '/')}"


def fingerprint(vuln_class: str, url: str) -> str:
    return hashlib.sha256(f"{vuln_class}|{route_shape(url)}".encode()).hexdigest()[:20]


def promote(db: DB, min_score: float = 0.55, log=print) -> int:
    """Turn confirmed experiments into deduplicated finding candidates."""
    rows = db.q(
        "SELECT * FROM experiments WHERE verdict='leak' AND score>=? "
        "ORDER BY score DESC", min_score)
    created = 0
    for r in rows:
        fp = fingerprint(r["kind"], r["url"])
        if db.one("SELECT 1 FROM findings WHERE fingerprint=?", fp):
            # merge evidence into the existing finding
            f = db.one("SELECT id, evidence_ids FROM findings WHERE fingerprint=?", fp)
            ev = set(json.loads(f["evidence_ids"] or "[]"))
            if r["id"] not in ev:
                ev.add(r["id"])
                db.ex("UPDATE findings SET evidence_ids=? WHERE id=?",
                      json.dumps(sorted(ev)), f["id"])
            continue

        detail = json.loads(r["detail"] or "{}")
        shape = route_shape(r["url"])
        host = urlsplit(r["url"]).hostname or ""

        # Whether a control was actually executed. For cross-identity classes
        # that is the anonymous request; for fuzz classes it is the inert
        # mutation, which the fuzzer always runs, or a proving oracle.
        if r["kind"] in _NEEDS_ANON_DISPROOF:
            disproved = any("disproof passed" in x for x in detail.get("reasons", []))
        else:
            disproved = (detail.get("oracle") in
                         ("oast", "computed", "boolean", "timing")
                         or any("inert control" in x
                                for x in detail.get("reasons", []))
                         or any("only under mutation" in x
                                for x in detail.get("reasons", [])))

        fid = db.ex(
            "INSERT INTO findings (fingerprint, vuln_class, severity, title, "
            "asset, route, summary, impact, evidence_ids, disproof_done, status) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            fp, r["kind"], _severity(r), _title(r, shape), host, shape,
            "; ".join(detail.get("reasons", []))[:2000],
            _impact(r, detail), json.dumps([r["id"]]),
            1 if disproved else 0,
            states.CANDIDATE,
        )
        # Severity above the class baseline is always a named, recorded
        # rule, never an unexplained jump.
        _apply_escalations(db, fid, detail, log=lambda *a, **k: None)
        created += 1
        log(f"[evidence] finding: {_title(r, shape)}")
    log(f"[evidence] {created} new findings ({len(rows)} leak experiments)")
    # every new finding immediately walks its gates; nothing is assumed
    if created:
        states.advance_all(db, log=log)
    return created


def _severity(r) -> str:
    """
    The base severity for this vulnerability class, before any escalation.

    Escalations used to happen here, silently: a PII string in the response
    jumped the finding a level, and an OAST hit jumped it again. Both are
    defensible rules, but a severity nobody can trace is a severity a
    triager will argue with and win. They now go through
    `ESCALATION_RULES`, which records the rule and the reason against the
    finding — see thor/chain.py::escalate.
    """
    return SEVERITY.get(r["kind"], "medium")


# Every automatic severity change is a named rule with a stated reason.
# Nothing escalates because it "feels" worse.
ESCALATION_RULES = [
    (
        "pii-returned-to-unauthorised-identity",
        lambda d: bool(d.get("pii")),
        lambda d: (f"the unauthorised response contained PII fields "
                   f"({', '.join(d.get('pii') or [])}) belonging to another "
                   f"user, so the impact is disclosure of personal data "
                   f"rather than of an opaque record"),
    ),
    (
        "out-of-band-callback-proved-execution",
        lambda d: d.get("oracle") == "oast",
        lambda d: ("an out-of-band callback correlated to this experiment "
                   "proved the payload executed server-side; the behaviour "
                   "is observed rather than inferred from a response"),
    ),
]


def _apply_escalations(db, finding_id: int, detail: dict, log=print) -> None:
    from . import chain
    for rule, applies, reason in ESCALATION_RULES:
        if applies(detail):
            chain.escalate(db, finding_id, rule=rule, reason=reason(detail),
                           steps=1, log=log)


def _title(r, shape: str) -> str:
    tpl = TITLES.get(r["kind"])
    if tpl:
        return tpl.format(r=shape)
    return f"{r['kind']} on {shape}"


def _impact(r, detail: dict) -> str:
    pii = detail.get("pii") or []
    shared = detail.get("shared_values") or []
    kind = r["kind"]
    bits = []
    if pii:
        bits.append(
            f"Response exposed PII fields ({', '.join(pii)}) belonging to another user.")
    if shared:
        bits.append(
            f"{len(shared)} values unique to the owning account were returned to "
            f"the unauthorised identity.")
    canned = {
        "bfla": "A low-privilege identity successfully invoked a function that "
                "should require elevated privileges.",
        "massassign": "A client-supplied privileged attribute was accepted and "
                      "persisted by the server.",
        "race": "A single-use operation completed more than once under "
                "concurrent requests.",
        "sqli": "User input reaches a SQL query engine. The oracle established "
                "the parse; data extraction was not attempted.",
        "ssti": "User input is evaluated as a server-side template expression, "
                "which commonly leads to remote code execution.",
        "cmdi": "User input reaches an OS command interpreter, confirmed by an "
                "out-of-band callback from the target.",
        "ssrf": "The server can be induced to make requests to attacker-chosen "
                "destinations, including internal addresses.",
        "path": "Arbitrary files readable by the application process can be "
                "retrieved.",
        "xss": "User input is reflected into a parsing-relevant HTML context "
               "with breaking characters unencoded.",
        "logic": "A business invariant is not enforced server-side, so the "
                 "client can drive the application into an invalid state.",
        "jwt": "Forged authentication tokens are accepted, allowing an "
               "attacker to assume an arbitrary identity.",
        "pathacl": "The gateway access-control rule can be bypassed by "
                   "request normalisation, exposing a protected route.",
        "cors": "An attacker-controlled origin can read authenticated "
                "responses from a victim's browser.",
        "cache": "An unkeyed request header is reflected into a cacheable "
                 "response, which can poison entries served to other users.",
        "graphql": "GraphQL fields return data without enforcing "
                   "field-level authorisation.",
        "tenant": "An identity in one tenant retrieved another tenant's "
                  "data. This crosses a customer boundary, not merely a "
                  "user boundary.",
        "oauth": "The OAuth flow deviates from RFC 9700, enabling code or "
                 "token interception.",
        "workflow": "A business workflow invariant is enforced only in the "
                    "client, so the state machine can be driven directly.",
        "protopollution": "Object prototypes can be polluted from request "
                          "input, affecting subsequent requests globally.",
        "redirect": "Users can be redirected to an attacker-controlled site "
                    "from a trusted origin.",
        "upload": "Files of dangerous types are accepted and served.",
    }
    if kind in canned:
        bits.append(canned[kind])
    if detail.get("reasons"):
        bits.append("Observed: " + "; ".join(detail["reasons"][:3]))
    body = " ".join(bits) or "See evidence."
    # Marked as auto-generated so the REPORT_READY gate can require a real
    # impact section written for a triager.
    return f"{states.AUTO_IMPACT_MARK} {body}"


def bundle(db: DB, finding_id: int, outdir: str | Path = "evidence") -> Path:
    """
    Write a self-contained, replayable evidence folder.

    No shell is generated from captured data. Request bodies are
    target-controlled; interpolating them into shell syntax was a command
    injection against the operator's own machine. See thor/replay.py.
    """
    f = db.one("SELECT * FROM findings WHERE id=?", finding_id)
    if not f:
        raise SystemExit(f"No finding {finding_id}")
    f = dict(f)
    ev_ids = json.loads(f["evidence_ids"] or "[]")
    exps = [db.one("SELECT * FROM experiments WHERE id=?", i) for i in ev_ids]
    exps = [e for e in exps if e]

    d = Path(outdir) / f"finding-{finding_id}-{f['vuln_class']}"
    d.mkdir(parents=True, exist_ok=True)

    gate = states.evaluate(db, finding_id, states.VERIFIED)
    meta = {
        "finding_id": finding_id,
        "fingerprint": f["fingerprint"],
        "class": f["vuln_class"],
        "cwe": CWE.get(f["vuln_class"], ""),
        "severity": f["severity"],
        "state": f["status"],
        "title": f["title"],
        "asset": f["asset"],
        "route": f["route"],
        "summary": f["summary"],
        "impact": f["impact"],
        "control_executed": bool(f["disproof_done"]) or gate.moved,
        "gates_passed": gate.passed,
        "gates_blocking": gate.blocked_by,
        "generated": runtime.utcstamp(),
        "experiments": [],
    }

    for e in exps:
        base = (db.one("SELECT * FROM requests WHERE id=?", e["base_request_id"])
                if e["base_request_id"] else None)
        meta["experiments"].append(vault.redact({
            "id": e["id"],
            "as_identity": e["as_identity"],
            "method": e["method"],
            "url": e["url"],
            "status": e["status"],
            "response_sha256": e["resp_sha256"],
            "response_bytes": e["resp_len"],
            "elapsed_ms": e["elapsed_ms"],
            "verdict": e["verdict"],
            "score": e["score"],
            "detail": json.loads(e["detail"] or "{}"),
            "owner_baseline": {
                "identity": base["identity"],
                "status": base["status"],
                "response_bytes": base["resp_len"],
            } if base else None,
        }))

    (d / "finding.json").write_text(json.dumps(meta, indent=2))
    replay_mod.write_bundle(db, f, exps, d)
    return d


# ---------------- duplicate avoidance ----------------

def dedupe_notes(db: DB, finding_id: int) -> list[str]:
    """
    Local duplicate signals. The remote check (program Hacktivity) is a
    Claude Code step -- see .claude/commands/dedupe.md -- because it needs
    judgement about what counts as 'the same bug'.
    """
    f = db.one("SELECT * FROM findings WHERE id=?", finding_id)
    if not f:
        return []
    out = []
    same_class = db.q(
        "SELECT id, route, status FROM findings WHERE vuln_class=? AND id!=?",
        f["vuln_class"], finding_id)
    for s in same_class:
        if s["route"].split("/")[0] == f["route"].split("/")[0]:
            out.append(f"finding {s['id']} is same class on same host "
                       f"({s['route']}, status={s['status']})")
    reported = db.q("SELECT id, route FROM findings WHERE status='reported'")
    if reported:
        out.append(f"{len(reported)} finding(s) already reported on this engagement "
                   "-- check the program's policy on related reports")
    return out
