"""
Hypothesis-native execution.

The review's sharpest architectural point: `reason.py` produced ranked
hypotheses with exact experiments and falsifiers, and then the loop ignored
all of that and asked "which engine should I run?" instead. Reasoning and
execution were only decoratively connected.

This module closes the gap. A hypothesis carries an **executable plan** —
which engine, scoped to which target, with which arguments — so selecting a
hypothesis *is* selecting an experiment. After it runs, the plan states how
to read the result against the falsifier, and the hypothesis is confirmed,
disproved, or left open with a reason.

The loop then re-plans: the graph is updated, invariants re-evaluated, and a
fresh hypothesis set generated that accounts for what was just learned. That
is the difference between a scheduler and a research process.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Callable
from urllib.parse import urlsplit

from . import graph, invariants, learn, risk
from .db import DB
from .scope import Scope

# Engine entry points, each narrowed to the target a hypothesis names.
# Signature: (db, scope, corpus, oast, target) -> dict
ENGINE_PLANS: dict[str, Callable] = {}


def _plan(name: str):
    def deco(fn):
        ENGINE_PLANS[name] = fn
        return fn
    return deco


@_plan("authz")
def _authz(db, sc, corpus, oast, target):
    from . import engine
    return engine.run_authz(db, sc, corpus, log=lambda *a: None)


@_plan("tenant")
def _tenant(db, sc, corpus, oast, target):
    from . import probes
    return probes.tenant(db, sc, corpus, log=lambda *a: None)


@_plan("bfla")
def _bfla(db, sc, corpus, oast, target):
    from . import engine
    return engine.run_bfla(db, sc, corpus, log=lambda *a: None)


@_plan("massassign")
def _massassign(db, sc, corpus, oast, target):
    from . import engine
    return engine.run_massassign(db, sc, corpus, log=lambda *a: None)


@_plan("fuzz")
def _fuzz(db, sc, corpus, oast, target):
    from . import fuzz
    route = None
    if target and target not in ("(application-wide)",):
        route = urlsplit(target).path or None
    return fuzz.run_fuzz(db, sc, corpus, oast=oast, only_route=route,
                         max_cases=900, log=lambda *a: None)


@_plan("graphql")
def _graphql(db, sc, corpus, oast, target):
    from . import detectors
    return detectors.graphql(db, sc, corpus, log=lambda *a: None)


@_plan("jwt")
def _jwt(db, sc, corpus, oast, target):
    from . import detectors
    return detectors.jwt_attacks(db, sc, corpus, log=lambda *a: None)


@_plan("pathacl")
def _pathacl(db, sc, corpus, oast, target):
    from . import detectors
    return detectors.path_acl(db, sc, corpus, log=lambda *a: None)


@_plan("cors")
def _cors(db, sc, corpus, oast, target):
    from . import detectors
    return detectors.cors(db, sc, corpus, log=lambda *a: None)


@_plan("cache")
def _cache(db, sc, corpus, oast, target):
    from . import detectors
    return detectors.cache_poison(db, sc, corpus, log=lambda *a: None)


@_plan("oauth")
def _oauth(db, sc, corpus, oast, target):
    from . import oauth
    return oauth.run(db, sc, corpus, log=lambda *a: None)


@_plan("workflow")
def _workflow(db, sc, corpus, oast, target):
    from . import workflow
    return workflow.run(db, sc, corpus, log=lambda *a: None)


@_plan("redirect")
def _redirect(db, sc, corpus, oast, target):
    from . import probes
    return probes.open_redirect(db, sc, corpus, log=lambda *a: None)


@_plan("protopollution")
def _pp(db, sc, corpus, oast, target):
    from . import probes
    return probes.prototype_pollution(db, sc, corpus, log=lambda *a: None)


@_plan("upload")
def _upload(db, sc, corpus, oast, target):
    from . import probes
    return probes.upload(db, sc, corpus, log=lambda *a: None)


@_plan("sourcemap")
def _sourcemap(db, sc, corpus, oast, target):
    from . import probes
    return probes.sourcemaps(db, sc, log=lambda *a: None)


@_plan("race")
def _race(db, sc, corpus, oast, target):
    from . import engine
    return engine.run_race(db, sc, corpus, log=lambda *a: None)


# --------------------------------------------------------------- outcomes

@dataclass
class Outcome:
    hypothesis_id: int
    statement: str
    engine: str
    target: str
    status: str                 # confirmed | disproved | inconclusive | blocked
    reason: str
    experiments: list[int] = field(default_factory=list)
    new_leaks: int = 0
    elapsed_s: float = 0.0

    def render(self) -> str:
        mark = {"confirmed": "✓", "disproved": "✗",
                "inconclusive": "·", "blocked": "!"}.get(self.status, "?")
        return (f"  {mark} {self.status:13} {self.statement[:70]}\n"
                f"      {self.reason}")


def _experiments_since(db: DB, marker: int, engine: str,
                       target: str) -> list[dict]:
    """
    Experiments this engine produced after the marker.

    Narrowing by target is attempted but never trusted: a hypothesis target
    can be an object key (`invoice:5001`), a route shape with `{id}`, or
    `(application-wide)`, and substring-matching those against live URLs
    silently drops the very experiment that proves the hypothesis. If the
    narrow set is empty, the full set for the engine is used.
    """
    rows = [dict(r) for r in db.q(
        "SELECT id, verdict, score, url, detail FROM experiments "
        "WHERE id > ? AND kind=?", marker, engine)]
    if not target or target in ("(application-wide)", ""):
        return rows

    needle = urlsplit(target).path or target
    needle = needle.replace("{id}", "").strip("/")
    if len(needle) < 3:
        return rows
    narrowed = [r for r in rows if needle in (r["url"] or "")]
    return narrowed or rows


def _invariant_became_violated(db: DB, hyp: dict, before: set[str]) -> bool:
    """
    The most reliable signal that a hypothesis was confirmed: the invariant
    it names moved from untested/holds to violated during this round.

    This is independent of URL shape, so it works for object-key targets and
    application-wide hypotheses where string matching cannot help.
    """
    key = hyp.get("invariant") or ""
    if not key:
        return False
    row = db.one("SELECT status FROM invariants WHERE key=?", key)
    return bool(row and row["status"] == "violated" and key not in before)


def _violated_now(db: DB) -> set[str]:
    from . import invariants
    try:
        return {v["key"] for v in invariants.violated(db)}
    except Exception:
        return set()


def execute(db: DB, scope: Scope, corpus: str, hyp: dict, *,
            oast=None, log=print) -> Outcome:
    """
    Run the experiment a hypothesis names, then judge it against its own
    falsifier. The judgement is deterministic: it reads experiment verdicts,
    which came from oracles, which read bytes.
    """
    engine = hyp.get("engine") or ""
    target = hyp.get("target") or ""
    hid = hyp["id"]

    gate = risk.gate_for(scope)
    if not gate.allows(engine):
        reason = gate.explain(engine)
        learn.close_hypothesis(db, hid, "blocked", reason, [])
        return Outcome(hid, hyp["statement"], engine, target, "blocked",
                       reason)

    plan = ENGINE_PLANS.get(engine)
    if not plan:
        reason = f"no executable plan for engine {engine!r}"
        learn.close_hypothesis(db, hid, "blocked", reason, [])
        return Outcome(hid, hyp["statement"], engine, target, "blocked", reason)

    marker = (db.one("SELECT COALESCE(MAX(id), 0) m FROM experiments")
              or {"m": 0})["m"]
    violated_before = _violated_now(db)
    t0 = time.monotonic()
    try:
        plan(db, scope, corpus, oast, target)
    except SystemExit as e:
        reason = f"precondition not met: {e}"
        learn.close_hypothesis(db, hid, "blocked", reason, [])
        return Outcome(hid, hyp["statement"], engine, target, "blocked", reason)
    except Exception as e:
        reason = f"{type(e).__name__}: {e}"
        learn.close_hypothesis(db, hid, "blocked", reason, [])
        return Outcome(hid, hyp["statement"], engine, target, "blocked", reason)
    elapsed = time.monotonic() - t0

    # re-evaluate invariants so the strongest confirmation signal is current
    try:
        from . import invariants as _inv
        _inv.evaluate(db, log=lambda *a: None)
    except Exception:
        pass

    produced = _experiments_since(db, marker, engine, target)
    leaks = [e for e in produced if e["verdict"] == "leak"]
    ids = [e["id"] for e in produced]

    if not leaks and _invariant_became_violated(db, hyp, violated_before):
        # the engine proved the named invariant false even though no
        # experiment matched the target string
        all_new = db.q("SELECT id FROM experiments WHERE id > ? AND kind=? "
                       "AND verdict='leak'", marker, engine)
        leaks = [{"id": r["id"], "detail": "{}"} for r in all_new]
        ids = ids or [r["id"] for r in all_new]

    if leaks:
        detail = json.loads(leaks[0]["detail"] or "{}")
        reason = (detail.get("reasons") or ["an oracle fired"])[0]
        learn.close_hypothesis(db, hid, "confirmed", reason,
                               [e["id"] for e in leaks])
        status = "confirmed"
    elif produced:
        reason = (f"{len(produced)} experiment(s) ran against this target and "
                  f"no oracle fired — {hyp.get('falsifier') or 'falsified'}")
        learn.close_hypothesis(db, hid, "disproved", reason, ids)
        status = "disproved"
    else:
        reason = ("the engine ran but produced no experiment for this target "
                  "— the precondition may not hold here")
        learn.close_hypothesis(db, hid, "disproved", reason, [])
        status = "disproved"

    return Outcome(hid, hyp["statement"], engine, target, status, reason,
                   ids, len(leaks), elapsed)


# --------------------------------------------------------------- selection

def select(db: DB, corpus: str, exclude: set[int] | None = None,
           log=print) -> tuple[dict | None, float, str]:
    """
    Choose the open hypothesis with the highest information gain.

    Gain is recomputed every call, so a discovery in the previous round
    changes the ranking of everything that follows. That re-scoring is the
    point: it is what makes this a research loop rather than a work queue.
    """
    from . import reason
    exclude = exclude or set()

    scored = reason.generate(db, corpus, log=lambda *a: None)
    by_statement = {h.statement: h for h in scored}

    best, best_gain, why = None, -1.0, ""
    for h in learn.open_hypotheses(db):
        if h["id"] in exclude:
            continue
        sc = by_statement.get(h["statement"])
        gain = sc.gain if sc else 0.25
        if sc:
            c = sc.components
            expl = (f"gain {gain:.2f} = "
                    f"{c['uncertainty']}u × {c['boundary_weight']}"
                    f"{c['family'][:4]} × {c['novelty']}n × "
                    f"{c['coverage_deficit']}d / "
                    f"{c['cost']}c × {c['risk_penalty']}r")
        else:
            expl = f"gain {gain:.2f} (no current scoring — seeded hypothesis)"
        if gain > best_gain:
            best, best_gain, why = h, gain, expl
    return best, best_gain, why


def replan(db: DB, corpus: str, log=print) -> int:
    """
    Rebuild the hypothesis space after a discovery.

    Graph → invariants → hypotheses, in that order, because each layer reads
    the one below it. Hypotheses already open or already closed are not
    duplicated, so this converges rather than growing without bound.
    """
    from . import reason
    graph.build(db, corpus, log=lambda *a: None)
    invariants.evaluate(db, log=lambda *a: None)
    fresh = reason.generate(db, corpus, log=lambda *a: None)
    added = reason.persist(db, fresh, log=lambda *a: None)
    if added:
        log(f"[replan] {added} new hypothesis/hypotheses from what was just "
            f"learned")
    return added


def ledger(db: DB) -> str:
    learn.ensure(db)
    rows = db.q("SELECT status, COUNT(*) c FROM hypotheses GROUP BY status")
    counts = {r["status"]: r["c"] for r in rows}
    out = [f"hypotheses: {json.dumps(counts)}", ""]
    for r in db.q("SELECT * FROM hypotheses ORDER BY "
                  "CASE status WHEN 'confirmed' THEN 0 WHEN 'open' THEN 1 "
                  "WHEN 'blocked' THEN 2 ELSE 3 END, id LIMIT 40"):
        mark = {"confirmed": "✓", "disproved": "✗", "open": "·",
                "blocked": "!"}.get(r["status"], "?")
        out.append(f"  {mark} [{r['id']:3}] {r['engine']:14} "
                   f"{r['statement'][:66]}")
        if r["status"] in ("disproved", "blocked") and r["outcome"]:
            out.append(f"          {r['outcome'][:100]}")
    out += ["", "Disproved hypotheses are kept: they stop the planner "
                "re-proposing what has already been ruled out."]
    return "\n".join(out)
