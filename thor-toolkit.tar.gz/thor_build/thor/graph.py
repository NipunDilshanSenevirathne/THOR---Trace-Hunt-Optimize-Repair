"""
Security knowledge graph.

The review's central criticism was right: the earlier system thinks in
requests, endpoints and engines. It should think in applications, identities,
objects, tenants and workflows, with the engines demoted to sensors feeding
that model.

This is the model. It is a property graph stored in SQLite -- not Neo4j,
because the workload is tens of thousands of nodes on a laptop and adding a
second datastore buys nothing but operational drag. Recursive CTEs handle
traversal fine at this scale.

The graph is what makes the difference between:

    "parameter named id looks interesting"

and:

    "invoice 5001 belongs to tenant Acme; Alice belongs to Acme; Bob belongs
     to Globex; the endpoint accepts arbitrary invoice ids and derives the
     tenant from a client-supplied header"

The second is a hypothesis with a predicted outcome. The first is a guess.
"""

from __future__ import annotations

import json
import re
from collections import defaultdict
from urllib.parse import urlsplit

from .db import DB

SCHEMA = """
CREATE TABLE IF NOT EXISTS nodes (
  id INTEGER PRIMARY KEY,
  kind TEXT NOT NULL,        -- Tenant|Identity|Role|Object|Endpoint|Asset|
                             -- Workflow|State|Parameter|Capability|Source
  key TEXT NOT NULL,         -- stable natural key within kind
  label TEXT,
  props TEXT,                -- json
  confidence REAL DEFAULT 1.0,
  first_seen TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(kind, key)
);

CREATE TABLE IF NOT EXISTS edges (
  id INTEGER PRIMARY KEY,
  src INTEGER NOT NULL REFERENCES nodes(id),
  rel TEXT NOT NULL,         -- owns|belongs_to|has_role|accesses|exposes|
                             -- accepts|transitions_to|implemented_by|scopes
  dst INTEGER NOT NULL REFERENCES nodes(id),
  props TEXT,
  confidence REAL DEFAULT 1.0,
  evidence TEXT,             -- json list of request/experiment ids
  UNIQUE(src, rel, dst)
);

CREATE INDEX IF NOT EXISTS idx_nodes_kind ON nodes(kind);
CREATE INDEX IF NOT EXISTS idx_edges_rel ON edges(rel);
CREATE INDEX IF NOT EXISTS idx_edges_src ON edges(src);
CREATE INDEX IF NOT EXISTS idx_edges_dst ON edges(dst);
"""

_ID_IN_PATH = re.compile(
    r"/(\d{1,19}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
    r"|[0-9a-fA-F]{24})(?=/|$)", re.I)

_OBJECT_NOUN = re.compile(
    r"(?i)/(invoices?|orders?|users?|accounts?|customers?|projects?|files?|"
    r"documents?|reports?|statements?|payments?|subscriptions?|tickets?|"
    r"messages?|teams?|workspaces?|organisations?|organizations?|companies|"
    r"cards?|transactions?|bookings?|records?|items?|posts?|comments?)/")


# Keys whose value names an object, and keys whose value names its type.
_OBJ_ID_KEY = re.compile(
    r"(?i)^(id|_id|uuid|guid|ref|key|slug|code|pk|"
    r"(\w+?)_?(id|uuid|guid|ref|key|pk))$")
_OBJ_TYPE_KEY = re.compile(r"(?i)^(type|kind|__typename|resource_?type|"
                           r"object_?type|entity)$")
_ID_VALUE = re.compile(
    r"^(?:\d{1,19}"
    r"|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
    r"|[0-9a-fA-F]{24}|[0-9a-fA-F]{32}|[A-Za-z0-9_-]{12,64})$")


def _objects_from_body(body: str, url: str,
                       confidence: float = 0.85) -> list[tuple[str, str, float]]:
    """
    Learn objects from a JSON document rather than from the URL.

    Real applications name objects in places a path regex never sees:

        {"resource": {"ref": "a8f92..."}}
        {"relationships":[{"type":"invoice","id":"..."}]}
        {"data":{"workspace":{"id":"..."}}}          (GraphQL)

    The type comes from a sibling `type`/`__typename` key when present, and
    otherwise from the containing key -- `{"invoice": {"id": 5}}` yields
    `invoice:5`.
    """
    body = (body or "").strip()
    if not body.startswith(("{", "[")) or len(body) > 400_000:
        return []
    try:
        data = json.loads(body)
    except Exception:
        return []

    out: list[tuple[str, str, float]] = []

    def walk(node, container: str = "", depth: int = 0):
        if depth > 8 or len(out) > 200:
            return
        if isinstance(node, list):
            for v in node[:50]:
                walk(v, container, depth + 1)
            return
        if not isinstance(node, dict):
            return

        # an explicit type sibling is the most reliable signal
        otype = ""
        for k, v in node.items():
            if _OBJ_TYPE_KEY.match(k) and isinstance(v, str) and len(v) < 40:
                otype = v.lower().rstrip("s")
                break
        oid = ""
        for k, v in node.items():
            if not isinstance(v, (str, int)) or isinstance(v, bool):
                continue
            sv = str(v)
            m = _OBJ_ID_KEY.match(k)
            if m and _ID_VALUE.match(sv):
                oid = sv
                if not otype and m.group(2):
                    otype = m.group(2).lower().rstrip("s")
                break
        if oid:
            t = (otype or container or "object").lower().rstrip("s")
            t = re.sub(r"[^a-z0-9_]", "", t) or "object"
            out.append((t, oid, confidence))

        for k, v in node.items():
            if isinstance(v, (dict, list)):
                walk(v, k if not _OBJ_TYPE_KEY.match(k) else container,
                     depth + 1)

    walk(data)
    return out


def ensure(db: DB) -> None:
    db.conn.executescript(SCHEMA)
    db.conn.commit()


# ------------------------------------------------------------- primitives

def node(db: DB, kind: str, key: str, label: str = "",
         props: dict | None = None, confidence: float = 1.0) -> int:
    ensure(db)
    row = db.one("SELECT id, props FROM nodes WHERE kind=? AND key=?", kind, key)
    if row:
        if props:
            merged = {}
            try:
                merged = json.loads(row["props"] or "{}")
            except Exception:
                pass
            merged.update(props)
            db.ex("UPDATE nodes SET props=?, label=COALESCE(NULLIF(?,''),label) "
                  "WHERE id=?", json.dumps(merged), label, row["id"])
        return row["id"]
    return db.ex("INSERT INTO nodes (kind, key, label, props, confidence) "
                 "VALUES (?,?,?,?,?)",
                 kind, key, label or key, json.dumps(props or {}), confidence)


def edge(db: DB, src: int, rel: str, dst: int, props: dict | None = None,
         confidence: float = 1.0, evidence: list | None = None) -> int:
    ensure(db)
    row = db.one("SELECT id, evidence FROM edges WHERE src=? AND rel=? AND dst=?",
                 src, rel, dst)
    if row:
        if evidence:
            have = set()
            try:
                have = set(json.loads(row["evidence"] or "[]"))
            except Exception:
                pass
            have |= set(evidence)
            db.ex("UPDATE edges SET evidence=? WHERE id=?",
                  json.dumps(sorted(have)), row["id"])
        return row["id"]
    return db.ex("INSERT INTO edges (src, rel, dst, props, confidence, evidence) "
                 "VALUES (?,?,?,?,?,?)",
                 src, rel, dst, json.dumps(props or {}), confidence,
                 json.dumps(evidence or []))


def neighbours(db: DB, node_id: int, rel: str | None = None,
               direction: str = "out") -> list[dict]:
    ensure(db)
    if direction == "out":
        sql = ("SELECT n.*, e.rel, e.evidence FROM edges e "
               "JOIN nodes n ON n.id = e.dst WHERE e.src=?")
    else:
        sql = ("SELECT n.*, e.rel, e.evidence FROM edges e "
               "JOIN nodes n ON n.id = e.src WHERE e.dst=?")
    args = [node_id]
    if rel:
        sql += " AND e.rel=?"
        args.append(rel)
    return [dict(r) for r in db.q(sql, *args)]


def find(db: DB, kind: str, key: str | None = None) -> list[dict]:
    ensure(db)
    if key:
        return [dict(r) for r in db.q(
            "SELECT * FROM nodes WHERE kind=? AND key=?", kind, key)]
    return [dict(r) for r in db.q("SELECT * FROM nodes WHERE kind=?", kind)]


# ------------------------------------------------------------ construction

def build(db: DB, corpus: str, log=print) -> dict:
    """
    Construct the graph from everything already observed: identities, the
    request corpus, the inferred schema, and the workflow inference.

    Every edge carries the request ids that justify it, so any claim the graph
    supports can be traced back to observed traffic.
    """
    ensure(db)
    from . import schema as schema_mod
    from .workflow import infer as wf_infer

    stats = defaultdict(int)

    # --- identities, roles, tenants --------------------------------------
    for r in db.q("SELECT * FROM identities"):
        nid = node(db, "Identity", r["name"], r["name"],
                   {"role": r["role"], "tenant": r["tenant"]})
        stats["Identity"] += 1
        if r["role"]:
            rid = node(db, "Role", r["role"])
            edge(db, nid, "has_role", rid)
            stats["Role"] += 1
        if r["tenant"]:
            tid = node(db, "Tenant", r["tenant"])
            edge(db, nid, "belongs_to", tid)
            stats["Tenant"] += 1

    # --- assets and endpoints ---------------------------------------------
    for a in db.q("SELECT * FROM assets WHERE status IS NOT NULL"):
        node(db, "Asset", a["host"], a["host"],
             {"status": a["status"], "server": a["server"],
              "tech": a["tech"], "score": a["anomaly_score"]})
        stats["Asset"] += 1

    schemas = schema_mod.infer(db, corpus)
    for key, s in schemas.items():
        p = urlsplit(s.route)
        eid = node(db, "Endpoint", key, key,
                   {"method": s.method, "route": s.route,
                    "host": p.netloc, "statuses": dict(s.resp_statuses),
                    "observations": len(s.request_ids)})
        stats["Endpoint"] += 1
        if p.netloc:
            aid = node(db, "Asset", p.netloc.split(":")[0])
            edge(db, aid, "exposes", eid)
        for f in s.fields.values():
            pid = node(db, "Parameter", f"{key}|{f.loc}:{f.name}",
                       f"{f.loc}:{f.name}",
                       {"type": f.primary_type, "format": f.primary_format,
                        "roles": sorted(f.roles), "enum": f.enum,
                        "seen": f.seen})
            edge(db, eid, "accepts", pid)
            stats["Parameter"] += 1

    # --- objects, and who owns them ---------------------------------------
    # Objects are learned from three places, not just URL nouns. Real
    # applications name objects in bodies (`{"resource":{"ref":"a8f9…"}}`),
    # in GraphQL variables, and in relationship arrays -- none of which a
    # path regex sees.
    for r in db.q("SELECT * FROM requests WHERE corpus=?", corpus):
        found: list[tuple[str, str, float]] = []   # (type, id, confidence)

        m = _ID_IN_PATH.search(urlsplit(r["url"]).path or "")
        if m:
            noun_m = _OBJECT_NOUN.search(urlsplit(r["url"]).path or "")
            otype = (noun_m.group(1).rstrip("s") if noun_m else "object").lower()
            found.append((otype, m.group(1), 1.0))

        found += _objects_from_body(r["body"] or "", r["url"])
        found += _objects_from_body(r["resp_body"] or "", r["url"],
                                    confidence=0.7)

        if not found:
            continue

        seen_here = set()
        for otype, oid, conf in found:
            okey = f"{otype}:{oid}"
            if okey in seen_here:
                continue
            seen_here.add(okey)
            node_id = node(db, "Object", okey, okey,
                           {"type": otype, "id": oid,
                            "representations": [r["url"].split("?")[0][:120]]},
                           confidence=conf)

            if r["status"] in (200, 201, 206) and r["identity"]:
                iid = node(db, "Identity", r["identity"])
                edge(db, iid, "accesses", node_id, evidence=[r["id"]],
                     confidence=conf)
                ident = db.one("SELECT tenant FROM identities WHERE name=?",
                               r["identity"])
                if ident and ident["tenant"]:
                    tid = node(db, "Tenant", ident["tenant"])
                    edge(db, node_id, "scoped_to", tid,
                         confidence=min(0.6, conf), evidence=[r["id"]])
            stats["Object"] += 1

            route = f"{r['method']} {_ID_IN_PATH.sub('/{id}', r['url'])}"
            row = db.one("SELECT id FROM nodes WHERE kind='Endpoint' "
                         "AND key LIKE ?",
                         f"%{urlsplit(route).path or route}%")
            if row:
                edge(db, row["id"], "accesses", node_id, evidence=[r["id"]])

    # --- workflows and states ---------------------------------------------
    for wf in wf_infer(db, corpus, log=lambda *a: None):
        if not wf.states:
            continue
        wid = node(db, "Workflow", f"wf:{wf.object_id}",
                   f"workflow for object {wf.object_id}",
                   {"states": wf.states, "steps": len(wf.steps)})
        stats["Workflow"] += 1
        prev = None
        for stt in wf.states:
            sid = node(db, "State", f"state:{stt}", stt)
            edge(db, wid, "has_state", sid)
            if prev is not None:
                edge(db, prev, "transitions_to", sid)
            prev = sid
            stats["State"] += 1

    db.conn.commit()
    n = (db.one("SELECT COUNT(*) c FROM nodes") or {"c": 0})["c"]
    e = (db.one("SELECT COUNT(*) c FROM edges") or {"c": 0})["c"]
    log(f"[graph] {n} nodes, {e} edges  ({dict(stats)})")
    return {"nodes": n, "edges": e, **dict(stats)}


# ------------------------------------------------------------- queries

def model_summary(db: DB) -> dict:
    ensure(db)
    counts = {r["kind"]: r["c"] for r in db.q(
        "SELECT kind, COUNT(*) c FROM nodes GROUP BY kind")}
    obj_endpoints = (db.one(
        "SELECT COUNT(DISTINCT src) c FROM edges e "
        "JOIN nodes n ON n.id=e.src WHERE n.kind='Endpoint' AND e.rel='accesses'")
        or {"c": 0})["c"]
    tenant_params = (db.one(
        "SELECT COUNT(*) c FROM nodes WHERE kind='Parameter' "
        "AND props LIKE '%identity%'") or {"c": 0})["c"]
    return {
        "identities": counts.get("Identity", 0),
        "roles": counts.get("Role", 0),
        "tenants": counts.get("Tenant", 0),
        "assets": counts.get("Asset", 0),
        "endpoints": counts.get("Endpoint", 0),
        "object_bearing_endpoints": obj_endpoints,
        "objects": counts.get("Object", 0),
        "parameters": counts.get("Parameter", 0),
        "tenant_scoped_parameters": tenant_params,
        "workflows": counts.get("Workflow", 0),
        "states": counts.get("State", 0),
    }


def cross_tenant_pairs(db: DB) -> list[dict]:
    """
    Objects scoped to one tenant, and identities in a different tenant.
    Each pair is a concrete authorisation experiment the graph can name.
    """
    ensure(db)
    rows = db.q("""
        SELECT o.key AS object_key, t.key AS object_tenant,
               i.key AS identity, t2.key AS identity_tenant
        FROM nodes o
        JOIN edges e1 ON e1.src = o.id AND e1.rel = 'scoped_to'
        JOIN nodes t  ON t.id = e1.dst AND t.kind = 'Tenant'
        JOIN edges e2 ON e2.src != o.id AND e2.rel = 'belongs_to'
        JOIN nodes i  ON i.id = e2.src AND i.kind = 'Identity'
        JOIN nodes t2 ON t2.id = e2.dst AND t2.kind = 'Tenant'
        WHERE o.kind = 'Object' AND t.key != t2.key
    """)
    return [dict(r) for r in rows]


def endpoints_with_object_refs(db: DB) -> list[dict]:
    ensure(db)
    return [dict(r) for r in db.q("""
        SELECT DISTINCT n.key, n.props FROM nodes n
        JOIN edges e ON e.src = n.id
        WHERE n.kind = 'Endpoint' AND e.rel = 'accesses'
    """)]


def render(db: DB, root_kind: str = "Tenant", limit: int = 4) -> str:
    """A readable slice of the graph, for the operator and for AI briefs."""
    ensure(db)
    out = []
    for t in find(db, root_kind)[:limit]:
        out.append(f"{root_kind}: {t['label']}")
        for i in neighbours(db, t["id"], "belongs_to", direction="in"):
            out.append(f"   ├── Identity: {i['label']}")
            for r in neighbours(db, i["id"], "has_role"):
                out.append(f"   │      └── Role: {r['label']}")
            accessed = neighbours(db, i["id"], "accesses")[:4]
            for o in accessed:
                out.append(f"   │      └── accesses {o['label']}")
        objs = neighbours(db, t["id"], "scoped_to", direction="in")[:6]
        for o in objs:
            out.append(f"   └── Object: {o['label']}")
            for ep in neighbours(db, o["id"], "accesses", direction="in")[:3]:
                out.append(f"          └── via {ep['label']}")
        out.append("")
    return "\n".join(out) or "(graph is empty — run `thor graph` after capture)"
