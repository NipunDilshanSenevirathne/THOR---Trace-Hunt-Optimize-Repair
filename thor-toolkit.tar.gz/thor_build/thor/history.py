"""
Attack-surface memory: snapshots and diffs.

This is the highest-value addition for bug bounty specifically, and it is
absent from generic scanners because it only pays off across time.

A subdomain that appeared last week has been looked at by fewer people than
one that has been there for three years. An endpoint that gained a parameter
since your last run is code that just changed -- which is where bugs are.
A route that *lost* an authentication requirement is a finding on its own.

Everything here is deterministic and costs no tokens.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field

from .db import DB
from . import runtime

SCHEMA = """
CREATE TABLE IF NOT EXISTS snapshots (
  id INTEGER PRIMARY KEY,
  label TEXT,
  taken_at TEXT DEFAULT CURRENT_TIMESTAMP,
  asset_count INTEGER,
  endpoint_count INTEGER,
  payload TEXT           -- json blob of the surface
);
CREATE INDEX IF NOT EXISTS idx_snap_time ON snapshots(taken_at DESC);
"""


def ensure(db: DB) -> None:
    db.conn.executescript(SCHEMA)
    db.conn.commit()


def _surface(db: DB) -> dict:
    assets = {}
    for r in db.q("SELECT host, status, title, server, tech, cname, ip, "
                  "content_length FROM assets"):
        assets[r["host"]] = {
            "status": r["status"], "title": r["title"], "server": r["server"],
            "tech": r["tech"], "cname": r["cname"], "ip": r["ip"],
            "len": r["content_length"],
        }
    endpoints = {}
    for r in db.q("SELECT url, method, params, is_api FROM endpoints"):
        endpoints[f"{r['method']} {r['url']}"] = {
            "params": r["params"], "is_api": r["is_api"],
        }
    secrets = [r["value_sha256"] for r in db.q("SELECT value_sha256 FROM secrets")]
    # auth posture per route, from the corpus
    auth = {}
    for r in db.q("SELECT url, method, status FROM requests"):
        auth[f"{r['method']} {r['url']}"] = r["status"]
    return {"assets": assets, "endpoints": endpoints,
            "secrets": sorted(secrets), "auth": auth}


def take(db: DB, label: str = "", log=print) -> int:
    ensure(db)
    s = _surface(db)
    sid = db.ex(
        "INSERT INTO snapshots (label, asset_count, endpoint_count, payload) "
        "VALUES (?,?,?,?)",
        label or runtime.utcnow().strftime("%Y-%m-%d %H:%M"),
        len(s["assets"]), len(s["endpoints"]), json.dumps(s))
    log(f"[history] snapshot {sid}: {len(s['assets'])} assets, "
        f"{len(s['endpoints'])} endpoints")
    return sid


@dataclass
class Delta:
    new_assets: list[str] = field(default_factory=list)
    gone_assets: list[str] = field(default_factory=list)
    new_endpoints: list[str] = field(default_factory=list)
    gone_endpoints: list[str] = field(default_factory=list)
    new_params: list[str] = field(default_factory=list)
    tech_changed: list[str] = field(default_factory=list)
    auth_weakened: list[str] = field(default_factory=list)
    status_changed: list[str] = field(default_factory=list)
    new_secrets: int = 0

    def is_empty(self) -> bool:
        return not any([self.new_assets, self.gone_assets, self.new_endpoints,
                        self.gone_endpoints, self.new_params, self.tech_changed,
                        self.auth_weakened, self.status_changed, self.new_secrets])

    def priority_targets(self) -> list[str]:
        """
        What deserves attention first. New surface and weakened auth beat
        everything else: new code has had the fewest eyes on it, and an
        endpoint that stopped requiring authentication is a finding already.
        """
        out = []
        out += [f"AUTH WEAKENED  {x}" for x in self.auth_weakened]
        out += [f"NEW ASSET      {x}" for x in self.new_assets]
        out += [f"NEW ENDPOINT   {x}" for x in self.new_endpoints]
        out += [f"NEW PARAM      {x}" for x in self.new_params]
        out += [f"TECH CHANGED   {x}" for x in self.tech_changed]
        return out


def _snap(db: DB, ident) -> tuple[int, dict] | None:
    if ident == "latest":
        r = db.one("SELECT id, payload FROM snapshots ORDER BY id DESC LIMIT 1")
    elif ident == "previous":
        r = db.one("SELECT id, payload FROM snapshots ORDER BY id DESC "
                   "LIMIT 1 OFFSET 1")
    else:
        r = db.one("SELECT id, payload FROM snapshots WHERE id=?", int(ident))
    return (r["id"], json.loads(r["payload"])) if r else None


def diff(db: DB, since="previous", until="latest", log=print) -> Delta:
    ensure(db)
    a = _snap(db, since)
    b = _snap(db, until)
    if not a or not b:
        log("[history] need two snapshots to diff. Run: thor snapshot")
        return Delta()
    _, old = a
    _, new = b
    d = Delta()

    d.new_assets = sorted(set(new["assets"]) - set(old["assets"]))
    d.gone_assets = sorted(set(old["assets"]) - set(new["assets"]))
    d.new_endpoints = sorted(set(new["endpoints"]) - set(old["endpoints"]))
    d.gone_endpoints = sorted(set(old["endpoints"]) - set(new["endpoints"]))

    for k, nv in new["endpoints"].items():
        ov = old["endpoints"].get(k)
        if not ov:
            continue
        try:
            np = set(json.loads(nv["params"] or "[]"))
            op = set(json.loads(ov["params"] or "[]"))
        except Exception:
            continue
        for p in sorted(np - op):
            d.new_params.append(f"{k}  +{p}")

    for h, nv in new["assets"].items():
        ov = old["assets"].get(h)
        if not ov:
            continue
        if (nv.get("tech") or "") != (ov.get("tech") or ""):
            d.tech_changed.append(f"{h}: {ov.get('tech')} -> {nv.get('tech')}")
        if nv.get("server") != ov.get("server"):
            d.tech_changed.append(
                f"{h}: server {ov.get('server')} -> {nv.get('server')}")
        if nv.get("status") != ov.get("status"):
            d.status_changed.append(
                f"{h}: {ov.get('status')} -> {nv.get('status')}")

    # the one that matters most: a route that used to deny and now allows
    for k, ns in new["auth"].items():
        os_ = old["auth"].get(k)
        if os_ in (401, 403) and ns in (200, 201, 206):
            d.auth_weakened.append(f"{k}: {os_} -> {ns}")

    d.new_secrets = len(set(new["secrets"]) - set(old["secrets"]))
    return d


def report(d: Delta) -> str:
    if d.is_empty():
        return "No change since the previous snapshot."
    lines = []
    if d.auth_weakened:
        lines.append("## Authentication weakened  ← investigate first\n")
        lines += [f"  {x}" for x in d.auth_weakened]
    if d.new_assets:
        lines.append(f"\n## New assets ({len(d.new_assets)})\n")
        lines += [f"  + {x}" for x in d.new_assets[:40]]
    if d.new_endpoints:
        lines.append(f"\n## New endpoints ({len(d.new_endpoints)})\n")
        lines += [f"  + {x}" for x in d.new_endpoints[:60]]
    if d.new_params:
        lines.append(f"\n## New parameters ({len(d.new_params)})\n")
        lines += [f"  + {x}" for x in d.new_params[:40]]
    if d.tech_changed:
        lines.append(f"\n## Technology changed ({len(d.tech_changed)})\n")
        lines += [f"  ~ {x}" for x in d.tech_changed[:30]]
    if d.status_changed:
        lines.append(f"\n## Status changed ({len(d.status_changed)})\n")
        lines += [f"  ~ {x}" for x in d.status_changed[:30]]
    if d.gone_assets:
        lines.append(f"\n## Assets gone ({len(d.gone_assets)})\n")
        lines += [f"  - {x}" for x in d.gone_assets[:20]]
    if d.new_secrets:
        lines.append(f"\n## {d.new_secrets} new secret candidate(s) in JS")
    return "\n".join(lines)


def boost_novel(db: DB, d: Delta, log=print) -> int:
    """
    Feed the delta back into the anomaly ranking. Novelty is a real signal:
    fewer researchers have looked at surface that appeared this week.
    """
    n = 0
    for host in d.new_assets:
        db.ex("UPDATE assets SET anomaly_score = anomaly_score + 4.0, "
              "anomaly_reasons = json_insert(COALESCE(anomaly_reasons,'[]'), "
              "'$[#]', '+4 newly appeared since last snapshot') WHERE host=?",
              host)
        n += 1
    for line in d.auth_weakened:
        host = line.split()[1].split("/")[2] if "//" in line else ""
        if host:
            db.ex("UPDATE assets SET anomaly_score = anomaly_score + 6.0 "
                  "WHERE host=?", host)
            n += 1
    if n:
        log(f"[history] boosted {n} asset(s) for novelty")
    return n
