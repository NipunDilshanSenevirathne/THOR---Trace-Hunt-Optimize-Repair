"""
Identity resolution.

The research database stores only non-secret headers plus an opaque
credential reference. Authentication material lives in the encrypted vault
and is joined in memory at send time, never written back.

Every engine that needs identity headers calls headers_for() rather than
reading the identities table directly.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field

from . import vault
from .db import DB


class CredentialUnavailable(Exception):
    """
    An identity has a credential reference the vault could not produce.

    This is fatal on purpose. The alternative -- carrying on with the
    non-secret headers -- turns an authenticated identity into an
    anonymous one, and every probe sent as that identity then comes back
    401 and is recorded as `denied`. The run reports a cleanly secured
    application and the operator is never told that nothing was actually
    tested. That is the worst possible failure for this tool: silent,
    confident, and in the direction of missing real bugs.
    """


@dataclass
class Identity:
    name: str
    role: str = "user"
    tenant: str = ""
    headers: dict = field(default_factory=dict)      # resolved, in memory only
    credential_ref: str = ""
    # Set when credential_ref exists but the vault could not produce it.
    # An identity in this state must never be used to send a request.
    unresolved: str = ""

    @property
    def is_anonymous(self) -> bool:
        return self.role == "anonymous" or not self.headers

    @property
    def usable(self) -> bool:
        return not self.unresolved


def add(db: DB, name: str, headers: dict, role: str = "user",
        tenant: str = "", v: vault.Vault | None = None,
        log=print) -> Identity:
    """Split credentials out to the vault; store only the reference."""
    secret, plain = vault.split_credentials(headers)
    ref = ""
    if secret:
        v = v or vault.default()
        try:
            ref = v.store(secret, label=f"identity:{name}")
        except vault.VaultUnavailable as e:
            raise SystemExit(
                f"{e}\nTHOR will not write credentials in plaintext. "
                f"Install cryptography, or add the identity without a token.")
    db.ex("INSERT OR REPLACE INTO identities "
          "(name, role, tenant, headers, credential_ref) VALUES (?,?,?,?,?)",
          name, role, tenant, json.dumps(plain), ref)
    log(f"[identity] {name}: role={role} tenant={tenant or '-'} "
        f"{len(plain)} plain header(s), "
        f"{len(secret)} credential(s) -> vault {ref or '(none)'}")
    return Identity(name, role, tenant, dict(headers), ref)


def load(db: DB, name: str, v: vault.Vault | None = None,
         allow_unresolved: bool = False) -> Identity | None:
    r = db.one("SELECT * FROM identities WHERE name=?", name)
    if not r:
        return None
    ident = _resolve(r, v)
    if ident.unresolved and not allow_unresolved:
        raise CredentialUnavailable(_message([ident]))
    return ident


def load_all(db: DB, v: vault.Vault | None = None,
             allow_unresolved: bool = False,
             audit=None) -> dict[str, Identity]:
    """
    Resolve every identity, joining credentials from the vault in memory.

    Raises `CredentialUnavailable` if any identity has a credential the
    vault could not produce. Callers that merely *display* identities pass
    `allow_unresolved=True`; anything that sends a request must not, because
    an identity silently stripped of its Authorization header is an
    anonymous request wearing a trusted name.
    """
    out = {}
    for r in db.q("SELECT * FROM identities"):
        out[r["name"]] = _resolve(r, v)
    out.setdefault("anon", Identity("anon", "anonymous", "", {}, ""))

    broken = [i for i in out.values() if i.unresolved]
    if broken:
        if audit:
            for i in broken:
                audit.event("identity.unresolved", identity=i.name,
                            credential_ref=i.credential_ref,
                            reason=i.unresolved)
        if not allow_unresolved:
            raise CredentialUnavailable(_message(broken))
    return out


def _message(broken: list[Identity]) -> str:
    names = ", ".join(sorted(i.name for i in broken))
    why = broken[0].unresolved
    return (
        f"Credentials for {names} could not be read from the vault "
        f"({why}).\n"
        f"\n"
        f"THOR is stopping rather than continuing. Without those headers "
        f"the probes would be sent unauthenticated, every one would come "
        f"back 401, and the run would record them as 'denied' — a report "
        f"that the application is well secured, when in fact nothing was "
        f"tested.\n"
        f"\n"
        f"Fix one of:\n"
        f"  export THOR_VAULT_KEY=...         the key the vault was written with\n"
        f"  export THOR_VAULT_PASSPHRASE=...  if you used a passphrase\n"
        f"  thor identity add {names.split(',')[0]} --header ...   re-add it\n"
        f"  thor vault check                  see what the vault can open")


def _resolve(row, v: vault.Vault | None) -> Identity:
    headers = {}
    try:
        headers = json.loads(row["headers"] or "{}")
    except Exception:
        pass
    ref = ""
    try:
        ref = row["credential_ref"] or ""
    except (IndexError, KeyError):
        ref = ""
    unresolved = ""
    if ref:
        try:
            headers.update((v or vault.default()).fetch(ref))
        except KeyError:
            unresolved = f"no entry {ref} in the vault"
        except vault.VaultLocked as e:
            unresolved = f"vault locked: {e}"
        except vault.VaultUnavailable as e:
            unresolved = f"vault unavailable: {e}"
        except Exception as e:                      # noqa: BLE001
            unresolved = f"{type(e).__name__}: {e}"
    return Identity(row["name"], row["role"] or "user", row["tenant"] or "",
                    headers, ref, unresolved)


def headers_for(db: DB, name: str, v: vault.Vault | None = None) -> dict:
    ident = load(db, name, v)
    return dict(ident.headers) if ident else {}


def tenants(db: DB) -> set[str]:
    return {r["tenant"] for r in db.q(
        "SELECT DISTINCT tenant FROM identities WHERE tenant != ''")
        if r["tenant"]}
