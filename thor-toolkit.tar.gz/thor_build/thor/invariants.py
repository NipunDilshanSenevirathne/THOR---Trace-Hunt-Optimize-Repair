"""
Security invariants as first-class objects.

This is the abstraction the review argued for, and it is the right one. The
question THOR asks stops being

    "does this endpoint have a vulnerability?"

and becomes

    "which of this application's security invariants does it violate?"

An invariant is a rule that should hold, expressed over graph entities, with
a stated way to test it and a stated way to disprove the violation. A
violation is a finding; a passing test is evidence the control exists, which
is useful in its own right because it tells the scheduler where not to look.

Every invariant here is checked by executing requests and comparing observed
bytes. None is judged by a model.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field

from .db import DB

SCHEMA = """
CREATE TABLE IF NOT EXISTS invariants (
  id INTEGER PRIMARY KEY,
  key TEXT UNIQUE,
  family TEXT,
  subject TEXT,
  rule TEXT,
  description TEXT,
  severity TEXT,
  status TEXT DEFAULT 'untested',   -- untested|holds|violated|untestable
  evidence TEXT,
  tested_at TEXT,
  detail TEXT
);
CREATE INDEX IF NOT EXISTS idx_inv_status ON invariants(status);
"""


def ensure(db: DB) -> None:
    db.conn.executescript(SCHEMA)
    db.conn.commit()


@dataclass
class Invariant:
    key: str
    family: str            # authorization | tenancy | workflow | token | quota
    subject: str           # what the rule is about
    rule: str              # the rule, in a form a human can check
    description: str
    severity: str = "high"
    engine: str = ""       # which engine tests it
    requires: list[str] = field(default_factory=list)   # preconditions

    def to_row(self) -> tuple:
        return (self.key, self.family, self.subject, self.rule,
                self.description, self.severity)


# ---------------------------------------------------------------------------
# The catalogue. Each entry states a rule the application is presumed to
# enforce, and names the engine whose oracle can falsify it.
# ---------------------------------------------------------------------------

CATALOGUE: list[Invariant] = [
    Invariant(
        key="authz.object_ownership",
        family="authorization", subject="object",
        rule="caller.identity == object.owner OR caller has an explicit grant",
        description=(
            "An identity may read an object only if it owns the object or was "
            "granted access. Violated when a second identity receives the "
            "owner's resource."),
        severity="high", engine="authz",
        requires=["two identities", "an object-bearing endpoint"]),

    Invariant(
        key="tenancy.isolation",
        family="tenancy", subject="object",
        rule="caller.tenant == object.tenant",
        description=(
            "An identity may reach only objects belonging to its own tenant. "
            "This is a customer boundary, not a user boundary, so violations "
            "are materially more severe than ordinary IDOR."),
        severity="critical", engine="tenant",
        requires=["identities in two tenants"]),

    Invariant(
        key="tenancy.server_derived",
        family="tenancy", subject="request",
        rule="effective_tenant derives from the session, never from a "
             "client-supplied header or parameter",
        description=(
            "Where a request carries a tenant hint (X-Org-Id and relatives), "
            "the server must ignore it in favour of the tenant bound to the "
            "session. Violated when changing the hint changes the data."),
        severity="critical", engine="tenant",
        requires=["a tenant-shaped parameter or header"]),

    Invariant(
        key="authz.function_level",
        family="authorization", subject="operation",
        rule="caller.role grants the operation being invoked",
        description=(
            "A low-privilege identity must not invoke an operation reserved "
            "for a higher role, including by swapping the HTTP method."),
        severity="high", engine="bfla",
        requires=["identities with different roles"]),

    Invariant(
        key="authz.attribute_whitelist",
        family="authorization", subject="object",
        rule="only whitelisted attributes are writable by the client",
        description=(
            "Privileged attributes (role, is_admin, balance, tenant) must not "
            "be settable by including them in a request body."),
        severity="high", engine="massassign",
        requires=["a JSON write endpoint"]),

    Invariant(
        key="authz.field_level",
        family="authorization", subject="field",
        rule="each returned field is authorised independently of the query",
        description=(
            "In GraphQL and sparse-fieldset APIs, reaching an object must not "
            "imply access to every field on it."),
        severity="high", engine="graphql",
        requires=["a GraphQL endpoint"]),

    Invariant(
        key="workflow.monotonic_state",
        family="workflow", subject="object",
        rule="state transitions follow the declared machine; terminal states "
             "are not reversible",
        description=(
            "An object must not move to a state the workflow does not permit "
            "from its current state, and must not leave a terminal state."),
        severity="high", engine="workflow",
        requires=["an object with observed states"]),

    Invariant(
        key="workflow.server_computed_state",
        family="workflow", subject="object",
        rule="state is computed server-side, never accepted from the client",
        description=(
            "Asserting a state value in a request body must not become the "
            "stored state."),
        severity="high", engine="workflow",
        requires=["a write endpoint carrying a state field"]),

    Invariant(
        key="workflow.single_use",
        family="workflow", subject="operation",
        rule="a single-use operation succeeds at most once per object",
        description=(
            "Redemption, claiming, approval and confirmation operations must "
            "be idempotent or refuse the second attempt."),
        severity="high", engine="workflow",
        requires=["a redeem/claim/approve style endpoint"]),

    Invariant(
        key="logic.value_bounds",
        family="logic", subject="value",
        rule="monetary and quantity values respect their domain bounds "
             "server-side",
        description=(
            "Prices, quantities, balances and discounts must be validated on "
            "the server. A negative computed total is a violation."),
        severity="high", engine="fuzz",
        requires=["a money-tagged field"]),

    Invariant(
        key="token.oauth_redirect_binding",
        family="token", subject="oauth",
        rule="redirect_uri is matched exactly against the registered value",
        description=(
            "RFC 9700 requires exact string matching except for localhost "
            "ports in native apps. Any accepted variant is a violation."),
        severity="high", engine="oauth",
        requires=["an OAuth authorize request"]),

    Invariant(
        key="token.oauth_code_single_use",
        family="token", subject="oauth",
        rule="an authorization code is redeemable exactly once",
        description="RFC 9700: codes MUST be single-use.",
        severity="high", engine="oauth",
        requires=["an authorization code and token endpoint"]),

    Invariant(
        key="token.pkce_not_downgradable",
        family="token", subject="oauth",
        rule="a client that uses PKCE cannot have it stripped",
        description=(
            "Accepting an authorization request without code_challenge from a "
            "client that normally sends one enables code replay."),
        severity="high", engine="oauth",
        requires=["an OAuth flow using PKCE"]),

    Invariant(
        key="token.signature_verified",
        family="token", subject="jwt",
        rule="token signatures are verified with the expected algorithm",
        description=(
            "alg:none, algorithm confusion, and unverified claim tampering "
            "must all be rejected."),
        severity="critical", engine="jwt",
        requires=["a JWT in the corpus"]),

    Invariant(
        key="acl.path_normalisation",
        family="authorization", subject="route",
        rule="the gateway ACL and the application router agree on the path",
        description=(
            "A protected route must stay protected under every encoding, "
            "traversal and header-override variant of its path."),
        severity="high", engine="pathacl",
        requires=["a route that returned 401/403"]),

    Invariant(
        key="origin.credentialed_cors",
        family="authorization", subject="origin",
        rule="credentialed responses are served only to allow-listed origins",
        description=(
            "Reflecting an arbitrary Origin with Allow-Credentials lets an "
            "attacker page read authenticated responses."),
        severity="medium", engine="cors",
        requires=["an authenticated endpoint"]),

    Invariant(
        key="cache.key_completeness",
        family="cache", subject="response",
        rule="every input that changes a response is part of the cache key",
        description=(
            "An unkeyed header that alters a cacheable response can poison "
            "entries served to other users."),
        severity="medium", engine="cache",
        requires=["a cacheable GET endpoint"]),

    Invariant(
        key="input.query_separation",
        family="injection", subject="parameter",
        rule="client input never becomes query, template or command syntax",
        description=(
            "Input must be bound as data. Violated when a parse error, a "
            "boolean condition, or a computed template result is observable."),
        severity="critical", engine="fuzz",
        requires=["a string parameter"]),

    Invariant(
        key="input.path_canonicalisation",
        family="injection", subject="parameter",
        rule="file paths derived from input stay within their root",
        description="Traversal sequences must not escape the intended directory.",
        severity="high", engine="fuzz",
        requires=["a file- or path-tagged field"]),

    Invariant(
        key="egress.no_ssrf",
        family="egress", subject="request",
        rule="server-side fetches target only allow-listed destinations",
        description=(
            "A URL-tagged parameter must not cause the server to reach "
            "attacker-chosen or internal destinations."),
        severity="high", engine="fuzz",
        requires=["a url-tagged field"]),

    Invariant(
        key="prototype.integrity",
        family="integrity", subject="runtime",
        rule="request data cannot modify object prototypes",
        description=(
            "Pollution via __proto__ or constructor.prototype affects every "
            "subsequent request in the process."),
        severity="high", engine="protopollution",
        requires=["a JSON write endpoint"]),

    Invariant(
        key="navigation.trusted_redirect",
        family="navigation", subject="parameter",
        rule="redirect targets are restricted to the application's own origins",
        description=(
            "Low severity alone; the first link in OAuth token-theft chains."),
        severity="low", engine="redirect",
        requires=["a redirect-shaped parameter"]),

    # ── v5.1 additions ────────────────────────────────────────────────
    #
    # Every one of these names an engine that already exists and can
    # actually falsify it. The temptation with an invariant catalogue is
    # to write down everything that could ever be true of an application:
    # a hundred rules with no falsifier make `thor invariants` a list of
    # things nobody tested, which is worse than a short list of things
    # somebody did.

    Invariant(
        key="authz.write_authorisation",
        family="authorization", subject="object",
        rule="an identity may modify an object only if it may modify it",
        description=(
            "Read access and write access are separate grants. An API that "
            "checks ownership on GET and not on PUT is common, because the "
            "read path was written first and the write path copied the "
            "route but not the guard."),
        severity="critical", engine="bfla",
        requires=["two identities", "a write method on an object route"]),

    Invariant(
        key="authz.delete_authorisation",
        family="authorization", subject="object",
        rule="an identity may delete an object only if it owns it",
        description=(
            "Deletion is the least reversible operation and often the least "
            "guarded, because it is added last."),
        severity="critical", engine="bfla",
        requires=["two identities", "destructive testing permitted"]),

    Invariant(
        key="authz.bulk_export",
        family="authorization", subject="collection",
        rule=("a collection endpoint returns only the rows the caller may "
              "see, not a filtered view of all of them"),
        description=(
            "Export and report endpoints frequently authorise the ROUTE and "
            "then select without a tenant predicate. The pagination hides "
            "it: page one looks right."),
        severity="critical", engine="authz",
        requires=["two identities", "a collection or export route"]),

    Invariant(
        key="identity.not_client_switchable",
        family="identity", subject="identity",
        rule=("the acting identity derives from the session, never from a "
              "client-supplied header, parameter or body field"),
        description=(
            "An X-User-Id or on-behalf-of header that the server trusts is "
            "authentication by assertion. Distinct from tenancy: this is "
            "the caller's own identity being chosen by the caller."),
        severity="critical", engine="tenant",
        requires=["two identities", "an identity-shaped request field"]),

    Invariant(
        key="workflow.single_use_under_concurrency",
        family="workflow", subject="operation",
        rule=("an operation the server treats as single-use stays single-use "
              "when requested concurrently"),
        description=(
            "Falsified only by a contradiction: the server rejects a "
            "sequential repeat but accepts several concurrent copies. Two "
            "concurrent successes on an idempotent endpoint prove nothing, "
            "which is why the control runs after the burst."),
        severity="high", engine="race",
        requires=["destructive testing permitted", "a single-use operation"]),

    Invariant(
        key="workflow.terminal_state_immutable",
        family="workflow", subject="state",
        rule=("an object in a terminal state cannot be moved out of it by a "
              "client request"),
        description=(
            "Cancelled orders that can be un-cancelled, refunded payments "
            "that can be re-refunded. The state machine exists in the UI "
            "and not in the API."),
        severity="high", engine="workflow",
        requires=["an observed state transition"]),

    Invariant(
        key="token.algorithm_and_signature",
        family="token", subject="token",
        rule=("a token is accepted only with the expected algorithm and a "
              "valid signature"),
        description=(
            "alg=none and HS256-signed-with-the-public-key remain live "
            "because the verification library was configured once and never "
            "revisited."),
        severity="critical", engine="jwt",
        requires=["a JWT-shaped credential"]),

    Invariant(
        key="token.audience_and_issuer",
        family="token", subject="token",
        rule="a token is accepted only for its intended audience and issuer",
        description=(
            "A valid token from a sibling service, or from the same identity "
            "provider for a different application, should not authenticate "
            "here."),
        severity="high", engine="jwt",
        requires=["a JWT-shaped credential"]),

    Invariant(
        key="upload.stored_file_is_not_executable",
        family="input", subject="file",
        rule=("an uploaded file cannot be retrieved as executable or active "
              "content"),
        description=(
            "The finding is not that an upload was accepted; it is that the "
            "stored object is served back with a content type that executes."),
        severity="critical", engine="upload",
        requires=["an upload endpoint", "sensitive testing permitted"]),

    Invariant(
        key="upload.path_not_client_controlled",
        family="input", subject="file",
        rule="the client cannot choose where an uploaded file is written",
        description=(
            "A filename containing traversal that lands outside the upload "
            "directory."),
        severity="critical", engine="upload",
        requires=["an upload endpoint", "sensitive testing permitted"]),

    Invariant(
        key="logic.quantity_bounds",
        family="quota", subject="parameter",
        rule=("quantities are validated server-side: non-negative, within "
              "stock, and within any per-account limit"),
        description=(
            "Client-side validation with no server counterpart. Falsified by "
            "an invariant oracle on the response, not by the request being "
            "accepted."),
        severity="high", engine="fuzz",
        requires=["a quantity-shaped field"]),

    Invariant(
        key="logic.value_conservation",
        family="quota", subject="computation",
        rule=("a server-computed total equals the sum of its parts and "
              "cannot be supplied by the client"),
        description=(
            "Falsified when a client-supplied total is honoured, or when the "
            "returned total does not match the items it claims to cover."),
        severity="high", engine="fuzz",
        requires=["a money- or total-shaped field"]),
]

BY_KEY = {i.key: i for i in CATALOGUE}
BY_ENGINE: dict[str, list[Invariant]] = {}
for _i in CATALOGUE:
    BY_ENGINE.setdefault(_i.engine, []).append(_i)


# ---------------------------------------------------------------- lifecycle

def install(db: DB, log=print) -> int:
    ensure(db)
    n = 0
    for inv in CATALOGUE:
        if db.one("SELECT 1 FROM invariants WHERE key=?", inv.key):
            continue
        db.ex("INSERT INTO invariants (key, family, subject, rule, "
              "description, severity) VALUES (?,?,?,?,?,?)", *inv.to_row())
        n += 1
    log(f"[invariants] catalogue: {len(CATALOGUE)} rules ({n} newly installed)")
    return n


# Which experiment kinds count as evidence for which invariant.
_ENGINE_TO_INVARIANT = {
    "authz": ["authz.object_ownership"],
    "tenant": ["tenancy.isolation", "tenancy.server_derived"],
    "bfla": ["authz.function_level"],
    "massassign": ["authz.attribute_whitelist"],
    "graphql": ["authz.field_level"],
    "workflow": ["workflow.monotonic_state", "workflow.server_computed_state",
                 "workflow.single_use"],
    "oauth": ["token.oauth_redirect_binding", "token.oauth_code_single_use",
              "token.pkce_not_downgradable"],
    "jwt": ["token.signature_verified"],
    "pathacl": ["acl.path_normalisation"],
    "cors": ["origin.credentialed_cors"],
    "cache": ["cache.key_completeness"],
    "protopollution": ["prototype.integrity"],
    "redirect": ["navigation.trusted_redirect"],
    "sqli": ["input.query_separation"],
    "nosql": ["input.query_separation"],
    "ssti": ["input.query_separation"],
    "cmdi": ["input.query_separation"],
    "path": ["input.path_canonicalisation"],
    "ssrf": ["egress.no_ssrf"],
    "logic": ["logic.value_bounds", "logic.quantity_bounds",
              "logic.value_conservation"],
    "race": ["workflow.single_use_under_concurrency"],
    "upload": ["upload.stored_file_is_not_executable",
               "upload.path_not_client_controlled"],
    "type": ["logic.quantity_bounds"],
}

# Invariants falsified by an engine that also falsifies others: the engine
# key above maps to a list, so these extend rather than replace.
_ENGINE_TO_INVARIANT["authz"] += ["authz.bulk_export"]
_ENGINE_TO_INVARIANT["bfla"] += ["authz.write_authorisation",
                                 "authz.delete_authorisation"]
_ENGINE_TO_INVARIANT["tenant"] += ["identity.not_client_switchable"]
_ENGINE_TO_INVARIANT["workflow"] += ["workflow.terminal_state_immutable"]
_ENGINE_TO_INVARIANT["jwt"] += ["token.algorithm_and_signature",
                                "token.audience_and_issuer"]


def evaluate(db: DB, log=print) -> dict:
    """
    Fold experiment outcomes into invariant verdicts.

    A violation needs a leak experiment. "Holds" needs experiments that ran
    and did not fire -- which is genuinely useful information, because it
    tells the scheduler the control exists and stops it retrying.
    """
    ensure(db)
    install(db, log=lambda *a: None)
    out = {"violated": 0, "holds": 0, "untested": 0}

    for inv in CATALOGUE:
        kinds = [k for k, v in _ENGINE_TO_INVARIANT.items() if inv.key in v]
        if not kinds:
            continue
        ph = ",".join("?" * len(kinds))
        rows = db.q(f"SELECT id, verdict, score, url, detail FROM experiments "
                    f"WHERE kind IN ({ph})", *kinds)
        if not rows:
            db.ex("UPDATE invariants SET status='untested' WHERE key=?", inv.key)
            out["untested"] += 1
            continue

        leaks = [r for r in rows if r["verdict"] == "leak"]
        if leaks:
            db.ex("UPDATE invariants SET status='violated', evidence=?, "
                  "tested_at=CURRENT_TIMESTAMP, detail=? WHERE key=?",
                  json.dumps([r["id"] for r in leaks[:20]]),
                  json.dumps({"violations": len(leaks),
                              "routes": sorted({r["url"] for r in leaks})[:10]}),
                  inv.key)
            out["violated"] += 1
        else:
            db.ex("UPDATE invariants SET status='holds', evidence=?, "
                  "tested_at=CURRENT_TIMESTAMP, detail=? WHERE key=?",
                  json.dumps([r["id"] for r in rows[:10]]),
                  json.dumps({"experiments": len(rows)}), inv.key)
            out["holds"] += 1

    log(f"[invariants] {out['violated']} violated, {out['holds']} hold, "
        f"{out['untested']} untested")
    return out


def untested(db: DB) -> list[dict]:
    ensure(db)
    return [dict(r) for r in db.q(
        "SELECT * FROM invariants WHERE status='untested'")]


def holds(db: DB) -> list[dict]:
    ensure(db)
    return [dict(r) for r in db.q(
        "SELECT * FROM invariants WHERE status='holds'")]


def violated(db: DB) -> list[dict]:
    ensure(db)
    return [dict(r) for r in db.q(
        "SELECT * FROM invariants WHERE status='violated' ORDER BY "
        "CASE severity WHEN 'critical' THEN 0 WHEN 'high' THEN 1 ELSE 2 END")]


def report(db: DB) -> str:
    ensure(db)
    rows = db.q("SELECT * FROM invariants ORDER BY family, key")
    if not rows:
        return "No invariants installed. Run `thor invariants`."
    mark = {"violated": "✗", "holds": "✓", "untested": "·", "untestable": "!"}
    out, fam = [], None
    for r in rows:
        if r["family"] != fam:
            fam = r["family"]
            out.append(f"\n{fam.upper()}")
        m = mark.get(r["status"], "?")
        out.append(f"  {m} {r['key']:34} {r['status']:10} {r['severity']}")
        if r["status"] == "violated":
            d = json.loads(r["detail"] or "{}")
            out.append(f"        rule: {r['rule']}")
            for rt in (d.get("routes") or [])[:4]:
                out.append(f"        at:   {rt}")
    out.append("")
    out.append("✗ violated   ✓ holds (control verified present)   · untested")
    out.append("An invariant that holds is useful: it tells the scheduler "
               "the control exists, so it stops retrying.")
    return "\n".join(out)
