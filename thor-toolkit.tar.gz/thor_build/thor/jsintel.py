"""
JavaScript intelligence.

Pulls endpoints, API routes, GraphQL operations, cloud buckets and secrets
out of JS bundles. This is where hidden admin routes live -- the ones that
never appear in the sitemap and that generic crawlers miss.
"""

from __future__ import annotations

import base64
import hashlib
import json
import re
from dataclasses import dataclass
from urllib.parse import urljoin, urlsplit

from .net import Client, Request

# --- endpoint extraction -------------------------------------------------

_ENDPOINT_RE = re.compile(
    r"""(?:"|'|`)
    (
      (?:/|\.\./|\./)[a-zA-Z0-9_\-/\.\{\}\$%:]{2,180}
      |
      https?://[a-zA-Z0-9_\-\.]+\.[a-z]{2,}[a-zA-Z0-9_\-/\.\{\}\$%:]{0,180}
    )
    (?:"|'|`)""",
    re.VERBOSE,
)

_ROUTE_HINT_RE = re.compile(
    r"""(?:fetch|axios\.\w+|\$\.(?:get|post|ajax)|XMLHttpRequest|url\s*:)\s*\(?\s*
        (?:"|'|`)([^"'`]{2,200})(?:"|'|`)""",
    re.VERBOSE | re.IGNORECASE,
)

_GQL_RE = re.compile(
    r"(?:query|mutation|subscription)\s+([A-Za-z_][A-Za-z0-9_]{2,60})\s*[\(\{]"
)

# --- secret patterns -----------------------------------------------------
# Each is (kind, regex). Kept tight to avoid the false-positive flood that
# gets reports auto-rejected.
SECRET_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("aws_access_key",   re.compile(r"\b((?:AKIA|ASIA|ABIA|ACCA)[0-9A-Z]{16})\b")),
    ("aws_secret",       re.compile(r"(?i)aws.{0,20}?secret.{0,20}?['\"]([0-9a-zA-Z/+]{40})['\"]")),
    ("google_api",       re.compile(r"\b(AIza[0-9A-Za-z\-_]{35})\b")),
    ("gcp_sa",           re.compile(r"\"type\"\s*:\s*\"service_account\"")),
    ("slack_token",      re.compile(r"\b(xox[baprs]-[0-9A-Za-z\-]{10,72})\b")),
    ("slack_webhook",    re.compile(r"(https://hooks\.slack\.com/services/T[0-9A-Za-z_\-/]{20,})")),
    ("github_pat",       re.compile(r"\b(gh[pousr]_[0-9A-Za-z]{36,255})\b")),
    ("gitlab_pat",       re.compile(r"\b(glpat-[0-9A-Za-z\-_]{20,})\b")),
    ("stripe_live",      re.compile(r"\b(sk_live_[0-9a-zA-Z]{24,})\b")),
    ("stripe_restricted", re.compile(r"\b(rk_live_[0-9a-zA-Z]{24,})\b")),
    ("twilio_sid",       re.compile(r"\b(AC[0-9a-fA-F]{32})\b")),
    ("sendgrid",         re.compile(r"\b(SG\.[0-9A-Za-z\-_]{22}\.[0-9A-Za-z\-_]{43})\b")),
    ("mailgun",          re.compile(r"\b(key-[0-9a-f]{32})\b")),
    ("jwt",              re.compile(r"\b(eyJ[A-Za-z0-9_\-]{10,}\.eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,})\b")),
    ("private_key",      re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |PGP )?PRIVATE KEY-----")),
    ("firebase_url",     re.compile(r"(https://[a-z0-9\-]+\.firebaseio\.com)")),
    ("s3_bucket",        re.compile(r"\b([a-z0-9\-\.]{3,63}\.s3(?:[.-][a-z0-9\-]+)?\.amazonaws\.com)\b")),
    ("azure_storage",    re.compile(r"\b([a-z0-9]{3,24}\.blob\.core\.windows\.net)\b")),
    ("basic_auth_url",   re.compile(r"(https?://[^/\s:@]{2,}:[^/\s:@]{2,}@[a-zA-Z0-9\.\-]+)")),
    ("generic_bearer",   re.compile(r"(?i)bearer\s+([A-Za-z0-9\-_\.=]{24,})")),
]

# Things that look like secrets but are noise.
_SECRET_DENY = re.compile(
    r"(?i)(example|sample|test|dummy|placeholder|xxxx|your[_-]?key|<.*>|0{12,}|1234567890)"
)

_INTERESTING_PATH = re.compile(
    r"(?i)/(api|v[0-9]|graphql|internal|admin|debug|actuator|swagger|openapi|"
    r"\.well-known|oauth|saml|sso|export|download|upload|invoice|billing|"
    r"account|user|users|org|tenant|impersonate|token|key|config|settings)"
)


@dataclass
class JSIntel:
    endpoints: set[str]
    graphql_ops: set[str]
    secrets: list[dict]
    interesting: set[str]


def analyse(js_text: str, base_url: str) -> JSIntel:
    eps: set[str] = set()
    for m in _ENDPOINT_RE.finditer(js_text):
        raw = m.group(1)
        if _skip_endpoint(raw):
            continue
        eps.add(_absolutise(raw, base_url))
    for m in _ROUTE_HINT_RE.finditer(js_text):
        raw = m.group(1)
        if not _skip_endpoint(raw):
            eps.add(_absolutise(raw, base_url))

    gql = {m.group(1) for m in _GQL_RE.finditer(js_text)}

    secrets = []
    seen = set()
    for kind, pat in SECRET_PATTERNS:
        for m in pat.finditer(js_text):
            val = m.group(1) if m.groups() else m.group(0)
            if _SECRET_DENY.search(val):
                continue
            h = hashlib.sha256(val.encode()).hexdigest()
            if h in seen:
                continue
            seen.add(h)
            if kind == "jwt" and not _jwt_plausible(val):
                continue
            ctx = js_text[max(0, m.start() - 60): m.end() + 60].replace("\n", " ")
            secrets.append({
                "kind": kind,
                "masked": _mask(val),
                "sha256": h,
                "context": ctx[:200],
                "source_url": base_url,
            })

    interesting = {e for e in eps if _INTERESTING_PATH.search(urlsplit(e).path or "")}
    return JSIntel(eps, gql, secrets, interesting)


def _skip_endpoint(raw: str) -> bool:
    if len(raw) < 3:
        return True
    low = raw.lower()
    if low.endswith((".png", ".jpg", ".jpeg", ".gif", ".svg", ".woff", ".woff2",
                     ".ttf", ".eot", ".ico", ".css", ".map", ".mp4", ".webp")):
        return True
    if raw.startswith(("./node_modules", "../node_modules")):
        return True
    if re.fullmatch(r"[/\.]+", raw):
        return True
    return False


def _absolutise(raw: str, base: str) -> str:
    if raw.startswith("http"):
        return raw
    return urljoin(base, raw)


def _mask(v: str) -> str:
    if len(v) <= 12:
        return v[:3] + "***"
    return f"{v[:6]}...{v[-4:]}"


def _jwt_plausible(tok: str) -> bool:
    """Only report JWTs we can actually decode -- kills template noise."""
    try:
        head = tok.split(".")[0]
        pad = head + "=" * (-len(head) % 4)
        data = json.loads(base64.urlsafe_b64decode(pad))
        return "alg" in data
    except Exception:
        return False


def fetch_and_analyse(client: Client, js_urls: list[str],
                      max_files: int = 400) -> tuple[JSIntel, dict]:
    """Download JS in scope and merge intel. Returns (intel, stats)."""
    all_eps: set[str] = set()
    all_gql: set[str] = set()
    all_sec: list[dict] = []
    all_int: set[str] = set()
    ok = fail = 0

    for url in js_urls[:max_files]:
        try:
            r = client.send(Request("GET", url))
        except Exception:
            fail += 1
            continue
        if r.status != 200 or len(r.body) > 8_000_000:
            fail += 1
            continue
        ok += 1
        intel = analyse(r.text, url)
        all_eps |= intel.endpoints
        all_gql |= intel.graphql_ops
        all_sec += intel.secrets
        all_int |= intel.interesting

    return (
        JSIntel(all_eps, all_gql, all_sec, all_int),
        {"fetched": ok, "failed": fail, "endpoints": len(all_eps),
         "secrets": len(all_sec), "graphql_ops": len(all_gql)},
    )
