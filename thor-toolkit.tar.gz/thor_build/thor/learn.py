"""
Outcome learning and the adaptive scheduler.

Earlier in the design I argued against an "expected information gain ×
impact × probability / cost" planner, because all three numerators were
guesses and multiplying three guesses gives you confident nonsense.

This is the version that earns its place: the probability is measured, not
guessed. Every probe records its outcome against an arm -- a
(technology, field-role, engine) combination -- and the arm accumulates a
Beta posterior. Thompson sampling then ranks arms by drawing from those
posteriors, which explores uncertain arms and exploits proven ones without
any hand-tuned constant.

Cold start is honest too: with no data, every arm is Beta(1,1) = uniform, so
the sampler explores. The schedule only becomes opinionated once it has seen
outcomes, which is exactly right.

No LLM. No tokens. Pure SQLite and a beta distribution.
"""

from __future__ import annotations

import json
import math
import random
from dataclasses import dataclass

from .db import DB

SCHEMA = """
CREATE TABLE IF NOT EXISTS arms (
  id INTEGER PRIMARY KEY,
  arm TEXT UNIQUE,          -- engine|tech|role
  engine TEXT,
  tech TEXT,
  role TEXT,
  successes INTEGER DEFAULT 0,
  failures INTEGER DEFAULT 0,
  last_seen TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS hypotheses (
  id INTEGER PRIMARY KEY,
  arm TEXT,
  engine TEXT,
  invariant TEXT,           -- the rule this hypothesis would falsify
  target TEXT,
  statement TEXT,
  predicted TEXT,           -- what we expect if the hypothesis is TRUE
  falsifier TEXT,           -- what observation would kill it
  status TEXT DEFAULT 'open',   -- open | confirmed | disproved | blocked
  outcome TEXT,
  experiment_ids TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  closed_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_hyp_status ON hypotheses(status);
"""


def ensure(db: DB) -> None:
    db.conn.executescript(SCHEMA)
    # additive migration for databases created before invariant tracking
    try:
        have = {r[1] for r in db.conn.execute("PRAGMA table_info(hypotheses)")}
        if "invariant" not in have:
            db.conn.execute("ALTER TABLE hypotheses ADD COLUMN invariant TEXT")
    except Exception:
        pass
    db.conn.commit()


def arm_key(engine: str, tech: str = "", role: str = "",
            archetype: str = "", relation: str = "") -> str:
    """
    An arm is the context a hypothesis was tested in.

    v4 used (engine, technology, parameter-role), which could learn "authz
    experiments work on nginx sites". That is too coarse to be useful. Adding
    the endpoint archetype and the identity relationship lets the planner
    learn the thing that actually transfers between programs:

        "on Express apps, object references on collection-detail endpoints
         are unusually productive for cross-tenant experiments"

    Unused dimensions collapse to '-', so old arms remain comparable.
    """
    return (f"{engine}|{tech or '-'}|{role or '-'}"
            f"|{archetype or '-'}|{relation or '-'}")


def archetype_of(url: str, method: str = "GET") -> str:
    """
    Classify an endpoint's shape. Shape predicts productivity far better than
    the hostname does.
    """
    import re as _re
    from urllib.parse import urlsplit as _split
    path = _split(url or "").path or "/"
    has_id = bool(_re.search(r"/(\d+|[0-9a-f-]{16,}|[0-9a-fA-F]{24})(?=/|$)",
                             path))
    m = (method or "GET").upper()
    if _re.search(r"(?i)/(admin|internal|manage|console|staff)", path):
        return "admin"
    if _re.search(r"(?i)/(export|download|report|bulk|batch)", path):
        return "bulk_export"
    if _re.search(r"(?i)/(search|query|filter|list)", path) or \
            (m == "GET" and not has_id):
        return "collection"
    if _re.search(r"(?i)/graphql", path):
        return "graphql"
    if _re.search(r"(?i)/(login|token|oauth|auth|session|register|reset)", path):
        return "auth_flow"
    if has_id and m == "GET":
        return "detail"
    if has_id and m in ("PUT", "PATCH", "DELETE"):
        return "mutation_scoped"
    if m == "POST":
        return "mutation_create"
    return "other"


def relation_of(actor_tenant: str, object_tenant: str,
                actor_role: str = "", owner: bool = False) -> str:
    """The identity relationship an experiment crosses."""
    if actor_tenant and object_tenant and actor_tenant != object_tenant:
        return "cross_tenant"
    if owner:
        return "owner"
    if actor_role in ("admin", "superuser"):
        return "privileged"
    if actor_role == "anonymous":
        return "anonymous"
    return "same_tenant_peer"


# ------------------------------------------------------------- recording

def record(db: DB, engine: str, tech: str, role: str, success: bool,
           n: int = 1) -> None:
    """One observed outcome for an arm. Called after every experiment."""
    ensure(db)
    key = arm_key(engine, tech, role)
    row = db.one("SELECT id FROM arms WHERE arm=?", key)
    if row:
        col = "successes" if success else "failures"
        db.ex(f"UPDATE arms SET {col}={col}+?, "
              f"last_seen=CURRENT_TIMESTAMP WHERE arm=?", n, key)
    else:
        db.ex("INSERT INTO arms (arm, engine, tech, role, successes, failures) "
              "VALUES (?,?,?,?,?,?)",
              key, engine, tech or "-", role or "-",
              n if success else 0, 0 if success else n)


def harvest(db: DB, log=print) -> int:
    """
    Rebuild the arm statistics from the experiment table. Idempotent, so it
    can run after every sweep.
    """
    ensure(db)
    db.ex("DELETE FROM arms")
    rows = db.q("SELECT kind, url, verdict, detail FROM experiments")
    tech_by_host = {}
    for a in db.q("SELECT host, tech FROM assets"):
        try:
            t = json.loads(a["tech"] or "[]")
        except Exception:
            t = []
        tech_by_host[a["host"]] = (t[0].lower() if t else "-")

    counts: dict[str, list[int]] = {}
    for r in rows:
        detail = {}
        try:
            detail = json.loads(r["detail"] or "{}")
        except Exception:
            pass
        role = "-"
        roles = detail.get("detail", {}).get("roles") if isinstance(
            detail.get("detail"), dict) else None
        if isinstance(roles, list) and roles:
            role = roles[0]
        elif detail.get("field"):
            role = str(detail["field"]).split(":")[0]
        host = ""
        try:
            from urllib.parse import urlsplit
            host = urlsplit(r["url"] or "").hostname or ""
        except Exception:
            pass
        tech = tech_by_host.get(host, "-")
        arch = archetype_of(r["url"] or "")
        key = arm_key(r["kind"] or "?", tech, role, arch)
        c = counts.setdefault(key, [0, 0])
        if r["verdict"] == "leak":
            c[0] += 1
        else:
            c[1] += 1

    for key, (s, f) in counts.items():
        parts = key.split("|")
        engine, tech, role = parts[0], parts[1], parts[2]
        db.ex("INSERT OR REPLACE INTO arms (arm, engine, tech, role, "
              "successes, failures) VALUES (?,?,?,?,?,?)",
              key, engine, tech, role, s, f)
    log(f"[learn] {len(counts)} arm(s) updated from "
        f"{len(rows)} experiments")
    return len(counts)


# ------------------------------------------------------------- sampling

@dataclass
class Arm:
    key: str
    engine: str
    tech: str
    role: str
    successes: int
    failures: int
    archetype: str = "-"
    relation: str = "-"

    @property
    def alpha(self) -> float:
        return self.successes + 1.0

    @property
    def beta(self) -> float:
        return self.failures + 1.0

    @property
    def mean(self) -> float:
        return self.alpha / (self.alpha + self.beta)

    @property
    def n(self) -> int:
        return self.successes + self.failures

    def sample(self, rng: random.Random) -> float:
        return rng.betavariate(self.alpha, self.beta)

    def interval(self) -> tuple[float, float]:
        """Rough 90% credible interval, for honest display."""
        m = self.mean
        sd = math.sqrt(m * (1 - m) / (self.alpha + self.beta + 1))
        return (max(0.0, m - 1.64 * sd), min(1.0, m + 1.64 * sd))


def load_arms(db: DB) -> list[Arm]:
    ensure(db)
    out = []
    for r in db.q("SELECT * FROM arms"):
        parts = (r["arm"] or "").split("|")
        out.append(Arm(r["arm"], r["engine"], r["tech"], r["role"],
                       r["successes"], r["failures"],
                       parts[3] if len(parts) > 3 else "-",
                       parts[4] if len(parts) > 4 else "-"))
    return out


def rank(db: DB, engines: list[str], tech: str = "-",
         seed: int | None = None) -> list[tuple[str, float, str]]:
    """
    Thompson-sample an ordering over engines for a given technology.

    Returns (engine, sampled_value, explanation). With no history every arm
    is uniform, so the order is effectively random -- which is the correct
    behaviour when you know nothing.
    """
    rng = random.Random(seed)
    arms = {a.key: a for a in load_arms(db)}
    out = []
    for e in engines:
        # prefer the tech-specific arm, fall back to the engine-wide one
        candidates = [a for k, a in arms.items()
                      if a.engine == e and a.tech in (tech, "-")]
        if candidates:
            a = max(candidates, key=lambda x: x.n)
        else:
            a = Arm(arm_key(e, tech), e, tech, "-", 0, 0)
        val = a.sample(rng)
        lo, hi = a.interval()
        why = (f"no history yet -- exploring" if a.n == 0 else
               f"{a.successes}/{a.n} hit rate, 90% CI {lo:.2f}-{hi:.2f}")
        out.append((e, val, why))
    out.sort(key=lambda x: -x[1])
    return out


def report(db: DB, min_n: int = 1) -> str:
    arms = [a for a in load_arms(db) if a.n >= min_n]
    if not arms:
        return ("No outcome history yet. Run a sweep, then "
                "`thor learn` to build the priors.")
    arms.sort(key=lambda a: -a.mean)
    lines = [f"{'arm':44} {'hits':>6} {'runs':>6} {'rate':>6}  90% CI",
             "-" * 82]
    for a in arms:
        lo, hi = a.interval()
        lines.append(f"{a.key[:44]:44} {a.successes:6} {a.n:6} "
                     f"{a.mean:6.2f}  {lo:.2f}-{hi:.2f}")
    lines.append("")
    lines.append("Arms with few runs have wide intervals and will keep being "
                 "explored; that is intentional.")
    return "\n".join(lines)


# ---------------------------------------------------------- hypotheses

@dataclass
class Hypothesis:
    engine: str
    target: str
    statement: str
    predicted: str
    falsifier: str
    arm: str = ""
    invariant: str = ""


def open_hypothesis(db: DB, h: Hypothesis) -> int:
    ensure(db)
    return db.ex(
        "INSERT INTO hypotheses (arm, engine, invariant, target, statement, "
        "predicted, falsifier) VALUES (?,?,?,?,?,?,?)",
        h.arm or arm_key(h.engine), h.engine, h.invariant, h.target,
        h.statement, h.predicted, h.falsifier)


def close_hypothesis(db: DB, hid: int, status: str, outcome: str,
                     experiment_ids: list[int] | None = None) -> None:
    ensure(db)
    db.ex("UPDATE hypotheses SET status=?, outcome=?, experiment_ids=?, "
          "closed_at=CURRENT_TIMESTAMP WHERE id=?",
          status, outcome, json.dumps(experiment_ids or []), hid)
    row = db.one("SELECT engine, arm FROM hypotheses WHERE id=?", hid)
    if row:
        parts = (row["arm"] or "").split("|")
        record(db, row["engine"], parts[1] if len(parts) > 1 else "-",
               parts[2] if len(parts) > 2 else "-", status == "confirmed")


def open_hypotheses(db: DB) -> list[dict]:
    ensure(db)
    return [dict(r) for r in db.q(
        "SELECT * FROM hypotheses WHERE status='open' ORDER BY id")]


def ledger(db: DB) -> str:
    ensure(db)
    rows = db.q("SELECT status, COUNT(*) c FROM hypotheses GROUP BY status")
    if not rows:
        return "No hypotheses recorded."
    counts = {r["status"]: r["c"] for r in rows}
    out = [f"hypotheses: {json.dumps(counts)}", ""]
    for r in db.q("SELECT * FROM hypotheses ORDER BY "
                  "CASE status WHEN 'confirmed' THEN 0 WHEN 'open' THEN 1 "
                  "ELSE 2 END, id LIMIT 40"):
        mark = {"confirmed": "✓", "disproved": "✗", "open": "·",
                "blocked": "!"}.get(r["status"], "?")
        out.append(f"  {mark} [{r['id']:3}] {r['engine']:12} {r['statement']}")
        if r["status"] == "disproved" and r["outcome"]:
            out.append(f"        killed by: {r['outcome'][:110]}")
    out.append("")
    out.append("Disproved hypotheses are kept deliberately: they stop the "
               "scheduler retrying what has already failed.")
    return "\n".join(out)
