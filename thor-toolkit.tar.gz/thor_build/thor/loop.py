"""
The research loop.

v4 ranked engines and consumed them one by one. The review was right that
this is a work queue, not research: a discovery in round one did not change
what round two did.

v5 is hypothesis-native and event-driven:

    OBSERVE  ─► MODEL ─► HYPOTHESISE ─┐
                                      │
       ┌──────────────────────────────┘
       ▼
    SELECT the highest-gain OPEN hypothesis
       ▼
    EXECUTE the experiment it names        (experiment.execute)
       ▼
    JUDGE against its own falsifier        (oracles, deterministic)
       ▼
    UPDATE graph · invariants · findings · arms
       ▼
    REPLAN — regenerate and re-score the hypothesis space
       ▼
    back to SELECT, now ranking against what was just learned

Everything above is code. The model is consulted only at named checkpoints
after the loop stops. A four-hour run costs a handful of prompts.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field

from . import (audit, chain, evidence, experiment, graph, history, invariants,
               learn, oast, reason, risk, rootcause, schema, states)
from .db import DB
from .scope import Scope
from . import runtime


@dataclass
class Budget:
    minutes: int = 120
    started: float = field(default_factory=time.monotonic)

    def elapsed_min(self) -> float:
        return (time.monotonic() - self.started) / 60

    def remaining_min(self) -> float:
        return max(0.0, self.minutes - self.elapsed_min())

    def exhausted(self) -> tuple[bool, str]:
        if self.elapsed_min() >= self.minutes:
            return True, f"time budget {self.minutes}m reached"
        return False, ""


@dataclass
class LoopState:
    rounds: int = 0
    executed: list[str] = field(default_factory=list)
    confirmed: int = 0
    disproved: int = 0
    blocked: int = 0
    replans: int = 0
    new_hypotheses: int = 0
    findings_before: int = 0
    findings_after: int = 0
    checkpoints: list[str] = field(default_factory=list)
    stopped_because: str = ""


def _seed(db: DB, corpus: str, log=print) -> int:
    """Bootstrap hypotheses from the graph and the invariant catalogue."""
    graph.build(db, corpus, log=log)
    invariants.install(db, log=log)
    invariants.evaluate(db, log=lambda *a: None)
    hyps = reason.generate(db, corpus, log=lambda *a: None)
    n = reason.persist(db, hyps, log=lambda *a: None)
    log(f"[loop] {n} hypothesis/hypotheses opened from the model")
    return n


def run(db: DB, scope: Scope, corpus: str, *,
        minutes: int = 120, max_rounds: int = 40,
        oast_kind: str = "auto", oast_domain: str | None = None,
        ai_checkpoints: bool = True, log=print) -> LoopState:
    st = LoopState()
    budget = Budget(minutes=minutes)
    gate = risk.gate_for(scope)
    al = audit.default(scope.engagement)
    st.findings_before = (db.one("SELECT COUNT(*) c FROM findings")
                          or {"c": 0})["c"]

    al.event("loop.start", budget_minutes=minutes, max_rounds=max_rounds,
             ceiling=risk.NAMES[gate.ceiling], corpus=corpus)
    log(f"[loop] budget {minutes}m · risk ceiling "
        f"{risk.NAMES[gate.ceiling]} ({'; '.join(gate.reasons)})")
    log(f"[loop] audit -> {al.path}")

    # ---- OBSERVE / MODEL ------------------------------------------------
    schemas = schema.infer(db, corpus)
    schema.persist(db, corpus, schemas)
    log(f"[loop] model: {len(schemas)} endpoints, "
        f"{sum(len(s.fields) for s in schemas.values())} fields")
    history.take(db, label=f"loop-start {runtime.utcnow():%H:%M}",
                 log=lambda *a: None)

    # ---- HYPOTHESISE ----------------------------------------------------
    st.new_hypotheses += _seed(db, corpus, log=log)

    oc = oast.make(oast_kind, domain=oast_domain, log=log)
    tried: set[int] = set()

    try:
        while st.rounds < max_rounds:
            done, why = budget.exhausted()
            if done:
                st.stopped_because = why
                break

            # ---- SELECT ---------------------------------------------------
            hyp, gain, why_pick = experiment.select(db, corpus, exclude=tried,
                                                    log=log)
            if hyp is None:
                st.stopped_because = "no open hypotheses remain"
                break
            tried.add(hyp["id"])
            st.rounds += 1

            log(f"\n[loop] round {st.rounds} · {budget.remaining_min():.0f}m left")
            log(f"[loop] H-{hyp['id']:03d} ({hyp['engine']})  {why_pick}")
            log(f"[loop]   {hyp['statement'][:96]}")
            log(f"[loop]   predicts: {(hyp.get('predicted') or '')[:80]}")

            # ---- EXECUTE + JUDGE ------------------------------------------
            out = experiment.execute(db, scope, corpus, hyp, oast=oc, log=log)
            st.executed.append(f"{hyp['engine']}:{out.status}")
            st.__dict__[out.status if out.status in
                        ("confirmed", "disproved", "blocked")
                        else "disproved"] += 1
            log(out.render())
            al.event("hypothesis.closed", hypothesis=hyp["id"],
                     engine=hyp["engine"], status=out.status,
                     gain=round(gain, 3), leaks=out.new_leaks)

            # ---- UPDATE ---------------------------------------------------
            evidence.promote(db, log=lambda *a: None)
            states.advance_all(db, log=lambda *a: None)
            learn.harvest(db, log=lambda *a: None)

            # ---- REPLAN: only when something changed ----------------------
            if out.status == "confirmed" or out.new_leaks:
                added = experiment.replan(db, corpus, log=log)
                st.new_hypotheses += added
                st.replans += 1
                if added:
                    # a discovery may make an already-tried engine worth
                    # revisiting against a different target
                    tried = {h for h in tried
                             if db.one("SELECT status FROM hypotheses "
                                       "WHERE id=?", h) is None
                             or db.one("SELECT status FROM hypotheses "
                                       "WHERE id=?", h)["status"] != "open"}
    finally:
        oc.close()

    # ---- CORRELATE ------------------------------------------------------
    log("\n[loop] correlating")
    invariants.evaluate(db, log=log)
    chain.persist(db, chain.find_chains(db, log=lambda *a: None), log=log)
    rootcause.persist(db, rootcause.analyse(db, log=lambda *a: None), log=log)
    states.advance_all(db, log=log)
    history.take(db, label=f"loop-end {runtime.utcnow():%H:%M}",
                 log=lambda *a: None)

    st.findings_after = (db.one("SELECT COUNT(*) c FROM findings")
                         or {"c": 0})["c"]
    if not st.stopped_because:
        st.stopped_because = f"round limit {max_rounds} reached"

    if ai_checkpoints:
        st.checkpoints = _checkpoints(db, log=log)

    log(f"\n[loop] {st.rounds} round(s): {st.confirmed} confirmed, "
        f"{st.disproved} disproved, {st.blocked} blocked")
    log(f"[loop] {st.replans} replan(s), {st.new_hypotheses} hypotheses opened")
    log(f"[loop] findings {st.findings_before} → {st.findings_after}")
    log(f"[loop] stopped: {st.stopped_because}")
    al.event("loop.end", rounds=st.rounds, confirmed=st.confirmed,
             disproved=st.disproved, findings_after=st.findings_after,
             reason=st.stopped_because)
    return st


def _checkpoints(db: DB, log=print) -> list[str]:
    """Where a prompt buys something code cannot, and what it buys."""
    out = []
    counts = {r["status"]: r["c"] for r in db.q(
        "SELECT status, COUNT(*) c FROM findings GROUP BY status")}
    verified = counts.get(states.VERIFIED, 0) + counts.get(states.DEDUPED, 0)
    held = counts.get(states.CANDIDATE, 0) + \
        counts.get(states.VERIFICATION_REQUIRED, 0)
    open_h = len(learn.open_hypotheses(db))
    rc = (db.one("SELECT COUNT(*) c FROM rootcauses") or {"c": 0})["c"]

    if verified:
        out.append(f"/impact    — {verified} verified finding(s) need an "
                   f"impact section to reach REPORT_READY")
    if rc:
        out.append(f"/rootcause — {rc} group(s): confirm the merge before "
                   f"writing anything up")
        out.append("/dedupe    — check the program's disclosures; duplicates "
                   "cost more than false positives")
    if held:
        out.append(f"/thor      — {held} finding(s) held short of VERIFIED; "
                   f"`thor state` shows which gate is blocking")
    if open_h >= 5:
        out.append(f"/reason    — {open_h} hypotheses still open; review "
                   f"whether the top ones are worth the hours")
    out.append("/fuzz      — design app-specific logic mutations for the "
               "business fields the schema could not place")

    if out:
        log("\n[loop] AI checkpoints worth a prompt:")
        for c in out:
            log(f"  {c}")
    return out


def status(db: DB) -> str:
    # `thor status` is the first command an operator runs on a new engagement,
    # so it must work before any table that a later stage creates lazily.
    learn.ensure(db)
    rootcause.ensure(db)
    s = db.stats()
    counts = {r["status"]: r["c"] for r in db.q(
        "SELECT status, COUNT(*) c FROM findings GROUP BY status")}
    return json.dumps({
        **s,
        "finding_states": counts,
        "open_hypotheses": len(learn.open_hypotheses(db)),
        "root_causes": (db.one("SELECT COUNT(*) c FROM rootcauses")
                        or {"c": 0})["c"],
        "invariants_violated": len(invariants.violated(db)),
        "invariants_untested": len(invariants.untested(db)),
    }, indent=2)
