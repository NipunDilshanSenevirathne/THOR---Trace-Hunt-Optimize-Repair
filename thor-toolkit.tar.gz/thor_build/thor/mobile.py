"""
Mobile ↔ API correlation.

Deliberately NOT a mobile security scanner. Android and iOS analysis are
their own disciplines with their own verification models, and building a
mediocre version of MobSF would make THOR worse, not better.

What is worth having is the *correlation*: a mobile app is a list of API
endpoints, hostnames, headers and secrets that the web corpus usually does
not contain. Mobile clients routinely talk to endpoints the web front-end
never calls, and those endpoints are frequently older and less guarded.

So this extracts attack surface from an APK/IPA and feeds it into the same
corpus the web engines already test. No new verification path, no new
finding type -- the existing authz, tenant, fuzz and workflow engines just
get more surface to work with.

Pure-Python: unzips the archive and reads strings out of the DEX/binary and
resources. No JADX, no apktool, no emulator. Endpoints and secrets are what
survives that, and endpoints and secrets are the point.
"""

from __future__ import annotations

import json
import plistlib
import re
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlsplit

from . import jsintel
from .db import DB
from .scope import Scope

_URL = re.compile(rb"https?://[A-Za-z0-9._~:/?#\[\]@!$&'()*+,;=%-]{6,200}")
_PATH = re.compile(rb"[\"'](/(?:api|v\d|graphql|internal|mobile|app|rest)"
                   rb"[A-Za-z0-9_\-/{}:.$]{1,120})[\"']")
_HOST = re.compile(rb"[a-z0-9][a-z0-9.-]{3,60}\.[a-z]{2,12}")

# Headers a mobile client sends that the web client does not. These are
# frequently trusted more than they should be.
_MOBILE_HEADER = re.compile(
    rb"(?i)[\"'](X-(?:App|Client|Device|Platform|Api|Mobile|Install|Build)"
    rb"-[A-Za-z-]{2,30})[\"']")

_SCHEME = re.compile(rb"[\"']([a-z][a-z0-9+.-]{2,30})://[\"']?")

_ANDROID_COMPONENT = re.compile(
    rb"(?i)<(activity|service|receiver|provider)[^>]*?"
    rb'android:name="([^"]+)"[^>]*?android:exported="true"')


@dataclass
class MobileIntel:
    package: str = ""
    platform: str = ""
    hosts: set[str] = field(default_factory=set)
    urls: set[str] = field(default_factory=set)
    paths: set[str] = field(default_factory=set)
    headers: set[str] = field(default_factory=set)
    schemes: set[str] = field(default_factory=set)
    exported: list[str] = field(default_factory=list)
    secrets: list[dict] = field(default_factory=list)
    cleartext_permitted: bool = False

    def summary(self) -> dict:
        return {"platform": self.platform, "package": self.package,
                "hosts": len(self.hosts), "urls": len(self.urls),
                "api_paths": len(self.paths), "mobile_headers": len(self.headers),
                "url_schemes": len(self.schemes),
                "exported_components": len(self.exported),
                "secrets": len(self.secrets),
                "cleartext_permitted": self.cleartext_permitted}


def _strings(blob: bytes) -> MobileIntel:
    m = MobileIntel()
    for hit in _URL.findall(blob):
        u = hit.decode("utf-8", "replace").rstrip('",;\\')
        if len(u) > 400:
            continue
        m.urls.add(u)
        h = urlsplit(u).hostname
        if h:
            m.hosts.add(h.lower())
    for hit in _PATH.findall(blob):
        m.paths.add(hit.decode("utf-8", "replace"))
    for hit in _MOBILE_HEADER.findall(blob):
        m.headers.add(hit.decode("utf-8", "replace"))
    for hit in _SCHEME.findall(blob):
        s = hit.decode("utf-8", "replace").lower()
        if s not in ("http", "https", "file", "content", "data", "about"):
            m.schemes.add(s)
    return m


def _merge(a: MobileIntel, b: MobileIntel) -> None:
    a.hosts |= b.hosts
    a.urls |= b.urls
    a.paths |= b.paths
    a.headers |= b.headers
    a.schemes |= b.schemes


def analyse(path: str | Path, log=print) -> MobileIntel:
    """Extract API surface from an APK, AAB or IPA."""
    path = Path(path)
    if not path.exists():
        raise SystemExit(f"no such file: {path}")

    intel = MobileIntel()
    intel.platform = "ios" if path.suffix.lower() == ".ipa" else "android"

    try:
        z = zipfile.ZipFile(path)
    except zipfile.BadZipFile:
        raise SystemExit(f"{path} is not a readable APK/AAB/IPA archive")

    with z:
        names = z.namelist()
        interesting = [
            n for n in names
            if n.endswith((".dex", ".xml", ".json", ".js", ".plist", ".strings",
                           ".properties", ".arsc"))
            or "/Info.plist" in n
            or re.search(r"Payload/[^/]+\.app/[^/.]+$", n)
        ]
        # cap the work: the biggest DEX files carry most of the strings
        interesting.sort(key=lambda n: -(z.getinfo(n).file_size or 0))
        for n in interesting[:60]:
            try:
                blob = z.read(n)
            except (KeyError, RuntimeError, zipfile.BadZipFile):
                continue
            if len(blob) > 80_000_000:
                continue
            _merge(intel, _strings(blob))

            if n.endswith("AndroidManifest.xml"):
                for kind, comp in _ANDROID_COMPONENT.findall(blob):
                    intel.exported.append(
                        f"{kind.decode()}:{comp.decode('utf-8','replace')}")
                if b"cleartextTrafficPermitted=\"true\"" in blob or \
                        b"usesCleartextTraffic=\"true\"" in blob:
                    intel.cleartext_permitted = True
                pm = re.search(rb'package="([^"]+)"', blob)
                if pm:
                    intel.package = pm.group(1).decode("utf-8", "replace")

            if n.endswith("Info.plist") or "/Info.plist" in n:
                try:
                    pl = plistlib.loads(blob)
                    intel.package = pl.get("CFBundleIdentifier", intel.package)
                    for url_type in pl.get("CFBundleURLTypes", []) or []:
                        for s in url_type.get("CFBundleURLSchemes", []) or []:
                            intel.schemes.add(str(s).lower())
                    ats = pl.get("NSAppTransportSecurity", {}) or {}
                    if ats.get("NSAllowsArbitraryLoads"):
                        intel.cleartext_permitted = True
                except Exception:
                    pass

            # reuse the JS secret patterns: they are format-based, not
            # language-based, so they work on DEX strings too
            try:
                text = blob.decode("utf-8", "ignore")
            except Exception:
                text = ""
            if text:
                ji = jsintel.analyse(text[:4_000_000], f"mobile://{n}")
                intel.secrets.extend(ji.secrets)

    # dedupe secrets
    seen, uniq = set(), []
    for s in intel.secrets:
        if s["sha256"] in seen:
            continue
        seen.add(s["sha256"])
        uniq.append(s)
    intel.secrets = uniq

    log(f"[mobile] {path.name}: {json.dumps(intel.summary())}")
    return intel


def ingest(db: DB, scope: Scope, intel: MobileIntel, log=print) -> dict:
    """
    Feed the extracted surface into the same tables the web engines read.

    Only in-scope hosts are stored. Everything else is reported as context so
    the operator can decide whether it belongs in the program's scope.
    """
    out = {"hosts_in_scope": 0, "hosts_out_of_scope": 0,
           "endpoints": 0, "secrets": 0, "notes": 0}

    in_scope_hosts = []
    for h in sorted(intel.hosts):
        if scope.host_allowed(h):
            in_scope_hosts.append(h)
            db.upsert_asset(h, source=f"mobile:{intel.platform}")
            out["hosts_in_scope"] += 1
        else:
            out["hosts_out_of_scope"] += 1

    for u in sorted(intel.urls):
        host = urlsplit(u).hostname or ""
        if not scope.host_allowed(host):
            continue
        row = db.one("SELECT id FROM assets WHERE host=?", host)
        db.add_endpoint(u.split("?")[0], "GET",
                        asset_id=row["id"] if row else None,
                        source=f"mobile:{intel.platform}",
                        is_api=1 if re.search(r"/(api|v\d|graphql)/", u) else 0)
        out["endpoints"] += 1

    # relative paths pair with every in-scope host the app talks to
    for host in in_scope_hosts:
        row = db.one("SELECT id, scheme FROM assets WHERE host=?", host)
        scheme = (row["scheme"] if row and row["scheme"] else "https")
        for p in sorted(intel.paths):
            db.add_endpoint(f"{scheme}://{host}{p}", "GET",
                            asset_id=row["id"] if row else None,
                            source=f"mobile:{intel.platform}",
                            is_api=1)
            out["endpoints"] += 1

    for s in intel.secrets:
        host = in_scope_hosts[0] if in_scope_hosts else None
        row = db.one("SELECT id FROM assets WHERE host=?", host) if host else None
        db.conn.execute(
            "INSERT OR IGNORE INTO secrets (asset_id, kind, value_masked, "
            "value_sha256, source_url, context) VALUES (?,?,?,?,?,?)",
            (row["id"] if row else None, s["kind"], s["masked"], s["sha256"],
             f"mobile:{intel.platform}:{intel.package}", s["context"]))
        out["secrets"] += 1
    db.conn.commit()

    subject = intel.package or f"mobile:{intel.platform}"
    if intel.headers:
        db.note(subject, "manual",
                f"mobile-only headers observed in the binary: "
                f"{sorted(intel.headers)}. Backends often trust these more "
                f"than web headers; try them on web endpoints.")
        out["notes"] += 1
    if intel.schemes:
        db.note(subject, "manual",
                f"custom URL schemes (deep-link surface): {sorted(intel.schemes)}")
        out["notes"] += 1
    if intel.exported:
        db.note(subject, "manual",
                f"{len(intel.exported)} exported components: "
                f"{intel.exported[:10]}")
        out["notes"] += 1
    if intel.cleartext_permitted:
        db.note(subject, "manual",
                "the app permits cleartext traffic (ATS disabled / "
                "usesCleartextTraffic), so its API calls may be interceptable")
        out["notes"] += 1
    if out["hosts_out_of_scope"]:
        db.note(subject, "manual",
                f"{out['hosts_out_of_scope']} host(s) referenced by the app are "
                f"NOT in scope.yaml — check whether the program's scope covers "
                f"the mobile backend before testing them")
        out["notes"] += 1

    log(f"[mobile] ingested: {json.dumps(out)}")
    return out


def mobile_only_endpoints(db: DB, corpus: str) -> list[str]:
    """
    Endpoints the mobile app knows about that the web corpus never exercised.
    This is the payload of the whole module: older, less-guarded surface that
    a web-only capture cannot reach.
    """
    web = set()
    for r in db.q("SELECT DISTINCT url FROM requests WHERE corpus=?", corpus):
        web.add(urlsplit(r["url"]).path or "/")
    out = []
    for r in db.q("SELECT DISTINCT url FROM endpoints WHERE source LIKE 'mobile:%'"):
        if (urlsplit(r["url"]).path or "/") not in web:
            out.append(r["url"])
    return sorted(out)


def report(db: DB, corpus: str) -> str:
    only = mobile_only_endpoints(db, corpus)
    notes = db.q("SELECT subject, body FROM notes WHERE body LIKE 'mobile%' "
                 "OR subject LIKE 'mobile:%'")
    out = [f"mobile-derived endpoints not present in the web corpus: {len(only)}",
           ""]
    for u in only[:40]:
        out.append(f"  {u}")
    if notes:
        out += ["", "context:"]
        for n in notes[:10]:
            out.append(f"  {n['body'][:160]}")
    out += ["", "These feed the normal engines. Run `thor authz`, `thor tenant` "
                "and `thor fuzz` again now that the corpus is larger."]
    return "\n".join(out)
