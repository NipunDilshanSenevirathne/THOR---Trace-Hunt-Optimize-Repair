"""
The only HTTP client in THOR.

Three things the earlier version did not do, all flagged by review:

1. **Pins the connection to the validated address.** Scope.check() resolves
   and validates; this connects to that address while sending the correct
   Host header and TLS SNI. There is no second resolution, so there is no
   TOCTOU window.

2. **Revalidates redirects.** Location headers are not followed blindly;
   each hop goes through the full scope check, and the hop chain is recorded.

3. **Captures replay-grade artifacts.** Enough to reproduce the exact
   experiment: HTTP version, the address actually connected to, TLS details,
   timing, redirect chain, and body hashes -- with credentials redacted on
   the way out.
"""

from __future__ import annotations

import hashlib
import json
import threading
import time as _time
import uuid
from dataclasses import dataclass, field
from typing import Any

import httpx

from . import vault
from .scope import Destination, Scope, ScopeViolation


class PinnedTransport(httpx.HTTPTransport):
    """
    Routes every connection to the address the scope gate validated.

    The obvious implementation — temporarily swapping socket.getaddrinfo —
    is a process-global mutation, and this client is used concurrently by the
    race engine. Two threads interleaving their patch/restore can leave the
    wrong resolver installed, which in a scope-enforcement layer is
    unacceptable.

    Instead the request URL's host is rewritten to the validated address and
    httpx's `sni_hostname` extension carries the original hostname, so TLS
    verification and the Host header still see the real name. Nothing global
    is touched, so this is safe under concurrency.
    """

    def __init__(self, pin_map: dict[tuple[str, int], str],
                 lock: threading.Lock | None = None, **kw):
        self._pins = pin_map
        self._lock = lock or threading.Lock()
        super().__init__(**kw)

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        host = (request.url.host or "").lower()
        port = request.url.port or (443 if request.url.scheme == "https" else 80)
        with self._lock:
            pinned = self._pins.get((host, port))

        if not pinned or pinned == host:
            return super().handle_request(request)

        # Preserve the name for TLS SNI and certificate verification…
        request.extensions = dict(request.extensions or {})
        request.extensions["sni_hostname"] = host
        # …and for the Host header, which httpx derives from the URL.
        request.headers["Host"] = (
            f"{host}:{port}"
            if port not in (80, 443) else host)
        # …then send to the validated address.
        literal = f"[{pinned}]" if ":" in pinned else pinned
        request.url = request.url.copy_with(host=literal)
        return super().handle_request(request)


@dataclass
class Hop:
    url: str
    status: int
    location: str
    address: str


@dataclass
class Response:
    status: int
    headers: dict[str, str]
    body: bytes
    elapsed_ms: float
    url: str
    http_version: str = ""
    address: str = ""
    tls: dict = field(default_factory=dict)
    hops: list[Hop] = field(default_factory=list)
    correlation_id: str = ""

    @property
    def text(self) -> str:
        return self.body.decode("utf-8", errors="replace")

    def json(self) -> Any:
        return json.loads(self.body)

    @property
    def sha256(self) -> str:
        return hashlib.sha256(self.body).hexdigest()

    def to_record(self) -> dict:
        """Replay-grade, credential-free."""
        return vault.redact({
            "status": self.status,
            "headers": dict(self.headers),
            "body_sha256": self.sha256,
            "body_len": len(self.body),
            "elapsed_ms": round(self.elapsed_ms, 2),
            "url": self.url,
            "http_version": self.http_version,
            "connected_address": self.address,
            "tls": self.tls,
            "redirect_chain": [h.__dict__ for h in self.hops],
            "correlation_id": self.correlation_id,
        })


@dataclass
class Request:
    method: str
    url: str
    headers: dict[str, str] = field(default_factory=dict)
    body: bytes | None = None
    identity: str = "anon"

    def signature(self) -> str:
        """
        Deterministic experiment identity. Headers are included: whole classes
        of test (ACL bypass, cache poisoning, tenant swapping) vary nothing
        else, and omitting them collapses every variant into one.
        """
        h = hashlib.sha256()
        for part in (self.method.upper(), self.url, self.identity):
            h.update(part.encode()); h.update(b"\x00")
        h.update(self.body or b""); h.update(b"\x00")
        for k in sorted(self.headers):
            h.update(k.lower().encode()); h.update(b"=")
            h.update(str(self.headers[k]).encode()); h.update(b";")
        return h.hexdigest()[:16]

    def to_record(self) -> dict:
        return vault.redact({
            "method": self.method,
            "url": self.url,
            "headers": dict(self.headers),
            "body": (self.body or b"").decode("utf-8", errors="replace")[:20000],
            "body_sha256": hashlib.sha256(self.body or b"").hexdigest(),
            "identity": self.identity,
            "signature": self.signature(),
        })


class Budget:
    """
    The engagement-wide request budget and rate limiter. Thread safe.

    One of these per engagement, handed out by `thor.runtime`. It used to be
    one per `Client`, which meant one per engine -- a scope file permitting
    20,000 requests actually permitted that many *each* to nineteen engines,
    and `max_rps: 3` became 3 rps per engine. The docstring claimed
    "global" while the constructor made a new one every time, which is why
    it went unnoticed.

    `used` is persisted on every take when a database is attached. A ceiling
    that resets on restart is not a ceiling: running `thor loop` four times
    would quietly send four budgets' worth against a program that authorised
    one.
    """

    def __init__(self, max_rps: float, max_requests: int,
                 engagement: str = "default", db=None,
                 concurrency: "threading.Semaphore | None" = None):
        self.max_rps = max_rps
        self.max_requests = max_requests
        self.engagement = engagement
        self.db = db
        self.concurrency = concurrency
        self._lock = threading.Lock()
        self._last = 0.0
        self.used = self._load()

    # ------------------------------------------------------- persistence

    def _load(self) -> int:
        if self.db is None:
            return 0
        try:
            from .runtime import SCHEMA, utcstamp
            self.db.conn.executescript(SCHEMA)
            row = self.db.one(
                "SELECT used FROM budget_state WHERE engagement=?",
                self.engagement)
            if row:
                return int(row["used"] or 0)
            self.db.ex("INSERT INTO budget_state (engagement, used, "
                       "max_requests, started_at, updated_at) "
                       "VALUES (?,?,?,?,?)",
                       self.engagement, 0, self.max_requests,
                       utcstamp(), utcstamp())
        except Exception:
            return 0
        return 0

    def _persist(self) -> None:
        if self.db is None:
            return
        try:
            from .runtime import utcstamp
            self.db.ex("UPDATE budget_state SET used=?, max_requests=?, "
                       "updated_at=? WHERE engagement=?",
                       self.used, self.max_requests, utcstamp(),
                       self.engagement)
        except Exception:
            pass

    # ------------------------------------------------------------- take

    def take(self) -> None:
        with self._lock:
            if self.used >= self.max_requests:
                raise ScopeViolation(
                    f"Engagement request budget exhausted "
                    f"({self.used}/{self.max_requests} for "
                    f"'{self.engagement}'). This ceiling is engagement-wide "
                    f"and survives restarts. Raise max_requests in "
                    f"scope.yaml only if the program permits it, or run "
                    f"`thor budget reset` to start a new engagement.")
            self.used += 1
            self._persist()
            if self.max_rps > 0:
                gap = 1.0 / self.max_rps
                wait = gap - (_time.monotonic() - self._last)
                if wait > 0:
                    _time.sleep(wait)
                self._last = _time.monotonic()

    def remaining(self) -> int:
        return max(0, self.max_requests - self.used)


MAX_REDIRECTS = 5


class Client:
    """Scoped, pinned HTTP client. Construct once per engagement."""

    def __init__(self, scope: Scope, budget: Budget | None = None,
                 timeout: float = 20.0, verify: bool = True,
                 audit=None, follow_redirects: bool = False):
        from . import runtime
        self.scope = scope
        # Not `Budget(...)`: that made the ceiling per engine. Ask the
        # engagement for the shared one, so an engine that does the obvious
        # thing is inside the boundary without having to know it exists.
        self.budget = budget or runtime.budget_for(scope)
        self.concurrency = runtime.concurrency_for(scope)
        self.audit = audit
        self.follow_redirects = follow_redirects
        self._timeout = timeout
        self._verify = verify
        self._pins: dict[tuple[str, int], str] = {}
        self._pin_lock = threading.Lock()
        self._c = httpx.Client(
            timeout=timeout, verify=verify,
            follow_redirects=False,          # we revalidate each hop ourselves
            http2=True,
            # trust_env=False is load-bearing. httpx defaults it to True and
            # would then read HTTP_PROXY/HTTPS_PROXY/ALL_PROXY from the
            # environment. A proxy terminates the connection itself, so the
            # address we validated and pinned would no longer be the address
            # the socket reaches -- the whole scope gate, reduced to an
            # environment variable. It happens to hold today because passing
            # an explicit `transport=` bypasses httpx's proxy mounts, but
            # that is incidental behaviour of a library we do not control.
            # tests/safety asserts the property directly.
            trust_env=False,
            transport=PinnedTransport(self._pins, self._pin_lock,
                                      verify=verify, http2=True,
                                      trust_env=False),
        )

    # ------------------------------------------------------------ send

    def send(self, req: Request, _depth: int = 0) -> Response:
        # 1. scope gate -- returns the destination we are allowed to reach
        try:
            dest: Destination = self.scope.check(req.method, req.url)
        except ScopeViolation as e:
            if self.audit:
                self.audit.event("scope.refused", method=req.method,
                                 url=req.url, identity=req.identity,
                                 reason=str(e))
            raise
        # 2. pin it so the socket cannot go anywhere else
        with self._pin_lock:
            self._pins[(dest.host, dest.port)] = dest.pinned()
        # 3. budget and rate limit
        self.budget.take()

        cid = uuid.uuid4().hex[:12]
        t0 = _time.perf_counter()
        # Engagement-wide concurrency, not per engine. A program's rate
        # limit is about load on their service, and ten parallel workers
        # each respecting a per-worker limit is still ten times the load.
        sem = self.concurrency
        if sem is not None:
            sem.acquire()
        try:
            r = self._c.request(req.method, req.url,
                                headers=req.headers or None, content=req.body)
        except Exception as e:
            if self.audit:
                self.audit.event("request.failed", url=req.url,
                                 identity=req.identity, error=str(e)[:200],
                                 correlation_id=cid)
            raise
        finally:
            if sem is not None:
                sem.release()
        elapsed = (_time.perf_counter() - t0) * 1000

        resp = Response(
            status=r.status_code, headers=dict(r.headers), body=r.content,
            elapsed_ms=elapsed, url=str(r.url),
            http_version=r.http_version or "",
            address=dest.pinned(),
            tls={"sni": dest.host, "scheme": dest.scheme, "verify": self._verify},
            correlation_id=cid,
        )

        if self.audit:
            self.audit.event("request.sent", method=req.method, url=req.url,
                             identity=req.identity, status=resp.status,
                             bytes=len(resp.body), address=dest.pinned(),
                             signature=req.signature(), correlation_id=cid)

        # 4. redirects: each hop gets the full check before it is followed
        loc = resp.headers.get("location") or resp.headers.get("Location")
        if self.follow_redirects and resp.status in (301, 302, 303, 307, 308) \
                and loc and _depth < MAX_REDIRECTS:
            try:
                self.scope.check_redirect(req.url, loc, req.method)
            except ScopeViolation as e:
                if self.audit:
                    self.audit.event("redirect.refused", from_url=req.url,
                                     location=loc[:300], reason=str(e),
                                     correlation_id=cid)
                resp.hops.append(Hop(req.url, resp.status, loc,
                                     dest.pinned()))
                return resp     # stop here; the chain left scope
            from urllib.parse import urljoin
            nxt = Request(
                "GET" if resp.status == 303 else req.method,
                urljoin(req.url, loc), dict(req.headers), req.body,
                req.identity)
            follow = self.send(nxt, _depth + 1)
            follow.hops = [Hop(req.url, resp.status, loc, dest.pinned())] \
                + follow.hops
            return follow

        if loc:
            resp.hops.append(Hop(req.url, resp.status, loc, dest.pinned()))
        return resp

    def close(self) -> None:
        self._c.close()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()
