"""
Out-of-band application security testing (OAST).

Blind SSRF, blind XXE, blind command injection and blind deserialisation all
share one property: the response tells you nothing. The only reliable proof
is observing the target reach out to infrastructure you control.

Supports two backends:
  * interactsh  -- public or self-hosted, via the `interactsh-client` binary
  * burp        -- Collaborator, polled through a Burp MCP tool by the caller
  * none        -- OAST payloads are skipped rather than reported unproven

Design note: without OAST, blind classes are simply not tested. They are
never reported on inference alone.
"""

from __future__ import annotations

import json
import re
import secrets
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass, field


@dataclass
class Interaction:
    protocol: str
    remote_address: str
    unique_id: str
    raw: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {"protocol": self.protocol, "remote-address": self.remote_address,
                "unique-id": self.unique_id, "full-id": self.unique_id}


class OASTClient:
    """Base: a no-op client that yields no interactions."""

    available = False
    domain = ""

    def payload(self, token: str) -> str:
        return ""

    def poll(self) -> list[dict]:
        return []

    def close(self) -> None:
        pass

    @staticmethod
    def new_token() -> str:
        return secrets.token_hex(8)


class InteractshClient(OASTClient):
    """
    Wraps the interactsh-client binary in JSON streaming mode.

        go install -v github.com/projectdiscovery/interactsh/cmd/interactsh-client@latest

    Self-host with `-server your.oast.domain` for engagements where a public
    OAST domain is inappropriate.
    """

    def __init__(self, server: str | None = None, token: str | None = None):
        self._proc = None
        self._lines: list[str] = []
        self._lock = threading.Lock()
        self.domain = ""
        if not shutil.which("interactsh-client"):
            return

        cmd = ["interactsh-client", "-json", "-silent"]
        if server:
            cmd += ["-server", server]
        if token:
            cmd += ["-token", token]
        try:
            self._proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                text=True, bufsize=1)
        except OSError:
            self._proc = None
            return

        threading.Thread(target=self._reader, daemon=True).start()
        # the binary prints the allocated domain on the first lines
        deadline = time.time() + 12
        while time.time() < deadline and not self.domain:
            time.sleep(0.3)
            with self._lock:
                for ln in self._lines:
                    m = re.search(r"([a-z0-9]+\.[a-z0-9.\-]*oast\.[a-z]+"
                                  r"|[a-z0-9]+\.interact\.sh)", ln, re.I)
                    if m:
                        self.domain = m.group(1)
                        break
        self.available = bool(self.domain)

    def _reader(self) -> None:
        if not self._proc or not self._proc.stdout:
            return
        for line in self._proc.stdout:
            with self._lock:
                self._lines.append(line.strip())

    def payload(self, token: str) -> str:
        """Correlatable hostname: the token is recoverable from the callback."""
        return f"{token}.{self.domain}" if self.domain else ""

    def poll(self) -> list[dict]:
        out = []
        with self._lock:
            lines, self._lines = self._lines, []
        for ln in lines:
            if not ln.startswith("{"):
                continue
            try:
                d = json.loads(ln)
            except json.JSONDecodeError:
                continue
            full = d.get("full-id") or d.get("unique-id") or ""
            out.append({
                "protocol": d.get("protocol", "?"),
                "remote-address": d.get("remote-address", "?"),
                "unique-id": full,
                "full-id": full,
                "raw-request": (d.get("raw-request") or "")[:2000],
                "timestamp": d.get("timestamp"),
            })
        return out

    def close(self) -> None:
        if self._proc:
            self._proc.terminate()


class StaticOASTClient(OASTClient):
    """
    For a Burp Collaborator domain, or any callback host you poll yourself.

    Generate payloads here; feed observed interactions back in via `feed()`
    (e.g. from a Burp MCP collaborator poll performed by the caller).
    """

    def __init__(self, domain: str):
        self.domain = domain.strip().lstrip(".")
        self.available = bool(self.domain)
        self._pending: list[dict] = []

    def payload(self, token: str) -> str:
        return f"{token}.{self.domain}"

    def feed(self, interactions: list[dict]) -> None:
        self._pending.extend(interactions)

    def poll(self) -> list[dict]:
        out, self._pending = self._pending, []
        return out


def make(kind: str = "auto", domain: str | None = None,
         server: str | None = None, log=print) -> OASTClient:
    """kind: auto | interactsh | static | none"""
    if kind == "none":
        return OASTClient()
    if kind == "static" or (kind == "auto" and domain):
        c = StaticOASTClient(domain or "")
        log(f"[oast] static domain {c.domain or '(none)'}")
        return c
    c = InteractshClient(server=server)
    if c.available:
        log(f"[oast] interactsh ready: {c.domain}")
    else:
        log("[oast] unavailable -- blind classes will be SKIPPED, not guessed. "
            "Install: go install -v "
            "github.com/projectdiscovery/interactsh/cmd/interactsh-client@latest")
    return c
