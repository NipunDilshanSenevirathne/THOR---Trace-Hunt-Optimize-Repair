"""
OAuth 2.0 / OIDC engine, built against RFC 9700 (Best Current Practice).

Each test maps to a stated requirement, and each has an observable outcome.
RFC 9700 is unusually good for this because its requirements are phrased as
things a server MUST or MUST NOT do, which is exactly what a test needs.

What is tested, and the requirement behind it:

  redirect_uri      exact string matching is REQUIRED except for localhost
                    ports in native apps. Anything else accepted is a finding.
  PKCE downgrade    a server MUST NOT accept a code_verifier where no
                    code_challenge was presented.
  state             one-time CSRF token bound to the user agent; absent or
                    unvalidated state is a finding.
  code reuse        authorization codes MUST be single-use.
  code binding      a code MUST be bound to the client and redirect_uri it
                    was issued for.
  mix-up            issuer identification (RFC 9207) or per-issuer redirect
                    URIs are required for multi-AS clients.

Deliberately NOT done here: nothing that completes an authorization for an
account the operator does not control. Every probe uses the operator's own
session, and the engine reports "accepted / rejected", never a stolen token.
"""

from __future__ import annotations

import json
import re
import secrets
from dataclasses import dataclass, field
from urllib.parse import parse_qs, urlencode, urlsplit, urlunsplit

from .db import DB
from .net import Client, Request
from .oracles import OracleHit
from .scope import Scope, ScopeViolation

_AUTHZ_HINT = re.compile(
    r"(?i)/(oauth2?|authorize|authorization|connect/authorize|"
    r"as/authorization|v1/authorize|openid)/?")
_TOKEN_HINT = re.compile(r"(?i)/(oauth2?/token|token|connect/token|v1/token)/?$")

_DISCOVERY_PATHS = [
    "/.well-known/openid-configuration",
    "/.well-known/oauth-authorization-server",
]


@dataclass
class Flow:
    authorize_url: str = ""
    token_url: str = ""
    client_id: str = ""
    redirect_uri: str = ""
    scope: str = ""
    response_type: str = "code"
    state: str = ""
    code_challenge: str = ""
    code_challenge_method: str = ""
    nonce: str = ""
    issuer: str = ""
    extras: dict = field(default_factory=dict)

    def complete(self) -> bool:
        return bool(self.authorize_url and self.client_id and self.redirect_uri)


def discover(db: DB, scope: Scope, corpus: str, client: Client,
             log=print) -> list[Flow]:
    """Recover the flow from captured traffic, then enrich from discovery."""
    flows: dict[str, Flow] = {}

    for r in db.q("SELECT url, method, body, resp_body FROM requests "
                  "WHERE corpus=?", corpus):
        u = r["url"]
        p = urlsplit(u)
        if _AUTHZ_HINT.search(p.path or "") and p.query:
            q = {k: v[0] for k, v in parse_qs(p.query).items()}
            if "client_id" not in q:
                continue
            f = Flow(
                authorize_url=urlunsplit(p._replace(query="", fragment="")),
                client_id=q.get("client_id", ""),
                redirect_uri=q.get("redirect_uri", ""),
                scope=q.get("scope", ""),
                response_type=q.get("response_type", "code"),
                state=q.get("state", ""),
                code_challenge=q.get("code_challenge", ""),
                code_challenge_method=q.get("code_challenge_method", ""),
                nonce=q.get("nonce", ""),
                extras={k: v for k, v in q.items()
                        if k not in ("client_id", "redirect_uri", "scope",
                                     "response_type", "state", "nonce",
                                     "code_challenge", "code_challenge_method")},
            )
            flows[f.authorize_url + f.client_id] = f
        if _TOKEN_HINT.search(p.path or ""):
            for f in flows.values():
                if not f.token_url:
                    f.token_url = urlunsplit(p._replace(query="", fragment=""))

    # discovery documents fill in what the capture missed
    hosts = {urlsplit(f.authorize_url).netloc for f in flows.values()}
    for host in hosts:
        for path in _DISCOVERY_PATHS:
            url = f"https://{host}{path}"
            try:
                resp = client.send(Request("GET", url, {}, None, identity="oauth"))
            except Exception:
                continue
            if resp.status != 200:
                continue
            try:
                doc = resp.json()
            except Exception:
                continue
            log(f"[oauth] discovery at {url}")
            for f in flows.values():
                if urlsplit(f.authorize_url).netloc != host:
                    continue
                f.token_url = f.token_url or doc.get("token_endpoint", "")
                f.issuer = doc.get("issuer", "")
            db.note(host, "manual", f"oauth discovery: {json.dumps(doc)[:1500]}")
            break

    out = [f for f in flows.values() if f.complete()]
    log(f"[oauth] {len(out)} usable flow(s) recovered from corpus")
    return out


def _authz_url(f: Flow, **overrides) -> str:
    q = {
        "client_id": f.client_id,
        "redirect_uri": f.redirect_uri,
        "response_type": f.response_type,
    }
    if f.scope:
        q["scope"] = f.scope
    if f.state:
        q["state"] = f.state
    if f.nonce:
        q["nonce"] = f.nonce
    if f.code_challenge:
        q["code_challenge"] = f.code_challenge
        q["code_challenge_method"] = f.code_challenge_method or "S256"
    q.update(f.extras)
    for k, v in overrides.items():
        if v is None:
            q.pop(k, None)
        else:
            q[k] = v
    p = urlsplit(f.authorize_url)
    return urlunsplit(p._replace(query=urlencode(q)))


def _redirect_variants(redirect_uri: str, log=print) -> list[tuple[str, str]]:
    """
    Candidate redirect_uris. RFC 9700 requires exact matching, so ANY of
    these being accepted is a deviation. The evil host is a domain we do not
    control and never will be served by -- we only observe whether the
    authorization server agrees to redirect there.
    """
    p = urlsplit(redirect_uri)
    host, path = p.netloc, p.path or "/"
    evil = "oauth-redirect-probe.example"
    return [
        (f"{p.scheme}://{evil}/cb", "wholly different host"),
        (f"{p.scheme}://{host}.{evil}/cb", "suffix-append bypass"),
        (f"{p.scheme}://{evil}/{host}/cb", "host in path"),
        (f"{p.scheme}://{evil}#@{host}/cb", "fragment confusion"),
        (f"{p.scheme}://{host}@{evil}/cb", "userinfo confusion"),
        (f"{p.scheme}://{host}{path}/../../evil", "path traversal in redirect"),
        (f"{p.scheme}://{host}{path}?next=https://{evil}/", "open-redirect chain param"),
        (redirect_uri + "/..;/evil", "semicolon traversal"),
        (redirect_uri + "%2f%2e%2e%2fevil", "encoded traversal"),
        (redirect_uri + "&x=1", "extra parameter appended"),
        (f"{p.scheme}://{host}:1337{path}", "port substitution"),
        (f"http://{host}{path}" if p.scheme == "https" else f"https://{host}{path}",
         "scheme downgrade"),
    ]


def _location(resp) -> str:
    return resp.headers.get("location", "") or resp.headers.get("Location", "")


def _accepted_redirect(resp, candidate: str) -> bool:
    """
    The server accepted the redirect_uri if it either redirects to it, or
    returns a login page rather than an error. A 400 naming the redirect_uri
    is the correct, secure behaviour.
    """
    loc = _location(resp)
    cand_host = urlsplit(candidate).netloc.split("@")[-1]
    if resp.status in (301, 302, 303, 307, 308) and loc:
        if cand_host and cand_host in loc:
            return True
    if resp.status == 200:
        body = resp.text[:4000].lower()
        if any(k in body for k in ("invalid redirect", "redirect_uri_mismatch",
                                   "invalid_request", "unauthorized_client",
                                   "invalid client")):
            return False
        # a login/consent page means the server was happy with the parameters
        if any(k in body for k in ("password", "sign in", "log in", "consent",
                                   "authorize", "continue")):
            return True
    return False


def _rec(db: DB, kind: str, req: Request, resp, hit: OracleHit | None,
         ident: str = "oauth") -> None:
    sig = req.signature()
    if db.seen_signature(sig):
        return
    db.ex(
        "INSERT INTO experiments (signature, kind, as_identity, method, url, "
        "body, status, resp_sha256, resp_len, elapsed_ms, verdict, score, detail, "
        "dest_address) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        sig, kind, ident, req.method, req.url,
        (req.body or b"").decode("utf-8", "replace")[:8000],
        resp.status, resp.sha256, len(resp.body), resp.elapsed_ms,
        "leak" if hit and hit.confidence >= 0.55 else "inconclusive",
        hit.confidence if hit else 0.0,
        json.dumps({"reasons": [hit.signal] if hit else [],
                    "oracle": hit.oracle if hit else None,
                    "shared_values": [], "pii": [],
                    "detail": hit.detail if hit else {}}),
        getattr(resp, "address", "") or "")


def run(db: DB, scope: Scope, corpus: str, log=print) -> dict:
    out = {"flows": 0, "redirect_bypass": 0, "no_state": 0, "no_pkce": 0,
           "pkce_downgrade": 0, "code_reuse": 0, "weak_state": 0}

    with Client(scope) as client:
        flows = discover(db, scope, corpus, client, log=log)
        out["flows"] = len(flows)
        if not flows:
            log("[oauth] no OAuth flows in corpus -- browse a login flow "
                "through Burp and re-import")
            return out

        for f in flows:
            log(f"[oauth] flow client_id={f.client_id[:24]} "
                f"redirect={f.redirect_uri}")

            # ---- 1. state parameter present and non-trivial --------------
            if not f.state:
                out["no_state"] += 1
                log("[oauth] no state parameter observed in the flow")
                db.note(f.authorize_url, "manual",
                        "OAuth flow carries no state parameter -- CSRF "
                        "protection for the callback is absent (RFC 9700)")
            elif len(f.state) < 12 or re.fullmatch(r"[01]+|\d+", f.state):
                out["weak_state"] += 1
                log(f"[oauth] state looks weak/predictable: {f.state[:24]!r}")
                db.note(f.authorize_url, "manual",
                        f"OAuth state parameter is short or low-entropy "
                        f"({f.state[:24]!r})")

            # ---- 2. PKCE present for a public client ---------------------
            if not f.code_challenge:
                out["no_pkce"] += 1
                log("[oauth] no code_challenge -- PKCE not in use")
                db.note(f.authorize_url, "manual",
                        "OAuth authorization request carries no "
                        "code_challenge; RFC 9700 requires PKCE for public "
                        "clients")
            elif (f.code_challenge_method or "plain").lower() == "plain":
                log("[oauth] PKCE method is 'plain' (S256 expected)")
                db.note(f.authorize_url, "manual",
                        "PKCE code_challenge_method is 'plain'; the verifier "
                        "is exposed in the authorization request")

            # ---- 3. redirect_uri exact matching --------------------------
            for candidate, why in _redirect_variants(f.redirect_uri):
                url = _authz_url(f, redirect_uri=candidate,
                                 state=secrets.token_hex(8))
                req = Request("GET", url, {}, None, identity="oauth")
                try:
                    resp = client.send(req)
                except (ScopeViolation, Exception):
                    continue
                hit = None
                if _accepted_redirect(resp, candidate):
                    out["redirect_bypass"] += 1
                    hit = OracleHit(
                        "oauth:redirect_uri",
                        f"authorization server accepted a non-registered "
                        f"redirect_uri via {why} ({candidate}); RFC 9700 "
                        f"requires exact string matching. Response "
                        f"{resp.status}"
                        + (f" -> {_location(resp)[:120]}" if _location(resp) else ""),
                        0.85,
                        {"technique": why, "candidate": candidate,
                         "status": resp.status, "location": _location(resp)[:300]})
                    log(f"[oauth] REDIRECT BYPASS  {why}: {candidate}")
                _rec(db, "oauth", req, resp, hit)

            # ---- 4. PKCE downgrade ---------------------------------------
            if f.code_challenge:
                url = _authz_url(f, code_challenge=None,
                                 code_challenge_method=None,
                                 state=secrets.token_hex(8))
                req = Request("GET", url, {}, None, identity="oauth")
                try:
                    resp = client.send(req)
                    accepted = _accepted_redirect(resp, f.redirect_uri) or (
                        resp.status == 200 and "invalid" not in resp.text[:2000].lower())
                    hit = None
                    if accepted:
                        out["pkce_downgrade"] += 1
                        hit = OracleHit(
                            "oauth:pkce_downgrade",
                            "authorization request without code_challenge was "
                            "accepted although the client normally sends one; "
                            "an attacker can strip PKCE and replay a stolen "
                            "code (RFC 9700)",
                            0.80, {"status": resp.status})
                        log("[oauth] PKCE DOWNGRADE accepted")
                    _rec(db, "oauth", req, resp, hit)
                except Exception:
                    pass

            # ---- 5. response_type / response_mode tampering --------------
            for rt, why in (("token", "implicit flow still enabled"),
                            ("code token", "hybrid flow enabled"),
                            ("code id_token", "hybrid flow enabled")):
                url = _authz_url(f, response_type=rt,
                                 state=secrets.token_hex(8))
                req = Request("GET", url, {}, None, identity="oauth")
                try:
                    resp = client.send(req)
                except Exception:
                    continue
                hit = None
                if _accepted_redirect(resp, f.redirect_uri):
                    hit = OracleHit(
                        "oauth:response_type",
                        f"{why}: response_type={rt!r} accepted for a client "
                        f"that normally uses {f.response_type!r}. Implicit and "
                        f"hybrid flows return tokens in the URL fragment, "
                        f"where they leak through history and referrers",
                        0.60, {"response_type": rt})
                    log(f"[oauth] response_type={rt} accepted ({why})")
                _rec(db, "oauth", req, resp, hit)

            # ---- 6. authorization code reuse -----------------------------
            code = _find_code(db, corpus)
            if code and f.token_url:
                body = urlencode({
                    "grant_type": "authorization_code", "code": code,
                    "redirect_uri": f.redirect_uri, "client_id": f.client_id})
                hdr = {"Content-Type": "application/x-www-form-urlencoded"}
                statuses = []
                for attempt in range(2):
                    req = Request("POST", f.token_url, dict(hdr), body.encode(),
                                  identity=f"oauth:reuse{attempt}")
                    try:
                        resp = client.send(req)
                    except Exception:
                        break
                    statuses.append(resp.status)
                    hit = None
                    if attempt == 1 and resp.status == 200 and \
                            "access_token" in resp.text:
                        out["code_reuse"] += 1
                        hit = OracleHit(
                            "oauth:code_reuse",
                            "an authorization code was redeemed twice and the "
                            "token endpoint issued a token both times; codes "
                            "MUST be single-use (RFC 9700)",
                            0.90, {"statuses": statuses})
                        log("[oauth] CODE REUSE accepted")
                    _rec(db, "oauth", req, resp, hit, f"oauth:reuse{attempt}")

    log(f"[oauth] {json.dumps(out)}")
    return out


def _find_code(db: DB, corpus: str) -> str | None:
    """An authorization code the operator already obtained, from their own flow."""
    for r in db.q("SELECT url, resp_headers FROM requests WHERE corpus=?", corpus):
        m = re.search(r"[?&#]code=([A-Za-z0-9._\-]{16,})", r["url"] or "")
        if m:
            return m.group(1)
        loc = ""
        try:
            loc = (json.loads(r["resp_headers"] or "{}").get("location")
                   or json.loads(r["resp_headers"] or "{}").get("Location") or "")
        except Exception:
            pass
        m = re.search(r"[?&#]code=([A-Za-z0-9._\-]{16,})", loc)
        if m:
            return m.group(1)
    return None
