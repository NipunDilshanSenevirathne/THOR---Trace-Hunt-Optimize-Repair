"""
Detection oracles.

The single biggest source of AI-generated bug bounty slop is payload-echo
detection: send `' OR 1=1--`, see it reflected, call it SQL injection. That
finds nothing and reports everything.

Every oracle here answers a question about *behaviour* instead:

  differential  -- did a semantically meaningful change move the response in
                   a way the control mutation did not?
  boolean       -- do a true-condition and a false-condition mutation produce
                   systematically different responses?
  timing        -- does a delay payload produce a delay, repeatably, with the
                   control staying fast?
  oast          -- did the server actually make an outbound request we
                   observed? (the only non-inferential oracle here)
  error         -- did the mutation surface a stack trace, a database error,
                   or a template engine error that the baseline did not?
  reflection    -- is input reflected in a context where it changes parsing
                   (not merely present in the body)?

A payload appearing in a response is never, on its own, a finding.
"""

from __future__ import annotations

import re
import statistics
from dataclasses import dataclass, field

from .diff import Normalised

# --- error fingerprints: engine-specific, not generic "error" ----------
_DB_ERRORS = [
    ("mysql",      re.compile(r"(?i)(SQL syntax.*MySQL|MySqlException|"
                              r"valid MySQL result|com\.mysql\.jdbc)")),
    ("postgres",   re.compile(r"(?i)(PostgreSQL.*ERROR|PSQLException|"
                              r"pg_query\(\)|unterminated quoted string)")),
    ("mssql",      re.compile(r"(?i)(Microsoft SQL Native Client|"
                              r"SqlException|Unclosed quotation mark|"
                              r"ODBC SQL Server Driver)")),
    ("oracle",     re.compile(r"(?i)(ORA-\d{5}|Oracle error|OracleException)")),
    ("sqlite",     re.compile(r"(?i)(SQLite/JDBCDriver|sqlite3\.OperationalError|"
                              r"SQLITE_ERROR|no such column)")),
    ("mongo",      re.compile(r"(?i)(MongoError|E11000 duplicate key|"
                              r"\$where.*not allowed)")),
]

_TEMPLATE_ERRORS = [
    ("jinja2",     re.compile(r"(?i)(jinja2\.exceptions|TemplateSyntaxError|"
                              r"UndefinedError)")),
    ("freemarker", re.compile(r"(?i)(FreeMarker template error|"
                              r"freemarker\.core)")),
    ("velocity",   re.compile(r"(?i)(org\.apache\.velocity)")),
    ("twig",       re.compile(r"(?i)(Twig\\\\Error|Twig_Error)")),
    ("erb",        re.compile(r"(?i)(ActionView::Template::Error)")),
]

_STACK_TRACES = [
    ("java",       re.compile(r"\bat [\w.$]+\([\w]+\.java:\d+\)")),
    ("python",     re.compile(r'File "[^"]+", line \d+, in ')),
    ("node",       re.compile(r"\bat [\w.<>]+ \([^)]+:\d+:\d+\)")),
    ("php",        re.compile(r"(?i)(Fatal error:|Warning:).*on line \d+")),
    ("dotnet",     re.compile(r"(?i)(System\.\w+Exception|Stack Trace:)")),
    ("go",         re.compile(r"goroutine \d+ \[running\]:")),
    ("ruby",       re.compile(r"\.rb:\d+:in `")),
]

_DESERIAL = [
    ("java_serial", re.compile(r"(?i)(java\.io\.(Invalid|Optional)?"
                               r"(Object|Stream)?Exception|ClassNotFoundException)")),
    ("pickle",      re.compile(r"(?i)(_pickle\.UnpicklingError|"
                               r"pickle\.UnpicklingError)")),
    ("yaml",        re.compile(r"(?i)(yaml\.constructor\.ConstructorError)")),
]

_FILE_DISCLOSURE = [
    ("passwd",     re.compile(r"root:[x*]:0:0:")),
    ("shadow",     re.compile(r"root:[$!*]")),
    ("win_ini",    re.compile(r"(?i)\[(fonts|extensions)\]")),
    ("hosts",      re.compile(r"(?m)^\s*127\.0\.0\.1\s+localhost")),
    ("env_file",   re.compile(r"(?m)^[A-Z_]{3,}=(?!\s*$).+")),
    ("php_source", re.compile(r"<\?php\s")),
    ("ssh_key",    re.compile(r"-----BEGIN (RSA |OPENSSH )?PRIVATE KEY-----")),
]

_CLOUD_METADATA = re.compile(
    r"(?i)(ami-id|instance-identity|iam/security-credentials|"
    r"\"AccessKeyId\"|computeMetadata|metadata\.google)")


@dataclass
class OracleHit:
    oracle: str               # which oracle fired
    signal: str               # what specifically was observed
    confidence: float         # 0..1
    detail: dict = field(default_factory=dict)


# ---------------------------------------------------------------- error

def error_oracle(baseline: Normalised, probe: Normalised) -> list[OracleHit]:
    """
    Did the mutation surface an engine error the baseline did not?

    The baseline comparison is what matters: an app that always shows a stack
    trace is misconfigured, not injectable. An app that shows one *only* for
    our mutation is parsing our input.
    """
    hits = []
    b, p = baseline.text or "", probe.text or ""

    for group, patterns, conf, label in [
        ("sqli", _DB_ERRORS, 0.80, "database error"),
        ("ssti", _TEMPLATE_ERRORS, 0.75, "template engine error"),
        ("deserial", _DESERIAL, 0.70, "deserialisation error"),
        ("trace", _STACK_TRACES, 0.45, "stack trace"),
    ]:
        for name, pat in patterns:
            if pat.search(p) and not pat.search(b):
                hits.append(OracleHit(
                    oracle=f"error:{group}",
                    signal=f"{label} ({name}) appeared only under mutation",
                    confidence=conf,
                    detail={"engine": name,
                            "excerpt": _excerpt(p, pat)},
                ))

    for name, pat in _FILE_DISCLOSURE:
        if pat.search(p) and not pat.search(b):
            hits.append(OracleHit(
                oracle="error:file_disclosure",
                signal=f"file content signature '{name}' in response",
                confidence=0.90,
                detail={"kind": name, "excerpt": _excerpt(p, pat)},
            ))

    if _CLOUD_METADATA.search(p) and not _CLOUD_METADATA.search(b):
        hits.append(OracleHit(
            oracle="error:cloud_metadata",
            signal="cloud instance metadata reflected in response",
            confidence=0.95,
            detail={"excerpt": _excerpt(p, _CLOUD_METADATA)},
        ))

    return hits


def _excerpt(text: str, pat: re.Pattern, pad: int = 90) -> str:
    m = pat.search(text)
    if not m:
        return ""
    a, b = max(0, m.start() - pad), min(len(text), m.end() + pad)
    return text[a:b].replace("\n", " ")


# ------------------------------------------------------------- boolean

def boolean_oracle(baseline: Normalised, true_resp: Normalised,
                   false_resp: Normalised) -> list[OracleHit]:
    """
    Blind injection. Send a condition that is always true and one that is
    always false. If the app's response tracks the truth value, our input is
    reaching a evaluator.

    Crucially, both mutations are the *same shape* -- so any difference is
    attributable to the condition, not to the syntax.
    """
    same_as_base = _similar(baseline, true_resp)
    differs = not _similar(true_resp, false_resp)

    if differs and same_as_base:
        return [OracleHit(
            oracle="boolean",
            signal="true-condition matched baseline while false-condition "
                   "diverged -- input is being evaluated server-side",
            confidence=0.80,
            detail={
                "baseline_status": baseline.status,
                "true_status": true_resp.status, "true_len": true_resp.length,
                "false_status": false_resp.status, "false_len": false_resp.length,
            },
        )]
    if differs:
        return [OracleHit(
            oracle="boolean",
            signal="true and false conditions produced different responses",
            confidence=0.45,
            detail={"true_len": true_resp.length, "false_len": false_resp.length},
        )]
    return []


def _similar(a: Normalised, b: Normalised, tol: float = 0.03) -> bool:
    if a.status != b.status:
        return False
    if a.shape and a.shape == b.shape:
        return True
    if not a.length and not b.length:
        return True
    hi = max(a.length, b.length) or 1
    return abs(a.length - b.length) / hi <= tol


# -------------------------------------------------------------- timing

def timing_oracle(control_ms: list[float], delay_ms: list[float],
                  expected_delay: float) -> list[OracleHit]:
    """
    Time-based blind injection, done properly.

    Requires repeated measurement of both arms. A single slow response is
    network noise; a consistent delay that scales with the requested sleep is
    a finding. We demand: median delay >= 80% of requested, and the control's
    spread must not explain it.
    """
    if len(control_ms) < 3 or len(delay_ms) < 3:
        return []

    c_med = statistics.median(control_ms)
    d_med = statistics.median(delay_ms)
    c_sd = statistics.pstdev(control_ms) or 1.0
    observed = d_med - c_med

    if observed < expected_delay * 0.8:
        return []
    z = observed / c_sd
    if z < 4:
        return []
    # every delayed request must beat every control request
    if min(delay_ms) <= max(control_ms):
        return []

    return [OracleHit(
        oracle="timing",
        signal=f"requested {expected_delay:.0f}ms delay produced "
               f"{observed:.0f}ms consistent delay (z={z:.1f}, "
               f"{len(delay_ms)} trials, no overlap with control)",
        confidence=0.85,
        detail={"control_median": round(c_med, 1),
                "delay_median": round(d_med, 1),
                "control_sd": round(c_sd, 1),
                "trials": len(delay_ms)},
    )]


# ---------------------------------------------------------- differential

def differential_oracle(baseline: Normalised, probe: Normalised,
                        control: Normalised | None = None) -> list[OracleHit]:
    """
    Did this mutation change behaviour in a way an inert control did not?

    The control is the same field mutated to a *harmless* value of the same
    type. If both the payload and the control move the response identically,
    the app is just reacting to "a different value", not to our payload.
    """
    hits = []
    changed = not _similar(baseline, probe)
    if not changed:
        return hits

    control_also_changed = control is not None and not _similar(baseline, control)
    if control_also_changed and _similar(probe, control):
        return hits   # ordinary input-dependent behaviour, not a signal

    conf = 0.35 if control is None else 0.55
    why = []
    if probe.status != baseline.status:
        why.append(f"status {baseline.status} -> {probe.status}")
        # A 4xx where the baseline was 2xx is usually the application
        # correctly rejecting malformed input. That is the opposite of a
        # finding, so it is heavily discounted rather than reported.
        if 400 <= probe.status < 500 and baseline.status < 400:
            conf -= 0.30
            why[-1] += " (input rejected -- likely correct validation)"
        else:
            conf += 0.10
    if baseline.length and probe.length:
        ratio = abs(probe.length - baseline.length) / max(baseline.length, 1)
        if ratio > 0.25:
            why.append(f"body size changed {ratio*100:.0f}%")
            conf += 0.05
    new_keys = probe.keys - baseline.keys
    if new_keys:
        why.append(f"new response fields: {sorted(new_keys)[:6]}")
        conf += 0.10
    if probe.pii_keys - baseline.pii_keys:
        why.append(f"new PII fields: {sorted(probe.pii_keys - baseline.pii_keys)}")
        conf += 0.20

    if not why:
        return hits
    hits.append(OracleHit(
        oracle="differential",
        signal="; ".join(why) + (" (inert control did not reproduce this)"
                                 if control is not None else ""),
        confidence=min(conf, 0.95),
        detail={"baseline_status": baseline.status, "probe_status": probe.status,
                "baseline_len": baseline.length, "probe_len": probe.length},
    ))
    return hits


# --------------------------------------------------------- reflection

_DANGEROUS_CONTEXT = [
    ("html_tag",    re.compile(r"<[^>]*{MARK}[^>]*>")),
    ("script_body", re.compile(r"<script[^>]*>[^<]*{MARK}", re.I | re.S)),
    ("attr_unquoted", re.compile(r"<[a-z]+[^>]+=\s*{MARK}", re.I)),
    ("js_string",   re.compile(r"['\"][^'\"]*{MARK}[^'\"]*['\"]\s*[;,)\]]")),
    ("url_context", re.compile(r"(?:href|src|action)\s*=\s*[\"']?[^\"'>]*{MARK}", re.I)),
]


def reflection_oracle(probe_text: str, marker: str,
                      content_type: str = "",
                      breaking_chars: str = "<>\"'") -> list[OracleHit]:
    """
    Reflection only matters if it lands somewhere that changes parsing AND
    the characters that would break out survive unencoded.

    A JSON response that contains the marker is not XSS -- the browser will
    never parse it as markup. Requiring an HTML-ish content type removes the
    single largest source of false XSS reports.
    """
    if marker not in probe_text:
        return []
    ct = (content_type or "").lower()
    if ct and not any(t in ct for t in ("html", "xml", "xhtml", "svg")):
        return []
    if not ct and not re.search(r"<(html|body|div|p|span|script|a|input)\b",
                                probe_text[:8000], re.I):
        return []   # no content type and no markup: not a rendering context

    hits = []
    esc = re.escape(marker)

    survived = [c for c in breaking_chars
                if f"{marker}{c}" in probe_text or f"{c}{marker}" in probe_text]

    for name, tpl in _DANGEROUS_CONTEXT:
        pat = re.compile(tpl.pattern.replace("{MARK}", esc), tpl.flags)
        if pat.search(probe_text):
            hits.append(OracleHit(
                oracle="reflection",
                signal=f"input reflected in {name} context"
                       + (f", unencoded: {survived}" if survived else
                          " (breaking chars appear encoded)"),
                confidence=0.70 if survived else 0.25,
                detail={"context": name, "unencoded_chars": survived},
            ))
    if not hits:
        hits.append(OracleHit(
            oracle="reflection",
            signal="input reflected in body but not in a parsing-relevant context",
            confidence=0.10,
            detail={"unencoded_chars": survived},
        ))
    return hits


# ---------------------------------------------------------------- oast

# --------------------------------------------------- business invariants

_NEG_NUM = re.compile(r"-\d+(\.\d+)?")


def invariant_oracle(baseline: Normalised, probe: Normalised,
                     roles: set[str], sent_value) -> list[OracleHit]:
    """
    Business-logic violations that return HTTP 200 and look structurally
    normal. The differential oracle misses these precisely because nothing
    "went wrong" -- the app cheerfully computed a nonsense answer.

    This is the class that pays well and that generic scanners never find,
    because finding it requires knowing what the numbers *mean*.
    """
    hits = []
    if probe.status not in (200, 201, 202):
        return hits

    # a value field accepted a negative and the response carries a negative
    if "money" in roles or "limit" in roles:
        base_neg = set(_NEG_NUM.findall(baseline.text or ""))
        probe_negs = _NEG_NUM.findall(probe.text or "")
        if probe_negs and not base_neg:
            hits.append(OracleHit(
                oracle="invariant:negative",
                signal=f"server accepted {sent_value!r} and returned a "
                       f"negative value in a {'/'.join(sorted(roles))} field "
                       f"-- the baseline response contained none",
                confidence=0.75,
                detail={"sent": str(sent_value)[:60],
                        "negatives_in_response": probe_negs[:5]},
            ))

    # the value we sent was echoed back as the *computed* result unchanged,
    # i.e. no server-side recalculation happened
    if "money" in roles and isinstance(sent_value, (int, float)):
        for key in ("total", "amount", "price", "balance", "subtotal"):
            m = re.search(rf'"{key}"\s*:\s*(-?\d+(?:\.\d+)?)', probe.text or "")
            if m:
                try:
                    got = float(m.group(1))
                except ValueError:
                    continue
                if got < 0:
                    hits.append(OracleHit(
                        oracle="invariant:negative_total",
                        signal=f"'{key}' computed as {got} after sending "
                               f"{sent_value!r} -- no lower bound enforced",
                        confidence=0.85,
                        detail={"field": key, "computed": got,
                                "sent": sent_value},
                    ))
                break

    # a state field moved to a privileged/terminal value we supplied
    if "state" in roles or "privilege" in roles:
        sv = str(sent_value).strip('"')
        # A real state value is a short token. Long filler strings and
        # generated noise are type-confusion payloads being echoed, not a
        # state transition -- reporting those is how a tool earns a
        # reputation for slop.
        plausible = (2 < len(sv) <= 40
                     and re.fullmatch(r"[\w .\-]+", sv) is not None
                     and len(set(sv)) > 2)
        if plausible and f'"{sv}"' in (probe.text or "") \
                and f'"{sv}"' not in (baseline.text or ""):
            hits.append(OracleHit(
                oracle="invariant:state",
                signal=f"client-supplied {'/'.join(sorted(roles))} value "
                       f"{sv!r} is reflected as the stored state; the "
                       f"baseline response did not contain it",
                confidence=0.70,
                detail={"value": sv},
            ))

    return hits


def oast_oracle(interactions: list[dict], token: str) -> list[OracleHit]:
    """
    The only oracle that proves rather than infers: the server made an
    outbound request we observed. No false positives are possible here --
    either the callback arrived or it did not.
    """
    mine = [i for i in interactions if token in str(i.get("full-id", ""))
            or token in str(i.get("unique-id", ""))]
    if not mine:
        return []
    kinds = {i.get("protocol", "?") for i in mine}
    src = {i.get("remote-address", "?") for i in mine}
    return [OracleHit(
        oracle="oast",
        signal=f"target made {len(mine)} outbound interaction(s) "
               f"({'/'.join(sorted(kinds))}) from {sorted(src)[:3]} "
               f"-- server-side request confirmed",
        confidence=1.0,
        detail={"count": len(mine), "protocols": sorted(kinds),
                "sources": sorted(src)[:5]},
    )]


def best(hits: list[OracleHit]) -> OracleHit | None:
    return max(hits, key=lambda h: h.confidence) if hits else None
