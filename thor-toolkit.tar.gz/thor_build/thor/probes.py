"""
Additional detectors: tenant isolation, prototype pollution, open redirect,
upload, WebSocket, source maps.

Prototype pollution deserves a note. The obvious technique -- polluting a
property that breaks the app -- is a denial of service against a live target
and must never be used on a program. Gareth Heyes' black-box research
supplies techniques that alter only *configuration* properties, so the
effect is observable but harmless: JSON spacing, an unusual status code,
an extra exposed CORS header. Those are what this implements, and each is
cleaned up immediately afterwards.
"""

from __future__ import annotations

import json
import re
import secrets
from urllib.parse import parse_qs, urlencode, urlsplit, urlunsplit

from . import engine
from .db import DB
from .diff import normalise
from .net import Client, Request
from .oracles import OracleHit
from .scope import Scope, ScopeViolation


def _rec(db: DB, kind: str, ident: str, req: Request, resp,
         hit: OracleHit | None) -> None:
    sig = req.signature()
    if db.seen_signature(sig):
        return
    db.ex(
        "INSERT INTO experiments (signature, kind, as_identity, method, url, "
        "body, status, resp_sha256, resp_len, elapsed_ms, verdict, score, detail, "
        "dest_address) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        sig, kind, ident, req.method, req.url,
        (req.body or b"").decode("utf-8", "replace")[:8000],
        resp.status, resp.sha256, len(resp.body), resp.elapsed_ms,
        "leak" if hit and hit.confidence >= 0.55 else "inconclusive",
        hit.confidence if hit else 0.0,
        json.dumps({"reasons": [hit.signal] if hit else [],
                    "oracle": hit.oracle if hit else None,
                    "shared_values": [], "pii": [],
                    "detail": hit.detail if hit else {}}),
        getattr(resp, "address", "") or "")


# ==================================================== tenant isolation

_TENANT_PARAM = re.compile(
    r"(?i)^(x-)?(tenant|org|organisation|organization|workspace|account|"
    r"company|customer|merchant|team|project|group|realm|site|shop|store)"
    r"[-_]?(id|uuid|key|slug|code)?$")


def tenant(db: DB, scope: Scope, corpus: str, log=print) -> dict:
    """
    Cross-tenant access is the highest-value authorisation class: one swap
    crosses an entire customer boundary, and it is routinely unprotected
    because the scoping value is treated as "internal".

    This builds the tenant matrix explicitly rather than relying on the
    generic object-reference swapper, because tenant keys often live in
    headers the generic engine leaves alone.
    """
    from . import identity as ident_mod
    idents = {n: (dict(i.headers), i.tenant)
              for n, i in ident_mod.load_all(db).items()}
    tenants = {t for _, t in idents.values() if t}
    if len(tenants) < 2:
        log("[tenant] need identities in at least two tenants: "
            "thor identity add userB --tenant other")
        return {"tenants": len(tenants)}

    out = {"tenants": len(tenants), "tested": 0, "crossed": 0, "stale": 0}
    rows = db.q("SELECT * FROM requests WHERE corpus=? AND status IN "
                "(200,201,206)", corpus)

    with Client(scope) as client:
        for r in rows:
            headers = json.loads(r["headers"] or "{}")
            url = r["url"]
            body = r["body"] or ""

            # find every tenant-shaped value in this request
            slots = []
            for hk, hv in headers.items():
                if _TENANT_PARAM.match(hk):
                    slots.append(("header", hk, hv))
            p = urlsplit(url)
            for k, v in parse_qs(p.query).items():
                if _TENANT_PARAM.match(k):
                    slots.append(("query", k, v[0]))
            if body.strip().startswith("{"):
                try:
                    for k, v in json.loads(body).items():
                        if _TENANT_PARAM.match(k) and isinstance(v, (str, int)):
                            slots.append(("body", k, str(v)))
                except Exception:
                    pass
            if not slots:
                continue

            owner = r["identity"]
            owner_tenant = idents.get(owner, ({}, ""))[1]

            # Same rule as the authz engine: the control must be
            # contemporaneous with the probe, or object drift since capture
            # reads as "not the same object" and hides a real crossing.
            baseline, skip = engine.refresh_control(
                client, r["method"], url, headers, body,
                idents.get(owner, ({}, ""))[0], owner, log)
            if skip:
                log(f"[tenant] skip {r['method']} {url} — {skip}")
                out["stale"] += 1
                continue
            if baseline is None:
                baseline = normalise(r["status"], r["resp_body"] or "",
                                     headers.get("Content-Type", ""))

            for other, (oh, ot) in idents.items():
                if other == owner or not ot or ot == owner_tenant:
                    continue
                for loc, name, value in slots:
                    h = {k: v for k, v in headers.items()
                         if k.lower() not in ("authorization", "cookie",
                                              "content-length")}
                    h.update(oh)
                    nu, nb = url, body
                    if loc == "header":
                        h[name] = value            # keep OWNER's tenant value
                    elif loc == "query":
                        q = dict(parse_qs(p.query))
                        q[name] = [value]
                        nu = urlunsplit(p._replace(
                            query=urlencode({k: v[0] for k, v in q.items()})))
                    else:
                        try:
                            d = json.loads(body)
                            d[name] = value
                            nb = json.dumps(d)
                        except Exception:
                            continue

                    req = Request(r["method"], nu, h,
                                  nb.encode() if nb else None,
                                  identity=f"{other}@{ot}")
                    try:
                        resp = client.send(req)
                    except (ScopeViolation, Exception):
                        continue
                    out["tested"] += 1
                    probe = normalise(resp.status, resp.text,
                                      resp.headers.get("content-type", ""))
                    hit = None
                    shared = {s for s in (baseline.values & probe.values)
                              if len(s) >= 4}
                    if resp.status in (200, 201, 206) and not probe.denied and \
                            (probe.shape == baseline.shape or len(shared) >= 3):
                        out["crossed"] += 1
                        hit = OracleHit(
                            "tenant:crossed",
                            f"identity '{other}' in tenant '{ot}' received "
                            f"tenant '{owner_tenant}' data by supplying "
                            f"{loc}:{name}={value!r}; "
                            f"{len(shared)} owner-specific values returned",
                            0.90,
                            {"slot": f"{loc}:{name}", "victim_tenant": owner_tenant,
                             "attacker_tenant": ot,
                             "shared_values": sorted(shared)[:10]})
                        log(f"[tenant] CROSSED {ot} -> {owner_tenant} via "
                            f"{loc}:{name} @ {r['method']} {url}")
                    _rec(db, "tenant", other, req, resp, hit)

    log(f"[tenant] {json.dumps(out)}")
    if out["stale"]:
        log(f"[tenant] {out['stale']} request(s) skipped: the owner can no "
            f"longer reach their own object. Re-capture and re-run — a "
            f"cross-tenant probe against a dead session proves nothing.")
    return out


# ================================================== prototype pollution

# Non-destructive techniques only (PortSwigger black-box research).
# Each pollutes a *configuration* property, is observable, and is reverted.
_PP_TECHNIQUES = [
    {
        "name": "json spaces",
        "pollute": {"json spaces": 10},
        "clean": {"json spaces": 0},
        "detect": "spacing",
        "why": "Express json-spaces reformats JSON responses with indentation",
    },
    {
        "name": "status",
        "pollute": {"status": 510},
        "clean": {"status": 200},
        "detect": "status510",
        "why": "http-errors adopts a polluted status property",
    },
    {
        "name": "exposedHeaders",
        "pollute": {"exposedHeaders": ["x-hunt-pp-probe"]},
        "clean": {"exposedHeaders": []},
        "detect": "header",
        "why": "cors module reflects a polluted exposedHeaders list",
    },
]

_PP_VECTORS = ["__proto__", "constructor.prototype"]


def prototype_pollution(db: DB, scope: Scope, corpus: str, log=print) -> dict:
    """
    Server-side prototype pollution, detected without a denial of service.

    Never pollutes a property that could break request handling. Every probe
    is followed by a cleanup request restoring the default, and the result is
    re-checked so we know the cleanup landed.
    """
    rows = db.q("SELECT * FROM requests WHERE corpus=? AND method IN "
                "('POST','PUT','PATCH') AND status IN (200,201,202)", corpus)
    out = {"tested": 0, "polluted": 0, "cleanup_failed": 0}

    with Client(scope) as client:
        for r in rows:
            body = r["body"] or ""
            if not body.strip().startswith("{"):
                continue
            try:
                base = json.loads(body)
            except Exception:
                continue
            if not isinstance(base, dict):
                continue

            headers = {k: v for k, v in json.loads(r["headers"] or "{}").items()
                       if k.lower() != "content-length"}

            # The pre-pollution snapshot has to be taken now, not read from
            # the capture. The spacing oracle asks "did this response gain
            # indentation it did not have before" -- if "before" is a Burp
            # export that was pretty-printed on the way out, the comparison
            # is against formatting the server never sent and the detection
            # is dead. One GET per URL, before anything is polluted.
            probe = Request("GET", r["url"], dict(headers), None,
                            identity="protopollution")
            try:
                baseline_resp = (client.send(probe).text or "")
            except Exception:
                baseline_resp = r["resp_body"] or ""

            for vec in _PP_VECTORS:
                for tech in _PP_TECHNIQUES:
                    payload = dict(base)
                    _nest(payload, vec, tech["pollute"])
                    req = Request(r["method"], r["url"], dict(headers),
                                  json.dumps(payload).encode(),
                                  identity="protopollution")
                    try:
                        resp = client.send(req)
                    except (ScopeViolation, Exception):
                        continue
                    out["tested"] += 1

                    # observe on a FOLLOW-UP request -- pollution is global,
                    # so the effect shows on the next request, not this one
                    try:
                        after = client.send(probe)
                    except Exception:
                        after = resp

                    hit = _pp_detect(tech, baseline_resp, after)
                    if hit:
                        out["polluted"] += 1
                        log(f"[protopollution] DETECTED via {vec} / "
                            f"{tech['name']} @ {r['method']} {r['url']}")
                    _rec(db, "protopollution", "protopollution", req, resp, hit)

                    # always clean up, then verify the cleanup
                    clean = dict(base)
                    _nest(clean, vec, tech["clean"])
                    try:
                        client.send(Request(r["method"], r["url"], dict(headers),
                                            json.dumps(clean).encode(),
                                            identity="protopollution:cleanup"))
                        verify = client.send(probe)
                        if _pp_detect(tech, baseline_resp, verify):
                            out["cleanup_failed"] += 1
                            log(f"[protopollution] WARNING cleanup did not "
                                f"revert {tech['name']} on {r['url']} -- "
                                f"tell the program")
                            db.note(r["url"], "manual",
                                    f"prototype pollution via {vec}/"
                                    f"{tech['name']} did not revert after "
                                    f"cleanup; the process may need a restart")
                    except Exception:
                        out["cleanup_failed"] += 1

                    if hit:
                        break   # one confirmed technique per vector is enough

    log(f"[protopollution] {json.dumps(out)}")
    return out


def _nest(d: dict, path: str, value: dict) -> None:
    cur = d
    for part in path.split("."):
        cur = cur.setdefault(part, {})
    cur.update(value)


def _pp_detect(tech: dict, baseline_body: str, resp) -> OracleHit | None:
    kind = tech["detect"]
    if kind == "status510" and resp.status == 510:
        return OracleHit("protopollution",
                         f"polluted 'status' property surfaced as HTTP 510 on "
                         f"a subsequent request -- {tech['why']}",
                         0.90, {"technique": tech["name"]})
    if kind == "header":
        exposed = resp.headers.get("access-control-expose-headers", "")
        if "x-hunt-pp-probe" in exposed.lower():
            return OracleHit("protopollution",
                             f"polluted 'exposedHeaders' appeared in "
                             f"Access-Control-Expose-Headers -- {tech['why']}",
                             0.90, {"technique": tech["name"],
                                    "header": exposed[:200]})
    if kind == "spacing":
        body = resp.text or ""
        if body.strip().startswith(("{", "[")) and "\n          " in body \
                and "\n          " not in (baseline_body or ""):
            return OracleHit("protopollution",
                             f"JSON response gained 10-space indentation that "
                             f"the baseline did not have -- {tech['why']}",
                             0.85, {"technique": tech["name"]})
    return None


# ======================================================= open redirect

_REDIRECT_PARAM = re.compile(
    r"(?i)^(next|url|target|dest|destination|redirect|redirect_uri|redirect_url|"
    r"return|return_to|returnurl|continue|goto|link|out|to|forward|callback|"
    r"success_url|cancel_url|back|ref|r|u)$")

_EVIL = "hunt-redirect-probe.example"


def _redirect_payloads(host: str) -> list[tuple[str, str]]:
    return [
        (f"https://{_EVIL}/", "absolute external"),
        (f"//{_EVIL}/", "protocol-relative"),
        (f"/\\{_EVIL}/", "backslash confusion"),
        (f"https://{host}@{_EVIL}/", "userinfo confusion"),
        (f"https://{_EVIL}#{host}", "fragment confusion"),
        (f"https://{_EVIL}?{host}", "query confusion"),
        (f"/%09/{_EVIL}", "tab injection"),
        (f"https:/{_EVIL}", "missing slash"),
        (f"%68%74%74%70%73%3a%2f%2f{_EVIL}", "url-encoded scheme"),
    ]


def open_redirect(db: DB, scope: Scope, corpus: str, log=print) -> dict:
    """
    Low severity alone, but it is the first link in the OAuth-token-theft
    chain, so chain.py wants it recorded.
    """
    out = {"tested": 0, "vulnerable": 0}
    rows = db.q("SELECT DISTINCT url, method, headers FROM requests "
                "WHERE corpus=?", corpus)

    with Client(scope) as client:
        for r in rows:
            p = urlsplit(r["url"])
            q = parse_qs(p.query)
            targets = [k for k in q if _REDIRECT_PARAM.match(k)]
            if not targets:
                continue
            headers = {k: v for k, v in json.loads(r["headers"] or "{}").items()
                       if k.lower() != "content-length"}
            for param in targets:
                for payload, why in _redirect_payloads(p.netloc):
                    nq = {k: v[0] for k, v in q.items()}
                    nq[param] = payload
                    url = urlunsplit(p._replace(query=urlencode(nq)))
                    req = Request("GET", url, dict(headers), None,
                                  identity="redirect")
                    try:
                        resp = client.send(req)
                    except (ScopeViolation, Exception):
                        continue
                    out["tested"] += 1
                    loc = resp.headers.get("location", "")
                    hit = None
                    if resp.status in (301, 302, 303, 307, 308) and \
                            _EVIL in loc:
                        out["vulnerable"] += 1
                        hit = OracleHit(
                            "redirect:open",
                            f"parameter '{param}' redirects off-site via "
                            f"{why}: {resp.status} -> {loc[:160]}",
                            0.80, {"param": param, "technique": why,
                                   "location": loc[:300]})
                        log(f"[redirect] OPEN {param} via {why} @ {r['url']}")
                    elif _EVIL in (resp.text[:3000] or "") and \
                            re.search(r"(?i)(location\.href|window\.location|"
                                      r"meta[^>]+refresh)", resp.text[:5000]):
                        out["vulnerable"] += 1
                        hit = OracleHit(
                            "redirect:client_side",
                            f"parameter '{param}' reaches a client-side "
                            f"navigation sink via {why}",
                            0.65, {"param": param, "technique": why})
                    _rec(db, "redirect", "redirect", req, resp, hit)

    log(f"[redirect] {json.dumps(out)}")
    return out


# ============================================================ source maps

def sourcemaps(db: DB, scope: Scope, log=print) -> dict:
    """
    A published .map file hands you the original source: internal API routes,
    debug endpoints, feature flags, comments, and often internal hostnames.
    Cheap to check and routinely forgotten in production builds.
    """
    js = [r["url"] for r in db.q(
        "SELECT DISTINCT url FROM endpoints WHERE url LIKE '%.js'")]
    out = {"js_files": len(js), "maps_found": 0, "sources": 0, "routes": 0}
    if not js:
        log("[sourcemap] no JS files in inventory -- run thor recon first")
        return out

    route_re = re.compile(r"[\"'`](/(?:api|v\d|internal|admin|graphql)"
                          r"[a-zA-Z0-9_\-/{}:.$]{1,120})[\"'`]")
    found_routes: set[str] = set()

    with Client(scope) as client:
        for u in js[:500]:
            for candidate in (u + ".map",
                              re.sub(r"\.js$", ".js.map", u)):
                try:
                    r = client.send(Request("GET", candidate, {}, None,
                                            identity="sourcemap"))
                except (ScopeViolation, Exception):
                    continue
                if r.status != 200 or len(r.body) < 40:
                    continue
                try:
                    doc = r.json()
                except Exception:
                    continue
                if "sources" not in doc:
                    continue
                out["maps_found"] += 1
                srcs = doc.get("sources") or []
                contents = doc.get("sourcesContent") or []
                out["sources"] += len(srcs)
                log(f"[sourcemap] {candidate} -> {len(srcs)} original sources")
                db.note(candidate, "manual",
                        f"source map exposed: {len(srcs)} original files, "
                        f"e.g. {srcs[:8]}")
                for body in contents[:200]:
                    if not body:
                        continue
                    for m in route_re.finditer(body):
                        found_routes.add(m.group(1))
                break

    for route in sorted(found_routes):
        out["routes"] += 1
        db.note(route, "manual", "route recovered from source map")
    if found_routes:
        log(f"[sourcemap] {len(found_routes)} route(s) recovered from "
            f"original source — these never appear in the bundle")
    log(f"[sourcemap] {json.dumps(out)}")
    return out


# ============================================================== uploads

_UPLOAD_HINT = re.compile(r"(?i)(upload|import|attach|avatar|photo|image|"
                          r"document|file|media|asset)")

_UPLOAD_CASES = [
    ("hunt.svg", "image/svg+xml",
     b'<?xml version="1.0"?><svg xmlns="http://www.w3.org/2000/svg" '
     b'onload="/*huntprobe*/"><text>huntprobe</text></svg>',
     "SVG accepted -- scriptable markup served from your origin"),
    ("hunt.html", "text/html",
     b"<html><body>huntprobe</body></html>",
     "HTML accepted -- stored XSS if served inline from the app origin"),
    ("hunt.jpg", "image/jpeg",
     b"\xff\xd8\xff\xe0" + b"huntprobe" * 4,
     "baseline valid image (control)"),
    ("hunt.php.jpg", "image/jpeg",
     b"\xff\xd8\xff\xe0huntprobe",
     "double extension accepted"),
    ("../hunt-traversal.txt", "text/plain", b"huntprobe",
     "path traversal in filename accepted"),
]


def upload(db: DB, scope: Scope, corpus: str, log=print) -> dict:
    """
    Detection only: uploads a marker file and reports what the server
    accepted and how it serves it back. Never uploads executable server-side
    code.
    """
    rows = db.q("SELECT * FROM requests WHERE corpus=? AND method='POST'", corpus)
    cands = [r for r in rows
             if _UPLOAD_HINT.search(r["url"])
             or "multipart/form-data" in (r["headers"] or "")]
    out = {"endpoints": len(cands), "tested": 0, "accepted": 0}
    if not cands:
        log("[upload] no upload endpoints in corpus")
        return out

    with Client(scope) as client:
        for r in cands:
            headers = {k: v for k, v in json.loads(r["headers"] or "{}").items()
                       if k.lower() not in ("content-length", "content-type")}
            for fname, ctype, content, why in _UPLOAD_CASES:
                boundary = "----hunt" + secrets.token_hex(8)
                body = (
                    f"--{boundary}\r\n"
                    f'Content-Disposition: form-data; name="file"; '
                    f'filename="{fname}"\r\n'
                    f"Content-Type: {ctype}\r\n\r\n").encode() + content + \
                    f"\r\n--{boundary}--\r\n".encode()
                h = dict(headers)
                h["Content-Type"] = f"multipart/form-data; boundary={boundary}"
                req = Request("POST", r["url"], h, body, identity="upload")
                try:
                    resp = client.send(req)
                except (ScopeViolation, Exception):
                    continue
                out["tested"] += 1
                hit = None
                if resp.status in (200, 201, 202) and "huntprobe" not in why:
                    served = _served_url(resp.text)
                    out["accepted"] += 1
                    hit = OracleHit(
                        "upload:accepted",
                        f"{why}; server returned {resp.status}"
                        + (f" and the file is served at {served}" if served else ""),
                        0.70 if "control" not in why else 0.0,
                        {"filename": fname, "content_type": ctype,
                         "served_url": served})
                    if hit.confidence:
                        log(f"[upload] ACCEPTED {fname}: {why}")
                _rec(db, "upload", "upload", req, resp, hit)

    log(f"[upload] {json.dumps(out)}")
    return out


def _served_url(text: str) -> str:
    m = re.search(r'"(https?://[^"]{4,300}|/[^"]{4,300})"', text or "")
    return m.group(1) if m else ""
