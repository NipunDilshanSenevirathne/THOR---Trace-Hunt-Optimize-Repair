"""
The reasoning layer: application model, hypothesis space, information gain.

`thor reason` answers the question the review said the tool could not yet
answer: given everything observed, what is this application, which security
boundaries does it appear to have, and which untested hypothesis would teach
us the most per unit of risk?

Information gain is computed, not guessed:

    gain = uncertainty(arm) × boundary_weight × novelty × coverage_deficit
           ────────────────────────────────────────────────────────────────
                              cost × risk_penalty

  uncertainty       variance of the arm's Beta posterior. A 50/50 arm teaches
                    more than one that is 0/40 or 20/20.
  boundary_weight   crossing a tenant boundary beats crossing a user boundary
                    beats a reflected-input question.
  novelty           surface that appeared since the last snapshot.
  coverage_deficit  untested invariants on this surface.
  cost              observed requests-per-finding for that engine.
  risk_penalty      SENSITIVE and DESTRUCTIVE engines pay for their risk.

Every term is derived from data already in the database. Nothing here calls
a model.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from urllib.parse import urlsplit

from . import graph, invariants, learn, risk
from .db import DB

# How much a violated invariant in each family is worth knowing about.
BOUNDARY_WEIGHT = {
    "tenancy": 1.00,
    "authorization": 0.90,
    "token": 0.85,
    "workflow": 0.75,
    "injection": 0.80,
    "egress": 0.70,
    "logic": 0.70,
    "integrity": 0.65,
    "cache": 0.45,
    "navigation": 0.30,
}

RISK_PENALTY = {0: 1.0, 1: 1.0, 2: 1.15, 3: 1.6, 4: 3.0}


@dataclass
class Hypothesis:
    key: str
    statement: str
    engine: str
    invariant: str
    target: str
    evidence: list[str] = field(default_factory=list)
    experiment: str = ""
    predicted: str = ""
    falsifier: str = ""
    gain: float = 0.0
    components: dict = field(default_factory=dict)

    def render(self) -> str:
        lines = [f"{self.key}",
                 f"{self.statement}",
                 "",
                 "Evidence:"]
        lines += [f"  {e}" for e in self.evidence[:5]]
        lines += ["", f"Invariant:  {self.invariant}",
                  f"Experiment: {self.experiment}",
                  f"Predicted:  {self.predicted}",
                  f"Falsifier:  {self.falsifier}",
                  f"Information gain: {self.gain:.2f}"]
        return "\n".join(lines)


def _uncertainty(db: DB, engine: str, tech: str) -> tuple[float, str]:
    """Beta variance, normalised. Peaks at p=0.5 and falls as n grows."""
    arms = {a.key: a for a in learn.load_arms(db)}
    cands = [a for a in arms.values() if a.engine == engine]
    if not cands:
        return 1.0, "no history — maximum uncertainty"
    a = max(cands, key=lambda x: x.n)
    al, be = a.alpha, a.beta
    var = (al * be) / (((al + be) ** 2) * (al + be + 1))
    # variance of Beta(1,1) is 1/12; scale so a cold arm is 1.0
    u = min(1.0, var / (1 / 12))
    return u, f"{a.successes}/{a.n} observed, posterior variance {var:.4f}"


def _cost(db: DB, engine: str) -> tuple[float, str]:
    """Observed requests per leak for this engine, normalised."""
    rows = db.q("SELECT verdict FROM experiments WHERE kind=?", engine)
    if not rows:
        return 1.0, "no cost history"
    leaks = sum(1 for r in rows if r["verdict"] == "leak")
    if leaks == 0:
        return min(3.0, 1.0 + len(rows) / 200), f"{len(rows)} experiments, no hits"
    per = len(rows) / leaks
    return max(0.5, min(3.0, per / 40)), f"{per:.0f} requests per hit"


def _novelty(db: DB, target: str) -> tuple[float, str]:
    host = urlsplit(target).hostname or target.split("/")[0]
    row = db.one("SELECT anomaly_score, anomaly_reasons FROM assets WHERE host=?",
                 host)
    if not row or row["anomaly_score"] is None:
        return 1.0, ""
    reasons = row["anomaly_reasons"] or ""
    if "newly appeared" in reasons:
        return 1.5, "surface appeared since the last snapshot"
    score = float(row["anomaly_score"] or 0)
    return 1.0 + min(0.5, score / 40), f"anomaly score {score:.1f}"


def generate(db: DB, corpus: str, log=print) -> list[Hypothesis]:
    """
    Walk the graph and the invariant catalogue, and emit every untested
    combination as an explicit, falsifiable statement.
    """
    graph.ensure(db)
    invariants.install(db, log=lambda *a: None)
    invariants.evaluate(db, log=lambda *a: None)

    tech = "-"
    row = db.one("SELECT tech FROM assets WHERE tech NOT IN ('','[]') "
                 "ORDER BY anomaly_score DESC LIMIT 1")
    if row:
        try:
            t = json.loads(row["tech"] or "[]")
            tech = (t[0].lower() if t else "-")
        except Exception:
            pass

    hyps: list[Hypothesis] = []
    n = 0

    untested = {r["key"] for r in invariants.untested(db)}

    # --- 1. cross-tenant pairs the graph can actually name -----------------
    pairs = graph.cross_tenant_pairs(db)
    seen_pairs = set()
    for p in pairs[:40]:
        pk = (p["object_tenant"], p["identity_tenant"])
        if pk in seen_pairs:
            continue
        seen_pairs.add(pk)
        n += 1
        hyps.append(Hypothesis(
            key=f"H-{n:03d}",
            statement=(f"tenant isolation may be enforced at routing rather "
                       f"than at object retrieval: {p['object_key']} is scoped "
                       f"to '{p['object_tenant']}', and '{p['identity']}' "
                       f"belongs to '{p['identity_tenant']}'"),
            engine="tenant", invariant="tenancy.isolation",
            target=p["object_key"],
            evidence=[f"object {p['object_key']} scoped to {p['object_tenant']}",
                      f"identity {p['identity']} in {p['identity_tenant']}",
                      "both observed in the captured corpus"],
            experiment=(f"replay the owning request as '{p['identity']}' while "
                        f"keeping the object identifier"),
            predicted=f"{p['identity']} receives {p['object_tenant']} data",
            falsifier="an unauthenticated request also returns it (public)",
        ))

    # --- 2. client-supplied tenant hints -----------------------------------
    for prm in graph.find(db, "Parameter"):
        props = json.loads(prm["props"] or "{}")
        roles = props.get("roles") or []
        if "identity" not in roles:
            continue
        name = prm["label"]
        if not re.search(r"(?i)(tenant|org|account|workspace|company|customer)",
                         name):
            continue
        n += 1
        hyps.append(Hypothesis(
            key=f"H-{n:03d}",
            statement=(f"{name} may override server-derived tenant identity "
                       f"rather than being ignored"),
            engine="tenant", invariant="tenancy.server_derived",
            target=prm["key"].split("|")[0],
            evidence=[f"parameter {name} observed on {prm['key'].split('|')[0]}",
                      f"type {props.get('type')}, seen {props.get('seen')}x",
                      "tenant-specific responses observed on this route"],
            experiment=(f"send the owner's {name} value with a different "
                        f"identity's credentials"),
            predicted="the response follows the header, not the session",
            falsifier="the response follows the session and ignores the header",
        ))

    # --- 3. endpoints with object refs and no authz experiment yet ---------
    tested_routes = {r["url"] for r in db.q(
        "SELECT DISTINCT url FROM experiments WHERE kind IN ('authz','tenant')")}
    for ep in graph.endpoints_with_object_refs(db)[:60]:
        props = json.loads(ep["props"] or "{}")
        route = props.get("route", ep["key"])
        if any(route.split("?")[0] in t for t in tested_routes):
            continue
        n += 1
        hyps.append(Hypothesis(
            key=f"H-{n:03d}",
            statement=(f"{ep['key']} resolves an object by client-supplied "
                       f"identifier; ownership may not be checked"),
            engine="authz", invariant="authz.object_ownership",
            target=route,
            evidence=[f"endpoint accesses {props.get('observations', '?')} "
                      f"observed object(s)",
                      f"statuses observed: {props.get('statuses')}"],
            experiment="replay with a second identity, same object identifier",
            predicted="the second identity receives the owner's resource",
            falsifier="anonymous request also returns it, or the probe is denied",
        ))

    # --- 4. untested invariants with satisfied preconditions ---------------
    model = graph.model_summary(db)
    precondition_met = {
        "authz.field_level": model["endpoints"] > 0,
        "workflow.monotonic_state": model["workflows"] > 0,
        "workflow.single_use": model["workflows"] > 0,
        "token.signature_verified": bool(db.one(
            "SELECT 1 FROM requests WHERE headers LIKE '%eyJ%' LIMIT 1")),
        "acl.path_normalisation": bool(db.one(
            "SELECT 1 FROM requests WHERE status IN (401,403) LIMIT 1")),
        "prototype.integrity": bool(db.one(
            "SELECT 1 FROM requests WHERE method IN ('POST','PUT','PATCH') "
            "AND body LIKE '{%' LIMIT 1")),
    }
    for key, met in precondition_met.items():
        if key not in untested or not met:
            continue
        inv = invariants.BY_KEY.get(key)
        if not inv:
            continue
        n += 1
        hyps.append(Hypothesis(
            key=f"H-{n:03d}",
            statement=f"{inv.rule} — never tested on this target",
            engine=inv.engine, invariant=key, target="(application-wide)",
            evidence=[f"preconditions satisfied: {', '.join(inv.requires)}",
                      f"{model['endpoints']} endpoints modelled"],
            experiment=f"run the {inv.engine} engine",
            predicted="the invariant holds, or an oracle fires",
            falsifier=inv.description,
        ))

    # --- score every hypothesis --------------------------------------------
    for h in hyps:
        inv = invariants.BY_KEY.get(h.invariant)
        family = inv.family if inv else "authorization"
        w = BOUNDARY_WEIGHT.get(family, 0.5)
        u, u_why = _uncertainty(db, h.engine, tech)
        c, c_why = _cost(db, h.engine)
        nov, nov_why = _novelty(db, h.target)
        deficit = 1.3 if h.invariant in untested else 1.0
        rp = RISK_PENALTY.get(risk.ENGINE_RISK.get(h.engine, 2), 1.2)
        h.gain = round((u * w * nov * deficit) / (c * rp), 3)
        h.components = {
            "uncertainty": round(u, 3), "uncertainty_why": u_why,
            "boundary_weight": w, "family": family,
            "novelty": round(nov, 2), "novelty_why": nov_why,
            "coverage_deficit": deficit,
            "cost": round(c, 2), "cost_why": c_why,
            "risk_penalty": rp,
        }

    hyps.sort(key=lambda h: -h.gain)
    log(f"[reason] {len(hyps)} hypotheses generated")
    return hyps


def persist(db: DB, hyps: list[Hypothesis], log=print) -> int:
    learn.ensure(db)
    existing = {h["statement"] for h in db.q("SELECT statement FROM hypotheses")}
    n = 0
    for h in hyps:
        if h.statement in existing:
            continue
        learn.open_hypothesis(db, learn.Hypothesis(
            engine=h.engine, target=h.target, statement=h.statement,
            predicted=h.predicted, falsifier=h.falsifier,
            invariant=h.invariant,
            arm=learn.arm_key(h.engine, "-", "-",
                              learn.archetype_of(h.target))))
        n += 1
    log(f"[reason] {n} hypothesis/hypotheses recorded")
    return n


def report(db: DB, corpus: str, top: int = 8, log=print) -> str:
    """The `thor reason` output."""
    g = graph.model_summary(db)
    hyps = generate(db, corpus, log=lambda *a: None)
    viol = invariants.violated(db)
    unt = invariants.untested(db)

    out = []
    out.append("APPLICATION MODEL")
    out.append("─" * 60)
    out.append(f"  {g['identities']:>4} identities    "
               f"{g['roles']:>4} roles        {g['tenants']:>4} tenants")
    out.append(f"  {g['assets']:>4} assets        "
               f"{g['endpoints']:>4} endpoints    "
               f"{g['object_bearing_endpoints']:>4} object-bearing")
    out.append(f"  {g['objects']:>4} objects       "
               f"{g['parameters']:>4} parameters   "
               f"{g['workflows']:>4} workflows ({g['states']} states)")

    out.append("")
    out.append("SECURITY BOUNDARIES")
    out.append("─" * 60)
    fams = {}
    for r in db.q("SELECT family, status, COUNT(*) c FROM invariants "
                  "GROUP BY family, status"):
        fams.setdefault(r["family"], {})[r["status"]] = r["c"]
    for fam, st in sorted(fams.items()):
        bits = []
        if st.get("violated"):
            bits.append(f"{st['violated']} violated")
        if st.get("holds"):
            bits.append(f"{st['holds']} hold")
        if st.get("untested"):
            bits.append(f"{st['untested']} untested")
        out.append(f"  {fam:16} {', '.join(bits)}")

    if viol:
        out.append("")
        out.append("VIOLATED INVARIANTS")
        out.append("─" * 60)
        for v in viol[:10]:
            d = json.loads(v["detail"] or "{}")
            out.append(f"  ✗ [{v['severity']:8}] {v['key']}")
            out.append(f"      {v['rule']}")
            for rt in (d.get("routes") or [])[:3]:
                out.append(f"      at {rt}")

    out.append("")
    out.append("OPEN HYPOTHESES  (ranked by information gain)")
    out.append("─" * 60)
    if not hyps:
        out.append("  none — every modelled boundary has been tested")
    for h in hyps[:top]:
        out.append("")
        out.append(h.render())
        c = h.components
        out.append(f"  gain = ({c['uncertainty']} uncertainty × "
                   f"{c['boundary_weight']} {c['family']} × {c['novelty']} "
                   f"novelty × {c['coverage_deficit']} deficit) / "
                   f"({c['cost']} cost × {c['risk_penalty']} risk)")
        out.append(f"  uncertainty: {c['uncertainty_why']};  cost: {c['cost_why']}")

    if unt:
        out.append("")
        out.append(f"UNTESTED INVARIANTS ({len(unt)})")
        out.append("─" * 60)
        for u in unt[:12]:
            out.append(f"  · {u['key']:34} needs: "
                       f"{', '.join(invariants.BY_KEY[u['key']].requires)}"
                       if u["key"] in invariants.BY_KEY else f"  · {u['key']}")

    return "\n".join(out)
