"""
Recon pipeline. Orchestrates existing best-in-class tools into the DB.

Deliberately excludes amass (slow). Coverage comes from
subfinder + crt.sh + alterx permutations + dnsx brute, which runs in
minutes instead of hours.

Zero LLM calls. Zero tokens. Runs on cron.
"""

from __future__ import annotations

import json
import re
from urllib.parse import urlsplit

from . import tools
from .db import DB
from .net import Client, Request
from .scope import Scope


def crtsh(client: Client, domain: str) -> list[str]:
    """Certificate transparency. Often finds what subfinder's APIs miss."""
    try:
        r = client.send(Request("GET", f"https://crt.sh/?q=%25.{domain}&output=json"))
        if r.status != 200:
            return []
        rows = r.json()
    except Exception:
        return []
    out = set()
    for row in rows:
        for name in (row.get("name_value") or "").split("\n"):
            name = name.strip().lstrip("*.").lower()
            if name.endswith(domain):
                out.add(name)
    return sorted(out)


def run_recon(db: DB, scope: Scope, domain: str, *,
              brute: bool = True, ports: bool = False,
              crawl: bool = True, js: bool = True,
              log=print) -> dict:
    """Full passive+active surface map. Returns a stats dict."""
    stats: dict = {"domain": domain}

    # --- 1. passive enumeration ---------------------------------------
    log(f"[recon] passive enumeration for {domain}")
    subs: set[str] = set()
    subs |= set(tools.subfinder(domain))

    # crt.sh must go through the scope-aware client only if in scope;
    # it is third-party infra, so use a bare short-lived client instead.
    ct_scope = Scope(engagement=f"{scope.engagement}:ct",
                     allowed_hosts=["crt.sh"], max_rps=1, max_requests=5)
    with Client(ct_scope) as ctc:
        subs |= set(crtsh(ctc, domain))

    subs = {s for s in subs if s.endswith(domain)}
    log(f"[recon]   {len(subs)} subdomains from passive sources")
    stats["passive_subs"] = len(subs)

    # --- 2. permutation brute (alterx replaces amass) -----------------
    if brute and subs:
        log("[recon] permutation generation (alterx)")
        candidates = tools.alterx(sorted(subs))
        log(f"[recon]   {len(candidates)} permutation candidates")
        resolved = tools.dnsx(candidates)
        new = {r["host"] for r in resolved if r.get("host")}
        log(f"[recon]   {len(new - subs)} new hosts resolved")
        subs |= new
        stats["brute_new"] = len(new - set())

    # --- 3. resolve everything ----------------------------------------
    log("[recon] resolving")
    dns_rows = tools.dnsx(sorted(subs)) if subs else []
    dns_by_host = {r["host"]: r for r in dns_rows}
    stats["resolved"] = len(dns_rows)

    # --- 4. HTTP probe -------------------------------------------------
    log("[recon] probing HTTP")
    live = tools.httpx(sorted({r["host"] for r in dns_rows} or subs))
    log(f"[recon]   {len(live)} live hosts")
    stats["live"] = len(live)

    in_scope_urls = []
    for h in live:
        host = (h.get("host") or "").split(":")[0]
        if not scope.host_allowed(host):
            continue
        d = dns_by_host.get(host, {})
        db.upsert_asset(
            host,
            ip=h.get("ip"),
            port=h.get("port") or 443,
            scheme=h.get("scheme") or "https",
            status=h.get("status"),
            title=(h.get("title") or "")[:300],
            server=h.get("server"),
            tech=h.get("tech") or [],
            cname=h.get("cname") or d.get("cname"),
            content_length=h.get("content_length"),
            source="httpx",
        )
        if h.get("url"):
            in_scope_urls.append(h["url"])

    stats["in_scope"] = len(in_scope_urls)
    log(f"[recon]   {len(in_scope_urls)} in scope")

    # --- 5. ports (optional) -------------------------------------------
    if ports and in_scope_urls:
        log("[recon] port scan (naabu, top 1000)")
        hosts = [urlsplit(u).hostname for u in in_scope_urls]
        for row in tools.naabu([h for h in hosts if h]):
            if row["port"] not in (80, 443):
                db.note(row["host"], "manual", f"open port {row['port']}")
        stats["ports_scanned"] = len(hosts)

    # --- 6. URL corpus --------------------------------------------------
    urls: set[str] = set()
    if crawl and in_scope_urls:
        log("[recon] crawling (katana) + archives (gau)")
        urls |= set(tools.katana(in_scope_urls))
        urls |= {u for u in tools.gau(domain)}
        urls = {u for u in urls if scope.host_allowed(urlsplit(u).hostname or "")}
        urls = set(tools.uro(sorted(urls)))
        log(f"[recon]   {len(urls)} unique URLs")
        for u in urls:
            params = sorted(set(re.findall(r"[?&]([a-zA-Z0-9_\-\[\]\.]{1,40})=", u)))
            host = urlsplit(u).hostname or ""
            row = db.one("SELECT id FROM assets WHERE host=?", host)
            db.add_endpoint(
                u, "GET",
                asset_id=row["id"] if row else None,
                params=params,
                source="crawl",
                is_api=1 if re.search(r"/(api|v\d|graphql)/", u) else 0,
            )
    stats["urls"] = len(urls)

    # --- 7. JS intelligence ---------------------------------------------
    if js and urls:
        js_urls = sorted({u for u in urls if u.split("?")[0].endswith(".js")})
        log(f"[recon] analysing {len(js_urls)} JS files")
        with Client(scope) as c:
            intel, jstats = jsintel_run(c, js_urls)
        log(f"[recon]   {jstats['endpoints']} endpoints, "
            f"{jstats['secrets']} secret candidates, "
            f"{jstats['graphql_ops']} graphql ops")
        for ep in intel.endpoints:
            host = urlsplit(ep).hostname or ""
            if not scope.host_allowed(host):
                continue
            row = db.one("SELECT id FROM assets WHERE host=?", host)
            db.add_endpoint(ep, "GET", asset_id=row["id"] if row else None,
                            source="js",
                            is_api=1 if re.search(r"/(api|v\d|graphql)/", ep) else 0)
        for s in intel.secrets:
            host = urlsplit(s["source_url"]).hostname or ""
            row = db.one("SELECT id FROM assets WHERE host=?", host)
            db.conn.execute(
                "INSERT OR IGNORE INTO secrets "
                "(asset_id, kind, value_masked, value_sha256, source_url, context) "
                "VALUES (?,?,?,?,?,?)",
                (row["id"] if row else None, s["kind"], s["masked"],
                 s["sha256"], s["source_url"], s["context"]))
        db.conn.commit()
        for op in intel.graphql_ops:
            db.note(domain, "manual", f"graphql operation: {op}")
        stats.update({f"js_{k}": v for k, v in jstats.items()})

    log(f"[recon] done. {json.dumps(db.stats())}")
    return stats


def jsintel_run(client, js_urls):
    from .jsintel import fetch_and_analyse
    return fetch_and_analyse(client, js_urls)


def run_nuclei(db: DB, scope: Scope, severity: str = "critical,high",
               log=print) -> int:
    """Known-CVE pass. Low yield on mature programs -- run it, don't rely on it."""
    rows = db.q("SELECT scheme, host, port FROM assets WHERE status IS NOT NULL")
    urls = [f"{r['scheme']}://{r['host']}" for r in rows
            if scope.host_allowed(r["host"])]
    if not urls:
        return 0
    log(f"[nuclei] scanning {len(urls)} hosts at {severity}")
    hits = tools.nuclei(urls, severity=severity)
    for h in hits:
        db.note(h["matched"] or "", "manual",
                f"nuclei {h['severity']}: {h['name']} ({h['template']})")
    log(f"[nuclei] {len(hits)} hits")
    return len(hits)
