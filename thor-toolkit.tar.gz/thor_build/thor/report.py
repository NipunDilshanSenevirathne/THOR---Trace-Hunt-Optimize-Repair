"""
Report generation. Renders strictly from the evidence bundle.

If a claim has no evidence id behind it, it does not get written. That is
the whole design.
"""

from __future__ import annotations

import json
from pathlib import Path

from .db import DB
from .evidence import CWE, bundle, dedupe_notes
from . import runtime

TEMPLATE = """\
# {title}

**Severity:** {severity}{severity_basis}
**Asset:** {asset}
**Route:** `{route}`
**Class:** {cwe}
**Finding ID:** {fid} (fingerprint `{fp}`)

## Summary

{summary_text}

## Reproduction

{repro}

## Evidence

{evidence}

## Impact

{impact}

## Disproof performed

{disproof}

## Limitations

{limitations}

## Remediation

{remediation}

---
*Evidence bundle: `{bundle_path}` — contains `finding.json` (hashed
request/response records) and `replay.sh`.*
*Generated {ts} from deterministic response diffing. Every claim above
maps to an experiment id in the bundle.*
"""


def render(db: DB, finding_id: int, outdir: str | Path = "reports") -> Path:
    f = db.one("SELECT * FROM findings WHERE id=?", finding_id)
    if not f:
        raise SystemExit(f"No finding {finding_id}")

    ev_ids = json.loads(f["evidence_ids"] or "[]")
    exps = [db.one("SELECT * FROM experiments WHERE id=?", i) for i in ev_ids]
    exps = [e for e in exps if e]
    b = bundle(db, finding_id)

    # impact may be raw text or the AI brief's JSON
    impact_txt, remediation = _impact_and_fix(f)

    repro = _repro(db, exps)
    evidence = _evidence(db, exps)
    disproof = (
        "An unauthenticated request for the same resource was executed and did "
        "**not** return it, ruling out the resource simply being public."
        if f["disproof_done"] else
        "_Not executed for this finding — run `thor authz` with an `anon` "
        "identity configured before submitting._"
    )

    dupes = dedupe_notes(db, finding_id)
    summary = f["summary"] or ""
    if dupes:
        summary += "\n\n> **Local duplicate signals:** " + "; ".join(dupes)

    md = TEMPLATE.format(
        title=f["title"], severity=(f["severity"] or "").upper(),
        severity_basis=_severity_basis(db, finding_id),
        asset=f["asset"], route=f["route"],
        cwe=CWE.get(f["vuln_class"], f["vuln_class"]),
        fid=f["id"], fp=f["fingerprint"],
        summary_text=summary, repro=repro, evidence=evidence,
        impact=impact_txt, disproof=disproof, remediation=remediation,
        limitations=_limitations(db, f), bundle_path=b, ts=runtime.utcstamp(),
    )

    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    p = out / f"finding-{finding_id}-{f['vuln_class']}.md"
    p.write_text(md)
    return p


def _impact_and_fix(f) -> tuple[str, str]:
    raw = f["impact"] or ""
    try:
        d = json.loads(raw)
        parts = []
        if d.get("attack_narrative"):
            parts.append(d["attack_narrative"])
        if d.get("worst_case"):
            parts.append(f"\n**Worst case:** {d['worst_case']}")
        if d.get("scale_evidence"):
            parts.append(f"\n**Scale supported by evidence:** {d['scale_evidence']}")
        if d.get("cvss_vector"):
            parts.append(f"\n**CVSS 3.1:** `{d['cvss_vector']}` — "
                         f"{d.get('cvss_justification', '')}")
        return "\n".join(parts), d.get("remediation", "_See evidence._")
    except Exception:
        return raw or "_See evidence._", "_Enforce server-side ownership checks._"


def _repro(db: DB, exps) -> str:
    if not exps:
        return "_No experiments attached._"
    e = exps[0]
    base = (db.one("SELECT * FROM requests WHERE id=?", e["base_request_id"])
            if e["base_request_id"] else None)
    lines = []
    if base:
        # Report the control the verdict was computed against, not the
        # captured response. Printing "owner: 46 bytes / attacker: 75 bytes"
        # when both in fact returned the same 75-byte object reads as two
        # different objects, and a triager closes the report on that line.
        try:
            c_status, c_len = e["control_status"], e["control_len"]
        except (IndexError, KeyError):
            c_status = c_len = None
        status = c_status if c_status is not None else base["status"]
        length = c_len if c_len is not None else base["resp_len"]
        lines += [
            f"1. Authenticate as **{base['identity']}** and issue:",
            f"   ```",
            f"   {base['method']} {base['url']}",
            f"   ```",
            f"   Observed: `{status}`, {length} bytes.",
        ]
    lines += [
        f"{'2' if base else '1'}. Authenticate as **{e['as_identity']}** "
        f"(a separate account with no relationship to the above) and issue the "
        f"*same* request, changing only the credentials:",
        f"   ```",
        f"   {e['method']} {e['url']}",
        f"   ```",
        f"   Observed: `{e['status']}`, {e['resp_len']} bytes "
        f"(sha256 `{(e['resp_sha256'] or '')[:16]}…`).",
        "",
        "Expected behaviour: the second request should be denied.",
    ]
    return "\n".join(lines)


def _evidence(db: DB, exps) -> str:
    rows = ["| exp | identity | method | status | bytes | sha256 | score |",
            "|-----|----------|--------|--------|-------|--------|-------|"]
    detail_blocks = []
    for e in exps:
        rows.append(
            f"| {e['id']} | `{e['as_identity']}` | {e['method']} | {e['status']} | "
            f"{e['resp_len']} | `{(e['resp_sha256'] or '')[:12]}` | {e['score']:.2f} |")
        d = json.loads(e["detail"] or "{}")
        if d.get("reasons"):
            detail_blocks.append(
                f"\n**Experiment {e['id']} — why this is a leak:**\n"
                + "\n".join(f"- {r}" for r in d["reasons"]))
        if d.get("shared_values"):
            vals = ", ".join(f"`{v[:40]}`" for v in d["shared_values"][:10])
            detail_blocks.append(
                f"\nValues unique to the owning account that appeared in the "
                f"unauthorised response: {vals}")
    return "\n".join(rows) + "\n" + "\n".join(detail_blocks)


def render_all(db: DB, outdir: str | Path = "reports", log=print) -> list[Path]:
    out = []
    for f in db.q("SELECT id FROM findings WHERE status IN "
                  "('candidate','confirmed')"):
        p = render(db, f["id"], outdir)
        out.append(p)
        log(f"[report] {p}")
    return out


def _severity_basis(db: DB, finding_id: int) -> str:
    """
    Say why the severity is what it is, if it was raised above the class
    baseline. An unexplained severity is one a triager argues with and
    wins; a named rule is one they can accept or push back on.
    """
    from . import chain
    try:
        esc = chain.escalations_for(db, finding_id)
    except Exception:
        return ""
    if not esc:
        return ""
    bits = [f"`{e['rule']}` ({e['from_sev']}→{e['to_sev']}): {e['reason']}"
            for e in esc]
    return ("\n**Severity basis:** raised above the baseline for this class "
            "by:\n" + "\n".join(f"  - {b}" for b in bits))


def _limitations(db: DB, f) -> str:
    """
    State plainly what this finding does not establish.

    A report that only argues one way reads as advocacy. Naming the limits
    is what makes the rest of it credible, and it stops a triager finding
    the gap first.
    """
    from . import states
    out = []
    try:
        gates = {g["gate"]: g for g in states.gate_results(db, f["id"])}
    except Exception:
        gates = {}

    if not f["disproof_done"]:
        out.append("The anonymous control was not executed for this finding, "
                   "so the resource being simply public is not ruled out.")
    ev = 0
    try:
        ev = len(json.loads(f["evidence_ids"] or "[]"))
    except Exception:
        pass
    if ev <= 1:
        out.append("A single experiment supports this finding; it has not "
                   "been shown to reproduce across multiple objects.")
    if any(not g["passed"] for g in gates.values()):
        failed = sorted(g for g, r in gates.items() if not r["passed"])
        out.append(f"Gates not satisfied at the time of writing: "
                   f"{', '.join(failed)}.")
    dd = None
    try:
        dd = db.one("SELECT verdict FROM finding_dedupe WHERE finding_id=?",
                    f["id"])
    except Exception:
        pass
    if not dd:
        out.append("No duplicate check has been recorded for this finding.")
    elif dd["verdict"] == "grouped":
        out.append("This is one manifestation of a shared root cause; it "
                   "should be reported together with the others rather than "
                   "as an independent issue.")

    out.append("Impact beyond what the evidence above shows has not been "
               "tested; no data belonging to real users was retrieved "
               "beyond what the reproduction displays.")
    return "\n".join(f"- {x}" for x in out)
