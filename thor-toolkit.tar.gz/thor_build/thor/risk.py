"""
Risk levels and the destructive-action gate.

Every engine declares what it can do to a live target. The gate is checked
before an engine runs, not inside it, so a new engine cannot forget.

  0 PASSIVE     no packets to the target (archives, CT logs, parsing)
  1 SAFE        reads only: GET/HEAD, no state change
  2 ACTIVE      writes with benign values, reversible
  3 SENSITIVE   writes that may create records, send mail, alter state
  4 DESTRUCTIVE deletes, charges, irreversible

scope.yaml controls the ceiling:
  destructive: false      -> max level 2
  sensitive: true         -> max level 3
  destructive: true       -> max level 4
"""

from __future__ import annotations

from dataclasses import dataclass

PASSIVE, SAFE, ACTIVE, SENSITIVE, DESTRUCTIVE = 0, 1, 2, 3, 4

NAMES = {0: "PASSIVE", 1: "SAFE", 2: "ACTIVE", 3: "SENSITIVE", 4: "DESTRUCTIVE"}

# Declared risk for every engine in the system.
ENGINE_RISK: dict[str, int] = {
    "recon": SAFE,
    "jsintel": SAFE,
    "sourcemap": SAFE,
    "schema": PASSIVE,
    "anomaly": PASSIVE,
    "authz": SAFE,          # replays reads as other identities
    "graphql": SAFE,
    "cors": SAFE,
    "pathacl": SAFE,
    "redirect": SAFE,
    "tenant": SAFE,
    "jwt": ACTIVE,          # sends forged tokens
    "cache": ACTIVE,        # detection only, never poisons
    "protopollution": ACTIVE,   # non-destructive techniques only
    "fuzz": ACTIVE,
    "oauth": ACTIVE,
    "bfla": SENSITIVE,      # method swaps can write
    "massassign": SENSITIVE,
    "workflow": SENSITIVE,  # drives state transitions
    "upload": SENSITIVE,
    "websocket": ACTIVE,
    "race": DESTRUCTIVE,    # genuinely duplicates operations
    "smuggling": DESTRUCTIVE,   # can desync a shared front-end. Not implemented.
}

# Engines that are DECLARED above but have no implementation, with the
# reason. Declaring a risk level for an engine that does not exist tells
# the operator THOR can test something it cannot, and `thor risk` listed
# both of these as available for months.
#
# A unit test asserts this set exactly matches the engines with no
# runnable entry point, so the table cannot drift back into claiming
# capabilities that are not there.
NOT_IMPLEMENTED: dict[str, str] = {
    "smuggling": (
        "deliberately unimplemented: desynchronising a shared front-end "
        "affects other users of the service, which no bug bounty scope "
        "authorises"),
    "websocket": (
        "not implemented: the corpus is HTTP traffic, so there is no "
        "WebSocket handshake to model. Capture WS frames and this becomes "
        "worth building; until then an engine here would test nothing"),
}


def implemented(engine: str) -> bool:
    return engine not in NOT_IMPLEMENTED


@dataclass
class Gate:
    ceiling: int
    reasons: list[str]

    def allows(self, engine: str) -> bool:
        return ENGINE_RISK.get(engine, ACTIVE) <= self.ceiling

    def explain(self, engine: str) -> str:
        r = ENGINE_RISK.get(engine, ACTIVE)
        if r <= self.ceiling:
            return f"{engine} ({NAMES[r]}) permitted"
        return (f"{engine} is {NAMES[r]}; scope ceiling is "
                f"{NAMES[self.ceiling]}. Set the matching flag in scope.yaml "
                f"if the program genuinely permits it.")


def gate_for(scope) -> Gate:
    ceiling = ACTIVE
    reasons = ["default ceiling is ACTIVE"]
    if getattr(scope, "sensitive", False):
        ceiling = SENSITIVE
        reasons = ["scope.sensitive = true"]
    if getattr(scope, "destructive", False):
        ceiling = DESTRUCTIVE
        reasons = ["scope.destructive = true"]
    return Gate(ceiling, reasons)


def filter_engines(scope, engines: list[str], log=print) -> list[str]:
    g = gate_for(scope)
    out = []
    for e in engines:
        if g.allows(e):
            out.append(e)
        else:
            log(f"[risk] SKIP {g.explain(e)}")
    return out
