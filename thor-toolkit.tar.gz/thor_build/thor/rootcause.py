"""
Root-cause grouping.

Twenty IDORs behind one broken middleware is ONE bug. Submitting them
separately gets nineteen closed as duplicates and annoys the triager.
Submitting them as one report with twenty manifestations is a bigger
finding than any of them alone.

This is the second half of the duplicate problem — the first half is
checking the program's disclosures (a Claude Code step, /dedupe), and this
is the half that is computable: clustering your *own* findings by the cause
they share.

Deterministic. The AI writes the prose afterwards, from this grouping.
"""

from __future__ import annotations

import json
import re
from collections import defaultdict
from dataclasses import dataclass, field
from urllib.parse import urlsplit

from .db import DB

SCHEMA = """
CREATE TABLE IF NOT EXISTS rootcauses (
  id INTEGER PRIMARY KEY,
  fingerprint TEXT UNIQUE,
  title TEXT,
  hypothesis TEXT,        -- what single defect explains all members
  vuln_class TEXT,
  severity TEXT,
  member_ids TEXT,        -- json list of finding ids
  shared_traits TEXT,     -- json: what they have in common
  confidence REAL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
"""


def ensure(db: DB) -> None:
    db.conn.executescript(SCHEMA)
    db.conn.commit()


# Route families: /api/v2/orders/{id}/items -> api|orders|items
def route_family(route: str) -> tuple[str, ...]:
    path = urlsplit("//" + route if "://" not in route else route).path or route
    segs = [s for s in re.split(r"[/]", path) if s]
    segs = [s for s in segs
            if s not in ("{id}", "api") and not re.fullmatch(r"v\d+", s)]
    return tuple(segs[:3])


def _prefix(route: str, depth: int = 2) -> str:
    path = urlsplit("//" + route if "://" not in route else route).path or route
    segs = [s for s in path.split("/") if s]
    return "/" + "/".join(segs[:depth])


@dataclass
class RootCause:
    title: str
    hypothesis: str
    vuln_class: str
    severity: str
    members: list[int] = field(default_factory=list)
    traits: dict = field(default_factory=dict)
    confidence: float = 0.0

    def fingerprint(self) -> str:
        return f"rc:{self.vuln_class}:{'-'.join(map(str, sorted(self.members)))}"


SEV_ORDER = ["info", "low", "medium", "high", "critical"]


def _max_sev(sevs: list[str]) -> str:
    idx = max((SEV_ORDER.index(s) if s in SEV_ORDER else 1) for s in sevs)
    return SEV_ORDER[idx]


def _escalate(sev: str) -> str:
    i = SEV_ORDER.index(sev) if sev in SEV_ORDER else 1
    return SEV_ORDER[min(i + 1, len(SEV_ORDER) - 1)]


def analyse(db: DB, log=print) -> list[RootCause]:
    """
    Group findings whose evidence is consistent with one shared defect.

    Each rule states the defect it is proposing, not just the similarity --
    "these four share a route prefix" is a coincidence; "these four are all
    served by the middleware mounted at /api/billing, which does not check
    ownership" is a root cause.
    """
    ensure(db)
    findings = [dict(r) for r in db.q(
        "SELECT * FROM findings WHERE vuln_class NOT IN ('chain')")]
    if len(findings) < 2:
        return []

    causes: list[RootCause] = []

    # --- rule 1: same class, same route prefix -> shared middleware --------
    by_prefix: dict[tuple, list[dict]] = defaultdict(list)
    for f in findings:
        host = (f["asset"] or "").split(":")[0]
        by_prefix[(f["vuln_class"], host, _prefix(f["route"] or ""))].append(f)

    for (cls, host, prefix), group in by_prefix.items():
        if len(group) < 2:
            continue
        causes.append(RootCause(
            title=f"Missing {_defect_for(cls)} on everything under {prefix}",
            hypothesis=(
                f"All {len(group)} manifestations are {cls} findings on routes "
                f"under {prefix} on {host}. A single control mounted at that "
                f"prefix — middleware, a decorator, a gateway rule — is the "
                f"most economical explanation. Fixing each route individually "
                f"would leave the cause in place; the next route added under "
                f"{prefix} would inherit it."),
            vuln_class=cls,
            severity=_escalate(_max_sev([g["severity"] for g in group])),
            members=[g["id"] for g in group],
            traits={"prefix": prefix, "host": host, "class": cls,
                    "routes": [g["route"] for g in group]},
            confidence=0.75,
        ))

    # --- rule 2: same class across UNRELATED subsystems -> shared data layer
    # "Unrelated" means distinct top-level resource families. Three routes
    # under /api/billing are one subsystem, and rule 1 already explains them
    # with a shared middleware -- the more precise claim. Only genuinely
    # unrelated families justify blaming the data-access layer.
    by_class: dict[tuple, list[dict]] = defaultdict(list)
    for f in findings:
        host = (f["asset"] or "").split(":")[0]
        by_class[(f["vuln_class"], host)].append(f)

    for (cls, host), group in by_class.items():
        fams = {route_family(g["route"] or "") for g in group}
        tops = {f[0] for f in fams if f}
        prefixes = {_prefix(g["route"] or "") for g in group}
        if len(group) >= 3 and len(tops) >= 3 and len(prefixes) >= 2:
            causes.append(RootCause(
                title=f"Application-wide {_defect_for(cls)} on {host}",
                hypothesis=(
                    f"{len(group)} {cls} findings span {len(tops)} unrelated "
                    f"top-level resource families "
                    f"({', '.join(sorted(tops)[:5])}) across "
                    f"{len(prefixes)} route prefixes. That breadth rules out "
                    f"a per-route mistake or a single middleware. The likely "
                    f"cause is a shared data-access layer or base controller "
                    f"that resolves objects by identifier without scoping the "
                    f"query to the caller."),
                vuln_class=cls,
                severity="critical",
                members=[g["id"] for g in group],
                traits={"host": host, "families": ["/".join(f) for f in fams],
                        "prefixes": sorted(prefixes)},
                confidence=0.80,
            ))

    # --- rule 3: same injection class, different endpoints -> shared sink --
    inj = {"sqli", "nosql", "ssti", "cmdi", "path"}
    for (cls, host), group in by_class.items():
        if cls in inj and len(group) >= 2:
            causes.append(RootCause(
                title=f"Shared unsanitised sink reachable from "
                      f"{len(group)} endpoints on {host}",
                hypothesis=(
                    f"The same {cls} behaviour appears at {len(group)} "
                    f"endpoints. Rather than {len(group)} separate coding "
                    f"errors, one helper function is most likely building the "
                    f"{_sink_for(cls)} from raw input, and every caller "
                    f"inherits the flaw."),
                vuln_class=cls,
                severity=_escalate(_max_sev([g["severity"] for g in group])),
                members=[g["id"] for g in group],
                traits={"host": host, "routes": [g["route"] for g in group]},
                confidence=0.70,
            ))

    # --- rule 4: authz + bfla + massassign on one host -> ownership model --
    for host in {(f["asset"] or "").split(":")[0] for f in findings}:
        hf = [f for f in findings if (f["asset"] or "").split(":")[0] == host]
        classes = {f["vuln_class"] for f in hf}
        if len({"authz", "bfla", "massassign"} & classes) >= 2:
            members = [f["id"] for f in hf
                       if f["vuln_class"] in ("authz", "bfla", "massassign")]
            causes.append(RootCause(
                title=f"Object ownership is not modelled server-side on {host}",
                hypothesis=(
                    f"Findings on {host} span {sorted(classes & {'authz','bfla','massassign'})}. "
                    f"Read authorisation, write authorisation and attribute "
                    f"authorisation are failing together, which points at the "
                    f"absence of an ownership concept rather than three "
                    f"missing checks. The application appears to authenticate "
                    f"requests but never asks whether the authenticated "
                    f"principal is entitled to the object."),
                vuln_class="authz",
                severity="critical",
                members=members,
                traits={"host": host, "classes": sorted(classes)},
                confidence=0.85,
            ))

    # deduplicate: keep the largest cluster when member sets overlap heavily
    causes.sort(key=lambda c: (-len(c.members), -c.confidence))
    kept: list[RootCause] = []
    claimed: set[int] = set()
    for c in causes:
        ms = set(c.members)
        if len(ms & claimed) / max(len(ms), 1) > 0.6:
            continue
        kept.append(c)
        claimed |= ms

    log(f"[rootcause] {len(kept)} root cause(s) explaining "
        f"{len(claimed)} of {len(findings)} findings")
    return kept


def _defect_for(cls: str) -> str:
    return {
        "authz": "object-level authorisation",
        "bfla": "function-level authorisation",
        "massassign": "attribute whitelisting",
        "graphql": "field-level authorisation",
        "pathacl": "gateway path normalisation",
        "sqli": "query parameterisation",
        "nosql": "query parameterisation",
        "ssti": "template input separation",
        "path": "path canonicalisation",
        "xss": "output encoding",
        "logic": "server-side invariant enforcement",
        "cors": "origin allow-listing",
    }.get(cls, f"{cls} control")


def _sink_for(cls: str) -> str:
    return {"sqli": "SQL query", "nosql": "database query",
            "ssti": "template string", "cmdi": "shell command",
            "path": "file path"}.get(cls, "sink")


MEMBERSHIP_SCHEMA = """
-- Grouping is metadata about a finding, not a stage in its life.
CREATE TABLE IF NOT EXISTS finding_rootcauses (
  finding_id  INTEGER NOT NULL,
  rootcause_id INTEGER NOT NULL,
  is_primary  INTEGER DEFAULT 0,
  added_at    TEXT DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (finding_id, rootcause_id)
);
"""


def persist(db: DB, causes: list[RootCause], log=print) -> int:
    """
    Record root causes and which findings manifest them.

    This used to write `findings.status = 'grouped'`. That was wrong twice
    over: it bypassed `states.advance()`, the only writer of status, and
    'grouped' is not a state in the lifecycle — so a grouped finding fell
    out of the state machine and could never reach report_ready again.
    Running `thor rootcause` quietly broke every finding it touched.

    Grouping is metadata. It goes in a relation table, and the finding
    keeps whatever state its evidence earned.
    """
    ensure(db)
    db.conn.executescript(MEMBERSHIP_SCHEMA)
    from . import states

    n = 0
    grouped: set[int] = set()
    for c in causes:
        fp = c.fingerprint()
        row = db.one("SELECT id FROM rootcauses WHERE fingerprint=?", fp)
        if row:
            rc_id = row["id"]
        else:
            rc_id = db.ex(
                "INSERT INTO rootcauses (fingerprint, title, hypothesis, "
                "vuln_class, severity, member_ids, shared_traits, confidence) "
                "VALUES (?,?,?,?,?,?,?,?)",
                fp, c.title, c.hypothesis, c.vuln_class, c.severity,
                json.dumps(sorted(c.members)), json.dumps(c.traits),
                c.confidence)
            n += 1
            log(f"[rootcause] {c.severity.upper():8} {c.title}  "
                f"({len(c.members)} manifestations)")
        for m in sorted(c.members):
            db.ex("INSERT OR IGNORE INTO finding_rootcauses "
                  "(finding_id, rootcause_id) VALUES (?,?)", m, rc_id)
            states.record_dedupe(
                db, m, "grouped", group_id=rc_id,
                basis=f"manifestation of root cause {rc_id}: {c.title}")
            grouped.add(m)

    # Analysis also concludes something about the findings it did NOT
    # group: they stand alone. That is a per-finding determination, which
    # is what the dedupe gate needs — previously the gate passed for every
    # finding the moment the rootcauses table existed.
    for r in db.q("SELECT id FROM findings"):
        if r["id"] not in grouped:
            states.record_dedupe(
                db, r["id"], "unique",
                basis="root-cause analysis ran and placed this finding in "
                      "no group")
    return n


def members_of(db: DB, rootcause_id: int) -> list[int]:
    db.conn.executescript(MEMBERSHIP_SCHEMA)
    return [r["finding_id"] for r in db.q(
        "SELECT finding_id FROM finding_rootcauses WHERE rootcause_id=? "
        "ORDER BY finding_id", rootcause_id)]


def groups_for(db: DB, finding_id: int) -> list[int]:
    db.conn.executescript(MEMBERSHIP_SCHEMA)
    return [r["rootcause_id"] for r in db.q(
        "SELECT rootcause_id FROM finding_rootcauses WHERE finding_id=?",
        finding_id)]


def report_text(db: DB) -> str:
    ensure(db)
    rows = db.q("SELECT * FROM rootcauses ORDER BY "
                "CASE severity WHEN 'critical' THEN 0 WHEN 'high' THEN 1 "
                "ELSE 2 END, id")
    if not rows:
        return "No root causes identified."
    out = []
    for r in rows:
        members = json.loads(r["member_ids"] or "[]")
        out.append(f"## {r['title']}  [{(r['severity'] or '').upper()}]\n")
        out.append(f"{r['hypothesis']}\n")
        out.append(f"\n**Manifestations ({len(members)}):**\n")
        for m in members:
            f = db.one("SELECT route, title FROM findings WHERE id=?", m)
            if f:
                out.append(f"- finding {m}: `{f['route']}`")
        out.append("\n> Submit this as **one** report with the manifestations "
                   "listed, not as separate reports. One root cause, one fix.\n")
    return "\n".join(out)
