"""
The engagement runtime: one safety boundary, shared by everything.

Why this exists
---------------

Before this module, every engine did:

    with Client(scope) as client:
        ...

and `Client.__init__` did:

    self.budget = budget or Budget(scope.max_rps, scope.max_requests)

so each of the nineteen engines minted its *own* budget. A scope file
saying

    max_requests: 20000
    max_rps: 3

therefore authorised 20,000 requests **per engine**, and a fresh rate
limiter per engine. The `Budget` docstring said "Global request budget",
which is how it survived review: the name asserted the property, the code
did not implement it.

For a bug bounty program this is not a tidiness problem. A published rate
limit is a term of the authorisation. Exceeding it because the tool counted
per engine is a breach of the thing the scope file exists to honour, and
"my scanner had a bug" is not a defence anyone accepts.

Design
------

One `Engagement` per process, bound once by the CLI::

    runtime.bind(scope, db, audit)

It owns:

    scope            the authority
    budget           ONE request budget + rate limiter, engagement-wide
    concurrency      one semaphore, engagement-wide
    audit            one log
    vault            one credential store
    db               one database

`net.Client` asks this module for the budget whenever it is not handed one,
so an engine that does the obvious thing gets the shared boundary
automatically. That property matters more than passing a parameter around:
the guarantee has to hold for code nobody reviewed.

The counter is persisted on every take. A contractual ceiling that resets
when the process restarts is not a ceiling -- an operator who runs
`thor loop` four times has sent four budgets' worth, and nothing said so.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

from .scope import Scope

SCHEMA = """
CREATE TABLE IF NOT EXISTS budget_state (
  engagement   TEXT PRIMARY KEY,
  used         INTEGER NOT NULL DEFAULT 0,
  max_requests INTEGER,
  started_at   TEXT,
  updated_at   TEXT
);
"""


def utcnow() -> datetime:
    """Timezone-aware UTC. datetime.utcnow() is deprecated and naive."""
    return datetime.now(timezone.utc)


def utcstamp() -> str:
    return utcnow().isoformat()


@dataclass
class Engagement:
    scope: Scope
    db: object = None
    audit: object = None
    vault: object = None
    budget: object = None                       # net.Budget
    _sem: Optional[threading.Semaphore] = None
    _lock: threading.Lock = field(default_factory=threading.Lock)

    @property
    def name(self) -> str:
        return self.scope.engagement or "default"

    @property
    def concurrency(self) -> threading.Semaphore:
        if self._sem is None:
            n = max(1, int(getattr(self.scope, "max_concurrency", 4) or 4))
            self._sem = threading.Semaphore(n)
        return self._sem


_CURRENT: Engagement | None = None
_BIND_LOCK = threading.Lock()


def bind(scope: Scope, db=None, audit=None, vault=None,
         reset_budget: bool = False) -> Engagement:
    """
    Establish the process-wide engagement. Called once, by the CLI.

    Re-binding with a different scope replaces the runtime; re-binding with
    the same engagement name keeps the existing budget so a second command
    in the same engagement continues counting rather than starting over.
    """
    global _CURRENT
    from . import net                       # late: net imports this module

    with _BIND_LOCK:
        name = scope.engagement or "default"
        keep = (_CURRENT is not None and _CURRENT.name == name
                and not reset_budget)
        budget = _CURRENT.budget if keep else None
        eng = Engagement(scope=scope, db=db, audit=audit, vault=vault)
        if budget is None:
            budget = net.Budget(scope.max_rps, scope.max_requests,
                                engagement=name, db=db,
                                concurrency=eng.concurrency)
        else:
            budget.db = db or budget.db
        eng.budget = budget
        _CURRENT = eng
        return eng


def current() -> Engagement | None:
    return _CURRENT


def reset() -> None:
    """Drop the bound engagement. For tests."""
    global _CURRENT
    with _BIND_LOCK:
        _CURRENT = None


def budget_for(scope: Scope):
    """
    The budget a Client should use when it was not handed one.

    If an engagement is bound and its name matches, the shared budget is
    returned -- this is what makes the ceiling engagement-wide without every
    engine having to remember to ask. If nothing is bound (unit tests
    constructing a Client directly), a private budget is created, because
    silently sharing across unrelated tests would be worse.
    """
    from . import net

    eng = _CURRENT
    if eng is not None and eng.name == (scope.engagement or "default"):
        return eng.budget
    return net.Budget(scope.max_rps, scope.max_requests,
                      engagement=scope.engagement or "default")


def concurrency_for(scope: Scope) -> threading.Semaphore | None:
    eng = _CURRENT
    if eng is not None and eng.name == (scope.engagement or "default"):
        return eng.concurrency
    return None


def status() -> dict:
    eng = _CURRENT
    if eng is None:
        return {"bound": False}
    b = eng.budget
    return {
        "bound": True,
        "engagement": eng.name,
        "requests_used": getattr(b, "used", 0),
        "requests_max": getattr(b, "max_requests", 0),
        "requests_left": max(0, getattr(b, "max_requests", 0)
                             - getattr(b, "used", 0)),
        "max_rps": getattr(b, "max_rps", 0),
        "max_concurrency": getattr(eng.scope, "max_concurrency", 4),
        "window": (f"{eng.scope.window_start}-{eng.scope.window_end} "
                   f"{eng.scope.window_timezone}")
                  if eng.scope.window_start else "any time",
    }
