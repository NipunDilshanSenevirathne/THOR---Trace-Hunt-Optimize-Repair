"""
Schema inference from observed traffic.

Grammar-aware fuzzing needs a grammar. Rather than requiring an OpenAPI spec
(most targets do not publish one), this infers the schema from the requests
and responses you actually captured: types, formats, enums, numeric ranges,
string lengths, optionality, and nullability.

The inferred schema is what makes mutation *semantic* rather than random --
you cannot mutate "one field at a time, keeping the rest valid" until you
know which fields exist and what shape they take.

Deterministic. No model calls.
"""

from __future__ import annotations

import json
import re
import statistics
from collections import Counter
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import parse_qsl, urlsplit

from .db import DB

# Recognised semantic formats. Knowing a field is an email (not just a string)
# is what lets the mutator produce a *plausible* invalid value instead of noise.
_FORMATS: list[tuple[str, re.Pattern]] = [
    ("email",     re.compile(r"^[^@\s]+@[^@\s]+\.[a-z]{2,}$", re.I)),
    ("uuid",      re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I)),
    ("objectid",  re.compile(r"^[0-9a-fA-F]{24}$")),
    ("iso_date",  re.compile(r"^\d{4}-\d{2}-\d{2}$")),
    ("iso_dt",    re.compile(r"^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}")),
    ("url",       re.compile(r"^https?://", re.I)),
    ("path",      re.compile(r"^(/[\w.\-]+)+/?$")),
    ("filename",  re.compile(r"^[\w\-. ]+\.[a-z0-9]{2,5}$", re.I)),
    ("jwt",       re.compile(r"^eyJ[\w\-]+\.eyJ[\w\-]+\.[\w\-]+$")),
    ("ipv4",      re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")),
    ("hex",       re.compile(r"^[0-9a-f]{6,}$", re.I)),
    ("b64",       re.compile(r"^[A-Za-z0-9+/]{16,}={0,2}$")),
    ("slug",      re.compile(r"^[a-z0-9]+(-[a-z0-9]+)+$")),
    ("currency",  re.compile(r"^-?\d+\.\d{2}$")),
    ("phone",     re.compile(r"^\+?[\d\s\-()]{7,20}$")),
    ("html",      re.compile(r"<[a-z]+[\s>]", re.I)),
]

# Field names whose semantics matter more than their type.
_ROLE_HINTS = [
    ("money",     re.compile(r"(?i)(price|amount|total|cost|fee|balance|credit|"
                             r"discount|subtotal|tax|refund|payout|quantity|qty)")),
    ("privilege", re.compile(r"(?i)(role|admin|is_?staff|permission|scope|acl|"
                             r"privilege|access_?level|tier|plan|superuser)")),
    ("identity",  re.compile(r"(?i)(user|owner|account|customer|member|tenant|"
                             r"org|workspace|team|company)_?(id|uuid|key)?$")),
    ("state",     re.compile(r"(?i)(status|state|stage|phase|approved|confirmed|"
                             r"verified|enabled|active|published|visibility)")),
    ("target",    re.compile(r"(?i)(url|uri|endpoint|callback|redirect|webhook|"
                             r"host|domain|link|src|href|dest|next|return)")),
    ("file",      re.compile(r"(?i)(file|path|filename|document|attachment|"
                             r"template|include|page|dir|folder)")),
    ("query",     re.compile(r"(?i)(q|query|search|filter|sort|order_?by|where|"
                             r"select|field|column|expr)")),
    ("limit",     re.compile(r"(?i)(limit|count|size|per_?page|offset|page|skip|take)")),
]


@dataclass
class FieldSchema:
    name: str                       # dotted path for JSON, plain name otherwise
    loc: str                        # query | body | header | path
    types: Counter = field(default_factory=Counter)
    formats: Counter = field(default_factory=Counter)
    examples: list[Any] = field(default_factory=list)
    numeric: list[float] = field(default_factory=list)
    lengths: list[int] = field(default_factory=list)
    seen: int = 0
    nullable: bool = False
    roles: set[str] = field(default_factory=set)

    @property
    def primary_type(self) -> str:
        return self.types.most_common(1)[0][0] if self.types else "string"

    @property
    def primary_format(self) -> str | None:
        return self.formats.most_common(1)[0][0] if self.formats else None

    @property
    def enum(self) -> list[Any] | None:
        """Few distinct values across many observations -> it is an enum."""
        vals = [e for e in self.examples if e is not None]
        distinct = {json.dumps(v, sort_keys=True) for v in vals}
        if self.seen >= 4 and 1 < len(distinct) <= 6:
            return [json.loads(v) for v in sorted(distinct)]
        return None

    @property
    def num_range(self) -> tuple[float, float] | None:
        if len(self.numeric) < 2:
            return None
        return (min(self.numeric), max(self.numeric))

    def to_dict(self) -> dict:
        return {
            "name": self.name, "loc": self.loc, "type": self.primary_type,
            "format": self.primary_format, "enum": self.enum,
            "range": self.num_range, "seen": self.seen,
            "nullable": self.nullable, "roles": sorted(self.roles),
            "example": self.examples[0] if self.examples else None,
            "median_len": int(statistics.median(self.lengths)) if self.lengths else None,
        }


@dataclass
class EndpointSchema:
    method: str
    route: str                      # normalised: /api/orders/{id}
    fields: dict[str, FieldSchema] = field(default_factory=dict)
    request_ids: list[int] = field(default_factory=list)
    resp_shapes: Counter = field(default_factory=Counter)
    resp_statuses: Counter = field(default_factory=Counter)
    content_type: str = "application/json"

    def key(self) -> str:
        return f"{self.method} {self.route}"

    def to_dict(self) -> dict:
        return {
            "method": self.method, "route": self.route,
            "content_type": self.content_type,
            "observations": len(self.request_ids),
            "statuses": dict(self.resp_statuses),
            "fields": [f.to_dict() for f in self.fields.values()],
        }


_ROUTE_ID = re.compile(
    r"/(\d{1,19}"
    r"|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
    r"|[0-9a-fA-F]{24}|[0-9a-fA-F]{32})(?=/|$)", re.I)


def normalise_route(url: str) -> str:
    p = urlsplit(url)
    return f"{p.scheme}://{p.netloc}{_ROUTE_ID.sub('/{id}', p.path or '/')}"


def _detect_format(v: str) -> str | None:
    for name, pat in _FORMATS:
        if pat.match(v):
            return name
    return None


def _detect_roles(name: str) -> set[str]:
    leaf = name.split(".")[-1].split("[")[0]
    return {role for role, pat in _ROLE_HINTS if pat.search(leaf)}


def _observe(schema: EndpointSchema, loc: str, name: str, value: Any) -> None:
    key = f"{loc}:{name}"
    fs = schema.fields.get(key)
    if fs is None:
        fs = FieldSchema(name=name, loc=loc)
        fs.roles = _detect_roles(name)
        schema.fields[key] = fs
    fs.seen += 1

    if value is None:
        fs.nullable = True
        fs.types["null"] += 1
        return
    if isinstance(value, bool):
        fs.types["boolean"] += 1
    elif isinstance(value, (int, float)):
        fs.types["number"] += 1
        fs.numeric.append(float(value))
    elif isinstance(value, list):
        fs.types["array"] += 1
        fs.lengths.append(len(value))
    elif isinstance(value, dict):
        fs.types["object"] += 1
    else:
        s = str(value)
        fs.types["string"] += 1
        fs.lengths.append(len(s))
        f = _detect_format(s)
        if f:
            fs.formats[f] += 1
        # numeric-looking strings still carry numeric semantics
        if re.fullmatch(r"-?\d+(\.\d+)?", s):
            try:
                fs.numeric.append(float(s))
            except ValueError:
                pass
    if len(fs.examples) < 12:
        fs.examples.append(value)


def _walk_json(schema: EndpointSchema, node: Any, path: str = "") -> None:
    if isinstance(node, dict):
        for k, v in node.items():
            p = f"{path}.{k}" if path else k
            if isinstance(v, (dict, list)):
                _observe(schema, "body", p, v)
                _walk_json(schema, v, p)
            else:
                _observe(schema, "body", p, v)
    elif isinstance(node, list):
        for v in node[:10]:
            _walk_json(schema, v, path + "[]")


def infer(db: DB, corpus: str, min_obs: int = 1) -> dict[str, EndpointSchema]:
    """Build a schema per (method, normalised route) from captured traffic."""
    schemas: dict[str, EndpointSchema] = {}
    rows = db.q("SELECT * FROM requests WHERE corpus=?", corpus)

    for r in rows:
        route = normalise_route(r["url"])
        key = f"{r['method']} {route}"
        s = schemas.get(key)
        if s is None:
            s = EndpointSchema(method=r["method"], route=route)
            schemas[key] = s
        s.request_ids.append(r["id"])
        s.resp_statuses[r["status"]] += 1

        headers = json.loads(r["headers"] or "{}")
        ct = (headers.get("Content-Type") or headers.get("content-type") or "")
        if ct:
            s.content_type = ct.split(";")[0]

        # path params
        p = urlsplit(r["url"])
        for m in _ROUTE_ID.finditer(p.path or ""):
            _observe(s, "path", f"seg{m.start()}", m.group(1))

        # query
        for k, v in parse_qsl(p.query, keep_blank_values=True):
            _observe(s, "query", k, v)

        # body
        body = r["body"] or ""
        if body.strip().startswith(("{", "[")):
            try:
                _walk_json(s, json.loads(body))
            except Exception:
                pass
        elif "=" in body:
            for k, v in parse_qsl(body, keep_blank_values=True):
                _observe(s, "body", k, v)

        # interesting request headers only
        for hk, hv in headers.items():
            if re.match(r"(?i)^x-|^(accept|content-type|origin|referer)$", hk):
                if hk.lower() not in ("x-csrf-token", "x-xsrf-token"):
                    _observe(s, "header", hk, hv)

        # response shape, for the differential oracle later
        if r["resp_body"]:
            s.resp_shapes[_shape_key(r["resp_body"])] += 1

    return {k: v for k, v in schemas.items() if len(v.request_ids) >= min_obs}


def _shape_key(body: str) -> str:
    try:
        d = json.loads(body)
    except Exception:
        return "nonjson"
    def sk(n, depth=0):
        if depth > 5:
            return "…"
        if isinstance(n, dict):
            return "{" + ",".join(sorted(n)) + "}"
        if isinstance(n, list):
            return "[" + (sk(n[0], depth + 1) if n else "") + "]"
        return type(n).__name__
    return sk(d)


def persist(db: DB, corpus: str, schemas: dict[str, EndpointSchema]) -> int:
    for key, s in schemas.items():
        db.note(key, "schema", json.dumps(s.to_dict()))
    return len(schemas)


def summary(schemas: dict[str, EndpointSchema]) -> str:
    lines = []
    for key, s in sorted(schemas.items()):
        interesting = [f for f in s.fields.values() if f.roles]
        lines.append(f"{key}  ({len(s.request_ids)} obs, {len(s.fields)} fields)")
        for f in interesting[:8]:
            e = f.enum
            extra = f" enum={e}" if e else (f" range={f.num_range}" if f.num_range else "")
            lines.append(f"    {f.loc}:{f.name}  {f.primary_type}"
                         f"{'/' + f.primary_format if f.primary_format else ''}"
                         f"  roles={sorted(f.roles)}{extra}")
    return "\n".join(lines)
