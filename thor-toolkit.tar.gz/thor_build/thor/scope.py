"""
Scope gate — the security boundary of the tool itself.

The earlier version checked the URL and then let httpx resolve the hostname
again at connect time. That is a time-of-check-to-time-of-use window: an
attacker controlling DNS (or a target with round-robin records) can have the
validated answer differ from the connected answer. The review flagged it and
it was a real bug.

This version resolves once, validates every returned address, and then
connects to the *validated address* while preserving Host and TLS SNI. The
destination identity established at check time is the destination identity
used at socket time.

Also handled, because each is a documented way past a naive allowlist:
  - IDNA / punycode and unicode homographs in the hostname
  - trailing dots, case, and userinfo (`https://allowed@evil/`)
  - IPv4-mapped IPv6, decimal/octal/hex IPv4 literals
  - redirects: revalidated in full before being followed
  - alternate ports
  - every A/AAAA record, not just the first
"""

from __future__ import annotations

import fnmatch
import ipaddress
import re
import socket
from dataclasses import dataclass, field
from datetime import datetime, time, timezone
from pathlib import Path
from urllib.parse import urlsplit

import yaml

try:
    from zoneinfo import ZoneInfo
except ImportError:                                   # pragma: no cover
    ZoneInfo = None


def _zone(name: str):
    """Resolve an IANA timezone, falling back to UTC rather than to local."""
    if not name or name.upper() == "UTC" or ZoneInfo is None:
        return timezone.utc
    try:
        return ZoneInfo(name)
    except Exception:
        # An unknown timezone must not silently become the laptop's local
        # time -- that would shift a contractual testing window.
        return timezone.utc


class ScopeViolation(Exception):
    """Raised when a request is refused. Never caught-and-continued."""


# Networks that must never be reachable, whatever the scope file says.
_HARD_DENY_NETS = [
    ipaddress.ip_network(n) for n in (
        "0.0.0.0/8", "127.0.0.0/8", "10.0.0.0/8", "172.16.0.0/12",
        "192.168.0.0/16", "169.254.0.0/16", "100.64.0.0/10",
        "192.0.0.0/24", "192.0.2.0/24", "198.18.0.0/15", "198.51.100.0/24",
        "203.0.113.0/24", "224.0.0.0/4", "240.0.0.0/4", "255.255.255.255/32",
        "::1/128", "::/128", "fc00::/7", "fe80::/10", "ff00::/8",
        "2001:db8::/32", "64:ff9b::/96",
    )
]

_HARD_DENY_HOSTS = {
    "metadata.google.internal", "metadata.goog", "instance-data",
    "metadata.azure.com", "169.254.169.254", "metadata",
}

_MAX_HOST_LEN = 253


def _norm_host(host: str) -> str:
    """
    Canonicalise a hostname the way the resolver will see it, so the allowlist
    compares the same string the socket will use.
    """
    h = (host or "").strip().strip(".").lower()
    if not h:
        return ""
    if "@" in h:                     # userinfo never belongs in a host
        h = h.rsplit("@", 1)[-1]
    if h.startswith("[") and h.endswith("]"):
        h = h[1:-1]
    try:
        h = h.encode("idna").decode("ascii")   # punycode / homograph folding
    except (UnicodeError, UnicodeDecodeError):
        pass
    return h[:_MAX_HOST_LEN]


def _as_ip(host: str):
    """Parse literal addresses, including the obfuscated forms."""
    try:
        return ipaddress.ip_address(host)
    except ValueError:
        pass
    # decimal / octal / hex IPv4 literals: 2130706433, 0177.0.0.1, 0x7f000001
    if re.fullmatch(r"\d{1,10}", host):
        try:
            return ipaddress.ip_address(int(host))
        except ValueError:
            return None
    if re.fullmatch(r"0x[0-9a-f]{1,8}", host):
        try:
            return ipaddress.ip_address(int(host, 16))
        except ValueError:
            return None
    if re.fullmatch(r"(0[0-7]{1,3}\.){3}0[0-7]{1,3}", host):
        try:
            parts = [int(p, 8) for p in host.split(".")]
            return ipaddress.ip_address(".".join(map(str, parts)))
        except ValueError:
            return None
    return None


def _is_denied_ip(ip) -> bool:
    if isinstance(ip, ipaddress.IPv6Address):
        if ip.ipv4_mapped is not None:
            ip = ip.ipv4_mapped
        elif getattr(ip, "sixtofour", None):
            ip = ip.sixtofour
    return any(ip in net for net in _HARD_DENY_NETS)


@dataclass
class Destination:
    """The validated identity of a connection: what was checked IS what connects."""
    scheme: str
    host: str           # canonical hostname, for Host header and TLS SNI
    port: int
    addresses: list[str] = field(default_factory=list)   # validated, pinned
    literal: bool = False

    def pinned(self) -> str:
        return self.addresses[0] if self.addresses else self.host

    def __str__(self) -> str:
        return (f"{self.scheme}://{self.host}:{self.port} "
                f"-> {','.join(self.addresses[:3]) or 'unresolved'}")


@dataclass
class Scope:
    engagement: str
    allowed_hosts: list[str] = field(default_factory=list)
    denied_hosts: list[str] = field(default_factory=list)
    allowed_methods: list[str] = field(default_factory=lambda: [
        "GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])
    allowed_ports: list[int] = field(default_factory=list)   # empty = any
    denied_path_patterns: list[str] = field(default_factory=list)
    max_rps: float = 3.0
    max_requests: int = 20000
    # Engagement-wide, not per engine. Enforced by one shared Budget; see
    # thor/runtime.py. A program's published rate limit is a contractual
    # ceiling, so exceeding it by running several engines is a real breach
    # and not merely impolite.
    max_concurrency: int = 4
    window_start: str | None = None
    window_end: str | None = None
    # IANA timezone the window is expressed in. Unset means UTC -- a window
    # without a timezone is ambiguous, and "22:00-05:00" means different
    # hours to the operator and the server.
    window_timezone: str = "UTC"
    sensitive: bool = False
    destructive: bool = False
    allow_private_targets: bool = False
    notes: str = ""

    # ---------------------------------------------------------- loading

    @classmethod
    def load(cls, path: str | Path) -> "Scope":
        path = Path(path)
        if not path.exists():
            raise ScopeViolation(
                f"No scope file at {path}. Refusing to run without an "
                f"explicit scope.")
        try:
            raw = yaml.safe_load(path.read_text()) or {}
        except yaml.YAMLError as e:
            # This is the one file the whole tool's safety rests on. A
            # traceback here buries the only useful line -- which row of
            # scope.yaml is wrong -- under a stack trace.
            where = ""
            mark = getattr(e, "problem_mark", None)
            if mark is not None:
                where = f" at line {mark.line + 1}, column {mark.column + 1}"
            raise ScopeViolation(
                f"{path} is not valid YAML{where}: "
                f"{getattr(e, 'problem', None) or e}. "
                f"Refusing to run — fix the scope file first.") from None
        if not isinstance(raw, dict):
            raise ScopeViolation(
                f"{path} must be a YAML mapping of settings, not "
                f"{type(raw).__name__}. Refusing.")
        if not raw.get("allowed_hosts"):
            raise ScopeViolation("scope.yaml has no allowed_hosts. Refusing.")
        known = set(cls.__dataclass_fields__)
        unknown = set(raw) - known
        if unknown:
            raise ScopeViolation(f"Unknown scope keys: {sorted(unknown)}")
        return cls(**raw)

    # ----------------------------------------------------------- checks

    def host_allowed(self, host: str) -> bool:
        h = _norm_host(host)
        if not h or h in _HARD_DENY_HOSTS:
            return False
        for pat in self.denied_hosts:
            if fnmatch.fnmatch(h, _norm_host(pat) or pat.lower()):
                return False
        return any(fnmatch.fnmatch(h, _norm_host(pat) or pat.lower())
                   for pat in self.allowed_hosts)

    def port_allowed(self, port: int) -> bool:
        return not self.allowed_ports or port in self.allowed_ports

    def in_window(self, now: datetime | None = None) -> bool:
        """
        Is the current time inside the permitted testing window?

        The window is evaluated in `window_timezone` (default UTC), not in
        whatever the laptop happens to be set to. A program that permits
        testing 22:00-05:00 means its own hours; a researcher travelling, or
        a server in another region, must not silently shift the window.
        """
        if not (self.window_start and self.window_end):
            return True
        tz = _zone(self.window_timezone)
        if now is None:
            now = datetime.now(tz)
        elif now.tzinfo is None:
            now = now.replace(tzinfo=tz)
        else:
            now = now.astimezone(tz)
        start = time.fromisoformat(self.window_start)
        end = time.fromisoformat(self.window_end)
        cur = now.time()
        if start <= end:
            return start <= cur <= end
        return cur >= start or cur <= end

    def resolve(self, host: str, port: int) -> list[str]:
        """
        Resolve once and validate EVERY answer. A hostname whose record set
        mixes a public and a private address is refused outright -- that
        pattern is the signature of a rebinding attempt.
        """
        h = _norm_host(host)
        lit = _as_ip(h)
        if lit is not None:
            if _is_denied_ip(lit) and not self.allow_private_targets:
                raise ScopeViolation(
                    f"{host!r} is a literal address in reserved space")
            return [str(lit)]

        try:
            infos = socket.getaddrinfo(h, port, proto=socket.IPPROTO_TCP)
        except OSError as e:
            raise ScopeViolation(f"cannot resolve {host!r}: {e}")

        addrs: list[str] = []
        for info in infos:
            a = info[4][0]
            try:
                ip = ipaddress.ip_address(a)
            except ValueError:
                continue
            if _is_denied_ip(ip) and not self.allow_private_targets:
                raise ScopeViolation(
                    f"{host!r} resolves to {a}, which is in reserved address "
                    f"space. Refusing the whole record set -- a mixed public/"
                    f"private answer is how DNS rebinding presents.")
            if a not in addrs:
                addrs.append(a)
        if not addrs:
            raise ScopeViolation(f"{host!r} produced no usable address")
        return addrs

    def check(self, method: str, url: str) -> Destination:
        """
        Validate and return the pinned destination. The caller MUST connect to
        the returned Destination rather than re-resolving the URL.
        """
        parts = urlsplit(url)
        if parts.scheme not in ("http", "https"):
            raise ScopeViolation(f"Refused scheme {parts.scheme!r}: {url}")

        raw_host = parts.hostname or ""
        if "@" in (parts.netloc or ""):
            # userinfo in a URL is a classic allowlist bypass; the real host
            # is after the '@', which urlsplit already gives us -- but we
            # refuse it rather than silently accepting the confusing form.
            raise ScopeViolation(
                f"URL contains userinfo, which is ambiguous to parsers: {url}")

        host = _norm_host(raw_host)
        if not host:
            raise ScopeViolation(f"no host in URL: {url}")
        if not self.host_allowed(host):
            raise ScopeViolation(
                f"Host {host!r} is not in scope ({self.engagement})")

        port = parts.port or (443 if parts.scheme == "https" else 80)
        if not self.port_allowed(port):
            raise ScopeViolation(
                f"port {port} not in allowed_ports {self.allowed_ports}")

        if method.upper() not in {m.upper() for m in self.allowed_methods}:
            raise ScopeViolation(f"Method {method} not permitted by scope")

        for pat in self.denied_path_patterns:
            if re.search(pat, parts.path or "/"):
                raise ScopeViolation(
                    f"Path {parts.path} matches denied pattern {pat!r}")

        if not self.in_window():
            raise ScopeViolation(
                f"Outside testing window {self.window_start}-{self.window_end}")

        addrs = self.resolve(host, port)
        return Destination(scheme=parts.scheme, host=host, port=port,
                           addresses=addrs, literal=_as_ip(host) is not None)

    def check_redirect(self, from_url: str, location: str,
                       method: str = "GET") -> Destination:
        """
        A redirect is a new request to a new destination and gets the full
        check. Never follow a Location header without this.
        """
        from urllib.parse import urljoin
        target = urljoin(from_url, location)
        return self.check(method, target)

    def is_destructive_allowed(self) -> bool:
        return self.destructive

    def summary(self) -> str:
        return (f"engagement={self.engagement} hosts={self.allowed_hosts} "
                f"deny={self.denied_hosts} ports={self.allowed_ports or 'any'} "
                f"rps={self.max_rps} budget={self.max_requests} "
                f"sensitive={self.sensitive} destructive={self.destructive}")
