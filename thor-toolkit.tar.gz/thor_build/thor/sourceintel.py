"""
Source ↔ runtime correlation.

The review called this the biggest available upgrade in evidence quality, and
it is right. The difference between

    "this endpoint looks suspicious"

and

    "the runtime-controlled object id reaches db.get_user() on line 214 with
     no tenant argument, and the route is registered without the
     requireTenant middleware that its siblings have"

is the difference between a report that gets triaged and one that gets paid.

This is deliberately *not* a general SAST engine. It does three things that a
general SAST cannot, because they need the runtime side:

  1. extract the route table and its authorisation decorations
  2. match those routes against endpoints observed in the corpus
  3. flag the disagreements -- a route with no auth decoration whose siblings
     all have one, a route reachable at runtime that source says is guarded,
     an object lookup with no tenant/owner argument

Supported: Express/NestJS, Flask/FastAPI/Django, Rails, Spring, Laravel, Go
chi/gin/echo. Regex-based by design: an AST per language is a project in
itself, and route tables are one of the few things regex reads reliably.
"""

from __future__ import annotations

import json
import re
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlsplit

from . import graph
from .db import DB

SCHEMA = """
CREATE TABLE IF NOT EXISTS source_routes (
  id INTEGER PRIMARY KEY,
  framework TEXT,
  method TEXT,
  path TEXT,
  handler TEXT,
  file TEXT,
  line INTEGER,
  guards TEXT,          -- json list of auth decorations found
  sinks TEXT,           -- json list of {kind, line, snippet, scoped}
  UNIQUE(method, path, file, line)
);
CREATE TABLE IF NOT EXISTS correlations (
  id INTEGER PRIMARY KEY,
  route_id INTEGER REFERENCES source_routes(id),
  endpoint TEXT,
  kind TEXT,            -- unguarded | unscoped_sink | guard_mismatch | orphan
  severity TEXT,
  detail TEXT,
  UNIQUE(route_id, endpoint, kind)
);
"""


def ensure(db: DB) -> None:
    db.conn.executescript(SCHEMA)
    db.conn.commit()


# --------------------------------------------------------------- patterns

ROUTE_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("express", re.compile(
        r"""(?:app|router|r)\s*\.\s*(get|post|put|patch|delete|all)\s*\(\s*
            ['"`]([^'"`]+)['"`]\s*,?\s*(.*)""", re.I | re.X)),
    ("nestjs", re.compile(
        r"""@(Get|Post|Put|Patch|Delete)\s*\(\s*['"`]?([^'"`)]*)['"`]?\s*\)""",
        re.I)),
    ("flask", re.compile(
        r"""@\w+\.route\s*\(\s*['"]([^'"]+)['"]\s*(?:,\s*methods\s*=\s*\[([^\]]*)\])?""",
        re.I)),
    ("fastapi", re.compile(
        r"""@\w+\.(get|post|put|patch|delete)\s*\(\s*['"]([^'"]+)['"]""", re.I)),
    ("django", re.compile(
        r"""path\s*\(\s*['"]([^'"]*)['"]\s*,\s*([\w.]+)""", re.I)),
    ("rails", re.compile(
        r"""^\s*(get|post|put|patch|delete)\s+['"]([^'"]+)['"]""",
        re.I | re.M)),
    ("spring", re.compile(
        r"""@(Get|Post|Put|Patch|Delete|Request)Mapping\s*\(\s*(?:value\s*=\s*)?['"]([^'"]*)['"]""",
        re.I)),
    ("laravel", re.compile(
        r"""Route::(get|post|put|patch|delete|any)\s*\(\s*['"]([^'"]+)['"]""",
        re.I)),
    ("go", re.compile(
        r"""\.(Get|Post|Put|Patch|Delete|HandleFunc)\s*\(\s*["`]([^"`]+)["`]""",
        re.I)),
]

# Authorisation decorations. Presence is the signal; absence next to siblings
# that have it is the finding.
GUARD_PATTERNS = [
    ("auth_middleware", re.compile(
        r"(?i)\b(requireAuth|isAuthenticated|ensureAuth|authenticate|"
        r"authGuard|AuthGuard|jwtAuth|passport\.authenticate|verifyToken|"
        r"login_required|IsAuthenticated|authenticate_user!|"
        r"@PreAuthorize|@Secured|@RolesAllowed|auth:api|middleware\(['\"]auth)")),
    ("tenant_guard", re.compile(
        r"(?i)\b(requireTenant|tenantGuard|scopeToTenant|withTenant|"
        r"current_tenant|tenant_required|TenantScoped|forTenant|"
        r"belongs_to_tenant|@TenantScope)")),
    ("owner_guard", re.compile(
        r"(?i)\b(requireOwner|ownerOnly|isOwner|authorize_owner|"
        r"can\?|authorize!|@PostAuthorize|checkOwnership|assertOwner|"
        r"current_user\.owns)")),
    ("role_guard", re.compile(
        r"(?i)\b(requireRole|hasRole|isAdmin|adminOnly|admin_required|"
        r"@RolesAllowed|permission_required|authorize\(['\"])")),
    ("rate_limit", re.compile(r"(?i)\b(rateLimit|throttle|limiter)")),
]

# Object-retrieval sinks. The question is whether a scoping argument is present.
SINK_PATTERNS = [
    ("db_find_by_id", re.compile(
        r"""(?i)\b(?:\w+)\.(findById|findByPk|find_by_id|get_by_id|findOne|
            find_one|getById|first|get|query|findUnique)\s*\(([^)]{0,200})\)""",
        re.X)),
    ("orm_filter", re.compile(
        r"""(?i)\b\w+\.(objects\.get|objects\.filter|where|find_by)\s*\(([^)]{0,200})\)""")),
    ("raw_sql", re.compile(
        r"""(?i)\b(execute|raw|query)\s*\(\s*[f"'`].{0,160}(SELECT|UPDATE|DELETE)""")),
]

SCOPE_ARG = re.compile(
    r"(?i)\b(tenant|org|organisation|organization|workspace|account|company|"
    r"owner|user_?id|current_user|userId|customer)\b")

SRC_EXT = {".js", ".jsx", ".ts", ".tsx", ".mjs", ".py", ".rb", ".java",
           ".kt", ".php", ".go", ".cs"}

SKIP_DIRS = {"node_modules", ".git", "dist", "build", "vendor", "__pycache__",
             ".venv", "venv", "target", "coverage", ".next", "migrations"}


@dataclass
class Route:
    framework: str
    method: str
    path: str
    handler: str
    file: str
    line: int
    guards: list[str] = field(default_factory=list)
    sinks: list[dict] = field(default_factory=list)


def _context(lines: list[str], idx: int, before: int = 6,
             after: int = 40) -> str:
    """Handler body: the route line and what follows, for sink detection."""
    return "\n".join(lines[idx: idx + after])


def _guard_context(lines: list[str], idx: int) -> str:
    """
    Guards belong to the route line itself (Express-style middleware
    arguments) or to decorator lines immediately above it (Python, Java, C#).

    Looking further back is a real bug: a route inherits the guards of the
    route declared before it, and an unguarded route is silently reported as
    guarded. Only contiguous decorator/annotation lines count.
    """
    parts = [lines[idx]]
    j = idx - 1
    while j >= 0 and idx - j <= 6:
        ln = lines[j].strip()
        if not ln or ln.startswith(("//", "#", "*", "/*")):
            j -= 1
            continue
        if ln.startswith("@") or ln.endswith(("\\", ",")):
            parts.append(ln)
            j -= 1
            continue
        break
    # the route statement may wrap across lines before the handler body
    k = idx + 1
    while k < len(lines) and k - idx <= 2 and "=>" not in lines[idx] \
            and "{" not in lines[idx]:
        parts.append(lines[k])
        k += 1
    return "\n".join(parts)


def scan(root: str | Path, log=print) -> list[Route]:
    """Extract the route table and its authorisation decorations."""
    root = Path(root)
    if not root.exists():
        raise SystemExit(f"no such source tree: {root}")
    routes: list[Route] = []
    files = 0

    for p in root.rglob("*"):
        if p.is_dir() or p.suffix.lower() not in SRC_EXT:
            continue
        if any(part in SKIP_DIRS for part in p.parts):
            continue
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if len(text) > 4_000_000:
            continue
        files += 1
        lines = text.splitlines()

        for fw, pat in ROUTE_PATTERNS:
            for m in pat.finditer(text):
                groups = [g for g in m.groups() if g is not None]
                if fw in ("flask", "django"):
                    path, method = groups[0], "GET"
                    if fw == "flask" and len(groups) > 1 and groups[1]:
                        method = re.findall(r"['\"](\w+)['\"]",
                                            groups[1])[:1] or ["GET"]
                        method = method[0].upper()
                else:
                    method = groups[0].upper()
                    path = groups[1] if len(groups) > 1 else "/"
                if method in ("ALL", "ANY", "REQUEST", "HANDLEFUNC"):
                    method = "GET"
                idx = text[:m.start()].count("\n")
                ctx = _context(lines, idx)
                gctx = _guard_context(lines, idx)

                guards = [name for name, gp in GUARD_PATTERNS if gp.search(gctx)]
                sinks = []
                for kind, sp in SINK_PATTERNS:
                    for sm in sp.finditer(ctx):
                        args = sm.group(2) if sm.lastindex and sm.lastindex >= 2 \
                            else sm.group(0)
                        sinks.append({
                            "kind": kind,
                            "snippet": sm.group(0)[:160].replace("\n", " "),
                            "scoped": bool(SCOPE_ARG.search(args or "")),
                        })

                routes.append(Route(
                    framework=fw, method=method, path=path or "/",
                    handler=(groups[2][:80] if len(groups) > 2 else ""),
                    file=str(p.relative_to(root)), line=idx + 1,
                    guards=guards, sinks=sinks))

    log(f"[source] {files} files scanned, {len(routes)} routes extracted")
    return routes


def persist(db: DB, routes: list[Route], log=print) -> int:
    ensure(db)
    n = 0
    for r in routes:
        try:
            db.ex("INSERT OR IGNORE INTO source_routes (framework, method, "
                  "path, handler, file, line, guards, sinks) "
                  "VALUES (?,?,?,?,?,?,?,?)",
                  r.framework, r.method, r.path, r.handler, r.file, r.line,
                  json.dumps(r.guards), json.dumps(r.sinks))
            n += 1
        except Exception:
            pass
    log(f"[source] {n} routes stored")
    return n


# ------------------------------------------------------------- correlation

def _normalise_source_path(p: str) -> str:
    p = "/" + p.strip("/")
    p = re.sub(r":([A-Za-z_]\w*)", "{id}", p)          # express/rails :id
    p = re.sub(r"\{[^}]*\}", "{id}", p)                # {id}, {slug}
    p = re.sub(r"<[^>]*>", "{id}", p)                  # flask <int:id>
    p = re.sub(r"\(\?P<[^>]*>[^)]*\)", "{id}", p)      # django regex
    p = re.sub(r"\*+", "", p)
    return p.rstrip("/") or "/"


def _normalise_runtime_path(url: str) -> str:
    path = urlsplit(url).path or "/"
    path = re.sub(
        r"/(\d{1,19}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-"
        r"[0-9a-f]{12}|[0-9a-fA-F]{24})(?=/|$)", "/{id}", path, flags=re.I)
    return path.rstrip("/") or "/"


def correlate(db: DB, corpus: str, log=print) -> dict:
    """
    Match source routes to observed endpoints and report the disagreements.

    The strongest signal is a *sibling comparison*: when nine routes under a
    prefix carry a tenant guard and the tenth does not, that tenth route is
    almost certainly an oversight rather than a design decision.
    """
    ensure(db)
    graph.ensure(db)
    routes = [dict(r) for r in db.q("SELECT * FROM source_routes")]
    if not routes:
        log("[source] no routes stored — run `thor source scan <path>` first")
        return {"routes": 0}

    observed = {}
    for r in db.q("SELECT DISTINCT method, url FROM requests WHERE corpus=?",
                  corpus):
        observed[(r["method"].upper(), _normalise_runtime_path(r["url"]))] = r["url"]

    out = {"routes": len(routes), "matched": 0, "unguarded": 0,
           "unscoped_sink": 0, "guard_mismatch": 0, "orphan": 0}

    # sibling guard census, by path prefix
    by_prefix: dict[str, list[dict]] = defaultdict(list)
    for r in routes:
        segs = [s for s in _normalise_source_path(r["path"]).split("/") if s]
        by_prefix["/" + "/".join(segs[:2])].append(r)

    for r in routes:
        spath = _normalise_source_path(r["path"])
        key = (r["method"].upper(), spath)
        runtime = observed.get(key)
        guards = json.loads(r["guards"] or "[]")
        sinks = json.loads(r["sinks"] or "[]")

        if runtime:
            out["matched"] += 1
            # link source to the graph endpoint
            eid = graph.node(db, "Endpoint", f"{r['method']} {runtime}")
            sid = graph.node(db, "Source", f"{r['file']}:{r['line']}",
                             f"{r['file']}:{r['line']}",
                             {"framework": r["framework"], "guards": guards,
                              "handler": r["handler"]})
            graph.edge(db, eid, "implemented_by", sid)

        # --- 1. reachable at runtime with no authorisation decoration ------
        if runtime and not guards:
            segs = [s for s in spath.split("/") if s]
            prefix = "/" + "/".join(segs[:2])
            siblings = by_prefix.get(prefix, [])
            guarded_siblings = [s for s in siblings
                                if json.loads(s["guards"] or "[]")]
            if len(siblings) >= 3 and len(guarded_siblings) >= len(siblings) * 0.6:
                out["unguarded"] += 1
                _store(db, r["id"], runtime, "unguarded", "high", {
                    "reason": (
                        f"{len(guarded_siblings)} of {len(siblings)} routes "
                        f"under {prefix} carry an authorisation decoration; "
                        f"this one carries none, and it is reachable at "
                        f"runtime"),
                    "sibling_guards": sorted({g for s in guarded_siblings
                                              for g in json.loads(s["guards"])}),
                    "file": f"{r['file']}:{r['line']}"})
                log(f"[source] UNGUARDED {r['method']} {spath} "
                    f"({r['file']}:{r['line']}) — "
                    f"{len(guarded_siblings)}/{len(siblings)} siblings guarded")

        # --- 2. object lookup with no scoping argument ---------------------
        unscoped = [s for s in sinks if not s["scoped"]]
        if runtime and unscoped and "tenant_guard" not in guards \
                and "owner_guard" not in guards:
            out["unscoped_sink"] += 1
            _store(db, r["id"], runtime, "unscoped_sink", "high", {
                "reason": (
                    "the handler retrieves an object by client-supplied "
                    "identifier with no tenant or owner argument, and the "
                    "route carries no ownership guard"),
                "sinks": unscoped[:4],
                "file": f"{r['file']}:{r['line']}"})
            log(f"[source] UNSCOPED SINK {r['method']} {spath} "
                f"({r['file']}:{r['line']}): {unscoped[0]['snippet'][:70]}")

        # --- 3. source says guarded, runtime says reachable ----------------
        if runtime and guards:
            row = db.one(
                "SELECT status FROM requests WHERE url=? AND method=? "
                "AND headers NOT LIKE '%Authorization%' "
                "AND headers NOT LIKE '%Cookie%' LIMIT 1",
                runtime, r["method"].upper())
            if row and row["status"] in (200, 201, 206):
                out["guard_mismatch"] += 1
                _store(db, r["id"], runtime, "guard_mismatch", "critical", {
                    "reason": (
                        f"source declares guards {guards} on this route, but "
                        f"an unauthenticated request returned "
                        f"{row['status']}. The declared control is not in the "
                        f"effective request path."),
                    "guards": guards, "file": f"{r['file']}:{r['line']}"})
                log(f"[source] GUARD MISMATCH {r['method']} {spath}: "
                    f"declares {guards}, anon got {row['status']}")

        # --- 4. in source, never exercised ---------------------------------
        if not runtime and r["method"].upper() in ("GET", "POST"):
            out["orphan"] += 1
            _store(db, r["id"], f"{r['method']} {spath}", "orphan", "info", {
                "reason": "route exists in source but was never observed in "
                          "captured traffic — unexercised attack surface",
                "file": f"{r['file']}:{r['line']}"})

    db.conn.commit()
    log(f"[source] {json.dumps(out)}")
    return out


def _store(db: DB, route_id: int, endpoint: str, kind: str, severity: str,
           detail: dict) -> None:
    db.conn.execute(
        "INSERT OR IGNORE INTO correlations (route_id, endpoint, kind, "
        "severity, detail) VALUES (?,?,?,?,?)",
        (route_id, endpoint, kind, severity, json.dumps(detail)))


def promote(db: DB, log=print) -> int:
    """
    Turn correlations into experiments the normal pipeline can promote.

    A source finding is a *hypothesis with strong prior*, not a finding: it
    says where to look, and the runtime engines still have to prove it. Only
    guard_mismatch is promoted directly, because that one already has runtime
    evidence attached.
    """
    ensure(db)
    n = 0
    for c in db.q("SELECT * FROM correlations WHERE kind='guard_mismatch'"):
        d = json.loads(c["detail"] or "{}")
        sig = f"source:{c['id']}"
        if db.seen_signature(sig):
            continue
        db.ex("INSERT INTO experiments (signature, kind, as_identity, method, "
              "url, status, verdict, score, detail) VALUES (?,?,?,?,?,?,?,?,?)",
              sig, "authz", "anon", "GET", c["endpoint"], 200, "leak", 0.85,
              json.dumps({"reasons": [d.get("reason", "")],
                          "oracle": "source_runtime_correlation",
                          "source": d.get("file"), "shared_values": [],
                          "pii": [], "detail": d}))
        n += 1
    log(f"[source] {n} correlation(s) promoted to experiments")
    return n


def report(db: DB) -> str:
    ensure(db)
    rows = db.q("SELECT c.*, s.method, s.path, s.file, s.line FROM correlations c "
                "JOIN source_routes s ON s.id = c.route_id "
                "ORDER BY CASE c.severity WHEN 'critical' THEN 0 "
                "WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END")
    if not rows:
        return "No source correlations. Run `thor source scan <path>` then "\
               "`thor source correlate --corpus <name>`."
    out, kind = [], None
    for r in rows:
        if r["kind"] != kind:
            kind = r["kind"]
            out.append(f"\n{kind.upper().replace('_', ' ')}")
            out.append("─" * 60)
        d = json.loads(r["detail"] or "{}")
        out.append(f"  [{r['severity']:8}] {r['method']} {r['path']}")
        out.append(f"      {r['file']}:{r['line']}")
        out.append(f"      {d.get('reason', '')}")
        for s in (d.get("sinks") or [])[:2]:
            out.append(f"      sink: {s['snippet'][:90]}")
    out.append("")
    out.append("Source findings are hypotheses with a strong prior, not "
               "findings. The runtime engines still have to prove them — "
               "except guard_mismatch, which already carries runtime evidence.")
    return "\n".join(out)
