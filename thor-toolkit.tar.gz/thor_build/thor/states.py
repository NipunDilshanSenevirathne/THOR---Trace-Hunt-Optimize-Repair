"""
Finding state machine.

The review found a real gap: promotion started from `WHERE verdict='leak' AND
score >= x`, so a leak experiment with no executed disproof still produced a
finding. And separately, `ai.apply_answer` could write `status` directly, so a
model's JSON could move a finding to confirmed or rejected. Both contradict
the architecture's central claim.

This module makes the lifecycle explicit and gated:

    OBSERVED → HYPOTHESIS → CANDIDATE → VERIFICATION_REQUIRED
             → VERIFIED → DEDUPED → REPORT_READY → SUBMITTED
                                  ↘ REJECTED / DUPLICATE / BLOCKED

Each transition has a **gate**: a deterministic predicate over the database.
A finding cannot enter VERIFIED unless the gates for VERIFIED return true --
there is no argument, no confidence score and no model opinion involved.

`advance()` is the only writer of `findings.status`. `ai.py` calls
`annotate()`, which writes narrative fields and refuses authoritative ones.
A SQLite trigger enforces the same rule at the storage layer, so a future
code path that forgets cannot violate it either.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Callable

from .db import DB

# ---------------------------------------------------------------- states

OBSERVED = "observed"
HYPOTHESIS = "hypothesis"
CANDIDATE = "candidate"
VERIFICATION_REQUIRED = "verification_required"
VERIFIED = "verified"
DEDUPED = "deduped"
REPORT_READY = "report_ready"
SUBMITTED = "submitted"
REJECTED = "rejected"
DUPLICATE = "duplicate"
BLOCKED = "blocked"

ORDER = [OBSERVED, HYPOTHESIS, CANDIDATE, VERIFICATION_REQUIRED, VERIFIED,
         DEDUPED, REPORT_READY, SUBMITTED]

TERMINAL = {REJECTED, DUPLICATE, BLOCKED, SUBMITTED}

# Fields only the state machine and deterministic engines may write.
AUTHORITATIVE_FIELDS = {
    "status", "severity", "disproof_done", "evidence_ids", "fingerprint",
    "vuln_class", "route", "asset",
}

# Fields the AI layer is allowed to write.
NARRATIVE_FIELDS = {
    "impact", "title", "summary", "remediation", "attack_narrative",
    "cvss_vector", "triager_notes",
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS finding_transitions (
  id INTEGER PRIMARY KEY,
  finding_id INTEGER,
  from_state TEXT,
  to_state TEXT,
  actor TEXT,            -- always a deterministic component, never 'ai'
  gates TEXT,            -- json: which gates passed
  reason TEXT,
  at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_ft_finding ON finding_transitions(finding_id);

-- Per-finding gate outcomes. A gate result belongs to one finding and
-- names the evidence it was decided on, so "why is this report-ready" has
-- a recorded answer months later, and so no finding can pass a gate
-- because some unrelated finding satisfied it.
CREATE TABLE IF NOT EXISTS finding_gate_results (
  finding_id      INTEGER NOT NULL,
  gate            TEXT NOT NULL,
  passed          INTEGER NOT NULL,
  detail          TEXT,
  evidence_ids    TEXT,
  checker_version TEXT,
  checked_at      TEXT DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (finding_id, gate)
);

-- Duplicate determination, per finding. Previously the dedupe gate passed
-- as soon as the rootcauses table existed, i.e. for every finding at once.
CREATE TABLE IF NOT EXISTS finding_dedupe (
  finding_id INTEGER PRIMARY KEY,
  verdict    TEXT,      -- unique | grouped | likely_duplicate | uncertain
  group_id   INTEGER,   -- rootcause id when grouped
  basis      TEXT,
  checked_at TEXT DEFAULT CURRENT_TIMESTAMP
);
"""

# Bumped when a gate's meaning changes, so old PASS records are not
# mistaken for evidence under the new rule.
CHECKER_VERSION = "5.1"

# The storage-layer backstop. If any future code path writes status through a
# connection tagged as the AI actor, the write is rejected by SQLite itself.
GUARD_TRIGGER = """
CREATE TABLE IF NOT EXISTS _actor (who TEXT);

CREATE TRIGGER IF NOT EXISTS findings_authoritative_guard
BEFORE UPDATE OF status, severity, disproof_done, evidence_ids, fingerprint,
                 vuln_class ON findings
WHEN (SELECT who FROM _actor LIMIT 1) = 'ai'
BEGIN
  SELECT RAISE(ABORT,
    'the AI layer may not write authoritative finding fields');
END;
"""


def ensure(db: DB) -> None:
    db.conn.executescript(SCHEMA)
    db.conn.executescript(GUARD_TRIGGER)
    db.conn.commit()


class ActorContext:
    """
    Marks the current writer. `with as_ai(db):` makes the guard trigger fire
    on any authoritative write, so the protection does not depend on ai.py
    remembering to behave.
    """

    def __init__(self, db: DB, who: str):
        self.db, self.who = db, who

    def __enter__(self):
        ensure(self.db)
        self.db.conn.execute("DELETE FROM _actor")
        self.db.conn.execute("INSERT INTO _actor (who) VALUES (?)", (self.who,))
        self.db.conn.commit()
        return self

    def __exit__(self, *a):
        self.db.conn.execute("DELETE FROM _actor")
        self.db.conn.commit()
        return False


def as_ai(db: DB) -> ActorContext:
    return ActorContext(db, "ai")


# ----------------------------------------------------------------- gates

@dataclass
class Gate:
    name: str
    describe: str
    check: Callable[[DB, dict], bool]
    explain_failure: str


def _has_evidence(db: DB, f: dict) -> bool:
    try:
        ids = json.loads(f.get("evidence_ids") or "[]")
    except Exception:
        return False
    if not ids:
        return False
    rows = db.q(f"SELECT id FROM experiments WHERE id IN "
                f"({','.join('?' * len(ids))})", *ids)
    return len(rows) == len(ids)


def _oracle_fired(db: DB, f: dict) -> bool:
    ids = json.loads(f.get("evidence_ids") or "[]")
    if not ids:
        return False
    rows = db.q(f"SELECT verdict, score FROM experiments WHERE id IN "
                f"({','.join('?' * len(ids))})", *ids)
    return any(r["verdict"] == "leak" and (r["score"] or 0) >= 0.55
               for r in rows)


def _control_executed(db: DB, f: dict) -> bool:
    """
    A control must have been RUN, not assumed. For cross-identity classes that
    is the anonymous disproof; for mutation classes it is the inert control or
    a proving oracle (OAST, computed, boolean, timing).
    """
    if f.get("disproof_done"):
        return True
    ids = json.loads(f.get("evidence_ids") or "[]")
    if not ids:
        return False
    rows = db.q(f"SELECT detail FROM experiments WHERE id IN "
                f"({','.join('?' * len(ids))})", *ids)
    for r in rows:
        try:
            d = json.loads(r["detail"] or "{}")
        except Exception:
            continue
        if d.get("oracle") in ("oast", "computed", "boolean", "timing"):
            return True
        for reason in d.get("reasons", []):
            if ("disproof passed" in reason or "inert control" in reason
                    or "only under mutation" in reason):
                return True
    return False


def _scope_proven(db: DB, f: dict) -> bool:
    """
    Every piece of evidence must have been produced through the scope gate.

    This used to be `SELECT 1 FROM experiments WHERE url LIKE '%asset%'`,
    which was wrong in both directions: an asset of `example.com` matched
    `notexample.com.evil.net`, and a finding whose asset string did not
    happen to appear in a URL was blocked even though every one of its
    experiments had gone through the gate. Seven of ten genuine findings
    were stuck behind it.

    The fact is recorded instead of inferred. An experiment row can only
    exist after `Client.send()` passed `Scope.check()`, and `dest_address`
    holds the address the gate validated and pinned. Its presence is the
    proof, for these specific experiments, not for some other finding's.
    """
    ids = json.loads(f.get("evidence_ids") or "[]")
    if not ids:
        return False
    rows = db.q(f"SELECT id, dest_address FROM experiments "
                f"WHERE id IN ({','.join('?' * len(ids))})", *ids)
    if len(rows) != len(ids):
        return False
    return all((_col(r, "dest_address") or "") for r in rows)


def _replayable(db: DB, f: dict) -> bool:
    """
    The evidence must be enough to rebuild a bundle that reproduces the
    observation: a method, a URL, a status, and a response hash to compare
    against. Without the hash there is nothing for a triager's replay to
    match, and 'it returned 200' is not a reproduction.
    """
    ids = json.loads(f.get("evidence_ids") or "[]")
    if not ids:
        return False
    rows = db.q(f"SELECT method, url, status, resp_sha256 FROM experiments "
                f"WHERE id IN ({','.join('?' * len(ids))})", *ids)
    if len(rows) != len(ids):
        return False
    return all(r["method"] and r["url"] and r["status"] is not None
               and (r["resp_sha256"] or "") for r in rows)


def _dedupe_checked(db: DB, f: dict) -> bool:
    """
    THIS finding must have been considered for duplication.

    The old version returned True if the `rootcauses` table merely existed
    — so every finding passed the moment `thor rootcause` had run once, for
    any reason, about some other finding. A gate that a finding satisfies
    because a different finding satisfied it is not a gate.

    A finding is checked when root-cause analysis has reached a conclusion
    about it: either it belongs to a group, or analysis ran and placed it
    in none.
    """
    fid = f.get("id")
    if not fid:
        return False
    try:
        row = db.one("SELECT verdict FROM finding_dedupe WHERE finding_id=?",
                     fid)
    except Exception:
        return False
    return bool(row and row["verdict"])


def _col(row, name):
    try:
        return row[name]
    except (IndexError, KeyError):
        return None


AUTO_IMPACT_MARK = "[auto]"


def _has_impact(db: DB, f: dict) -> bool:
    """
    REPORT_READY needs an impact section written for a triager, not the
    auto-generated summary that promote() attaches. The auto text is marked
    so this gate can tell them apart -- otherwise every finding would reach
    REPORT_READY with boilerplate, which is exactly the kind of report that
    gets closed as noise.
    """
    imp = (f.get("impact") or "").strip()
    if not imp or imp in ("See evidence.", "_See evidence._"):
        return False
    if imp.startswith(AUTO_IMPACT_MARK):
        return False
    # AI-written impact arrives as a JSON object with a narrative
    if imp.startswith("{"):
        try:
            d = json.loads(imp)
            return bool((d.get("attack_narrative") or "").strip())
        except Exception:
            return False
    return len(imp) > 40


GATES: dict[str, list[Gate]] = {
    CANDIDATE: [
        Gate("evidence_exists", "every evidence id resolves to an experiment",
             _has_evidence, "no experiment backs this finding"),
        Gate("oracle_fired", "a deterministic oracle returned leak >= 0.55",
             _oracle_fired, "no oracle fired above threshold"),
    ],
    VERIFICATION_REQUIRED: [
        Gate("scope_proven", "every experiment went through the scope gate",
             _scope_proven,
             "an experiment has no recorded validated destination — either "
             "it predates destination recording (re-run the engine) or it "
             "was not produced by the scope-gated client"),
    ],
    VERIFIED: [
        Gate("control_executed",
             "a control was EXECUTED: anonymous disproof, inert control, or a "
             "proving oracle",
             _control_executed,
             "no control was run — the finding could be public data, or "
             "ordinary input-dependent behaviour"),
        Gate("replayable", "every experiment carries method, url and status",
             _replayable, "evidence is incomplete for replay"),
    ],
    DEDUPED: [
        Gate("dedupe_checked", "root-cause grouping has run",
             _dedupe_checked, "run `thor rootcause` first"),
    ],
    REPORT_READY: [
        Gate("has_impact", "an impact statement exists",
             _has_impact, "no impact written — run /impact"),
    ],
}


# ------------------------------------------------------------- transitions

@dataclass
class Result:
    finding_id: int
    from_state: str
    to_state: str
    moved: bool
    passed: list[str] = field(default_factory=list)
    blocked_by: list[str] = field(default_factory=list)

    def render(self) -> str:
        if self.moved:
            return (f"finding {self.finding_id}: {self.from_state} → "
                    f"{self.to_state}  ({', '.join(self.passed) or 'no gates'})")
        return (f"finding {self.finding_id}: held at {self.from_state} — "
                f"{'; '.join(self.blocked_by)}")


def evaluate(db: DB, finding_id: int, target: str) -> Result:
    """Check the gates for `target` without moving anything."""
    ensure(db)
    f = db.one("SELECT * FROM findings WHERE id=?", finding_id)
    if not f:
        raise SystemExit(f"no finding {finding_id}")
    f = dict(f)
    ev = f.get("evidence_ids") or "[]"
    passed, blocked = [], []
    for g in GATES.get(target, []):
        ok = bool(g.check(db, f))
        if ok:
            passed.append(g.name)
        else:
            blocked.append(f"{g.name}: {g.explain_failure}")
        # Record the outcome against THIS finding. Six months later,
        # "why did this reach report_ready" has an answer that names the
        # gate, the evidence it read and the version of the rule.
        try:
            db.ex("INSERT INTO finding_gate_results (finding_id, gate, "
                  "passed, detail, evidence_ids, checker_version, checked_at) "
                  "VALUES (?,?,?,?,?,?,CURRENT_TIMESTAMP) "
                  "ON CONFLICT(finding_id, gate) DO UPDATE SET "
                  "passed=excluded.passed, detail=excluded.detail, "
                  "evidence_ids=excluded.evidence_ids, "
                  "checker_version=excluded.checker_version, "
                  "checked_at=CURRENT_TIMESTAMP",
                  finding_id, g.name, 1 if ok else 0,
                  "" if ok else g.explain_failure, ev, CHECKER_VERSION)
        except Exception:
            pass
    return Result(finding_id, f.get("status") or CANDIDATE, target,
                  not blocked, passed, blocked)


def gate_results(db: DB, finding_id: int) -> list[dict]:
    ensure(db)
    return [dict(r) for r in db.q(
        "SELECT gate, passed, detail, checker_version, checked_at "
        "FROM finding_gate_results WHERE finding_id=? ORDER BY rowid",
        finding_id)]


def record_dedupe(db: DB, finding_id: int, verdict: str,
                  group_id: int | None = None, basis: str = "") -> None:
    """
    Record that THIS finding was considered for duplication.

    verdict: unique | grouped | likely_duplicate | uncertain
    """
    ensure(db)
    db.ex("INSERT INTO finding_dedupe (finding_id, verdict, group_id, basis, "
          "checked_at) VALUES (?,?,?,?,CURRENT_TIMESTAMP) "
          "ON CONFLICT(finding_id) DO UPDATE SET verdict=excluded.verdict, "
          "group_id=excluded.group_id, basis=excluded.basis, "
          "checked_at=CURRENT_TIMESTAMP",
          finding_id, verdict, group_id, basis)


def advance(db: DB, finding_id: int, actor: str = "state_machine",
            log=print) -> Result:
    """
    Move a finding as far along the chain as its gates permit.

    This is the ONLY function that writes findings.status. It refuses to run
    under the AI actor.
    """
    ensure(db)
    if actor == "ai":
        raise PermissionError(
            "the AI layer may not advance a finding's state")

    f = db.one("SELECT * FROM findings WHERE id=?", finding_id)
    if not f:
        raise SystemExit(f"no finding {finding_id}")
    cur = f["status"] or CANDIDATE
    if cur in TERMINAL:
        return Result(finding_id, cur, cur, False, [], ["terminal state"])
    if cur not in ORDER:
        cur = CANDIDATE

    last = Result(finding_id, cur, cur, False)
    idx = ORDER.index(cur)
    while idx + 1 < len(ORDER):
        nxt = ORDER[idx + 1]
        if nxt == SUBMITTED:
            break                      # only a human submits
        r = evaluate(db, finding_id, nxt)
        if not r.moved:
            last = Result(finding_id, cur, nxt, False, r.passed, r.blocked_by)
            break
        db.ex("UPDATE findings SET status=? WHERE id=?", nxt, finding_id)
        db.ex("INSERT INTO finding_transitions (finding_id, from_state, "
              "to_state, actor, gates, reason) VALUES (?,?,?,?,?,?)",
              finding_id, cur, nxt, actor, json.dumps(r.passed),
              "all gates passed")
        log(f"[state] finding {finding_id}: {cur} → {nxt} "
            f"({', '.join(r.passed)})")
        cur = nxt
        idx += 1
        last = Result(finding_id, ORDER[idx - 1], cur, True, r.passed)
    return last


def advance_all(db: DB, log=print) -> dict:
    ensure(db)
    out = {"moved": 0, "held": 0, "by_state": {}, "blocked_by": {}}
    for row in db.q("SELECT id FROM findings"):
        r = advance(db, row["id"], log=lambda *a: None)
        if r.moved:
            out["moved"] += 1
        else:
            out["held"] += 1
            # Naming the current state tells the operator nothing actionable
            # -- "held at deduped" sounds like dedupe is the problem when the
            # gate that actually refused is the next one. Name the gate.
            for b in r.blocked_by:
                gate = b.split(":", 1)[0].strip()
                out["blocked_by"][gate] = out["blocked_by"].get(gate, 0) + 1
    for row in db.q("SELECT status, COUNT(*) c FROM findings GROUP BY status"):
        out["by_state"][row["status"]] = row["c"]
    log(f"[state] {out['moved']} advanced, {out['held']} held "
        f"{json.dumps(out['by_state'])}")
    if out["blocked_by"]:
        for gate, n in sorted(out["blocked_by"].items(), key=lambda x: -x[1]):
            log(f"[state]   {n} blocked by {gate}")
    return out


def reject(db: DB, finding_id: int, reason: str,
           actor: str = "operator") -> None:
    if actor == "ai":
        raise PermissionError("the AI layer may not reject a finding")
    ensure(db)
    cur = (db.one("SELECT status FROM findings WHERE id=?", finding_id)
           or {"status": CANDIDATE})["status"]
    db.ex("UPDATE findings SET status=? WHERE id=?", REJECTED, finding_id)
    db.ex("INSERT INTO finding_transitions (finding_id, from_state, to_state, "
          "actor, gates, reason) VALUES (?,?,?,?,?,?)",
          finding_id, cur, REJECTED, actor, "[]", reason)


def annotate(db: DB, finding_id: int, fields: dict, log=print) -> list[str]:
    """
    The AI layer's only write path. Narrative fields are applied;
    authoritative fields are dropped and reported.
    """
    ensure(db)
    applied, refused, ignored = [], [], []
    for k, v in fields.items():
        if k in AUTHORITATIVE_FIELDS:
            # The AI tried to set a verdict field. Worth saying loudly.
            refused.append(k)
            continue
        if k not in NARRATIVE_FIELDS:
            # Not a column at all -- extra narrative keys the brief asked
            # for (worst_case, scale_evidence) live inside the impact JSON
            # and are rendered from there. Reporting these as "refused"
            # alongside a genuine attempt on `status` buries the signal
            # that matters in a list of things that are perfectly fine.
            ignored.append(k)
            continue
        applied.append((k, v))
    if applied:
        with as_ai(db):
            sets = ", ".join(f"{k}=?" for k, _ in applied)
            db.conn.execute(f"UPDATE findings SET {sets} WHERE id=?",
                            [v for _, v in applied] + [finding_id])
            db.conn.commit()
    if refused:
        log(f"[state] REFUSED AI writes to {sorted(set(refused))} on finding "
            f"{finding_id} — these decide whether the finding is true, and "
            f"only code that observed bytes may set them")
    return refused


def report(db: DB) -> str:
    ensure(db)
    rows = db.q("SELECT status, COUNT(*) c FROM findings GROUP BY status")
    if not rows:
        return "No findings."
    out = ["finding lifecycle", "─" * 56]
    counts = {r["status"]: r["c"] for r in rows}
    for s in ORDER + [REJECTED, DUPLICATE, BLOCKED]:
        if s in counts:
            bar = "█" * min(30, counts[s])
            out.append(f"  {s:22} {counts[s]:3}  {bar}")
    held = db.q("SELECT id, status, title FROM findings WHERE status IN "
                "(?,?,?)", CANDIDATE, VERIFICATION_REQUIRED, VERIFIED)
    if held:
        out += ["", "held short of REPORT_READY:"]
        for h in held:
            r = evaluate(db, h["id"],
                         ORDER[min(ORDER.index(h["status"]) + 1,
                                   len(ORDER) - 1)]
                         if h["status"] in ORDER else VERIFIED)
            out.append(f"  [{h['id']:3}] {h['status']:22} {h['title'][:44]}")
            for b in r.blocked_by:
                out.append(f"        ✗ {b}")
    out += ["", "Only deterministic code moves a finding between states. "
                "The AI layer writes narrative fields and nothing else; a "
                "SQLite trigger enforces this independently of ai.py."]
    return "\n".join(out)
