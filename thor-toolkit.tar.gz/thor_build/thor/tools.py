"""
Wrappers for external recon binaries.

Every wrapper: checks the tool exists, streams output, never crashes the
pipeline if a tool is missing. Amass is deliberately absent -- too slow for
iterative hunting; alterx + dnsx brute-force covers the same ground faster.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Iterable, Iterator

TOOLS = {
    "subfinder": "go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest",
    "dnsx":      "go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest",
    "httpx":     "go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest",
    "katana":    "go install -v github.com/projectdiscovery/katana/cmd/katana@latest",
    "nuclei":    "go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest",
    "naabu":     "go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest",
    "alterx":    "go install -v github.com/projectdiscovery/alterx/cmd/alterx@latest",
    "tlsx":      "go install -v github.com/projectdiscovery/tlsx/cmd/tlsx@latest",
    "gau":       "go install -v github.com/lc/gau/v2/cmd/gau@latest",
    "uro":       "pipx install uro",
    "arjun":     "pipx install arjun",
    "interactsh-client":
        "go install -v github.com/projectdiscovery/interactsh/cmd/interactsh-client@latest",
}


def have(tool: str) -> bool:
    return shutil.which(tool) is not None


def doctor() -> dict[str, bool]:
    return {t: have(t) for t in TOOLS}


def run(cmd: list[str], stdin_lines: Iterable[str] | None = None,
        timeout: int = 1800) -> Iterator[str]:
    """Run a tool, yield stdout lines. Missing tool -> yields nothing."""
    if not have(cmd[0]):
        return
    inp = "\n".join(stdin_lines) + "\n" if stdin_lines is not None else None
    try:
        p = subprocess.run(
            cmd, input=inp, capture_output=True, text=True, timeout=timeout
        )
    except subprocess.TimeoutExpired:
        return
    for line in p.stdout.splitlines():
        line = line.strip()
        if line:
            yield line


def _jsonl(lines: Iterable[str]) -> Iterator[dict]:
    for ln in lines:
        try:
            yield json.loads(ln)
        except json.JSONDecodeError:
            continue


# ---------------- individual tools ----------------

def subfinder(domain: str) -> list[str]:
    return list(run(["subfinder", "-d", domain, "-all", "-silent", "-recursive"]))


def alterx(subs: list[str], limit: int = 30000) -> list[str]:
    out = list(run(["alterx", "-silent"], stdin_lines=subs))
    return out[:limit]


def dnsx(hosts: list[str]) -> list[dict]:
    """Resolve. Returns {host, a[], cname}."""
    rows = []
    for d in _jsonl(run(["dnsx", "-silent", "-json", "-a", "-cname", "-resp"],
                        stdin_lines=hosts)):
        rows.append({
            "host": d.get("host"),
            "a": d.get("a") or [],
            "cname": (d.get("cname") or [None])[0] if d.get("cname") else None,
        })
    return rows


def httpx(hosts: list[str]) -> list[dict]:
    """Probe. Returns rich per-host facts used by the anomaly scorer."""
    cmd = [
        "httpx", "-silent", "-json", "-td", "-title", "-server", "-status-code",
        "-content-length", "-ip", "-cname", "-follow-redirects", "-no-color",
        "-rate-limit", "50",
    ]
    rows = []
    for d in _jsonl(run(cmd, stdin_lines=hosts)):
        rows.append({
            "url": d.get("url"),
            "host": d.get("input") or d.get("host"),
            "status": d.get("status_code") or d.get("status-code"),
            "title": d.get("title"),
            "server": (d.get("webserver") or d.get("server")),
            "tech": d.get("tech") or d.get("technologies") or [],
            "content_length": d.get("content_length") or d.get("content-length"),
            "ip": (d.get("a") or [None])[0] if d.get("a") else d.get("host"),
            "cname": (d.get("cname") or [None])[0] if d.get("cname") else None,
            "scheme": d.get("scheme"),
            "port": d.get("port"),
        })
    return rows


def katana(urls: list[str], depth: int = 3, js: bool = True) -> list[str]:
    cmd = ["katana", "-silent", "-d", str(depth), "-kf", "all", "-rl", "40"]
    if js:
        cmd += ["-jc", "-jsl"]
    return list(run(cmd, stdin_lines=urls))


def gau(domain: str) -> list[str]:
    return list(run(["gau", "--subs", "--threads", "5", domain]))


def uro(urls: list[str]) -> list[str]:
    out = list(run(["uro"], stdin_lines=urls))
    return out or urls


def naabu(hosts: list[str], top: int = 1000) -> list[dict]:
    rows = []
    for d in _jsonl(run(["naabu", "-silent", "-json", "-top-ports", str(top),
                         "-rate", "500"], stdin_lines=hosts)):
        rows.append({"host": d.get("host") or d.get("ip"), "port": d.get("port")})
    return rows


def nuclei(urls: list[str], severity: str = "critical,high,medium",
           tags: str | None = None, rate: int = 30) -> list[dict]:
    cmd = ["nuclei", "-silent", "-jsonl", "-severity", severity,
           "-rl", str(rate), "-nc", "-duc"]
    if tags:
        cmd += ["-tags", tags]
    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False) as f:
        f.write("\n".join(urls))
        listfile = f.name
    cmd += ["-l", listfile]
    rows = []
    for d in _jsonl(run(cmd, timeout=3600)):
        info = d.get("info", {})
        rows.append({
            "template": d.get("template-id"),
            "name": info.get("name"),
            "severity": info.get("severity"),
            "matched": d.get("matched-at") or d.get("host"),
            "type": d.get("type"),
        })
    Path(listfile).unlink(missing_ok=True)
    return rows


def arjun(url: str, method: str = "GET") -> list[str]:
    with tempfile.NamedTemporaryFile("r", suffix=".json", delete=False) as f:
        out = f.name
    list(run(["arjun", "-u", url, "-m", method, "-oJ", out, "-q", "--stable"],
             timeout=300))
    try:
        data = json.loads(Path(out).read_text())
        params = []
        for v in data.values():
            if isinstance(v, dict):
                params += list(v.get("params", []) or [])
            elif isinstance(v, list):
                params += v
        return sorted(set(params))
    except Exception:
        return []
    finally:
        Path(out).unlink(missing_ok=True)
