"""
Credential vault.

The review was right: putting live bearer tokens and session cookies in
plaintext in the research database is fine for a prototype and not fine for
a tool that accumulates credentials for a dozen programs on a laptop.

Design:

    identities table  ──►  credential_ref (cred_xxxx)
                                 │
                                 ▼
                        vault file (Fernet, AES-128-CBC + HMAC)
                                 │
                        key from OS keyring, or a passphrase,
                        or THOR_VAULT_KEY

The research DB never contains authentication material. Evidence bundles and
reports never contain it either -- `redact()` is applied on the way out.

Falls back gracefully: if `cryptography` is unavailable the vault refuses to
store rather than silently writing plaintext.
"""

from __future__ import annotations

import base64
import getpass
import hashlib
import json
import os
import secrets
import stat
from dataclasses import dataclass
from pathlib import Path

try:
    from cryptography.fernet import Fernet, InvalidToken
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    HAVE_CRYPTO = True
except ImportError:      # pragma: no cover
    HAVE_CRYPTO = False
    Fernet = None
    InvalidToken = Exception

try:
    import keyring
    HAVE_KEYRING = True
except ImportError:
    HAVE_KEYRING = False

SERVICE = "thor-vault"
DEFAULT_PATH = Path(".thor") / "vault.enc"

# Header names whose values are authentication material.
SECRET_HEADERS = {
    "authorization", "cookie", "set-cookie", "x-api-key", "x-auth-token",
    "x-access-token", "x-session-token", "x-csrf-token", "x-xsrf-token",
    "proxy-authorization", "x-amz-security-token", "api-key", "apikey",
    "x-auth", "token", "auth", "x-token", "session",
}


class VaultLocked(Exception):
    pass


class VaultUnavailable(Exception):
    pass


def _derive(passphrase: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt,
                     iterations=390_000)
    return base64.urlsafe_b64encode(kdf.derive(passphrase.encode()))


@dataclass
class Vault:
    path: Path = DEFAULT_PATH
    _key: bytes | None = None
    _data: dict | None = None

    def __post_init__(self):
        # accept a plain string path; callers should not have to remember
        self.path = Path(self.path)

    # ------------------------------------------------------------ key

    def _load_key(self, passphrase: str | None = None,
                  create: bool = False) -> bytes:
        if self._key:
            return self._key
        if not HAVE_CRYPTO:
            raise VaultUnavailable(
                "python 'cryptography' is not installed. Install it "
                "(pip install cryptography) -- THOR will not write "
                "credentials in plaintext.")

        env = os.environ.get("THOR_VAULT_KEY")
        if env:
            k = env.encode()
            # Validate here rather than letting it fail inside Fernet: a
            # malformed key should say so, not produce a stack trace three
            # layers down.
            try:
                Fernet(k)
            except Exception:
                raise VaultUnavailable(
                    "THOR_VAULT_KEY is not a valid Fernet key (32 url-safe "
                    "base64 bytes). Generate one with:\n"
                    "  python -c \"from cryptography.fernet import Fernet; "
                    "print(Fernet.generate_key().decode())\"")
            self._key = k
            return self._key

        if HAVE_KEYRING and not passphrase:
            stored = None
            try:
                stored = keyring.get_password(SERVICE, "master")
            except Exception:
                stored = None
            if stored:
                self._key = stored.encode()
                return self._key
            if create:
                k = Fernet.generate_key()
                try:
                    keyring.set_password(SERVICE, "master", k.decode())
                    self._key = k
                    return self._key
                except Exception:
                    pass   # fall through to passphrase

        salt_file = self.path.with_suffix(".salt")
        if salt_file.exists():
            salt = salt_file.read_bytes()
        elif create:
            salt = secrets.token_bytes(16)
            salt_file.parent.mkdir(parents=True, exist_ok=True)
            salt_file.write_bytes(salt)
            os.chmod(salt_file, stat.S_IRUSR | stat.S_IWUSR)
        else:
            raise VaultLocked("no vault salt; nothing stored yet")

        pw = passphrase or os.environ.get("THOR_VAULT_PASSPHRASE")
        if not pw:
            pw = getpass.getpass("THOR vault passphrase: ")
        self._key = _derive(pw, salt)
        return self._key

    # ----------------------------------------------------------- io

    def _read(self, passphrase: str | None = None) -> dict:
        if self._data is not None:
            return self._data
        if not self.path.exists():
            self._data = {}
            return self._data
        key = self._load_key(passphrase)
        blob = self.path.read_bytes()
        try:
            self._data = json.loads(Fernet(key).decrypt(blob))
        except InvalidToken:
            raise VaultLocked("wrong passphrase, or the vault is corrupt")
        return self._data

    def _write(self, passphrase: str | None = None) -> None:
        key = self._load_key(passphrase, create=True)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        blob = Fernet(key).encrypt(json.dumps(self._data or {}).encode())
        tmp = self.path.with_suffix(".tmp")
        tmp.write_bytes(blob)
        os.chmod(tmp, stat.S_IRUSR | stat.S_IWUSR)
        tmp.replace(self.path)
        os.chmod(self.path, stat.S_IRUSR | stat.S_IWUSR)

    # -------------------------------------------------------- public

    def store(self, headers: dict, label: str = "",
              passphrase: str | None = None) -> str:
        """Store credential headers, return an opaque reference."""
        self._data = self._read(passphrase)
        ref = "cred_" + secrets.token_hex(8)
        self._data[ref] = {"headers": headers, "label": label}
        self._write(passphrase)
        return ref

    def fetch(self, ref: str, passphrase: str | None = None) -> dict:
        d = self._read(passphrase)
        entry = d.get(ref)
        if entry is None:
            raise KeyError(f"no credential {ref} in the vault")
        return dict(entry.get("headers") or {})

    def delete(self, ref: str, passphrase: str | None = None) -> bool:
        self._data = self._read(passphrase)
        gone = self._data.pop(ref, None) is not None
        if gone:
            self._write(passphrase)
        return gone

    def list_refs(self, passphrase: str | None = None) -> list[tuple[str, str]]:
        d = self._read(passphrase)
        return [(k, v.get("label", "")) for k, v in sorted(d.items())]

    # ------------------------------------------------- captured artifacts

    def store_artifact(self, obj, label: str = "",
                       passphrase: str | None = None) -> str:
        """
        Encrypt an arbitrary captured artifact (original headers, request
        body, response body) and return an opaque reference.

        Captured traffic is where credentials actually live. An identity's
        token was already vaulted; a HAR export of the same session puts the
        identical token in `requests.headers`, plus session cookies, plus
        whatever passwords were posted to the login endpoint. The research
        database must hold the sanitised form and a reference, never the
        original.
        """
        self._data = self._read(passphrase)
        ref = "art_" + secrets.token_hex(8)
        self._data[ref] = {"artifact": obj, "label": label}
        self._write(passphrase)
        return ref

    def fetch_artifact(self, ref: str, passphrase: str | None = None):
        d = self._read(passphrase)
        entry = d.get(ref)
        if entry is None:
            raise KeyError(f"no artifact {ref} in the vault")
        return entry.get("artifact")

    def rotate(self, passphrase: str | None = None) -> None:
        """Re-encrypt under a fresh key."""
        data = self._read(passphrase)
        self._key = None
        if HAVE_KEYRING:
            try:
                keyring.delete_password(SERVICE, "master")
            except Exception:
                pass
        self._data = data
        self._write(passphrase)


# --------------------------------------------------------------- helpers

_DEFAULT = Vault()


def default() -> Vault:
    return _DEFAULT


def split_credentials(headers: dict) -> tuple[dict, dict]:
    """Separate authentication material from ordinary headers."""
    secret, plain = {}, {}
    for k, v in (headers or {}).items():
        (secret if k.lower() in SECRET_HEADERS else plain)[k] = v
    return secret, plain


def fingerprint(value: str) -> str:
    return hashlib.sha256(str(value).encode()).hexdigest()[:12]


def redact(obj, _depth: int = 0):
    """
    Recursively replace credential values with a stable fingerprint.

    Applied on every path out of the system: evidence bundles, reports, AI
    briefs, audit log. The fingerprint is stable, so two records using the
    same token are still correlatable without the token being present.
    """
    if _depth > 12:
        return obj
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if isinstance(k, str) and k.lower() in SECRET_HEADERS:
                out[k] = f"<redacted:{fingerprint(v)}>"
            else:
                out[k] = redact(v, _depth + 1)
        return out
    if isinstance(obj, list):
        return [redact(v, _depth + 1) for v in obj]
    if isinstance(obj, str):
        return _redact_inline(obj)
    return obj


import re as _re

_INLINE_PATTERNS = [
    _re.compile(r"(?i)\b(bearer\s+)([A-Za-z0-9\-._~+/]{20,})"),
    _re.compile(r"\b(eyJ[A-Za-z0-9_\-]{8,}\.eyJ[A-Za-z0-9_\-]{8,}\.)([A-Za-z0-9_\-]{8,})"),
    _re.compile(r"(?i)\b((?:session|sid|phpsessid|jsessionid|auth|token)=)([^;\s\"']{8,})"),
    _re.compile(r"\b((?:AKIA|ASIA)[0-9A-Z]{16})\b"),
    _re.compile(r"\b(gh[pousr]_)([0-9A-Za-z]{20,})"),
    _re.compile(r"\b(sk_live_)([0-9a-zA-Z]{16,})"),
]


def _redact_inline(s: str) -> str:
    if len(s) > 200_000:
        return s
    for pat in _INLINE_PATTERNS:
        def sub(m):
            groups = m.groups()
            if len(groups) == 1:
                return f"<redacted:{fingerprint(m.group(0))}>"
            return f"{groups[0]}<redacted:{fingerprint(groups[1])}>"
        s = pat.sub(sub, s)
    return s


# Body field names whose *values* are authentication material. Matched on
# the key, case-insensitively, anywhere in a JSON body or form encoding.
SECRET_FIELDS = _re.compile(
    r"(?i)(^|[_\-.])(password|passwd|pwd|secret|token|api[_\-]?key|apikey|"
    r"auth|credential|private[_\-]?key|client[_\-]?secret|refresh[_\-]?token|"
    r"access[_\-]?token|id[_\-]?token|session|otp|mfa[_\-]?code|totp|"
    r"security[_\-]?answer|pin)($|[_\-.])")


def _secret_field(name: str) -> bool:
    n = (name or "").strip()
    return bool(SECRET_FIELDS.search(f"_{n}_"))


def sanitise_body(body: str) -> tuple[str, bool]:
    """
    Replace credential-shaped *values* in a request/response body.

    Returns (sanitised, had_secrets).

    The structure is preserved so schema inference, shape comparison and
    object-reference extraction all still work — only the values change,
    and they change to a stable fingerprint so two bodies carrying the same
    token still compare equal.

    A captured login request contains a real password. There is no reason
    for that to sit in a research database that gets copied between
    machines, attached to bug reports and kept for months.
    """
    if not body:
        return body or "", False
    found = False
    stripped = body.lstrip()
    if stripped[:1] in "{[":
        try:
            data = json.loads(body)
        except Exception:
            data = None
        if data is not None:
            def walk(o, depth=0):
                nonlocal found
                if depth > 12:
                    return o
                if isinstance(o, dict):
                    out = {}
                    for k, v in o.items():
                        if _secret_field(str(k)) and isinstance(
                                v, (str, int, float)):
                            found = True
                            out[k] = f"<vaulted:{fingerprint(str(v))}>"
                        else:
                            out[k] = walk(v, depth + 1)
                    return out
                if isinstance(o, list):
                    return [walk(v, depth + 1) for v in o]
                if isinstance(o, str):
                    s = _redact_inline(o)
                    if s != o:
                        found = True
                    return s
                return o
            out = json.dumps(walk(data))
            return out, found

    # form-encoded and everything else: inline patterns plus key=value
    def _kv(m):
        nonlocal found
        if _secret_field(m.group(1)):
            found = True
            return f"{m.group(1)}=<vaulted:{fingerprint(m.group(2))}>"
        return m.group(0)
    out = _re.sub(r"([A-Za-z0-9_\-.\[\]]{1,64})=([^&\s]{1,4096})", _kv, body)
    after = _redact_inline(out)
    if after != out:
        found = True
    return after, found


def sanitise_headers(headers: dict) -> tuple[dict, dict]:
    """
    Split captured headers into (safe_to_store, secret).

    Secret values are replaced with a stable fingerprint rather than
    dropped, so two requests carrying the same session remain correlatable
    in the database without the session being present in it.
    """
    secret, plain = split_credentials(headers or {})
    safe = dict(plain)
    for k, v in secret.items():
        safe[k] = f"<vaulted:{fingerprint(v)}>"
    return safe, secret


def scan_for_leaks(text: str) -> list[str]:
    """Return credential-shaped strings still present. Used by the safety tests."""
    found = []
    for pat in _INLINE_PATTERNS:
        for m in pat.finditer(text or ""):
            val = m.group(0)
            if "<redacted:" not in val:
                found.append(val[:40])
    return found
