"""
Workflow / business-logic engine.

Everything else in this toolkit tests one request. This tests *sequences*,
which is where the bugs that generic scanners structurally cannot find live:

  - skipping a step (pay -> ship, without the pay)
  - repeating a step that should be single-use (redeem a coupon twice)
  - running a step out of order (approve before submit)
  - reverting a terminal state (cancel a completed order)
  - acting on someone else's workflow instance

The state machine is inferred from captured traffic: sequences of requests
against the same object, and the state values the responses report. Then the
engine proposes transitions that were never observed, and tries them.

Risk: SENSITIVE. This drives real state changes. Gated in risk.py.
"""

from __future__ import annotations

import json
import re
from collections import defaultdict
from dataclasses import dataclass, field
from urllib.parse import urlsplit

from .db import DB
from .diff import normalise
from .net import Client, Request
from .oracles import OracleHit
from .scope import Scope, ScopeViolation

_STATE_KEY = re.compile(
    r"(?i)^(status|state|stage|phase|step|workflow_?state|order_?status|"
    r"payment_?status|approval_?state|lifecycle)$")

_TERMINAL = re.compile(
    r"(?i)^(completed|complete|approved|paid|shipped|delivered|published|"
    r"active|confirmed|settled|closed|fulfilled|succeeded|verified)$")

_INITIAL = re.compile(
    r"(?i)^(created|draft|new|pending|initiated|started|open|unpaid|"
    r"awaiting.*|requested)$")

# Actions whose repetition or reordering has financial or access consequences.
_SENSITIVE_ACTION = re.compile(
    r"(?i)/(checkout|pay|payment|purchase|order|refund|withdraw|transfer|"
    r"redeem|coupon|voucher|discount|apply|claim|approve|reject|confirm|"
    r"submit|publish|activate|deactivate|cancel|invite|grant|revoke|"
    r"upgrade|downgrade|subscribe|unsubscribe|verify|complete|finalize)")

_ID_IN_PATH = re.compile(
    r"/(\d{1,19}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
    r"|[0-9a-fA-F]{24})(?=/|$)", re.I)


@dataclass
class Step:
    request_id: int
    method: str
    url: str
    body: str
    headers: dict
    identity: str
    status: int
    state_before: str = ""
    state_after: str = ""
    action: str = ""
    object_id: str = ""

    def route(self) -> str:
        p = urlsplit(self.url)
        return f"{self.method} {_ID_IN_PATH.sub('/{id}', p.path or '/')}"


@dataclass
class Workflow:
    object_id: str
    steps: list[Step] = field(default_factory=list)
    states: list[str] = field(default_factory=list)

    def transitions(self) -> set[tuple[str, str, str]]:
        out = set()
        for s in self.steps:
            if s.state_before or s.state_after:
                out.add((s.state_before, s.action, s.state_after))
        return out


def _state_of(body: str) -> str:
    if not body or not body.strip().startswith(("{", "[")):
        return ""
    try:
        d = json.loads(body)
    except Exception:
        return ""

    found = []

    def walk(n, depth=0):
        if depth > 5:
            return
        if isinstance(n, dict):
            for k, v in n.items():
                if _STATE_KEY.match(k) and isinstance(v, str) and len(v) < 40:
                    found.append(v)
                walk(v, depth + 1)
        elif isinstance(n, list):
            for v in n[:10]:
                walk(v, depth + 1)

    walk(d)
    return found[0] if found else ""


def _object_of(url: str, body: str) -> str:
    m = _ID_IN_PATH.search(urlsplit(url).path or "")
    if m:
        return m.group(1)
    if body and body.strip().startswith("{"):
        try:
            d = json.loads(body)
            for k in ("id", "order_id", "orderId", "object_id", "resource_id"):
                if k in d:
                    return str(d[k])
        except Exception:
            pass
    return ""


def _action_of(url: str) -> str:
    p = urlsplit(url).path or ""
    m = _SENSITIVE_ACTION.search(p)
    if m:
        return m.group(1).lower()
    segs = [s for s in p.split("/") if s and not _ID_IN_PATH.match("/" + s)]
    return segs[-1].lower() if segs else "request"


def infer(db: DB, corpus: str, log=print) -> list[Workflow]:
    """Group captured traffic into per-object sequences and read the states."""
    rows = db.q("SELECT * FROM requests WHERE corpus=? ORDER BY id", corpus)
    by_object: dict[str, Workflow] = {}

    last_state: dict[str, str] = defaultdict(str)
    for r in rows:
        oid = _object_of(r["url"], r["body"] or "")
        if not oid:
            continue
        wf = by_object.setdefault(oid, Workflow(object_id=oid))
        after = _state_of(r["resp_body"] or "")
        step = Step(
            request_id=r["id"], method=r["method"], url=r["url"],
            body=r["body"] or "", headers=json.loads(r["headers"] or "{}"),
            identity=r["identity"] or "", status=r["status"],
            state_before=last_state[oid], state_after=after,
            action=_action_of(r["url"]), object_id=oid,
        )
        if after:
            last_state[oid] = after
            if after not in wf.states:
                wf.states.append(after)
        wf.steps.append(step)

    flows = [w for w in by_object.values() if len(w.steps) >= 2]
    log(f"[workflow] {len(flows)} object workflow(s), "
        f"{sum(len(w.states) for w in flows)} observed states")
    for w in flows[:8]:
        if w.states:
            log(f"[workflow]   object {w.object_id}: "
                f"{' -> '.join(w.states)}  ({len(w.steps)} steps)")
    return flows


@dataclass
class Probe:
    kind: str
    description: str
    invariant: str
    steps: list[Step]
    expect: str


def plan(flows: list[Workflow], log=print) -> list[Probe]:
    """
    Propose transitions the application never demonstrated. Each carries the
    invariant it would violate, so the oracle knows what to look for.
    """
    probes: list[Probe] = []

    for wf in flows:
        sensitive = [s for s in wf.steps
                     if _SENSITIVE_ACTION.search(urlsplit(s.url).path or "")
                     and s.method in ("POST", "PUT", "PATCH", "DELETE")
                     and s.status in (200, 201, 202, 204)]

        # --- repeat a single-use action ------------------------------------
        for s in sensitive:
            probes.append(Probe(
                kind="replay",
                description=f"repeat '{s.action}' on object {wf.object_id}",
                invariant=f"'{s.action}' should apply at most once per object",
                steps=[s],
                expect="second attempt should be rejected",
            ))

        # --- skip to a terminal state --------------------------------------
        terminal = [st for st in wf.states if _TERMINAL.match(st)]
        initial = [st for st in wf.states if _INITIAL.match(st)]
        if terminal and initial:
            for s in sensitive:
                if s.method in ("PUT", "PATCH") and s.body.strip().startswith("{"):
                    probes.append(Probe(
                        kind="state_jump",
                        description=(f"set state directly to '{terminal[-1]}' "
                                     f"on object {wf.object_id}"),
                        invariant=(f"the client should not be able to move an "
                                   f"object to '{terminal[-1]}' by asserting it"),
                        steps=[s],
                        expect="server should recompute state, not accept it",
                    ))
                    break

        # --- reverse a terminal state --------------------------------------
        if terminal:
            for s in wf.steps:
                if s.method == "DELETE" and s.status in (200, 204):
                    probes.append(Probe(
                        kind="terminal_revert",
                        description=(f"cancel/delete object {wf.object_id} "
                                     f"after it reached '{terminal[-1]}'"),
                        invariant=(f"an object in '{terminal[-1]}' should not "
                                   f"be cancellable"),
                        steps=[s],
                        expect="should be rejected once terminal",
                    ))
                    break

        # --- run steps out of order ----------------------------------------
        if len(sensitive) >= 2:
            a, b = sensitive[0], sensitive[-1]
            probes.append(Probe(
                kind="reorder",
                description=(f"perform '{b.action}' before '{a.action}' "
                             f"on object {wf.object_id}"),
                invariant=f"'{b.action}' should require '{a.action}' first",
                steps=[b],
                expect="should be rejected out of order",
            ))

    log(f"[workflow] {len(probes)} transition probe(s) planned")
    return probes


def run(db: DB, scope: Scope, corpus: str, log=print) -> dict:
    """
    Execute the planned probes. SENSITIVE risk: these change state. The risk
    gate in risk.py decides whether this runs at all.
    """
    flows = infer(db, corpus, log=log)
    probes = plan(flows, log=log)
    out = {"workflows": len(flows), "probes": len(probes), "violations": 0}
    if not probes:
        return out

    with Client(scope) as client:
        for p in probes:
            s = p.steps[0]
            headers = {k: v for k, v in s.headers.items()
                       if k.lower() != "content-length"}
            body = s.body

            if p.kind == "state_jump":
                terminal = next((st for wf in flows for st in wf.states
                                 if _TERMINAL.match(st)), "completed")
                try:
                    d = json.loads(body)
                    changed = False
                    for k in list(d):
                        if _STATE_KEY.match(k):
                            d[k] = terminal
                            changed = True
                    if not changed:
                        d["status"] = terminal
                    body = json.dumps(d)
                except Exception:
                    continue

            req = Request(s.method, s.url, headers,
                          body.encode() if body else None,
                          identity=f"workflow:{p.kind}")
            try:
                resp = client.send(req)
            except (ScopeViolation, Exception):
                continue

            probe_n = normalise(resp.status, resp.text,
                                resp.headers.get("content-type", ""))
            accepted = resp.status in (200, 201, 202, 204) and not probe_n.denied
            hit = None
            if accepted:
                out["violations"] += 1
                hit = OracleHit(
                    f"workflow:{p.kind}",
                    f"{p.description} succeeded ({resp.status}). "
                    f"Invariant not enforced: {p.invariant}. "
                    f"Expected: {p.expect}.",
                    0.70 if p.kind == "replay" else 0.75,
                    {"kind": p.kind, "invariant": p.invariant,
                     "object": s.object_id, "action": s.action,
                     "original_status": s.status})
                log(f"[workflow] VIOLATION {p.kind}: {p.description} "
                    f"-> {resp.status}")

            sig = req.signature()
            if not db.seen_signature(sig):
                db.ex(
                    "INSERT INTO experiments (signature, kind, base_request_id, "
                    "as_identity, method, url, body, status, resp_sha256, "
                    "resp_len, elapsed_ms, verdict, score, detail, dest_address) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    sig, "workflow", s.request_id, f"workflow:{p.kind}",
                    req.method, req.url, (body or "")[:8000], resp.status,
                    resp.sha256, len(resp.body), resp.elapsed_ms,
                    "leak" if hit else "inconclusive",
                    hit.confidence if hit else 0.0,
                    json.dumps({"reasons": [hit.signal] if hit else [],
                                "oracle": hit.oracle if hit else None,
                                "invariant": p.invariant,
                                "shared_values": [], "pii": [],
                                "detail": hit.detail if hit else {}}),
                    getattr(resp, "address", "") or "")

    log(f"[workflow] {json.dumps(out)}")
    return out
